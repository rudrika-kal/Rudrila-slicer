package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.rudrila.slicer.model.PathRole
import com.rudrila.slicer.model.Point2
import com.rudrila.slicer.model.Toolpath
import com.rudrila.slicer.model.ToolpathResult
import kotlin.math.max
import kotlin.math.min

/**
 * Mobile 2D toolpath preview.
 * Step 2.1 adds stable layer/model fit modes so tiny first-layer islands remain readable.
 */
class ToolpathPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private enum class FitMode { LAYER, MODEL }

    private val bgPaint = Paint().apply { color = Color.rgb(15, 18, 20) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(48, 55, 59)
        strokeWidth = 1f
        style = Paint.Style.STROKE
    }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(82, 92, 97)
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }
    private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ghostPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.argb(54, 180, 190, 194)
        strokeCap = Paint.Cap.ROUND
    }
    private val travelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.rgb(90, 150, 255)
        pathEffect = DashPathEffect(floatArrayOf(8f, 7f), 0f)
    }

    private var result: ToolpathResult? = null
    private var bedX = 256f
    private var bedY = 256f
    private val visibleRoles = PathRole.values().toMutableSet()

    var showTravel: Boolean = false
        set(value) { field = value; invalidate() }

    var showBelowLayers: Boolean = false
        set(value) { field = value; invalidate() }

    private var fitMode = FitMode.LAYER

    var layerIndex: Int = 0
        set(value) {
            val count = result?.layers?.size ?: 0
            field = if (count == 0) 0 else value.coerceIn(0, count - 1)
            if (count > 0 && fitMode == FitMode.LAYER) {
                applyLayerFitBounds(field)
                resetCameraInternal()
            } else {
                invalidate()
            }
        }

    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private var modelMinX = 0f
    private var modelMinY = 0f
    private var modelMaxX = bedX
    private var modelMaxY = bedY

    private var fitMinX = 0f
    private var fitMinY = 0f
    private var fitMaxX = bedX
    private var fitMaxY = bedY

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val oldZoom = zoom
            val nextZoom = (zoom * detector.scaleFactor).coerceIn(0.35f, 16f)
            if (nextZoom == oldZoom) return true

            // Keep the point under the fingers stable instead of zooming around the view centre.
            val ratio = nextZoom / oldZoom
            val fx = detector.focusX - width * 0.5f
            val fy = detector.focusY - height * 0.5f
            panX = fx - (fx - panX) * ratio
            panY = fy - (fy - panY) * ratio
            zoom = nextZoom
            invalidate()
            return true
        }
    })

    fun setBedSize(x: Float, y: Float) {
        bedX = x.coerceAtLeast(1f)
        bedY = y.coerceAtLeast(1f)
        if (result == null) {
            modelMinX = 0f; modelMinY = 0f; modelMaxX = bedX; modelMaxY = bedY
            applyModelFitBounds()
        }
        invalidate()
    }

    fun setResult(value: ToolpathResult) {
        result = value
        computeModelBounds(value)
        fitMode = FitMode.LAYER
        if (value.layers.isNotEmpty()) {
            layerIndex = layerIndex.coerceIn(0, value.layers.lastIndex)
        } else {
            applyModelFitBounds()
            resetCameraInternal()
        }
    }

    fun setRoleVisible(role: PathRole, visible: Boolean) {
        if (visible) visibleRoles += role else visibleRoles -= role
        invalidate()
    }

    /** Auto-fit every selected layer; this is the default mobile preview mode. */
    fun fitToCurrentLayer() {
        fitMode = FitMode.LAYER
        applyLayerFitBounds(layerIndex)
        resetCameraInternal()
    }

    /** Keep one stable frame covering the complete sliced model while scrubbing layers. */
    fun fitToModel() {
        fitMode = FitMode.MODEL
        applyModelFitBounds()
        resetCameraInternal()
    }

    /** Reset only user zoom/pan while preserving Layer Fit vs Model Fit. */
    fun resetCamera() = resetCameraInternal()

    private fun resetCameraInternal() {
        zoom = 1f
        panX = 0f
        panY = 0f
        invalidate()
    }

    private fun computeModelBounds(value: ToolpathResult) {
        val b = boundsForPaths(value.layers.asSequence().flatMap { it.paths.asSequence() })
        if (b == null) {
            modelMinX = 0f; modelMinY = 0f; modelMaxX = bedX; modelMaxY = bedY
        } else {
            modelMinX = b[0]; modelMinY = b[1]; modelMaxX = b[2]; modelMaxY = b[3]
        }
    }

    private fun applyLayerFitBounds(index: Int) {
        val layer = result?.layers?.getOrNull(index)
        val b = layer?.let { boundsForPaths(it.paths.asSequence()) }
        if (b == null) {
            applyModelFitBounds()
            return
        }
        applyPaddedBounds(b[0], b[1], b[2], b[3], 0.12f)
    }

    private fun applyModelFitBounds() {
        applyPaddedBounds(modelMinX, modelMinY, modelMaxX, modelMaxY, 0.08f)
    }

    private fun boundsForPaths(paths: Sequence<Toolpath>): FloatArray? {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var count = 0
        for (path in paths) for (p in path.points) {
            if (p.x < minX) minX = p.x
            if (p.y < minY) minY = p.y
            if (p.x > maxX) maxX = p.x
            if (p.y > maxY) maxY = p.y
            count++
        }
        return if (count == 0 || !minX.isFinite() || !minY.isFinite() || !maxX.isFinite() || !maxY.isFinite()) null
        else floatArrayOf(minX, minY, maxX, maxY)
    }

    private fun applyPaddedBounds(minX: Float, minY: Float, maxX: Float, maxY: Float, marginFraction: Float) {
        val rawW = (maxX - minX).coerceAtLeast(1f)
        val rawH = (maxY - minY).coerceAtLeast(1f)
        val margin = max(rawW, rawH) * marginFraction + 1f
        fitMinX = minX - margin
        fitMinY = minY - margin
        fitMaxX = maxX + margin
        fitMaxY = maxY + margin
    }

    private var drawScale = 1f
    private var drawCxMm = 0f
    private var drawCyMm = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (width <= 0 || height <= 0) return

        drawScale = baseScale() * zoom
        drawCxMm = (fitMinX + fitMaxX) * 0.5f
        drawCyMm = (fitMinY + fitMaxY) * 0.5f
        drawGrid(canvas)
        val r = result ?: return
        val current = r.layers.getOrNull(layerIndex) ?: return

        if (showBelowLayers && layerIndex > 0) {
            val stride = max(1, layerIndex / 40)
            var i = 0
            while (i < layerIndex) {
                val layer = r.layers[i]
                for (path in layer.paths) if (path.role in visibleRoles) drawPath(canvas, path, ghostPaint, false)
                i += stride
            }
        }

        var lastEnd: Point2? = null
        for (path in current.paths) {
            if (path.points.size < 2) continue
            if (showTravel) {
                val start = path.points.first()
                val prev = lastEnd
                if (prev != null && distanceSquared(prev, start) > 0.0001f) drawSegment(canvas, prev, start, travelPaint)
            }
            if (path.role in visibleRoles) {
                pathPaint.color = roleColor(path.role)
                pathPaint.strokeWidth = (path.widthMm * drawScale).coerceIn(1.35f, 7f)
                drawPath(canvas, path, pathPaint, true)
            }
            lastEnd = path.points.last()
        }
    }

    private fun drawGrid(canvas: Canvas) {
        val visibleMm = max((fitMaxX - fitMinX).coerceAtLeast(1f), (fitMaxY - fitMinY).coerceAtLeast(1f))
        val step = when {
            visibleMm <= 20f -> 2f
            visibleMm <= 50f -> 5f
            visibleMm <= 100f -> 10f
            else -> 20f
        }
        var x = 0f
        while (x <= bedX + 0.001f) {
            canvas.drawLine(toScreenX(x), toScreenY(0f), toScreenX(x), toScreenY(bedY), if (x == 0f) axisPaint else gridPaint)
            x += step
        }
        var y = 0f
        while (y <= bedY + 0.001f) {
            canvas.drawLine(toScreenX(0f), toScreenY(y), toScreenX(bedX), toScreenY(y), if (y == 0f) axisPaint else gridPaint)
            y += step
        }
    }

    private fun drawPath(canvas: Canvas, path: Toolpath, paint: Paint, emphasize: Boolean) {
        val pts = path.points
        if (pts.size < 2) return
        var prevX = toScreenX(pts[0].x)
        var prevY = toScreenY(pts[0].y)
        for (i in 1 until pts.size) {
            val p = pts[i]
            val x = toScreenX(p.x)
            val y = toScreenY(p.y)
            canvas.drawLine(prevX, prevY, x, y, paint)
            prevX = x; prevY = y
        }
        if (emphasize && path.closed && pts.size > 2 && distanceSquared(pts.first(), pts.last()) > 0.0001f) {
            canvas.drawLine(prevX, prevY, toScreenX(pts.first().x), toScreenY(pts.first().y), paint)
        }
    }

    private fun drawSegment(canvas: Canvas, a: Point2, b: Point2, paint: Paint) {
        canvas.drawLine(toScreenX(a.x), toScreenY(a.y), toScreenX(b.x), toScreenY(b.y), paint)
    }

    private fun roleColor(role: PathRole): Int = when (role) {
        PathRole.WALL -> Color.rgb(52, 211, 153)
        PathRole.SOLID -> Color.rgb(251, 191, 36)
        PathRole.GAP_FILL -> Color.rgb(244, 114, 182)
        PathRole.INFILL -> Color.rgb(96, 165, 250)
        PathRole.SUPPORT -> Color.rgb(192, 132, 252)
        PathRole.SUPPORT_INTERFACE -> Color.rgb(167, 139, 250)
        PathRole.BRIM -> Color.rgb(156, 163, 175)
    }

    private fun baseScale(): Float {
        val wMm = (fitMaxX - fitMinX).coerceAtLeast(1f)
        val hMm = (fitMaxY - fitMinY).coerceAtLeast(1f)
        return min(width / wMm, height / hMm) * 0.90f
    }

    private fun toScreenX(x: Float): Float = width * 0.5f + (x - drawCxMm) * drawScale + panX
    private fun toScreenY(y: Float): Float = height * 0.5f - (y - drawCyMm) * drawScale + panY

    private fun distanceSquared(a: Point2, b: Point2): Float {
        val dx = a.x - b.x; val dy = a.y - b.y
        return dx * dx + dy * dy
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y; dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && !scaleDetector.isInProgress && event.pointerCount == 1) {
                    panX += event.x - lastX
                    panY += event.y - lastY
                    lastX = event.x; lastY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; return true }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
