RUDRILA SLICER — STEP 2.1 LAYER PREVIEW FIX

Carries forward Slice Engine V2.4 + Step 2 and fixes the phone-preview issues observed on the real Android device:
- current layer auto-fits and centres instead of appearing tiny/off-corner
- Fit Layer and Fit Model modes for either per-layer inspection or a stable whole-model frame
- pinch zoom now stays anchored under the fingers
- representative layer opens first instead of forcing layer 1
- filters are a compact 3-column mobile grid; no hidden horizontal row
- separate Support / Interface / Brim counts in the layer summary
- shorter responsive preview area with a scroll-safe dialog for small phones
- dedicated Fit Layer / Fit Model / Reset controls
- vertical slider width tightened so more screen belongs to the preview

Step 1 V2.4 geometry safety, low-memory slicing and G-code export gates remain unchanged.
