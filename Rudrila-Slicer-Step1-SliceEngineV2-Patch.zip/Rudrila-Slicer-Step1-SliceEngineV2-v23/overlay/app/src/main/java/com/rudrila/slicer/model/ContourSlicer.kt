package com.rudrila.slicer.model

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** 2D point in the centered build-plate coordinate system, in millimetres. */
data class Point2(val x: Float, val y: Float)

/**
 * A closed cross-section contour. Outer material boundaries are canonicalized CCW;
 * holes are canonicalized CW. [nestingDepth] is 0 for an outer island, 1 for a hole,
 * 2 for an island inside a hole, and so on.
 */
data class SliceLoop(
    val points: List<Point2>,
    val isHole: Boolean = false,
    val nestingDepth: Int = 0
)

data class SliceLayer(
    val index: Int,
    val z: Float,
    val loops: List<SliceLoop>,
    val openPaths: List<List<Point2>>
)

data class SliceDiagnostics(
    val duplicateSegmentsRemoved: Int = 0,
    val degenerateSegmentsDropped: Int = 0,
    val tinyLoopsDropped: Int = 0,
    val tinyGapsHealed: Int = 0,
    val touchingVerticesResolved: Int = 0,
    val nonManifoldVertices: Int = 0,
    val selfIntersectingLoops: Int = 0,
    val invalidLayerCount: Int = 0
)

data class SliceResult(
    val layers: List<SliceLayer>,
    val sourceObjectCount: Int,
    val diagnostics: SliceDiagnostics = SliceDiagnostics()
) {
    val layerCount get() = layers.size
    val closedLoopCount get() = layers.sumOf { it.loops.size }
    val openPathCount get() = layers.sumOf { it.openPaths.size }
    val exportBlockerCount get() = openPathCount + diagnostics.nonManifoldVertices + diagnostics.selfIntersectingLoops
    val isWatertightForExport get() = exportBlockerCount == 0

    fun exportBlockerSummary(): String? {
        if (isWatertightForExport) return null
        val reasons = mutableListOf<String>()
        if (openPathCount > 0) reasons += "$openPathCount open contour path(s)"
        if (diagnostics.nonManifoldVertices > 0) reasons += "${diagnostics.nonManifoldVertices} non-manifold/branched contour vertex/vertices"
        if (diagnostics.selfIntersectingLoops > 0) reasons += "${diagnostics.selfIntersectingLoops} self-intersecting contour loop(s)"
        val suffix = if (diagnostics.invalidLayerCount > 0) " across ${diagnostics.invalidLayerCount} invalid layer(s)" else ""
        return reasons.joinToString(", ") + suffix + "; repair the model before G-code export"
    }
}

/**
 * Slice Engine V2 contour stage.
 *
 * Design goals for the mobile build:
 * - Never allocate a second transformed copy of a dense source mesh.
 * - Deduplicate coincident triangle/plane segments before graph stitching.
 * - Canonicalize outer/hole loop nesting and winding so walls offset toward material.
 * - Keep open contours visible as a hard export safety gate instead of silently closing them.
 */
object ContourSlicer {
    private const val EPS = 1e-5f
    // Exact graph snapping stays tight; repair is a separate, conservative pass.
    private const val JOIN_TOL = 0.002f
    // 0.15 mm is intentionally below half a normal 0.4 mm extrusion width. It heals numeric/STL cracks
    // without globally snapping nearby walls together. Only endpoints in the same connected contour
    // component are eligible, and a repair bridge may not cross existing contour edges.
    private const val AUTO_HEAL_TOL = 0.15f
    private const val TINY_SPUR_TOL = 0.05f
    private const val MIN_LOOP_AREA_MM2 = 0.0004f

    fun slice(objects: List<SceneObject>, process: ProcessProfile): SliceResult {
        require(objects.isNotEmpty()) { "No models on plate" }
        process.validate()
        val maxZ = objects.maxOf { TransformMath.transformedBounds(it.mesh, it.transform).maxZ }.coerceAtLeast(0f)
        if (maxZ <= EPS) return SliceResult(emptyList(), objects.size)

        val first = min(process.firstLayerHeightMm, maxZ)
        val step = process.layerHeightMm
        val count = (floor((((maxZ - first) / step) + 1e-4f).toDouble()).toInt() + 1).coerceAtLeast(1)
        val segmentsByLayer = Array(count) { mutableListOf<Segment>() }
        var degenerateDropped = 0

        for (obj in objects) {
            val source = obj.mesh.vertices
            val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
            val worldTri = FloatArray(9)
            var base = 0
            while (base + 8 < source.size) {
                tx.write(base, worldTri, 0)
                tx.write(base + 3, worldTri, 3)
                tx.write(base + 6, worldTri, 6)
                val z0 = worldTri[2]; val z1 = worldTri[5]; val z2 = worldTri[8]
                val lo = min(z0, min(z1, z2)); val hi = max(z0, max(z1, z2))
                val start = ceil(((lo - first) / step).toDouble() - 1e-4).toInt().coerceAtLeast(0)
                val end = floor(((hi - first) / step).toDouble() + 1e-4).toInt().coerceAtMost(count - 1)
                if (end >= start) {
                    for (li in start..end) {
                        val z = first + li * step
                        val sectionZ = when {
                            z > hi && z - hi <= step * 0.01f -> hi
                            z < lo && lo - z <= step * 0.01f -> lo
                            else -> z
                        }
                        val section = triangleSection(worldTri, 0, sectionZ)
                        if (section != null) segmentsByLayer[li] += section
                    }
                }
                base += 9
            }
        }

        var duplicateRemoved = 0
        var tinyLoopsDropped = 0
        var tinyGapsHealed = 0
        var touchingVerticesResolved = 0
        var nonManifoldVertices = 0
        var selfIntersectingLoops = 0
        var invalidLayerCount = 0
        val layers = ArrayList<SliceLayer>(count)
        for (i in 0 until count) {
            val z = first + i * step
            val dedup = deduplicate(segmentsByLayer[i])
            duplicateRemoved += segmentsByLayer[i].size - dedup.size

            val pruned = pruneTinySpurs(dedup)
            degenerateDropped += dedup.size - pruned.size
            val healed = healTinyGaps(pruned)
            tinyGapsHealed += healed.bridgesAdded

            val stitched = stitch(healed.segments)
            val cycleMerged = mergeOpenCycles(stitched.openPaths)
            val remainingOpen = cycleMerged.openPaths
            val split = splitTouchingLoops(stitched.loops + cycleMerged.loops)
            touchingVerticesResolved += split.splits + cycleMerged.cyclesClosed

            // A branch that decomposes cleanly into simple closed loops is a printable touching-shell case,
            // not an export blocker. Unresolved branches remain blocked if they leave an open path or
            // a genuinely self-crossing contour.
            val selfCrossing = split.loops.count { hasSelfIntersection(it.points) }
            val unresolvedBranches = if (stitched.nonManifoldVertices > 0 &&
                (remainingOpen.isNotEmpty() || selfCrossing > 0)) stitched.nonManifoldVertices else 0
            nonManifoldVertices += unresolvedBranches
            selfIntersectingLoops += selfCrossing

            val canonical = canonicalize(split.loops)
            if (remainingOpen.isNotEmpty() || unresolvedBranches > 0 || selfCrossing > 0) invalidLayerCount++
            tinyLoopsDropped += split.loops.size - canonical.size
            layers += SliceLayer(i, z, canonical, remainingOpen)
        }
        return SliceResult(
            layers,
            objects.size,
            SliceDiagnostics(
                duplicateSegmentsRemoved = duplicateRemoved,
                degenerateSegmentsDropped = degenerateDropped,
                tinyLoopsDropped = tinyLoopsDropped,
                tinyGapsHealed = tinyGapsHealed,
                touchingVerticesResolved = touchingVerticesResolved,
                nonManifoldVertices = nonManifoldVertices,
                selfIntersectingLoops = selfIntersectingLoops,
                invalidLayerCount = invalidLayerCount
            )
        )
    }

    private data class Segment(val a: Point2, val b: Point2)
    private data class Key(val x: Long, val y: Long) : Comparable<Key> {
        override fun compareTo(other: Key): Int = if (x != other.x) x.compareTo(other.x) else y.compareTo(other.y)
    }
    private data class SegmentKey(val a: Key, val b: Key)

    private fun triangleSection(v: FloatArray, base: Int, z: Float): Segment? {
        val pts = ArrayList<Point2>(3)
        fun edge(i0: Int, i1: Int) {
            val z0 = v[i0 + 2]; val z1 = v[i1 + 2]
            // Coplanar edges are ignored: neighbouring non-coplanar triangles define the contour,
            // while adding coplanar edges creates duplicate/branching graph edges.
            if (abs(z0 - z) < EPS && abs(z1 - z) < EPS) return
            val crosses = (z0 < z && z1 >= z) || (z1 < z && z0 >= z)
            if (!crosses) return
            val dz = z1 - z0
            if (abs(dz) < EPS) return
            val t = (z - z0) / dz
            val p = Point2(v[i0] + (v[i1] - v[i0]) * t, v[i0 + 1] + (v[i1 + 1] - v[i0 + 1]) * t)
            if (pts.none { dist2(it, p) < EPS * EPS }) pts += p
        }
        edge(base, base + 3); edge(base + 3, base + 6); edge(base + 6, base)
        return if (pts.size == 2 && dist2(pts[0], pts[1]) > EPS * EPS) Segment(pts[0], pts[1]) else null
    }

    /** Remove coincident undirected segments generated at shared vertices/edges. */
    private fun deduplicate(segments: List<Segment>): List<Segment> {
        if (segments.size < 2) return segments
        val seen = HashSet<SegmentKey>(segments.size * 2)
        val out = ArrayList<Segment>(segments.size)
        for (s in segments) {
            val ka = key(s.a); val kb = key(s.b)
            if (ka == kb) continue
            val sk = if (ka <= kb) SegmentKey(ka, kb) else SegmentKey(kb, ka)
            if (seen.add(sk)) out += s
        }
        return out
    }


    private data class HealResult(val segments: List<Segment>, val bridgesAdded: Int)

    /**
     * Remove only very short dangling spurs attached to a branch vertex. These commonly come from
     * degenerate facets. Long geometry is never discarded by this pass.
     */
    private fun pruneTinySpurs(input: List<Segment>): List<Segment> {
        if (input.size < 2) return input
        var segments = input
        repeat(2) {
            val degree = HashMap<Key, Int>()
            for (s in segments) {
                degree[key(s.a)] = (degree[key(s.a)] ?: 0) + 1
                degree[key(s.b)] = (degree[key(s.b)] ?: 0) + 1
            }
            val next = segments.filterNot { s ->
                val da = degree[key(s.a)] ?: 0
                val db = degree[key(s.b)] ?: 0
                val len2 = dist2(s.a, s.b)
                len2 <= TINY_SPUR_TOL * TINY_SPUR_TOL &&
                    ((da > 2 && db == 1) || (db > 2 && da == 1))
            }
            if (next.size == segments.size) return segments
            segments = next
        }
        return segments
    }

    /**
     * Conservatively close tiny cracks. Eligible endpoints must belong to the same already-connected
     * contour component, so two separate nearby objects are not welded together. Bridges are selected
     * shortest-first and rejected if they cross any existing edge.
     */
    private fun healTinyGaps(input: List<Segment>): HealResult {
        if (input.size < 2) return HealResult(input, 0)

        val adjacency = HashMap<Key, MutableList<Key>>()
        val pointByKey = HashMap<Key, Point2>()
        val degree = HashMap<Key, Int>()
        fun link(a: Key, b: Key) {
            adjacency.getOrPut(a) { mutableListOf() } += b
            adjacency.getOrPut(b) { mutableListOf() } += a
        }
        for (s in input) {
            val a = key(s.a); val b = key(s.b)
            pointByKey.putIfAbsent(a, s.a); pointByKey.putIfAbsent(b, s.b)
            degree[a] = (degree[a] ?: 0) + 1
            degree[b] = (degree[b] ?: 0) + 1
            link(a, b)
        }

        // Connected-component IDs on the exact contour graph.
        val component = HashMap<Key, Int>()
        var componentId = 0
        for (start in adjacency.keys) {
            if (component.containsKey(start)) continue
            val q = java.util.ArrayDeque<Key>()
            q.add(start); component[start] = componentId
            while (q.isNotEmpty()) {
                val k = q.removeFirst()
                for (n in adjacency[k].orEmpty()) if (!component.containsKey(n)) {
                    component[n] = componentId; q.add(n)
                }
            }
            componentId++
        }

        data class Candidate(val a: Key, val b: Key, val d2: Float)
        val endpoints = degree.filterValues { it == 1 }.keys.toList()
        val candidates = ArrayList<Candidate>()
        for (i in endpoints.indices) for (j in i + 1 until endpoints.size) {
            val a = endpoints[i]; val b = endpoints[j]
            val pa = pointByKey[a] ?: continue; val pb = pointByKey[b] ?: continue
            val d2 = dist2(pa, pb)
            // Quantized graph keys can land in neighbouring buckets even when two endpoints are
            // much closer than JOIN_TOL. Never leave those numeric cracks open. Also allow tiny
            // gaps between disconnected fragments: many exported STL files split a visually closed
            // shell into multiple components. The bridge is still capped below half a normal 0.4 mm
            // extrusion width and is rejected if it crosses existing contour geometry.
            if (d2 > EPS * EPS && d2 <= AUTO_HEAL_TOL * AUTO_HEAL_TOL) {
                candidates += Candidate(a, b, d2)
            }
        }
        candidates.sortBy { it.d2 }

        val usedEndpoints = HashSet<Key>()
        val out = ArrayList<Segment>(input.size + candidates.size)
        out += input
        var added = 0
        for (c in candidates) {
            if (c.a in usedEndpoints || c.b in usedEndpoints) continue
            val a = pointByKey[c.a] ?: continue; val b = pointByKey[c.b] ?: continue
            val bridge = Segment(a, b)
            if (crossesExistingStrictly(bridge, out)) continue
            out += bridge
            usedEndpoints += c.a; usedEndpoints += c.b
            added++
        }
        return HealResult(out, added)
    }

    private fun crossesExistingStrictly(candidate: Segment, segments: List<Segment>): Boolean {
        val ca = key(candidate.a); val cb = key(candidate.b)
        for (s in segments) {
            val sa = key(s.a); val sb = key(s.b)
            if (sa == ca || sa == cb || sb == ca || sb == cb) continue
            if (segmentsIntersect(candidate.a, candidate.b, s.a, s.b)) return true
        }
        return false
    }

    private data class LoopSplitResult(val loops: List<SliceLoop>, val splits: Int)

    /**
     * A degree-4 touch point often arrives as one figure-eight walk that revisits exactly the same
     * snapped vertex. Split that walk into independent closed loops before self-intersection testing.
     * True crossings that do not occur at an existing vertex remain blocked.
     */
    private fun splitTouchingLoops(raw: List<SliceLoop>): LoopSplitResult {
        if (raw.isEmpty()) return LoopSplitResult(emptyList(), 0)
        val queue = java.util.ArrayDeque<List<Point2>>()
        raw.forEach { queue.add(normalizeClosed(it.points)) }
        val out = ArrayList<SliceLoop>()
        var splits = 0
        var guard = 0
        while (queue.isNotEmpty() && guard++ < raw.size * 16 + 64) {
            val closed = normalizeClosed(queue.removeFirst())
            if (closed.size < 4) continue
            val pts = closed.dropLast(1)
            val firstAt = HashMap<Key, Int>()
            var cutA = -1; var cutB = -1
            for (i in pts.indices) {
                val k = key(pts[i])
                val previous = firstAt[k]
                if (previous == null) firstAt[k] = i
                else if (i - previous > 1 && !(previous == 0 && i == pts.lastIndex)) {
                    cutA = previous; cutB = i; break
                }
            }
            if (cutA < 0) {
                out += SliceLoop(closed)
                continue
            }

            val a = ArrayList<Point2>()
            for (i in cutA..cutB) a += pts[i]
            if (a.isNotEmpty()) a[a.lastIndex] = a.first()

            val b = ArrayList<Point2>()
            for (i in cutB until pts.size) b += pts[i]
            for (i in 0..cutA) b += pts[i]
            if (b.isNotEmpty()) b[b.lastIndex] = b.first()

            val ca = normalizeClosed(a)
            val cb = normalizeClosed(b)
            if (ca.size >= 4 && cb.size >= 4) {
                queue.add(ca); queue.add(cb); splits++
            } else {
                // Do not hide malformed geometry if it cannot be split into two real rings.
                out += SliceLoop(closed)
            }
        }
        while (queue.isNotEmpty()) out += SliceLoop(normalizeClosed(queue.removeFirst()))
        return LoopSplitResult(out, splits)
    }

    private data class OpenCycleMergeResult(
        val loops: List<SliceLoop>,
        val openPaths: List<List<Point2>>,
        val cyclesClosed: Int
    )

    /**
     * Stitch can split a valid touching/branched contour into several open walks even when those
     * walks form an exact closed cycle at their snapped endpoints. Reassemble only endpoint-graph
     * components where every endpoint has degree exactly 2. No geometric bridge is invented here:
     * true cracks keep degree-1 endpoints and remain blocked by the export safety gate.
     */
    private fun mergeOpenCycles(paths: List<List<Point2>>): OpenCycleMergeResult {
        if (paths.size < 2) return OpenCycleMergeResult(emptyList(), paths, 0)

        // Quantized keys can differ by one bucket for coordinates only a few microns apart when
        // they lie on opposite sides of a rounding boundary. Cluster path endpoints geometrically
        // within JOIN_TOL so numerically identical junctions share one graph node.
        val nodePoints = ArrayList<Point2>()
        fun nodeFor(p: Point2): Int {
            for (i in nodePoints.indices) if (dist2(nodePoints[i], p) <= JOIN_TOL * JOIN_TOL) return i
            nodePoints += p
            return nodePoints.lastIndex
        }

        data class PathEdge(val pathIndex: Int, val a: Int, val b: Int)
        val edges = ArrayList<PathEdge>(paths.size)
        val endpointMap = HashMap<Int, MutableList<Int>>()
        fun add(node: Int, edgeIndex: Int) { endpointMap.getOrPut(node) { mutableListOf() } += edgeIndex }
        for (i in paths.indices) {
            val p = paths[i]
            if (p.size < 2) continue
            val a = nodeFor(p.first()); val b = nodeFor(p.last())
            val ei = edges.size
            edges += PathEdge(i, a, b)
            add(a, ei); add(b, ei)
        }
        if (edges.size < 2) return OpenCycleMergeResult(emptyList(), paths, 0)

        val edgeVisited = BooleanArray(edges.size)
        val pathConsumed = BooleanArray(paths.size)
        val mergedLoops = ArrayList<SliceLoop>()
        val remaining = ArrayList<List<Point2>>()
        var cycles = 0

        for (seed in edges.indices) {
            if (edgeVisited[seed]) continue
            val component = ArrayList<Int>()
            val queue = java.util.ArrayDeque<Int>()
            val vertices = HashSet<Int>()
            queue.add(seed); edgeVisited[seed] = true
            while (queue.isNotEmpty()) {
                val ei = queue.removeFirst()
                component += ei
                val e = edges[ei]
                vertices += e.a; vertices += e.b
                for (node in intArrayOf(e.a, e.b)) for (n in endpointMap[node].orEmpty()) {
                    if (!edgeVisited[n]) { edgeVisited[n] = true; queue.add(n) }
                }
            }

            // Only exact endpoint-graph cycles are auto-closed. A true crack has degree-1 nodes.
            val isCycle = component.size >= 2 &&
                vertices.all { node -> endpointMap[node].orEmpty().count { it in component } == 2 }
            if (!isCycle) continue

            val unused = component.toMutableSet()
            val firstEdge = unused.first()
            val fe = edges[firstEdge]
            val firstPath = paths[fe.pathIndex]
            unused.remove(firstEdge)
            pathConsumed[fe.pathIndex] = true
            val startNode = fe.a
            var currentNode = fe.b
            val merged = ArrayList<Point2>()
            merged += firstPath
            var guard = 0
            while (currentNode != startNode && guard++ < component.size + 2) {
                val nextEdge = endpointMap[currentNode].orEmpty().firstOrNull { it in unused } ?: break
                val ne = edges[nextEdge]
                val original = paths[ne.pathIndex]
                val oriented: List<Point2>
                val nextNode: Int
                if (ne.a == currentNode) { oriented = original; nextNode = ne.b }
                else { oriented = original.asReversed(); nextNode = ne.a }
                unused.remove(nextEdge)
                pathConsumed[ne.pathIndex] = true
                for (i in 1 until oriented.size) merged += oriented[i]
                currentNode = nextNode
            }
            if (currentNode == startNode && unused.isEmpty() && merged.size >= 4) {
                // Snap the final numerical endpoint to the exact first point.
                if (dist2(merged.first(), merged.last()) <= JOIN_TOL * JOIN_TOL) merged[merged.lastIndex] = merged.first()
                val closed = normalizeClosed(merged)
                mergedLoops += SliceLoop(closed)
                cycles++
            } else {
                // Defensive fallback: restore paths if closure was not fully proven.
                for (ei in component) pathConsumed[edges[ei].pathIndex] = false
            }
        }

        for (i in paths.indices) if (!pathConsumed[i]) remaining += paths[i]
        return OpenCycleMergeResult(mergedLoops, remaining, cycles)
    }

    private data class StitchResult(
        val loops: List<SliceLoop>,
        val openPaths: List<List<Point2>>,
        val nonManifoldVertices: Int
    )

    private fun stitch(segments: List<Segment>): StitchResult {
        if (segments.isEmpty()) return StitchResult(emptyList(), emptyList(), 0)
        val used = BooleanArray(segments.size)
        val endpointMap = HashMap<Key, MutableList<Int>>()
        fun add(k: Key, i: Int) { endpointMap.getOrPut(k) { mutableListOf() } += i }
        segments.forEachIndexed { i, s -> add(key(s.a), i); add(key(s.b), i) }
        // A closed manifold contour graph has degree exactly 2 at every snapped vertex.
        // Degree > 2 means touching/crossing shells or another non-manifold branch; do not silently choose one.
        val nonManifoldVertices = endpointMap.values.count { it.size > 2 }

        val loops = mutableListOf<SliceLoop>()
        val open = mutableListOf<List<Point2>>()
        for (seed in segments.indices) {
            if (used[seed]) continue
            used[seed] = true
            val s = segments[seed]
            val path = mutableListOf(s.a, s.b)
            val startKey = key(s.a)
            var currentKey = key(s.b)
            var guard = 0
            while (currentKey != startKey && guard++ < segments.size + 4) {
                val candidates = endpointMap[currentKey]?.filter { !used[it] }.orEmpty()
                if (candidates.isEmpty()) break
                // On a clean manifold graph degree is 2. If numerical noise makes a branch,
                // continue in the straightest direction rather than depending on list order.
                val previous = path.getOrNull(path.lastIndex - 1)
                val current = path.last()
                val next = candidates.minByOrNull { idx ->
                    if (previous == null) 0f else turnPenalty(previous, current, otherEnd(segments[idx], currentKey))
                } ?: break
                used[next] = true
                val other = otherEnd(segments[next], currentKey)
                path += other
                currentKey = key(other)
            }
            if (currentKey == startKey && path.size >= 4) {
                if (dist2(path.first(), path.last()) > JOIN_TOL * JOIN_TOL) path += path.first()
                loops += SliceLoop(cleanClosedPath(path))
            } else if (path.size >= 2) {
                open += cleanOpenPath(path)
            }
        }
        return StitchResult(loops, open, nonManifoldVertices)
    }

    /** Canonicalize nesting + winding, and remove sub-resolution rings. */
    private fun canonicalize(raw: List<SliceLoop>): List<SliceLoop> {
        val clean = raw.mapNotNull { loop ->
            val pts = normalizeClosed(loop.points)
            if (pts.size < 4) null
            else {
                val open = pts.dropLast(1)
                if (abs(PolygonOps.area(open)) < MIN_LOOP_AREA_MM2) null else open
            }
        }
        if (clean.isEmpty()) return emptyList()

        val out = ArrayList<SliceLoop>(clean.size)
        for (i in clean.indices) {
            var depth = 0
            val sample = clean[i][0]
            for (j in clean.indices) {
                if (i == j) continue
                if (pointInside(sample, clean[j])) depth++
            }
            val hole = depth % 2 == 1
            var poly = clean[i]
            val area = PolygonOps.area(poly)
            val wantsCcw = !hole
            if ((wantsCcw && area < 0f) || (!wantsCcw && area > 0f)) poly = poly.reversed()
            out += SliceLoop(poly + poly.first(), hole, depth)
        }
        // Stable ordering helps deterministic toolpaths/tests: islands before their nested holes, then by area.
        return out.sortedWith(compareBy<SliceLoop> { it.nestingDepth }.thenByDescending { abs(PolygonOps.area(it.points.dropLast(1))) })
    }

    private fun normalizeClosed(points: List<Point2>): List<Point2> {
        if (points.isEmpty()) return emptyList()
        val out = ArrayList<Point2>(points.size)
        for (p in points) if (out.isEmpty() || dist2(out.last(), p) > EPS * EPS) out += p
        if (out.size >= 2 && dist2(out.first(), out.last()) > JOIN_TOL * JOIN_TOL) out += out.first()
        else if (out.size >= 2) out[out.lastIndex] = out.first()
        return out
    }

    private fun cleanClosedPath(points: List<Point2>): List<Point2> = normalizeClosed(points)

    private fun cleanOpenPath(points: List<Point2>): List<Point2> {
        val out = ArrayList<Point2>(points.size)
        for (p in points) if (out.isEmpty() || dist2(out.last(), p) > EPS * EPS) out += p
        return out
    }

    private fun otherEnd(s: Segment, at: Key): Point2 = if (key(s.a) == at) s.b else s.a

    private fun turnPenalty(a: Point2, b: Point2, c: Point2): Float {
        val ux = b.x - a.x; val uy = b.y - a.y
        val vx = c.x - b.x; val vy = c.y - b.y
        val ul = kotlin.math.sqrt(ux * ux + uy * uy).coerceAtLeast(EPS)
        val vl = kotlin.math.sqrt(vx * vx + vy * vy).coerceAtLeast(EPS)
        // 0 = straight, 2 = reverse.
        return 1f - ((ux * vx + uy * vy) / (ul * vl)).coerceIn(-1f, 1f)
    }

    /** Sweep-line style self-intersection check with bounding-box pruning. */
    private fun hasSelfIntersection(points: List<Point2>): Boolean {
        val n = if (points.size > 1 && dist2(points.first(), points.last()) <= JOIN_TOL * JOIN_TOL) points.size - 1 else points.size
        if (n < 4) return false
        data class Edge(val index:Int, val a:Point2, val b:Point2, val minX:Float, val maxX:Float, val minY:Float, val maxY:Float)
        val edges = ArrayList<Edge>(n)
        for (i in 0 until n) {
            val a=points[i]; val b=points[(i+1)%n]
            edges += Edge(i,a,b,min(a.x,b.x),max(a.x,b.x),min(a.y,b.y),max(a.y,b.y))
        }
        val sorted=edges.sortedBy { it.minX }
        val active=ArrayList<Edge>()
        fun adjacent(i:Int,j:Int):Boolean { val d=abs(i-j); return d==1 || d==n-1 }
        for (e in sorted) {
            active.removeAll { it.maxX < e.minX - EPS }
            for (o in active) {
                if (adjacent(e.index,o.index)) continue
                if (o.maxY < e.minY - EPS || e.maxY < o.minY - EPS) continue
                if (segmentsProperlyCrossOrOverlap(e.a,e.b,o.a,o.b)) return true
            }
            active += e
        }
        return false
    }


    /**
     * Self-intersection safety check. A simple endpoint touch between non-adjacent edges is common
     * in multi-shell STL output and is not by itself an interior crossing. Proper X crossings remain
     * blocked, as do meaningful collinear overlaps.
     */
    private fun segmentsProperlyCrossOrOverlap(a:Point2,b:Point2,c:Point2,d:Point2):Boolean {
        fun cross(p:Point2,q:Point2,r:Point2)=(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x)
        val c1=cross(a,b,c); val c2=cross(a,b,d); val c3=cross(c,d,a); val c4=cross(c,d,b)
        val proper = ((c1>EPS && c2< -EPS)||(c1< -EPS && c2>EPS)) &&
            ((c3>EPS && c4< -EPS)||(c3< -EPS && c4>EPS))
        if (proper) return true

        if (abs(c1)<=EPS && abs(c2)<=EPS && abs(c3)<=EPS && abs(c4)<=EPS) {
            val overlapX = min(max(a.x,b.x), max(c.x,d.x)) - max(min(a.x,b.x), min(c.x,d.x))
            val overlapY = min(max(a.y,b.y), max(c.y,d.y)) - max(min(a.y,b.y), min(c.y,d.y))
            if (max(overlapX, overlapY) > JOIN_TOL) return true
        }
        return false
    }

    private fun segmentsIntersect(a:Point2,b:Point2,c:Point2,d:Point2):Boolean {
        fun cross(p:Point2,q:Point2,r:Point2)=(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x)
        fun on(p:Point2,q:Point2,r:Point2):Boolean =
            q.x >= min(p.x,r.x)-EPS && q.x <= max(p.x,r.x)+EPS && q.y >= min(p.y,r.y)-EPS && q.y <= max(p.y,r.y)+EPS
        val c1=cross(a,b,c); val c2=cross(a,b,d); val c3=cross(c,d,a); val c4=cross(c,d,b)
        if (((c1>EPS && c2< -EPS)||(c1< -EPS && c2>EPS)) && ((c3>EPS && c4< -EPS)||(c3< -EPS && c4>EPS))) return true
        if (abs(c1)<=EPS && on(a,c,b)) return true
        if (abs(c2)<=EPS && on(a,d,b)) return true
        if (abs(c3)<=EPS && on(c,a,d)) return true
        if (abs(c4)<=EPS && on(c,b,d)) return true
        return false
    }

    private fun pointInside(p: Point2, poly: List<Point2>): Boolean {
        if (poly.size < 3) return false
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val a = poly[i]; val b = poly[j]
            if (((a.y > p.y) != (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y + 1e-12f) + a.x) inside = !inside
            j = i
        }
        return inside
    }

    private fun key(p: Point2) = Key((p.x / JOIN_TOL).roundToLong(), (p.y / JOIN_TOL).roundToLong())
    private fun dist2(a: Point2, b: Point2): Float { val x = a.x - b.x; val y = a.y - b.y; return x * x + y * y }
}
