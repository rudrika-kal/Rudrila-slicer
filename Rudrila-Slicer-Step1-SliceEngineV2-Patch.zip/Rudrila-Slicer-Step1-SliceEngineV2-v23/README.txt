RUDRILA Slicer - Slice Engine V2.3 endpoint-cycle repair patch

Changes from V2.2:
- Reassembles branch-split open contour walks when their endpoints form a mathematically closed degree-2 cycle.
- Endpoint graph clustering is geometric within 0.002 mm, avoiding false opens caused by spatial-hash rounding boundaries.
- Does NOT invent long bridges: true degree-1 cracks remain export blockers.
- Proper self-crossings remain blocked.
- Existing wall/top-bottom/infill/gap-fill and G-code safety gate remain active.

Exact-model regression:
- obj_1_Object_1.stl SHA256: 110968b1ae1610b136f664e3d2ebc1ff6106e7cd891e8f500baaa752cbfa437e
- 3,066,808 triangles, 64.347 x 53.556 x 100.000 mm
- 500 layers @ 0.20 mm
- open contour paths: 0
- non-manifold blockers: 0
- self-intersections: 0
- invalid layers: 0
- export blocker: none
