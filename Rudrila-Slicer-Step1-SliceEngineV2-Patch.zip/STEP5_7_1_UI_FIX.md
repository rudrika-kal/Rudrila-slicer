# RUDRILA Slicer Step 5.7.1 UI Fix

Fixes the phone-layout regression introduced when SAVE was added to the top action bar.

- Title/status now occupy a full-width row.
- IMPORT / SLICE / PREVIEW / SAVE occupy a separate equal-width action row.
- Title is capped at one line and status at two lines so the header cannot grow vertically from width starvation.
- Model SAVE STL / SAVE 3MF behavior from Step 5.7 is unchanged.
