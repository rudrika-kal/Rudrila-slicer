# RUDRILA SLICER — Step 5.6 Final Audit

This patch is an A→Z audit of the current Step 5 feature surface. It intentionally preserves the already-green slice/support/preview core byte-for-byte and concentrates fixes in state management, profile persistence, export safety and the controlled P2S bridge.

## Frozen green core (unchanged)
- ContourSlicer.kt SHA256 7544731243d9a82af6b4ddf846da4444773c44298c7919696d4579b5ac78ffd0
- ToolpathEngine.kt SHA256 9bb256f3f9827fdda9296ad57cb3de5ccee500681453732862886e683cd36f62
- Step5Profiles.kt SHA256 4a0f2ff64c80e727f9fe4726a9bc9a2da71f19521a984b1860b74b71b335f898
- ToolpathPreviewView.kt SHA256 f2fe33121f065ddcb7853dc9c09d654bafad62be8d5a5e2188930d97fcf8ef9f
- VerticalLayerSlider.kt SHA256 9523815851704643bcc585ce1b49c2126ea9800c75b5b0fabb1074054b03accc

## Bugs proactively fixed
1. P2S Generic PLA Balanced could round-trip to legacy Generic PLA. P2S material selections are now canonicalized by material and persisted with commit()+read-back verification.
2. Long slices could publish stale results after a plate/profile change. Slice results now carry revision/request IDs and stale work is discarded.
3. Repeated Slice taps could queue duplicate giant jobs. A slice-busy gate prevents duplicate work.
4. Export could use mutable global state after the Android save picker. A revision-bound immutable export ticket now snapshots toolpaths/config/purpose/envelope and is revalidated after picker return.
5. P2S reference import previously read the entire file before enforcing a size cap. Import now streams through a hard 24 MiB character cap.
6. Controlled P2S reference validation previously checked only machine envelope signatures. V3 now validates the imported reference body itself: ~25 layers, 20×20×5 mm geometry, centered on the 256 mm plate, >=100 extrusion moves, PLA-range resolved temperatures and native P2S signatures.
7. Controlled reference temperatures are now required to match the Rudrila PLA preset within 5 °C.
8. Old V1/V2 controlled-reference caches are invalidated; only V3 cache data is accepted.
9. NaN/Infinity numeric UI input is rejected/falls back safely for size, exact transforms and brim.
10. Support V2 persistence now validates styles and uses commit() instead of asynchronous apply().
11. Generic G-code end sequence no longer issues a blind relative +5 mm Z move; parking is absolute and clamped to max build Z.
12. G-code safety now blocks slices with no actual extrusion segments.
13. Preflight and writer bed-edge tolerances now agree; accepted ±0.001 mm floating error is clamped before writing machine coordinates.
14. Background callbacks now avoid mutating destroyed activities; corrupt P2S cache files are deleted instead of silently reused.
15. Real Android SharedPreferences self-test runs on startup in an isolated store to guard the reported P2S PLA persistence regression.

## Local regression gates passed
- Step54SafetyTests
- Step5ProfileTests (all 4 P2S nozzles × all Step 5 materials validated)
- Step56 Controlled P2S tests, including reference-body/temperature rejection paths
- FinalAuditTests (zero extrusion, tolerance clamp, tall-Z park, profile migration)
- ProfilePersistenceTests using an in-memory Android SharedPreferences stub
- GCode formatter equivalence/performance tests
- MainActivity parser pass (no Kotlin syntax errors; Android symbols require the real Android build)

## Final CI gates required before APK is called validated
- clean patch merge + double Android build
- exact pinned 153,340,484-byte Hanuman STL regression
- Geometry gate PASS
- Supports V2 Tree/Organic
- preview and support/interface path verification
- G-code export
- no FATAL EXCEPTION / no ANR
- `HANUMAN_EMULATOR_REGRESSION_PASS`

Controlled P2S export remains locked to the dedicated safety cube. This is not a claim of general P2S production compatibility; a physical controlled print is still required to finish Step 5.

## Step 5.6.1 CI compile correction
GitHub final-audit run #19 identified one Android/Kotlin API misuse in the capped P2S reference reader: `InputStream.bufferedReader()` was called with a second buffer-size argument that the Kotlin stdlib overload does not accept. The reader now uses `InputStreamReader(input, UTF_8).buffered(64 KiB)`. No slice, support, preview, profile-catalog, toolpath, or G-code safety behavior was changed by this correction.


## Step 5.6.1 final profile self-audit fix
- Root cause: Step 5 filament presets passed volumetric-flow and density arguments in reverse order to `FilamentProfile`.
- Corrected PLA/PETG/ABS/TPU density + max-volumetric-flow values.
- Added explicit regression assertions for constructor field order.
- Local profile catalog + P2S canonical migration + persistence self-audit: PASS twice.
- Local Step 5 profile, Step 5.4 safety, controlled-P2S, final-audit model tests: PASS.
- Real 3MF two-object parser smoke test: PASS (10×10×5 mm and 8×8×4 mm parts, transforms preserved).
