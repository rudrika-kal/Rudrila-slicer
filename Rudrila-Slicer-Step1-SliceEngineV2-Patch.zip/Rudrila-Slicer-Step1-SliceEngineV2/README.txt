RUDRILA Slicer - Step 1: Slice Engine V2 hardening overlay

Modified files:
- ContourSlicer.kt
- ToolpathEngine.kt
- GCodeExporter.kt
- MainActivity.kt
- SliceEngineV2Tests.kt

What changed:
1. Contour endpoint snapping reduced from 0.02 mm to 0.002 mm so real small cracks are not silently bridged.
2. Open contours remain explicit export blockers.
3. Non-manifold/branched contour vertices (degree > 2) are counted and block export.
4. Closed self-intersecting contour loops are detected with sweep-style bounding-box pruning and block export.
5. Slice diagnostics report invalid layer count and exact blocker summary.
6. ToolpathResult.canExport now considers all geometry blockers, not only open paths.
7. GCodeExporter hard-refuses unsafe geometry with a human-readable reason.
8. MainActivity shows the geometry blocker reason and prevents export while still allowing layer preview.
9. Existing V2 walls, local top/bottom skin, sparse infill, gap fill and hole-aware offsets are preserved.

This package is an overlay for the extracted RudrilaSlicer-alpha07-work tree.
GitHub repository write was not performed because the connected GitHub integration returned HTTP 403 for write operations.
