RUDRILA SLICER — STEP 5.5 CONTROLLED P2S BRIDGE

Purpose
- Keep general Bambu Lab P2S printer-ready export blocked until a fully-native Rudrila machine-template engine exists.
- Enable one controlled real-printer test without bundling/copying Bambu Studio's AGPL machine template.

Controlled-test gate
- Bambu Lab P2S 0.4 mm profile only.
- Rudrila Generic PLA Balanced preset only.
- Supports OFF.
- Exact centered 20 x 20 mm footprint, 5 mm max Z safety cube only.
- User imports an already-resolved P2S safety-cube .gcode exported by Bambu Studio.
- Import must contain resolved P2S start/end markers, homing/leveling, temperature waits and shutdown; unresolved slicer placeholders are rejected.
- Rudrila stores only the verified start/end envelope and SHA-256, then inserts its controlled cube body between them.
- Normal P2S models remain blocked.

Regression rule
- ContourSlicer.kt, ToolpathEngine.kt, ToolpathPreviewView.kt, VerticalLayerSlider.kt and Step5Profiles.kt are frozen from the Step 5.4.3 green baseline and must remain byte-for-byte unchanged.
