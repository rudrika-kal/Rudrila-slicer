RUDRILA Slicer Step 4.3 - Supports V2 Final Candidate + Fast G-code Export

Base: Step 4.2 support engine that completed exact Hanuman Tree/Organic slicing in Android 36 emulator.

Preserves Step 4 Supports V2:
- Normal support
- Tree / Organic support routing
- Hybrid support routing
- configurable overhang angle
- configurable dense support-interface layers
- build-plate-only option
- separate SUPPORT and SUPPORT_INTERFACE toolpath roles
- persisted support settings
- optimized scanline occupancy + branch propagation

Step 4.3 export fix:
- replaces java.util.String.format("%.3f") in the hot G-code loop with a locale-independent fixed-3 formatter
- increases Android output buffering to 1 MiB for content-provider writes
- G-code semantics/coordinates remain unchanged (except Step 4.3 comment header)

Validated before packaging:
- support old-vs-new exact comparisons: 426 PASS from Step 4.2
- exact Hanuman Android 36 emulator slice: PASS
  - 500 layers
  - 90,599 toolpaths
  - 37.0 g estimate
  - 2h 9m estimate
  - Geometry gate: PASS
  - Tree / Organic, 55 degrees, interface 2
  - actual slice-start to completion observed ~5m33s on GitHub Android emulator
- G-code formatter: 1,000,000 random float equivalence checks vs String.format("%.3f"): PASS
- 91,000-path synthetic G-code output: byte-identical after normalizing only Step 4.2/4.3 comment header
- same 91,000-path JVM export benchmark: new ~0.29s vs old ~0.76s on this runner

Final acceptance gate after upload: Android 36 exact Hanuman export + preview support/interface scan + crash/ANR scan.
