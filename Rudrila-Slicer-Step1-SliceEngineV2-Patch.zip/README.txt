RUDRILA Slicer Step 4 - Supports V2

Base: validated Step 3 Print Quality Engine patch.

Adds:
- Normal support
- Tree / Organic support routing
- Hybrid support routing
- configurable overhang angle
- configurable dense support-interface layers
- build-plate-only option
- separate SUPPORT and SUPPORT_INTERFACE toolpath roles
- persisted support settings in Android SharedPreferences

Preserves:
- Slice Engine V2 geometry safety gate
- Step 2.5 smooth 3D/layer preview and plate centering
- Step 3 rear seam, bridge/overhang, volumetric cap, retract, acceleration and ironing

Manual phone verification required after CI build.
