RUDRILA Slicer Step 4.1 - Supports V2 Performance Final

Base: validated Step 3 Print Quality Engine + Step 4 Supports V2.

Adds/preserves:
- Normal support
- Tree / Organic support routing
- Hybrid support routing
- configurable overhang angle
- configurable dense support-interface layers
- build-plate-only option
- separate SUPPORT and SUPPORT_INTERFACE toolpath roles
- persisted support settings in Android SharedPreferences
- scanline support occupancy rasterizer for dense/high-poly models
- O(1) overhang membership via per-layer expanded support mask
- safe duplicate-route merging for vertical Normal supports

Regression guarantees used for this patch:
- 54 old-vs-new support combinations produced exact identical output signatures
  (Normal/Tree/Hybrid x angles 35/50/65 x interface 0/2/4 x plate-only ON/OFF).
- 500-layer synthetic complex support benchmark passed in 192 MB heap.
- Slice Engine V2 geometry code and preview renderer are otherwise preserved.

GitHub Android build + exact Hanuman Android emulator regression required before Step 4 is marked final.
