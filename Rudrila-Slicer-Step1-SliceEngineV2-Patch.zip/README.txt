RUDRILA SLICER — Step 5.6 Final A→Z Audit

Scope
- Preserve the last green Slice Engine / Supports V2 / Preview core byte-for-byte.
- Fix profile persistence and harden import/export lifecycle/safety paths.
- Keep P2S general printer-ready export blocked; allow only the gated controlled cube path.
- Keep STL import working and include 3MF import in the final regression scope.

Final-audit fixes
- P2S + legacy Generic PLA/PETG/ABS/TPU selections canonicalize to Step 5 balanced/safe preset IDs.
- Profile writes use synchronous verified commit and load-time migration; Android startup runs an isolated persistence self-test.
- Profile dialog immediately switches legacy PLA to Generic PLA • Balanced when P2S is selected and keeps the canonical profile in UI after Save.
- Slice requests are revision-tagged; stale slice results are discarded after model/profile changes and duplicate concurrent slices are blocked.
- Export uses an immutable ticket (toolpaths + config + purpose + envelope + revision); stale picker returns cannot export the wrong profile/slice.
- P2S reference reads are size-capped before allocation, reference cache is V2 + atomically replaced, and the imported Bambu G-code body itself must match a centered ~20×20×5 / ~25-layer PLA P2S safety cube.
- Generic G-code end parking uses absolute/clamped Z instead of blind relative +5 mm.
- Bed-edge tolerance used by preflight and emitted coordinates is consistent; emitted XY is clamped only inside the 0.001 mm tolerance.
- Empty/no-extrusion slices are an export blocker, not a warning.
- Exact-transform numeric inputs reject NaN/Infinity fallthrough.
- Support V2 settings are range-checked and synchronously persisted.
- 3MF remains accepted alongside STL; ZIP-signature imports route directly to 3MF instead of being mis-parsed as STL.

3MF
- Import path uses ThreeMfParser.parseParts already present in the alpha source.
- Multi-object 3MF is accepted as multiple imported scene objects.
- Final regression asset: overlay/tests/assets/RUDRILA_3MF_REGRESSION_TWO_CUBES.3mf

Frozen green core (unchanged)
- ContourSlicer.kt
- ToolpathEngine.kt
- ToolpathPreviewView.kt
- VerticalLayerSlider.kt
- Step5Profiles.kt
