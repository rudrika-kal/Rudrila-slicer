RUDRILA Slicer Step 4.2 - Supports V2 Branch-Propagation Final Candidate

Base: validated Step 3 Print Quality Engine + Step 4 Supports V2 UI/roles.

Adds/preserves:
- Normal support
- Tree / Organic support routing
- Hybrid support routing
- configurable overhang angle
- configurable dense support-interface layers
- build-plate-only option
- separate SUPPORT and SUPPORT_INTERFACE toolpath roles
- persisted support settings in Android SharedPreferences
- scanline support occupancy rasterizer for dense/high-poly models
- O(1) overhang membership via per-layer expanded support mask
- phase-state layer propagation for Tree/Organic/Hybrid branches
- bottom-up plate-connectivity gate for build-plate-only support

Performance fix:
- old Tree/Organic implementation traced every unsupported contact independently to lower layers.
- Step 4.2 propagates equivalent route phases once per layer/cell, merging duplicate deterministic suffix work.
- route phase retains interface/body state and exact merge cadence, preserving output geometry.

Regression gates used before packaging:
- deterministic matrix: 54/54 exact output signatures PASS
- randomized matrix: 288/288 exact output signatures PASS
- boundary matrix: 84/84 exact output signatures PASS
- total old-vs-new comparisons: 426 PASS
- 500-layer support benchmark (192 MB JVM heap): PASS, ~0.61 s planner on this runner
- dense 500-layer / 30-island-per-layer stress: PASS for Tree + Hybrid and plate-only ON/OFF
- Slice Engine V2 contour code and Step 2.5 preview renderer unchanged by this performance change

Final acceptance gate: GitHub Android build + exact 153,340,484-byte Hanuman STL Android 36 emulator regression.
