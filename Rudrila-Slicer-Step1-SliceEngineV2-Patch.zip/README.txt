RUDRILA Slicer Step 4.4 - Preview ANR Hard-Bounded Rendering Candidate

Base: Step 4.3 support engine + fast G-code export.

Preserved byte-for-byte from Step 4.3:
- ContourSlicer.kt
- ToolpathEngine.kt
- GCodeExporter.kt
- VerticalLayerSlider.kt
Therefore support geometry, path ordering, extrusion math, support counts and G-code formatting are unchanged.

Why Step 4.3 still failed Android run #10:
- exact Hanuman slice completed: 500 layers / 90,599 toolpaths / 37.0 g / 2h 9m
- Geometry gate PASS, Supports V2 Tree / Organic 55 deg interface 2
- Android preview did not become responsive within the 60 s regression gate
- Step 4.3 reduced eager bounds work but preview could still traverse/draw too many toolpath points on the UI thread

Step 4.4 fix:
- setResult model-bound setup is hard bounded to <=16 sampled layers, <=160 paths/layer and <=7 points/path
- 3D ghost preview is hard bounded to <=12 sampled historical layers, <=30 sampled paths/layer and <=72 sampled segments/path
- selected 3D layer is hard bounded to <=180 sampled paths and <=140 sampled segments/path
- current-layer top view is hard bounded to <=240 sampled paths and <=180 sampled segments/path
- per-layer bounds are sampled instead of walking every point
- detailed slider statistics are O(path count), removing exact segment-length/time traversal from the UI thread
- underlying slicer output remains untouched; sampling affects display only

Local safety/performance checks:
- ToolpathPreviewView Kotlin syntax/type check with Android/model compatibility stubs: PASS
- synthetic preview stress with 500 layers x 600 paths x 8,000 logical points/path (2.4 billion logical points):
  setResult ~6 ms, first draw ~7 ms on local JVM stub runner
- engine/export hashes unchanged vs Step 4.3: PASS

Final acceptance gate after upload:
GitHub Android build + exact Hanuman Android 36 emulator regression through preview, Support/Interface > 0 layer proof, G-code export and crash/ANR scan.
