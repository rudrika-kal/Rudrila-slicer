RUDRILA SLICER — Step 5.4.3 Preview ANR Isolation

What changed
- Full point-by-point G-code safety scan no longer runs during slice completion before Preview.
- Preview opens immediately after slice/toolpath generation without touching every packed point for preflight.
- Generic printer-ready export still runs full GCodeSafety inside GCodeExporter on the background export executor.
- P2S printer-ready export remains hard-blocked until native Bambu P2S machine start/end integration is complete.
- P2S analysis export remains available and is marked DO_NOT_PRINT.
- Slice engine, Supports V2, ToolpathPreviewView, ToolpathEngine and geometry logic are unchanged from the uploaded Step 5.4.1 base.

Reason
Hanuman emulator run #16 sliced and exported successfully but Android logged an ANR while Preview was acquiring focus. The run showed a 7.2 s focus-event stall and 507 skipped frames immediately after the pre-slice full safety scan had touched the giant packed toolpath dataset. Step 5.4.3 moves that full scan entirely to export-time so Preview does not inherit that CPU/page-pressure burst.
