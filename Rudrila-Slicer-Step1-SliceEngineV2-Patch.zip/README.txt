RUDRILA Slicer Step 4.3 - Supports V2 Final Candidate

Base: validated Step 4.2 support engine + fast G-code export.

Preserved byte-for-byte from current GitHub Step 4.2:
- ContourSlicer.kt
- ToolpathEngine.kt
- GCodeExporter.kt
Therefore support geometry, path ordering, extrusion math and fast G-code formatting are unchanged.

Step 4.3 preview ANR fix:
- avoids eager exact bounds calculation for every layer on the Android UI thread
- samples representative shell/support layers for camera model bounds
- exact layer bounds are calculated lazily only when that layer is inspected
- default preview layer is highest non-empty layer
- keeps Step 2.5 bed centering/orientation and Step 2.3 smooth renderer behavior

Exact Hanuman evidence before this preview patch:
- exact STL 153,340,484 bytes, SHA256 110968b1ae1610b136f664e3d2ebc1ff6106e7cd891e8f500baaa752cbfa437e
- Supports V2 Tree / Organic, 55 deg, interface 2 enabled
- slice complete on Android 36 emulator
- 500 layers, 90,599 toolpaths, 37.0 g, estimated 2h 9m
- Geometry gate: PASS
- remaining failure: opening support-heavy preview triggered Android ANR

Final acceptance gate after upload:
Android build + exact Hanuman emulator regression through preview support-layer verification + G-code export + crash/ANR scan.
