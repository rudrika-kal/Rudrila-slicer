RUDRILA SLICER — Step 5.5 Controlled P2S Bridge

Goal
- Move from software-only P2S profiles to one tightly controlled real-printer validation path.
- Keep general P2S printer-ready export blocked until a broader native machine-template engine is proven.

What changed
- Added P2SControlledBridge.kt.
- Import an already-resolved Bambu Studio P2S 0.4 / PLA safety-cube .gcode.
- The imported file must contain resolved P2S start/end markers, homing/leveling, temperature waits and shutdown; unresolved template variables are rejected.
- Only the centered 20 x 20 x 5 mm Rudrila safety cube, P2S 0.4 profile, Rudrila PLA preset and supports OFF can unlock controlled-test printer-ready export.
- General P2S models remain blocked.
- Generic-printer export behaviour remains unchanged.

Frozen core — byte-for-byte unchanged from Step 5.4.3 green baseline
- ContourSlicer.kt
- ToolpathEngine.kt
- ToolpathPreviewView.kt
- VerticalLayerSlider.kt
- Step5Profiles.kt

Why this design
- Bambu Studio's current P2S machine template is large, firmware-specific and AGPL-licensed. Rudrila does not copy/bundle that template.
- For the controlled test, Rudrila reuses only a user-imported, already-resolved native start/end envelope from a Bambu Studio safety-cube G-code and SHA-256 fingerprints it.
- This avoids guessing proprietary machine sequences while still allowing Rudrila's toolpath body to be physically tested under a known-good P2S envelope.
