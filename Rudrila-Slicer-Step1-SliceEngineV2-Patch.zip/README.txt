Rudrila Slicer Step 2.3 - Smooth 3D Preview patch

Preview-only performance update. Slice engine and G-code exporter are unchanged.

Changes:
- Trigonometry computed once per frame instead of per point.
- Zero-allocation 3D point projection in hot draw loops.
- Whole toolpaths rendered with Canvas.drawPath instead of one drawLine call per segment.
- Lower layers rendered as a lightweight translucent shell; selected layer remains exact/full detail.
- Reduced ghost-layer density during orbit/slider interaction, with higher detail at rest.
- Vertical slider callback throttled to animation frames.
- Slider drag uses lightweight layer status; detailed statistics refresh on release.
- Layer bounds cached once when preview opens.
- Selected/current layer remains crisp and role-colored for layer-by-layer inspection.

The following core files are intentionally unchanged from Step 2.2:
- model/ContourSlicer.kt
- model/ToolpathEngine.kt
- model/GCodeExporter.kt
