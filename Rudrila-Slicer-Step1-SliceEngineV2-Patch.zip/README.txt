RUDRILA Slicer Step 2.4 patch
Fixes 3D preview orientation/bed alignment while preserving Step 2.3 smooth rendering.
Workflow overlay root: overlay/
