RUDRILA Slicer Step 4.2 - Supports V2 Final Candidate + Fast G-code Export

Base: validated Step 3 Print Quality Engine + Step 4 Supports V2 UI/roles.

Adds/preserves:
- Normal support
- Tree / Organic support routing
- Hybrid support routing
- configurable overhang angle
- configurable dense support-interface layers
- build-plate-only option
- separate SUPPORT and SUPPORT_INTERFACE toolpath roles
- persisted support settings in Android SharedPreferences
- scanline support occupancy rasterizer for dense/high-poly models
- O(1) overhang membership via per-layer expanded support mask
- phase-state layer propagation for Tree/Organic/Hybrid branches
- bottom-up plate-connectivity gate for build-plate-only support

Support performance validation:
- deterministic matrix: 54/54 exact output signatures PASS
- randomized matrix: 288/288 exact output signatures PASS
- boundary matrix: 84/84 exact output signatures PASS
- total old-vs-new support comparisons: 426 PASS
- 500-layer support benchmark (192 MB JVM heap): PASS, ~0.61 s planner on local runner
- dense 500-layer / 30-island-per-layer stress: PASS for Tree + Hybrid and plate-only ON/OFF

Exact Hanuman Android 36 emulator run #6:
- exact release STL size/hash verified before test
- import PASS
- Supports V2 enabled PASS
- slice action start positively verified
- slice complete in ~5m33s on GitHub Android emulator
- 500 layers
- 90,599 toolpaths
- 37.0 g estimate
- 2h 9m estimate
- Geometry gate: PASS
- Supports V2: Tree / Organic • 55° • interface 2

G-code export performance fix:
- replaces per-coordinate java String.format(Locale.US, "%.3f") with fixed-3-decimal formatter matching existing rounding semantics
- 500,016 old-vs-new format equivalence cases: PASS
- local formatter benchmark: ~8.8x faster
- Android output writer buffer increased to 256 KiB
- G-code path/flow/speed/acceleration logic unchanged

Final acceptance gate after upload:
GitHub Android build + exact Hanuman emulator regression through preview/support scan, G-code export, and crash/ANR scan.
