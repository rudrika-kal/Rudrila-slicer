RUDRILA Slicer Step 3 - Print Quality Engine V3

Adds a conservative quality-focused toolpath/G-code pass while preserving the Step 2.5
smooth 3D preview and plate-centering correction.

Included in this patch:
- deterministic rear seam placement for closed walls/brim
- bridge detection with bridge speed/flow/acceleration tuning
- overhang-aware wall speed reduction
- Arachne-inspired variable-width narrow gap fill
- volumetric-flow-aware speed caps using actual width/height/flow ratio
- wider/slower first layer with a small flow increase and low acceleration
- conservative exposed-top ironing with low flow and mobile-bounded path density
- phase-aware travel optimization so ironing stays last
- long-travel retract/unretract in exported G-code
- per-path acceleration commands in exported G-code

Workflow overlay root: overlay/
