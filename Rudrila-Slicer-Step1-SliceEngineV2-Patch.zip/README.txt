RUDRILA Slicer Step 5.1 - Printer + Filament Profiles

Base: Step 4.4 exact-Hanuman emulator PASS checkpoint.

Scope
- Add Bambu Lab P2S printer profiles for 0.2 / 0.4 / 0.6 / 0.8 mm nozzles.
- P2S build volume 256 x 256 x 256 mm, max hotend 300 C, max bed 110 C.
- Add balanced PLA / PETG / ABS / TPU 95A presets.
- Add runtime machine caps: print speed, travel speed, print/travel acceleration, Z speed.
- Add filament runtime controls: cooling ramp, retract distance/speed, deretract speed.
- Apply printer + filament limits in ToolpathEngine and GCodeExporter.
- Enforce build-volume Z safety at export.
- Persist Step 5 printer/filament/process selections and basic process overrides.
- Show build/nozzle/motion/temp/flow/cooling/retraction details in the profile dialog.

Compatibility
- Fresh install default remains the legacy DefaultProfiles configuration (Generic CoreXY 256)
  so the exact Hanuman Step 4 regression workflow remains compatible.
- Existing legacy PLA retraction remains 0.8 mm to preserve Print Quality V3 regression behavior.
- Step 5 PLA/PETG/ABS presets use conservative P2S-oriented direct-drive retraction values.
- ContourSlicer.kt, preview rendering, support planning geometry and SupportSettings behavior are unchanged.

P2S profile policy
- Hardware envelope values are based on Bambu Lab published P2S specifications.
- Motion values are intentionally conservative slicer-side caps for the controlled-print phase;
  they are not claims of the firmware's absolute current limits.

Local checks
- Step5Profiles + GCodeExporter Kotlin compile with compatibility model stubs: PASS
- ProfileStore Kotlin compile with Android SharedPreferences stubs: PASS
- P2S 4-nozzle catalog: PASS
- PLA/PETG/ABS/TPU catalog: PASS
- volumetric-flow speed cap: PASS
- cooling ramp: PASS
- profile-driven retract/travel/Z feed in G-code: PASS
- max-Z export blocker: PASS
- legacy 0.8 mm retract compatibility: PASS

Post-upload acceptance
1. Android build Pass 1 + Pass 2 must succeed.
2. Exact Hanuman Android 36 regression must still emit HANUMAN_EMULATOR_REGRESSION_PASS.
3. Step 5 profile selection and G-code header/limits will then be verified from the built APK.
4. Only after software gates are green do a controlled real-printer P2S test; do not treat this patch alone as a printer-send/monitoring implementation.
