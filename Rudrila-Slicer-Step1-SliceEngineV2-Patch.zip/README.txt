STEP 5.4.1 SAFETY SCAN / PREVIEW ANR FIX
- GitHub Hanuman regression #15 proved slicing itself still passed (500 layers, 90,599 paths, Geometry PASS, Tree/Organic supports), but Android showed "Rudrila Slicer isn't responding" immediately after PREVIEW was requested.
- Root cause isolated to Step 5.4's exact full-point safety scan traversing PackedPointList through get(), which materialized a temporary Point2 object for every packed coordinate pair on the giant model.
- Safety scan remains exact across every point; packed toolpaths are now checked directly from their primitive FloatArray storage, avoiding per-point allocation/GC pressure.
- Preview renderer, ToolpathEngine, support planning, G-code geometry and Step 5 profile values are unchanged.
- P2S printer-ready export remains intentionally blocked until native P2S machine start/end integration is validated.

STEP 5.4 CONTROLLED P2S PRINT SAFETY
- Adds full G-code preflight across every layer/path/point before printer-ready export.
- Checks profile validity, nozzle/bed temperature limits, XY build-plate bounds, max Z, monotonic layers,
  layer-height/nozzle compatibility, line width, flow ratio, volumetric flow, speed and acceleration caps.
- Separates ANALYSIS vs PRINTER_READY export. Analysis files are marked DO_NOT_PRINT in the G-code header.
- P2S printer-ready export is intentionally hard-blocked until a native P2S machine start/end sequence is integrated.
- This gate is based on the current official Bambu Studio P2S profile requiring printer-specific startup/end
  behavior beyond generic homing/heating (plate detection, calibration/leveling, tool/AMS and machine commands).
- Generic printer profiles continue to support printer-ready export after preflight passes.
- Slice Engine V2, ToolpathEngine, Supports V2, Step 5 profiles and preview renderer are unchanged.
- Prepared controlled-test asset: RUDRILA_P2S_SAFETY_CUBE_20x20x5.stl.

STEP 5.3 PREVIEW POLISH
- Preview opens on the last real printable layer (post-layout lock), never an empty terminal layer.
- 3D ghost walls get a bounded translucent surface under-stroke for a smoother, less wireframe look.
- Slice, support, Step 5 profiles and G-code generation logic are unchanged.

RUDRILA Slicer Step 5.1 - Printer + Filament Profiles

Base: Step 4.4 exact-Hanuman emulator PASS checkpoint.

Scope
- Add Bambu Lab P2S printer profiles for 0.2 / 0.4 / 0.6 / 0.8 mm nozzles.
- P2S build volume 256 x 256 x 256 mm, max hotend 300 C, max bed 110 C.
- Add balanced PLA / PETG / ABS / TPU 95A presets.
- Add runtime machine caps: print speed, travel speed, print/travel acceleration, Z speed.
- Add filament runtime controls: cooling ramp, retract distance/speed, deretract speed.
- Apply printer + filament limits in ToolpathEngine and GCodeExporter.
- Enforce build-volume Z safety at export.
- Persist Step 5 printer/filament/process selections and basic process overrides.
- Show build/nozzle/motion/temp/flow/cooling/retraction details in the profile dialog.

Compatibility
- Fresh install default remains the legacy DefaultProfiles configuration (Generic CoreXY 256)
  so the exact Hanuman Step 4 regression workflow remains compatible.
- Existing legacy PLA retraction remains 0.8 mm to preserve Print Quality V3 regression behavior.
- Step 5 PLA/PETG/ABS presets use conservative P2S-oriented direct-drive retraction values.
- ContourSlicer.kt, preview rendering, support planning geometry and SupportSettings behavior are unchanged.

P2S profile policy
- Hardware envelope values are based on Bambu Lab published P2S specifications.
- Motion values are intentionally conservative slicer-side caps for the controlled-print phase;
  they are not claims of the firmware's absolute current limits.

Local checks
- Step5Profiles + GCodeExporter Kotlin compile with compatibility model stubs: PASS
- ProfileStore Kotlin compile with Android SharedPreferences stubs: PASS
- P2S 4-nozzle catalog: PASS
- PLA/PETG/ABS/TPU catalog: PASS
- volumetric-flow speed cap: PASS
- cooling ramp: PASS
- profile-driven retract/travel/Z feed in G-code: PASS
- max-Z export blocker: PASS
- legacy 0.8 mm retract compatibility: PASS

Post-upload acceptance
1. Android build Pass 1 + Pass 2 must succeed.
2. Exact Hanuman Android 36 regression must still emit HANUMAN_EMULATOR_REGRESSION_PASS.
3. Step 5 profile selection and G-code header/limits will then be verified from the built APK.
4. Only after software gates are green do a controlled real-printer P2S test; do not treat this patch alone as a printer-send/monitoring implementation.


STEP 5.2 PREVIEW CONTINUITY FIX
- Fixes sparse/disappearing 3D preview reported on tall 500-layer models.
- Normal 3D view now distributes up to 64 bounded ghost layers through the selected cut height.
- Ghost path selection is role-aware, prioritizing walls so infill-heavy layers cannot cause wall silhouettes to be skipped.
- Point sampling remains bounded (30 segments/path normal; 20 while interacting) to avoid reintroducing the Step 4 preview ANR.
- Preview opens on the last non-empty printable layer instead of an empty terminal layer.
- No slicing, support generation, print-quality, Step 5 profiles, or G-code geometry logic changed.
