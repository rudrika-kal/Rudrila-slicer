package com.rudrila.slicer.model

import kotlin.math.min

/**
 * Step 5 printer/filament runtime limits.
 *
 * PrintProfiles.kt remains the compatibility model used by the alpha project.  This catalog
 * adds machine-motion, cooling and retraction data without breaking old saved configurations.
 */
data class MachineRuntimeProfile(
    val maxPrintSpeedMmS: Float,
    val maxTravelSpeedMmS: Float,
    val maxPrintAccelerationMmS2: Int,
    val maxTravelAccelerationMmS2: Int,
    val maxZSpeedMmS: Float
)

data class FilamentRuntimeProfile(
    val firstLayerFanPercent: Int,
    val minFanPercent: Int,
    val maxFanPercent: Int,
    val fanFullAfterLayer: Int,
    val retractDistanceMm: Float,
    val retractSpeedMmS: Float,
    val deretractSpeedMmS: Float
)

object Step5Profiles {
    private fun p2s(id: String, nozzle: Float): PrinterProfile = PrinterProfile(
        id = id,
        name = "Bambu Lab P2S • ${"%.1f".format(nozzle)} mm",
        bedX = 256f,
        bedY = 256f,
        bedZ = 256f,
        nozzleDiameter = nozzle,
        filamentDiameter = 1.75f,
        maxHotendTempC = 300,
        maxBedTempC = 110
    )

    val printers: List<PrinterProfile> = buildList {
        add(p2s("bambu_p2s_04", 0.4f))
        add(p2s("bambu_p2s_02", 0.2f))
        add(p2s("bambu_p2s_06", 0.6f))
        add(p2s("bambu_p2s_08", 0.8f))
        DefaultProfiles.printers.forEach { legacy -> if (none { it.id == legacy.id }) add(legacy) }
    }

    val filaments: List<FilamentProfile> = buildList {
        add(FilamentProfile("step5_pla", "Generic PLA • Balanced", "PLA", 220, 55, 1.24f, 18f))
        add(FilamentProfile("step5_petg", "Generic PETG • Balanced", "PETG", 250, 75, 1.27f, 12f))
        add(FilamentProfile("step5_abs", "Generic ABS • Enclosed", "ABS", 260, 100, 1.04f, 16f))
        add(FilamentProfile("step5_tpu95a", "Generic TPU 95A • Safe", "TPU", 230, 45, 1.21f, 4.5f))
        DefaultProfiles.filaments.forEach { legacy -> if (none { it.id == legacy.id }) add(legacy) }
    }

    val processes: List<ProcessProfile> get() = DefaultProfiles.processes

    fun defaultConfiguration(): PrintConfiguration = DefaultProfiles.defaultConfiguration().also { validate(it) }

    /** Conservative slicer caps. They intentionally do not chase firmware beta maximums. */
    fun machine(printer: PrinterProfile): MachineRuntimeProfile = when {
        printer.id.startsWith("bambu_p2s_") -> MachineRuntimeProfile(
            maxPrintSpeedMmS = 500f,
            maxTravelSpeedMmS = 600f,
            maxPrintAccelerationMmS2 = 10_000,
            maxTravelAccelerationMmS2 = 10_000,
            maxZSpeedMmS = 20f
        )
        printer.name.contains("CoreXY", ignoreCase = true) -> MachineRuntimeProfile(300f, 400f, 8_000, 8_000, 15f)
        else -> MachineRuntimeProfile(220f, 250f, 4_000, 5_000, 12f)
    }

    fun material(filament: FilamentProfile): FilamentRuntimeProfile {
        val id = filament.id.lowercase()
        val material = filament.material.uppercase()
        return when {
            id == "step5_pla" -> FilamentRuntimeProfile(0, 70, 100, 3, 0.6f, 35f, 35f)
            id == "step5_petg" -> FilamentRuntimeProfile(0, 20, 60, 4, 0.6f, 30f, 30f)
            id == "step5_abs" -> FilamentRuntimeProfile(0, 0, 25, 5, 0.6f, 30f, 30f)
            id == "step5_tpu95a" -> FilamentRuntimeProfile(0, 35, 70, 4, 0.4f, 20f, 20f)
            material == "PLA" -> FilamentRuntimeProfile(0, 70, 100, 3, 0.8f, 35f, 35f)
            material == "PETG" -> FilamentRuntimeProfile(0, 20, 60, 4, 0.8f, 30f, 30f)
            material == "ABS" || material == "ASA" -> FilamentRuntimeProfile(0, 0, 25, 5, 0.8f, 30f, 30f)
            material.startsWith("TPU") -> FilamentRuntimeProfile(0, 35, 70, 4, 0.6f, 20f, 20f)
            else -> FilamentRuntimeProfile(0, 30, 80, 4, 0.8f, 30f, 30f)
        }
    }

    fun fanPercentForLayer(filament: FilamentProfile, layerIndex: Int): Int {
        val f = material(filament)
        if (layerIndex <= 0) return f.firstLayerFanPercent.coerceIn(0, 100)
        if (f.maxFanPercent <= f.minFanPercent) return f.maxFanPercent.coerceIn(0, 100)
        val rampEnd = f.fanFullAfterLayer.coerceAtLeast(2)
        if (layerIndex + 1 >= rampEnd) return f.maxFanPercent.coerceIn(0, 100)
        val t = (layerIndex.toFloat() / (rampEnd - 1).toFloat()).coerceIn(0f, 1f)
        return (f.minFanPercent + (f.maxFanPercent - f.minFanPercent) * t).toInt().coerceIn(0, 100)
    }

    fun extrusionSpeedLimitMmS(
        config: PrintConfiguration,
        lineWidthMm: Float,
        layerHeightMm: Float,
        flowRatio: Float = 1f
    ): Float {
        val machineLimit = machine(config.printer).maxPrintSpeedMmS
        val area = (lineWidthMm * layerHeightMm * flowRatio.coerceAtLeast(0.05f)).coerceAtLeast(0.01f)
        val volumetricLimit = config.filament.maxVolumetricSpeedMm3s / area
        return min(machineLimit, volumetricLimit).coerceAtLeast(5f)
    }

    fun capExtrusionSpeedMmS(
        requestedMmS: Float,
        config: PrintConfiguration,
        lineWidthMm: Float,
        layerHeightMm: Float,
        flowRatio: Float = 1f
    ): Float = min(requestedMmS, extrusionSpeedLimitMmS(config, lineWidthMm, layerHeightMm, flowRatio)).coerceAtLeast(5f)

    fun validate(config: PrintConfiguration) {
        config.validate()
        val machine = machine(config.printer)
        val filament = material(config.filament)
        require(config.printer.bedX in 50f..1000f && config.printer.bedY in 50f..1000f && config.printer.bedZ in 50f..1000f) { "Invalid printer build volume" }
        require(config.printer.nozzleDiameter in 0.1f..1.2f) { "Unsupported nozzle diameter" }
        require(machine.maxPrintSpeedMmS in 5f..1000f && machine.maxTravelSpeedMmS in 5f..1500f) { "Invalid machine speed limits" }
        require(machine.maxPrintAccelerationMmS2 in 100..30_000 && machine.maxTravelAccelerationMmS2 in 100..30_000) { "Invalid machine acceleration limits" }
        require(config.filament.maxVolumetricSpeedMm3s in 0.5f..80f) { "Invalid filament volumetric flow" }
        require(filament.firstLayerFanPercent in 0..100 && filament.minFanPercent in 0..100 && filament.maxFanPercent in 0..100) { "Invalid cooling profile" }
        require(filament.retractDistanceMm in 0f..8f && filament.retractSpeedMmS in 1f..100f) { "Invalid retraction profile" }
    }
}
