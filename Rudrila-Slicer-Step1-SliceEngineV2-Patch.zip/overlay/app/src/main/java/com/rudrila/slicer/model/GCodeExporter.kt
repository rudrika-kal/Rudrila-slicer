package com.rudrila.slicer.model

import java.util.Locale
import kotlin.math.PI
import kotlin.math.hypot

object GCodeExporter {
    private const val RETRACT_DISTANCE_MM = 0.80f
    private const val RETRACT_SPEED_MM_S = 35f
    private const val RETRACT_TRAVEL_THRESHOLD_MM = 1.5f
    private const val TRAVEL_ACCEL_MM_S2 = 4000

    fun generate(toolpaths:ToolpathResult, config:PrintConfiguration):String = buildString { write(toolpaths,config,this) }

    /** Streams G-code to any Appendable so Android export does not need to keep a huge file in RAM. */
    fun write(toolpaths:ToolpathResult, config:PrintConfiguration, out:Appendable) {
        config.validate()
        require(toolpaths.canExport) {
            toolpaths.exportBlockReason ?: "Slice geometry is not export-safe; repair the model before G-code export"
        }
        fun f(v:Float)=String.format(Locale.US,"%.3f",v)
        fun line(s:String){out.append(s).append('\n')}
        line("; Rudrila Slicer Alpha 0.7")
        line("; Print Quality Engine V3")
        line("; printer=${config.printer.name}")
        line("; filament=${config.filament.name}")
        line("; process=${config.process.name}")
        line("; estimated_time_s=${toolpaths.estimate.timeSeconds}")
        line("; filament_mm=${f(toolpaths.estimate.filamentLengthMm)}")
        line("G90 ; absolute XYZ")
        line("M83 ; relative extrusion")
        line("M140 S${config.filament.bedTempC}")
        line("M104 S${config.filament.nozzleTempC}")
        line("G28")
        line("M190 S${config.filament.bedTempC}")
        line("M109 S${config.filament.nozzleTempC}")
        line("G92 E0")

        val filamentArea=(PI*(config.printer.filamentDiameter/2f)*(config.printer.filamentDiameter/2f)).toFloat()
        var last:Point2?=null
        var currentAccel = -1
        var retracted = false
        val retractFeed = (RETRACT_SPEED_MM_S * 60f).toInt()

        fun machine(p:Point2)=Point2(p.x+config.printer.bedX/2f,p.y+config.printer.bedY/2f)
        fun checkBed(p:Point2){require(p.x in 0f..config.printer.bedX && p.y in 0f..config.printer.bedY) { "Toolpath is outside printer bed" }}
        fun setAccel(value:Int){
            val v=value.coerceIn(100,20000)
            if(v!=currentAccel){line("M204 S$v");currentAccel=v}
        }
        fun retract(){
            if(!retracted){line("G1 E-${f(RETRACT_DISTANCE_MM)} F$retractFeed");retracted=true}
        }
        fun unretract(){
            if(retracted){line("G1 E${f(RETRACT_DISTANCE_MM)} F$retractFeed");retracted=false}
        }

        toolpaths.layers.forEach{layer->
            line(";LAYER:${layer.index}")
            line("G0 Z${f(layer.z)} F900")
            for(path in layer.paths){
                if(path.points.size<2)continue
                val start=path.points.first();val ms=machine(start);checkBed(ms)
                val travel = last?.let { hypot((start.x-it.x).toDouble(),(start.y-it.y).toDouble()).toFloat() } ?: 0f
                if(last==null || travel>0.01f){
                    if(last!=null && travel>=RETRACT_TRAVEL_THRESHOLD_MM) retract()
                    setAccel(TRAVEL_ACCEL_MM_S2)
                    line("G0 X${f(ms.x)} Y${f(ms.y)} F9000")
                    unretract()
                }

                val pathAccel = when {
                    path.accelerationMmS2 > 0 -> path.accelerationMmS2
                    path.bridge -> 900
                    path.ironing -> 1200
                    else -> 1800
                }
                setAccel(pathAccel)
                line(";TYPE:${path.role.name}")
                if(path.bridge) line(";QUALITY:BRIDGE")
                if(path.ironing) line(";QUALITY:IRONING")
                if(path.role==PathRole.WALL && path.closed) line(";SEAM:REAR")
                val feed=(path.speedMmS*60f).toInt().coerceAtLeast(60)
                var prev=start
                for(i in 1 until path.points.size){
                    val cur=path.points[i];val len=hypot((cur.x-prev.x).toDouble(),(cur.y-prev.y).toDouble()).toFloat()
                    val mc=machine(cur);checkBed(mc)
                    if(len>1e-5f){
                        val e=(len*path.widthMm*layer.heightMm*path.flowRatio.coerceAtLeast(0f))/filamentArea
                        line("G1 X${f(mc.x)} Y${f(mc.y)} E${f(e)} F$feed")
                    }
                    prev=cur
                }
                last=path.points.last()
            }
        }
        if(retracted) unretract()
        line("M400")
        line("M104 S0")
        line("M140 S0")
        line("G91")
        line("G1 Z5 F600")
        line("G90")
        line("M84")
    }
}
