package com.rudrila.slicer.model

import kotlin.math.PI
import kotlin.math.hypot

object GCodeExporter {
    private const val RETRACT_TRAVEL_THRESHOLD_MM = 1.5f

    fun generate(toolpaths:ToolpathResult, config:PrintConfiguration):String = buildString { write(toolpaths,config,this) }

    /** Streams G-code to any Appendable so Android export does not need to keep a huge file in RAM. */
    fun write(toolpaths:ToolpathResult, config:PrintConfiguration, out:Appendable) {
        Step5Profiles.validate(config)
        val machineProfile = Step5Profiles.machine(config.printer)
        val filamentProfile = Step5Profiles.material(config.filament)
        require(toolpaths.canExport) {
            toolpaths.exportBlockReason ?: "Slice geometry is not export-safe; repair the model before G-code export"
        }
        // Fast fixed-3-decimal formatter. java.lang.String.format is extremely expensive on
        // Android when a support-heavy model emits millions of XYZ/E numbers. Toolpath
        // coordinates are finite and comfortably inside Int range after scaling by 1000.
        fun f(v:Float):String {
            val x=v.toDouble()*1000.0
            // Match Formatter's HALF_UP-at-3-decimals behavior, including negative ties,
            // while avoiding Formatter/Locale allocation on every coordinate.
            val scaled=(if(x>=0.0) kotlin.math.floor(x+0.5) else kotlin.math.ceil(x-0.5)).toInt()
            if(scaled==0)return if(v<0f) "-0.000" else "0.000"
            val negative=scaled<0
            val a=if(scaled==Int.MIN_VALUE) Int.MAX_VALUE else kotlin.math.abs(scaled)
            val whole=a/1000
            val frac=a%1000
            return buildString(16){
                if(negative)append('-')
                append(whole).append('.')
                if(frac<100)append('0')
                if(frac<10)append('0')
                append(frac)
            }
        }
        fun line(s:String){out.append(s).append('\n')}
        line("; Rudrila Slicer Alpha 0.7")
        line("; Step 5 Printer + Filament Profiles")
        line("; Print Quality Engine V3 + Supports V2")
        line("; printer=${config.printer.name}")
        line("; nozzle_mm=${f(config.printer.nozzleDiameter)}")
        line("; build_volume_mm=${f(config.printer.bedX)}x${f(config.printer.bedY)}x${f(config.printer.bedZ)}")
        line("; machine_print_cap_mm_s=${f(machineProfile.maxPrintSpeedMmS)}")
        line("; machine_travel_cap_mm_s=${f(machineProfile.maxTravelSpeedMmS)}")
        line("; machine_accel_cap_mm_s2=${machineProfile.maxPrintAccelerationMmS2}")
        line("; filament=${config.filament.name}")
        line("; filament_max_flow_mm3_s=${f(config.filament.maxVolumetricSpeedMm3s)}")
        line("; cooling_percent=${filamentProfile.minFanPercent}-${filamentProfile.maxFanPercent}")
        line("; retract_mm=${f(filamentProfile.retractDistanceMm)}")
        line("; process=${config.process.name}")
        line("; estimated_time_s=${toolpaths.estimate.timeSeconds}")
        line("; filament_mm=${f(toolpaths.estimate.filamentLengthMm)}")
        line("G90 ; absolute XYZ")
        line("M83 ; relative extrusion")
        line("M140 S${config.filament.bedTempC}")
        line("M104 S${config.filament.nozzleTempC}")
        line("G28")
        line("M190 S${config.filament.bedTempC}")
        line("M109 S${config.filament.nozzleTempC}")
        line("M107 ; cooling fan off for first layer")
        line("G92 E0")

        val filamentArea=(PI*(config.printer.filamentDiameter/2f)*(config.printer.filamentDiameter/2f)).toFloat()
        var last:Point2?=null
        var currentAccel = -1
        var retracted = false
        val retractFeed = (filamentProfile.retractSpeedMmS * 60f).toInt().coerceAtLeast(60)
        val deretractFeed = (filamentProfile.deretractSpeedMmS * 60f).toInt().coerceAtLeast(60)
        val travelFeed = (machineProfile.maxTravelSpeedMmS * 60f).toInt().coerceAtLeast(60)
        val zFeed = (machineProfile.maxZSpeedMmS * 60f).toInt().coerceAtLeast(60)
        val maxAnyAccel = maxOf(machineProfile.maxPrintAccelerationMmS2, machineProfile.maxTravelAccelerationMmS2)
        var currentFanPercent = -1

        fun machine(p:Point2)=Point2(p.x+config.printer.bedX/2f,p.y+config.printer.bedY/2f)
        fun checkBed(p:Point2){require(p.x in 0f..config.printer.bedX && p.y in 0f..config.printer.bedY) { "Toolpath is outside printer bed" }}
        fun setAccel(value:Int){
            val v=value.coerceIn(100,maxAnyAccel.coerceAtLeast(100))
            if(v!=currentAccel){line("M204 S$v");currentAccel=v}
        }
        fun retract(){
            if(!retracted && filamentProfile.retractDistanceMm > 0f){line("G1 E-${f(filamentProfile.retractDistanceMm)} F$retractFeed");retracted=true}
        }
        fun unretract(){
            if(retracted){line("G1 E${f(filamentProfile.retractDistanceMm)} F$deretractFeed");retracted=false}
        }

        fun setFan(percent:Int){
            val p=percent.coerceIn(0,100)
            if(p==currentFanPercent)return
            if(p<=0)line("M107") else line("M106 S${(p*255/100).coerceIn(1,255)}")
            currentFanPercent=p
        }

        toolpaths.layers.forEach{layer->
            require(layer.z >= -0.001f && layer.z <= config.printer.bedZ + 0.001f) { "Toolpath exceeds printer max Z" }
            line(";LAYER:${layer.index}")
            setFan(Step5Profiles.fanPercentForLayer(config.filament,layer.index))
            line("G0 Z${f(layer.z)} F$zFeed")
            for(path in layer.paths){
                if(path.points.size<2)continue
                val start=path.points.first();val ms=machine(start);checkBed(ms)
                val travel = last?.let { hypot((start.x-it.x).toDouble(),(start.y-it.y).toDouble()).toFloat() } ?: 0f
                if(last==null || travel>0.01f){
                    if(last!=null && travel>=RETRACT_TRAVEL_THRESHOLD_MM) retract()
                    setAccel(machineProfile.maxTravelAccelerationMmS2)
                    line("G0 X${f(ms.x)} Y${f(ms.y)} F$travelFeed")
                    unretract()
                }

                val pathAccel = when {
                    path.accelerationMmS2 > 0 -> path.accelerationMmS2
                    path.bridge -> 900
                    path.ironing -> 1200
                    else -> 1800
                }
                setAccel(pathAccel.coerceAtMost(machineProfile.maxPrintAccelerationMmS2))
                line(";TYPE:${path.role.name}")
                if(path.bridge) line(";QUALITY:BRIDGE")
                if(path.ironing) line(";QUALITY:IRONING")
                if(path.role==PathRole.WALL && path.closed) line(";SEAM:REAR")
                val safeSpeed=Step5Profiles.capExtrusionSpeedMmS(path.speedMmS,config,path.widthMm,layer.heightMm,path.flowRatio)
                val feed=(safeSpeed*60f).toInt().coerceAtLeast(60)
                var prev=start
                for(i in 1 until path.points.size){
                    val cur=path.points[i];val len=hypot((cur.x-prev.x).toDouble(),(cur.y-prev.y).toDouble()).toFloat()
                    val mc=machine(cur);checkBed(mc)
                    if(len>1e-5f){
                        val e=(len*path.widthMm*layer.heightMm*path.flowRatio.coerceAtLeast(0f))/filamentArea
                        line("G1 X${f(mc.x)} Y${f(mc.y)} E${f(e)} F$feed")
                    }
                    prev=cur
                }
                last=path.points.last()
            }
        }
        if(retracted) unretract()
        line("M400")
        line("M107")
        line("M104 S0")
        line("M140 S0")
        line("G91")
        line("G1 Z5 F600")
        line("G90")
        line("M84")
    }
}
