package com.rudrila.slicer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import com.rudrila.slicer.model.StlParser
import com.rudrila.slicer.model.Step5Profiles
import com.rudrila.slicer.model.ContourSlicer
import com.rudrila.slicer.model.SliceResult
import com.rudrila.slicer.model.PrintConfiguration
import com.rudrila.slicer.model.ProfileStore
import com.rudrila.slicer.model.ProfilePolicy
import com.rudrila.slicer.model.ThreeMfParser
import com.rudrila.slicer.model.TransformState
import com.rudrila.slicer.model.TransformMath
import com.rudrila.slicer.model.ToolpathEngine
import com.rudrila.slicer.model.ToolpathResult
import com.rudrila.slicer.model.GCodeExporter
import com.rudrila.slicer.model.ExportPurpose
import com.rudrila.slicer.model.SupportSettings
import com.rudrila.slicer.model.P2SNativeEnvelope
import com.rudrila.slicer.model.P2SControlledBridge
import com.rudrila.slicer.model.ModelExporter
import com.rudrila.slicer.model.ModelExportFormat
import com.rudrila.slicer.model.SceneObject
import com.rudrila.slicer.ui.SlicerGLSurfaceView
import com.rudrila.slicer.ui.ToolpathPreviewView
import com.rudrila.slicer.ui.VerticalLayerSlider
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class MainActivity : Activity() {
    private lateinit var glView:SlicerGLSurfaceView
    private lateinit var statusText:TextView
    private lateinit var modeText:TextView
    private lateinit var selectedText:TextView
    private lateinit var profileText:TextView
    private lateinit var profileStore:ProfileStore
    private lateinit var printConfig:PrintConfiguration
    @Volatile private var lastSlice:SliceResult?=null
    @Volatile private var lastToolpaths:ToolpathResult?=null
    @Volatile private var pendingP2SEnvelope:P2SNativeEnvelope?=null
    private val executor=Executors.newSingleThreadExecutor()
    private val stateRevision=AtomicLong(0L)
    private val sliceRequestId=AtomicLong(0L)
    private val sliceBusy=AtomicBoolean(false)
    private data class PendingExportTicket(
        val toolpaths:ToolpathResult,
        val config:PrintConfiguration,
        val purpose:ExportPurpose,
        val envelope:P2SNativeEnvelope?,
        val revision:Long
    )
    @Volatile private var pendingExportTicket:PendingExportTicket?=null
    private data class PendingModelExportTicket(
        val objects:List<SceneObject>,
        val format:ModelExportFormat,
        val revision:Long
    )
    @Volatile private var pendingModelExportTicket:PendingModelExportTicket?=null
    private val openCode=7001
    private val saveCode=7002
    private val p2sReferenceCode=7003
    private val saveModelCode=7004
    private val p2sEnvelopeFileName="p2s_controlled_envelope_v3.txt"

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.rgb(16,18,20);window.navigationBarColor=Color.rgb(16,18,20)
        profileStore=ProfileStore(this);printConfig=profileStore.load()
        loadSupportV2Settings()
        // V1 cached references did not validate the imported reference body. Never reuse them.
        runCatching{java.io.File(filesDir,"p2s_controlled_envelope_v1.txt").delete()}
        runCatching{java.io.File(filesDir,"p2s_controlled_envelope_v2.txt").delete()}
        pendingP2SEnvelope=loadP2SEnvelope()
        val startupAuditError=ProfileStore.runPersistenceSelfTest(this)
        setContentView(buildUi())
        if(startupAuditError!=null){
            statusText.text="Profile self-audit failed • $startupAuditError"
            statusText.setTextColor(Color.rgb(255,120,120))
        }
    }

    private fun buildUi():View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(16,18,20))}

        // Step 5.7.1 responsive header: keep title/status on their own full-width row.
        // Putting four wrap-content action buttons beside a weighted title can leave the title
        // with ~0 px width on phones, causing one-character-per-line wrapping and a huge header.
        val titleWrap=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(16),dp(9),dp(12),dp(5))
        }
        val title=TextView(this).apply{
            text="RUDRILA SLICER";textSize=19f;setTextColor(Color.WHITE);setTypeface(typeface,1)
            maxLines=1
        }
        statusText=TextView(this).apply{
            text="Mobile slicing workspace • Slice Engine V2 • Supports V2 • Step 5.7.1 Model Save"
            textSize=11f;setTextColor(Color.rgb(155,165,170));maxLines=2
        }
        titleWrap.addView(title,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))
        titleWrap.addView(statusText,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(titleWrap,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))

        val actions=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(8),dp(3),dp(8),dp(7))
        }
        fun addAction(label:String,onClick:()->Unit){
            actions.addView(actionButton(label,onClick),LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),0,dp(2),0)})
        }
        addAction("IMPORT"){openModels()}
        addAction("SLICE"){slicePlate()}
        addAction("PREVIEW"){showPreview()}
        addAction("SAVE"){showSaveModelDialog()}
        root.addView(actions,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))

        modeText=TextView(this).apply{text="VIEW • tap model to select • orbit / pan / zoom";gravity=Gravity.CENTER;setPadding(8,dp(6),8,dp(6));setTextColor(Color.rgb(126,224,187));textSize=11f}
        root.addView(modeText)
        profileText=TextView(this).apply{gravity=Gravity.CENTER;setPadding(8,dp(6),8,dp(6));setTextColor(Color.rgb(190,195,198));textSize=10f;setBackgroundColor(Color.rgb(22,25,28));setOnClickListener{showProfileDialog()}}
        root.addView(profileText);updateProfileLabel()

        glView=SlicerGLSurfaceView(this).apply{
            onSelectionChanged={runOnUiThread{if(!isFinishing && !isDestroyed)updateSelectedLabel()}}
            onStatus={msg->runOnUiThread{if(!isFinishing && !isDestroyed)statusText.text=msg}}
            onSceneChanged={invalidateSlice()}
        }
        root.addView(glView,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f))

        val selection=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(3),dp(8),dp(3))}
        selection.addView(smallButton("◀"){glView.sceneState.selectNext(-1);glView.refreshScene();updateSelectedLabel()},LinearLayout.LayoutParams(dp(48),dp(56)))
        selectedText=TextView(this).apply{text="No model";gravity=Gravity.CENTER;setTextColor(Color.WHITE);textSize=10.5f;maxLines=2;setOnClickListener{showObjectsDialog()}}
        selection.addView(selectedText,LinearLayout.LayoutParams(0,dp(56),1f))
        selection.addView(smallButton("▶"){glView.sceneState.selectNext(1);glView.refreshScene();updateSelectedLabel()},LinearLayout.LayoutParams(dp(48),dp(56)))
        selection.addView(smallButton("SIZE"){showSizeDialog()},LinearLayout.LayoutParams(dp(68),dp(56)))
        selection.addView(smallButton("EXACT"){showExactTransformDialog()},LinearLayout.LayoutParams(dp(68),dp(56)))
        root.addView(selection)

        val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(3),dp(6),dp(3))}
        quick.addView(toolMini("CENTER"){glView.sceneState.centerSelected();invalidateSlice();glView.refreshScene();statusText.text="Selected model centered"})
        quick.addView(toolMini("BED"){glView.sceneState.placeSelectedOnBed();invalidateSlice();glView.refreshScene();statusText.text="Selected model placed on bed"})
        quick.addView(toolMini("DUP"){val x=glView.sceneState.duplicateSelected();if(x!=null)invalidateSlice();glView.refreshScene();statusText.text=if(x!=null)"Duplicated ${x.name}" else "Select a model first"})
        quick.addView(toolMini("DEL"){val x=glView.sceneState.deleteSelected();if(x!=null)invalidateSlice();glView.refreshScene();statusText.text=if(x!=null)"Deleted ${x.name}" else "Select a model first"})
        quick.addView(toolMini("ARRANGE"){glView.sceneState.autoArrange();invalidateSlice();glView.refreshScene(true);statusText.text="Models auto-arranged"})
        root.addView(quick)

        val tools=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(4),dp(6),dp(12));setBackgroundColor(Color.rgb(22,25,28))}
        tools.addView(toolButton("VIEW"){selectMode(SlicerGLSurfaceView.InteractionMode.VIEW)})
        tools.addView(toolButton("MOVE"){selectMode(SlicerGLSurfaceView.InteractionMode.MOVE)})
        tools.addView(toolButton("ROTATE"){selectMode(SlicerGLSurfaceView.InteractionMode.ROTATE)})
        tools.addView(toolButton("SCALE"){selectMode(SlicerGLSurfaceView.InteractionMode.SCALE)})
        tools.addView(toolButton("FACE"){selectMode(SlicerGLSurfaceView.InteractionMode.LAY_FACE)})
        root.addView(tools)
        return root
    }

    private fun selectMode(mode:SlicerGLSurfaceView.InteractionMode){
        glView.interactionMode=mode
        modeText.text=when(mode){
            SlicerGLSurfaceView.InteractionMode.VIEW->"VIEW • tap model to select • orbit / pan / zoom"
            SlicerGLSurfaceView.InteractionMode.MOVE->"MOVE • drag selected model across build plate"
            SlicerGLSurfaceView.InteractionMode.ROTATE->"ROTATE • horizontal = Z • vertical = X"
            SlicerGLSurfaceView.InteractionMode.SCALE->"SCALE • drag vertically or pinch"
            SlicerGLSurfaceView.InteractionMode.LAY_FACE->"FACE • tap the face you want placed on the bed"
        }
    }

    private fun updateSelectedLabel(){
        val s=glView.sceneState.selected()
        selectedText.text=if(s==null) "No model" else {
            val b=TransformMath.transformedBoxBounds(s.mesh,s.transform)
            "${s.name}\nX ${"%.1f".format(b.width)}  Y ${"%.1f".format(b.depth)}  Z ${"%.1f".format(b.height)} mm"
        }
    }

    /** Bambu-style physical size editor. Lock proportions for uniform scaling, or unlock X/Y/Z. */
    private fun showSizeDialog(){
        val selected=glView.sceneState.selected()?:run{toast("Select a model first");return}
        val current=selected.transform
        val bounds=TransformMath.transformedBoxBounds(selected.mesh,current)
        val base=floatArrayOf(bounds.width.coerceAtLeast(0.001f),bounds.depth.coerceAtLeast(0.001f),bounds.height.coerceAtLeast(0.001f))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(10),dp(22),0)}
        val hint=TextView(this).apply{
            text="Size in mm • lock = keep proportions • unlock = change X / Y / Z separately."
            setTextColor(Color.DKGRAY);textSize=12f;setPadding(0,0,0,dp(6))
        }
        box.addView(hint)
        val lock=CheckBox(this).apply{
            text="Lock proportions"
            isChecked=true
            setTextColor(Color.DKGRAY)
            setPadding(0,0,0,dp(6))
        }
        box.addView(lock)
        val fields=ArrayList<EditText>(3)
        val labels=arrayOf("X mm","Y mm","Z mm")
        for(i in 0..2){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(TextView(this).apply{text=labels[i];setTextColor(Color.DKGRAY)},LinearLayout.LayoutParams(dp(70),dp(50)))
            val edit=EditText(this).apply{setText("%.2f".format(base[i]));inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;selectAll()}
            fields+=edit;row.addView(edit,LinearLayout.LayoutParams(0,dp(50),1f));box.addView(row)
        }
        var syncing=false
        var lastEditedAxis=0
        fun syncLocked(source:Int){
            if(!lock.isChecked || syncing)return
            val target=fields[source].text.toString().toFloatOrNull()?.takeIf{it.isFinite() && it>0f}?:return
            val ratio=target/base[source]
            syncing=true
            for(i in 0..2) if(i!=source){
                val text="%.2f".format(base[i]*ratio)
                if(fields[i].text.toString()!=text) fields[i].setText(text)
            }
            syncing=false
        }
        fields.forEachIndexed { source, edit ->
            edit.addTextChangedListener(object:TextWatcher{
                override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
                override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){}
                override fun afterTextChanged(e:Editable?){
                    if(syncing)return
                    lastEditedAxis=source
                    syncLocked(source)
                }
            })
        }
        lock.setOnCheckedChangeListener { _, checked ->
            hint.text=if(checked) "Locked • editing one axis changes all axes proportionally." else "Unlocked • X, Y and Z can be changed independently."
            if(checked) syncLocked(lastEditedAxis)
        }
        AlertDialog.Builder(this).setTitle("Model size • ${selected.name}").setView(box)
            .setNegativeButton("Cancel",null)
            .setNeutralButton("100%"){_,_->
                glView.sceneState.updateSelected(current.copy(scale=1f,scaleX=1f,scaleY=1f,scaleZ=1f),placeOnBed=true)
                invalidateSlice();glView.refreshScene(true);updateSelectedLabel();statusText.text="Size reset to 100%"
            }
            .setPositiveButton("Apply"){_,_->
                fun finiteSize(text:String,fallback:Float)=text.toFloatOrNull()?.takeIf{it.isFinite() && it>0f}?:fallback
                val target=floatArrayOf(
                    finiteSize(fields[0].text.toString(),base[0]),
                    finiteSize(fields[1].text.toString(),base[1]),
                    finiteSize(fields[2].text.toString(),base[2])
                )
                val next=if(lock.isChecked){
                    val ratio=(target[lastEditedAxis]/base[lastEditedAxis]).coerceAtLeast(0.0001f)
                    current.copy(scale=(current.scale*ratio).coerceIn(0.01f,20f))
                } else {
                    // Fold the current uniform scale into the per-axis values. This makes each
                    // physical dimension independently editable without losing the current size.
                    val rx=(target[0]/base[0]).coerceAtLeast(0.0001f)
                    val ry=(target[1]/base[1]).coerceAtLeast(0.0001f)
                    val rz=(target[2]/base[2]).coerceAtLeast(0.0001f)
                    current.copy(
                        scale=1f,
                        scaleX=(current.scale*current.scaleX*rx).coerceIn(0.01f,20f),
                        scaleY=(current.scale*current.scaleY*ry).coerceIn(0.01f,20f),
                        scaleZ=(current.scale*current.scaleZ*rz).coerceIn(0.01f,20f)
                    )
                }
                glView.sceneState.updateSelected(next,placeOnBed=true)
                invalidateSlice();glView.refreshScene(true);updateSelectedLabel()
                val updated=glView.sceneState.selected()
                if(updated!=null){
                    val b=TransformMath.transformedBoxBounds(updated.mesh,updated.transform)
                    statusText.text="Size • X ${"%.1f".format(b.width)} × Y ${"%.1f".format(b.depth)} × Z ${"%.1f".format(b.height)} mm${if(lock.isChecked)" • locked" else " • XYZ independent"}"
                }
            }.show()
    }

    private fun slicePlate(){
        val scene=glView.sceneState.snapshot()
        if(scene.isEmpty()){toast("Import a model first");return}
        if(!sliceBusy.compareAndSet(false,true)){toast("A slice is already running");return}
        val config=printConfig
        val revision=stateRevision.get()
        val requestId=sliceRequestId.incrementAndGet()
        statusText.text="Slicing ${scene.size} object(s)…"
        executor.execute{
            try{
                val result=ContourSlicer.slice(scene,config.process)
                val toolpaths=ToolpathEngine.plan(result,config)
                runOnUiThread{
                    if(isFinishing || isDestroyed)return@runOnUiThread
                    val current=requestId==sliceRequestId.get() && revision==stateRevision.get()
                    if(!current){
                        statusText.text="Slice discarded • plate/profile changed • slice again"
                        return@runOnUiThread
                    }
                    lastSlice=result;lastToolpaths=toolpaths
                    val mins=toolpaths.estimate.timeSeconds/60
                    val geometryGate=if(toolpaths.canExport) "Geometry gate: PASS" else "BLOCKED: ${toolpaths.exportBlockReason ?: "${toolpaths.warningCount} geometry issue(s)"}"
                    val printerGate="Printer preflight: export-time safety gate"
                    statusText.text="${result.layerCount} layers • ${toolpaths.pathCount} paths • ~${mins} min • ready for preview"
                    AlertDialog.Builder(this)
                        .setTitle("Slice complete • Step 5.6 Final Audit")
                        .setMessage("Objects: ${result.sourceObjectCount}\nLayers: ${result.layerCount}\nToolpaths: ${toolpaths.pathCount}\nFilament: ${"%.1f".format(toolpaths.estimate.filamentGrams)} g\nEstimated time: ${mins/60}h ${mins%60}m${if(result.diagnostics.duplicateSegmentsRemoved>0)"\nContour duplicates cleaned: ${result.diagnostics.duplicateSegmentsRemoved}" else ""}${if(result.diagnostics.tinyLoopsDropped>0)"\nTiny loops dropped: ${result.diagnostics.tinyLoopsDropped}" else ""}\n$geometryGate\n$printerGate\nQuality V3: rear seam • bridge/overhang • retract • accel • ironing${if(config.process.supportEnabled)"\nSupports V2: ${SupportSettings.styleOverride ?: config.process.supportStyle} • ${SupportSettings.overhangDeg}° • interface ${SupportSettings.interfaceLayers}${if(SupportSettings.buildPlateOnly)" • plate only" else ""}" else "\nSupports V2: OFF"}\n\n${config.process.name} • ${config.filament.name}")
                        .setNegativeButton("Close",null)
                        .setNeutralButton("Export G-code"){_,_->exportGcode()}
                        .setPositiveButton("Preview"){_,_->showPreview()}.show()
                }
            }catch(t:Throwable){
                runOnUiThread{
                    if(isFinishing || isDestroyed)return@runOnUiThread
                    if(revision==stateRevision.get()){
                        statusText.text="Slice failed"
                        toast(t.message?:"Could not slice plate")
                    }
                }
            }finally{
                sliceBusy.set(false)
            }
        }
    }

    private fun invalidateSlice(){
        stateRevision.incrementAndGet()
        lastSlice=null;lastToolpaths=null
        pendingExportTicket=null
    }

    private fun showPreview(){
        val tool=lastToolpaths?:run{toast("Slice the plate first");return}
        if(tool.layers.isEmpty()){toast("No printable layers");return}

        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),0)}
        val totalMins=tool.estimate.timeSeconds/60
        val summary=TextView(this).apply{
            text="${tool.layers.size} layers • ${"%.1f".format(tool.estimate.filamentGrams)} g • ${totalMins/60}h ${totalMins%60}m • ${tool.pathCount} paths"
            setTextColor(Color.rgb(225,230,232));gravity=Gravity.CENTER;textSize=11f;setPadding(0,0,0,dp(2))
        }
        val label=TextView(this).apply{setTextColor(Color.rgb(225,230,232));gravity=Gravity.CENTER;textSize=10f;maxLines=4}
        val viewLabel=TextView(this).apply{
            text="3D MODEL • slider cuts visible height"
            setTextColor(Color.rgb(126,224,187));gravity=Gravity.CENTER;textSize=9.5f;setPadding(0,0,0,dp(2))
        }
        val preview=ToolpathPreviewView(this).apply{
            setBedSize(printConfig.printer.bedX,printConfig.printer.bedY)
            setResult(tool)
        }
        val slider=VerticalLayerSlider(this).apply{max=(tool.layers.size-1).coerceAtLeast(0)}

        var scrubbing=false
        fun updateLight(i:Int){
            preview.layerIndex=i
            slider.progress=i
            val layer=tool.layers[i]
            label.text="Layer ${i+1}/${tool.layers.size} • Cut Z ${"%.2f".format(layer.z)} mm • H ${"%.2f".format(layer.heightMm)} mm • ${layer.paths.size} paths\n"+
                "Scrubbing preview • release slider for detailed layer statistics"
        }
        fun updateDetailed(i:Int){
            preview.layerIndex=i
            slider.progress=i
            val layer=tool.layers[i]
            // Keep slider release O(path count), not O(total point count). Exact length/time
            // calculations walk every segment and can stall accessibility/rendering on giant layers.
            val roleCounts=IntArray(com.rudrila.slicer.model.PathRole.values().size)
            for(path in layer.paths) roleCounts[path.role.ordinal]++
            fun role(role:com.rudrila.slicer.model.PathRole)=roleCounts[role.ordinal]
            val travels=(layer.paths.size-1).coerceAtLeast(0)
            val support=role(com.rudrila.slicer.model.PathRole.SUPPORT)
            val iface=role(com.rudrila.slicer.model.PathRole.SUPPORT_INTERFACE)
            label.text="Layer ${i+1}/${tool.layers.size} • Cut Z ${"%.2f".format(layer.z)} mm • H ${"%.2f".format(layer.heightMm)} mm • ${layer.paths.size} paths\n"+
                "Wall ${role(com.rudrila.slicer.model.PathRole.WALL)} • Skin ${role(com.rudrila.slicer.model.PathRole.SOLID)} • Gap ${role(com.rudrila.slicer.model.PathRole.GAP_FILL)} • Infill ${role(com.rudrila.slicer.model.PathRole.INFILL)}\n"+
                "Support $support • Interface $iface • Brim ${role(com.rudrila.slicer.model.PathRole.BRIM)} • Travel ~$travels\n"+
                "Preview statistics are sampled for responsive mobile inspection"
        }
        slider.onProgressChanged={i->if(scrubbing)updateLight(i) else updateDetailed(i)}
        slider.onScrubStateChanged={active->
            scrubbing=active
            preview.setSliderScrubbing(active)
            if(!active)updateDetailed(slider.progress)
        }

        val previewHeight=maxOf(dp(230),minOf(dp(410),(resources.displayMetrics.heightPixels*0.41f).toInt()))
        val stage=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        stage.addView(preview,LinearLayout.LayoutParams(0,previewHeight,1f))
        stage.addView(slider,LinearLayout.LayoutParams(dp(52),previewHeight))

        fun chip(labelText:String,initial:Boolean,activeColor:Int=Color.rgb(28,110,84),onChanged:(Boolean)->Unit):TextView{
            fun style(v:TextView,on:Boolean){
                v.text=if(on)"✓ $labelText" else labelText
                v.setTextColor(if(on)Color.WHITE else Color.rgb(205,210,212))
                v.background=android.graphics.drawable.GradientDrawable().apply{
                    cornerRadius=dp(6).toFloat()
                    setColor(if(on)activeColor else Color.rgb(58,62,65))
                    setStroke(dp(1),if(on)Color.argb(255,220,230,232) else Color.rgb(92,98,102))
                }
            }
            return TextView(this).apply{
                gravity=Gravity.CENTER;textSize=9f;setPadding(dp(2),0,dp(2),0);tag=initial;style(this,initial)
                setOnClickListener{val next=!(tag as Boolean);tag=next;style(this,next);onChanged(next)}
            }
        }
        fun actionChip(textValue:String,onClick:()->Unit)=TextView(this).apply{
            text=textValue;gravity=Gravity.CENTER;textSize=9f;setTextColor(Color.rgb(225,230,232));setPadding(dp(2),0,dp(2),0)
            background=android.graphics.drawable.GradientDrawable().apply{cornerRadius=dp(6).toFloat();setColor(Color.rgb(52,57,60));setStroke(dp(1),Color.rgb(92,98,102))}
            setOnClickListener{onClick()}
        }
        fun row(a:View,b:View,c:View)=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            listOf(a,b,c).forEachIndexed{index,v->
                val lp=LinearLayout.LayoutParams(0,dp(31),1f).apply{if(index>0)leftMargin=dp(4);topMargin=dp(3)}
                addView(v,lp)
            }
        }

        val controls=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        controls.addView(row(
            chip("Wall",true,Color.rgb(34,139,105)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.WALL,it)},
            chip("Skin",true,Color.rgb(165,120,20)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.SOLID,it)},
            chip("Infill",true,Color.rgb(55,105,170)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.INFILL,it)}
        ))
        controls.addView(row(
            chip("Gap",true,Color.rgb(155,65,115)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.GAP_FILL,it)},
            chip("Support",true,Color.rgb(115,70,160)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.SUPPORT,it)},
            chip("Interface",true,Color.rgb(95,80,160)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.SUPPORT_INTERFACE,it)}
        ))
        controls.addView(row(
            chip("Brim",true,Color.rgb(100,105,110)){preview.setRoleVisible(com.rudrila.slicer.model.PathRole.BRIM,it)},
            chip("Travel",false,Color.rgb(55,105,170)){preview.showTravel=it},
            actionChip("RESET VIEW"){preview.resetCamera()}
        ))

        lateinit var modelButton:TextView
        lateinit var layerButton:TextView
        fun styleModeButtons(model:Boolean){
            fun apply(v:TextView,on:Boolean){
                v.setTextColor(if(on)Color.WHITE else Color.rgb(205,210,212))
                v.background=android.graphics.drawable.GradientDrawable().apply{
                    cornerRadius=dp(6).toFloat();setColor(if(on)Color.rgb(28,110,84) else Color.rgb(52,57,60));setStroke(dp(1),if(on)Color.rgb(78,210,164) else Color.rgb(92,98,102))
                }
            }
            apply(modelButton,model);apply(layerButton,!model)
            viewLabel.text=if(model)"3D MODEL • slider cuts visible height" else "CURRENT LAYER • exact top view"
        }
        modelButton=actionChip("3D MODEL"){
            preview.fitToModel();styleModeButtons(true)
        }
        layerButton=actionChip("LAYER TOP"){
            preview.fitToCurrentLayer();styleModeButtons(false)
        }
        controls.addView(row(modelButton,layerButton,actionChip("FIT / RESET"){preview.resetCamera()}))

        val hint=TextView(this).apply{
            text="3D: 1 finger orbit • 2 fingers pan • pinch zoom • right slider = cut height\nLayer Top: drag pan • pinch zoom"
            setTextColor(Color.rgb(155,165,170));gravity=Gravity.CENTER;textSize=8.7f;setPadding(0,dp(3),0,dp(2));maxLines=2
        }
        box.addView(summary,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(24)))
        box.addView(viewLabel,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(22)))
        box.addView(label,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(62)))
        box.addView(stage)
        box.addView(controls,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(hint,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(38)))

        val initialLayer = tool.layers.indexOfLast { layer ->
            layer.paths.any { path -> path.points.size >= 2 }
        }.let { if (it >= 0) it else tool.layers.lastIndex }
        updateLight(initialLayer)
        preview.fitToModel()
        styleModeButtons(true)

        val scroller=ScrollView(this).apply{isFillViewport=true;addView(box)}
        AlertDialog.Builder(this)
            .setTitle("Toolpath Preview • Step 5.6 Final Audit")
            .setView(scroller)
            .setNegativeButton("Close",null)
            .setPositiveButton("Export G-code"){_,_->exportGcode()}
            .show()

        // Some Android layouts/accessibility passes can redraw the slider at its maximum during
        // dialog attachment. Re-assert the last real printable layer after layout so Preview
        // always opens on useful geometry instead of an empty terminal Z layer.
        slider.post {
            scrubbing=false
            preview.setSliderScrubbing(false)
            updateDetailed(initialLayer)
        }
    }

    private fun exportGcode(){
        val tool=lastToolpaths?:run{toast("Slice the plate first");return}
        if(!tool.canExport){toast(tool.exportBlockReason ?: "Repair slice geometry before export");return}

        // Step 5.6: Preview remains lightweight. Full safety scans still run on the background
        // export executor. General P2S printer-ready export remains blocked; only the dedicated
        // centered 20x20x5 mm / P2S 0.4 / PLA controlled cube can use an imported, already-resolved
        // Bambu Studio P2S native start/end envelope.
        if(printConfig.printer.id.startsWith("bambu_p2s_")){
            val envelope=pendingP2SEnvelope ?: loadP2SEnvelope().also{pendingP2SEnvelope=it}
            val gateErrors=P2SControlledBridge.controlledTestErrors(tool,printConfig,envelope)
            if(gateErrors.isEmpty()){
                AlertDialog.Builder(this)
                    .setTitle("P2S controlled print test")
                    .setMessage("Native reference ${envelope!!.shortSha} verified. Printer-ready export is unlocked ONLY for the centered 20×20×5 mm safety cube. General P2S models remain blocked.")
                    .setNegativeButton("Close",null)
                    .setNeutralButton("Analysis G-code"){_,_->beginGcodeExport(ExportPurpose.ANALYSIS)}
                    .setPositiveButton("Controlled test"){_,_->beginGcodeExport(ExportPurpose.P2S_CONTROLLED_TEST)}
                    .show()
            }else{
                AlertDialog.Builder(this)
                    .setTitle("P2S controlled test gated")
                    .setMessage(gateErrors.take(5).joinToString("\n• ",prefix="• ")+"\n\nImport a resolved P2S 0.4 / PLA safety-cube .gcode from Bambu Studio to arm controlled-test export. General P2S export stays blocked.")
                    .setNegativeButton("Close",null)
                    .setNeutralButton("Analysis G-code"){_,_->beginGcodeExport(ExportPurpose.ANALYSIS)}
                    .setPositiveButton("Import reference"){_,_->importP2SReference()}
                    .show()
            }
            return
        }
        beginGcodeExport(ExportPurpose.PRINTER_READY)
    }

    private fun beginGcodeExport(purpose:ExportPurpose){
        val tool=lastToolpaths?:run{toast("Slice the plate first");return}
        if(!tool.canExport){toast(tool.exportBlockReason ?: "Repair slice geometry before export");return}
        val config=printConfig
        val revision=stateRevision.get()
        val envelope=if(config.printer.id.startsWith("bambu_p2s_")) {
            pendingP2SEnvelope ?: loadP2SEnvelope().also{pendingP2SEnvelope=it}
        } else null
        if(purpose==ExportPurpose.P2S_CONTROLLED_TEST){
            val errors=P2SControlledBridge.controlledTestErrors(tool,config,envelope)
            if(errors.isNotEmpty()){toast(errors.first());return}
        }
        pendingExportTicket=PendingExportTicket(tool,config,purpose,envelope,revision)
        val filename=when(purpose){
            ExportPurpose.PRINTER_READY->"rudrila_print.gcode"
            ExportPurpose.P2S_CONTROLLED_TEST->"rudrila_p2s_controlled_test.gcode"
            ExportPurpose.ANALYSIS->"rudrila_analysis_DO_NOT_PRINT.gcode"
        }
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/plain";putExtra(Intent.EXTRA_TITLE,filename)}
        runCatching{startActivityForResult(intent,saveCode)}.onFailure{
            pendingExportTicket=null
            toast(it.message?:"Could not open save picker")
        }
    }

    private fun importP2SReference(){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type="*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent,p2sReferenceCode)
    }

    private fun loadP2SEnvelope():P2SNativeEnvelope?{
        val f=java.io.File(filesDir,p2sEnvelopeFileName)
        if(!f.exists())return null
        return runCatching{P2SControlledBridge.decode(f.readText(Charsets.UTF_8))}.getOrElse{
            runCatching{f.delete()}
            null
        }
    }

    private fun saveP2SEnvelope(envelope:P2SNativeEnvelope){
        val target=java.io.File(filesDir,p2sEnvelopeFileName)
        val temp=java.io.File(filesDir,"$p2sEnvelopeFileName.tmp")
        temp.writeText(P2SControlledBridge.encode(envelope),Charsets.UTF_8)
        check(temp.renameTo(target) || runCatching{target.writeText(temp.readText(Charsets.UTF_8),Charsets.UTF_8);temp.delete();true}.getOrDefault(false)){
            "Could not persist P2S reference"
        }
    }

    private fun readTextCapped(uri:Uri,maxChars:Int=P2SControlledBridge.MAX_REFERENCE_CHARS):String{
        val reader=contentResolver.openInputStream(uri)?.let{java.io.InputStreamReader(it,Charsets.UTF_8).buffered(64*1024)}
            ?: error("Could not open reference G-code")
        return reader.use{
            val out=StringBuilder(minOf(maxChars,1024*1024))
            val buf=CharArray(64*1024)
            while(true){
                val n=it.read(buf)
                if(n<0)break
                require(out.length+n<=maxChars){"Reference G-code is too large for controlled-test validation"}
                out.append(buf,0,n)
            }
            out.toString()
        }
    }

    private fun updateProfileLabel(){
        if(!::profileText.isInitialized)return
        profileText.text="${printConfig.printer.name} • ${printConfig.filament.name} • ${printConfig.process.name}  ›"
    }

    private fun showProfileDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(12),dp(22),0)}
        fun label(text:String)=TextView(this).apply{this.text=text;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))}
        val printer=Spinner(this);printer.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,Step5Profiles.printers.map{it.name})
        val filament=Spinner(this);filament.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,Step5Profiles.filaments.map{it.name})
        val process=Spinner(this);process.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,Step5Profiles.processes.map{it.name})
        val support=CheckBox(this).apply{text="Generate supports";isChecked=printConfig.process.supportEnabled}
        val supportStyles=listOf("Tree / Organic","Normal","Hybrid")
        val currentSupportStyle=(SupportSettings.styleOverride?.takeIf{it in supportStyles}) ?: if(printConfig.process.supportStyle=="Normal")"Normal" else "Tree / Organic"
        val supportStyle=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,supportStyles);setSelection(supportStyles.indexOf(currentSupportStyle).coerceAtLeast(0))}
        val supportAngle=EditText(this).apply{setText(SupportSettings.overhangDeg.toString());inputType=InputType.TYPE_CLASS_NUMBER}
        val interfaceLayers=EditText(this).apply{setText(SupportSettings.interfaceLayers.toString());inputType=InputType.TYPE_CLASS_NUMBER}
        val buildPlateOnly=CheckBox(this).apply{text="Support on build plate only";isChecked=SupportSettings.buildPlateOnly}
        val infill=EditText(this).apply{setText(printConfig.process.infillPercent.toString());inputType=InputType.TYPE_CLASS_NUMBER}
        val brim=EditText(this).apply{setText(printConfig.process.brimWidthMm.toString());inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        printer.setSelection(Step5Profiles.printers.indexOfFirst{it.id==printConfig.printer.id}.coerceAtLeast(0))
        filament.setSelection(Step5Profiles.filaments.indexOfFirst{it.id==printConfig.filament.id}.coerceAtLeast(0))
        process.setSelection(Step5Profiles.processes.indexOfFirst{it.id==printConfig.process.id}.coerceAtLeast(0))
        val profileDetails=TextView(this).apply{setTextColor(Color.rgb(70,74,78));textSize=12f;setPadding(0,dp(8),0,dp(8))}
        fun refreshProfileDetails(){
            val pr=Step5Profiles.printers[printer.selectedItemPosition.coerceIn(0,Step5Profiles.printers.lastIndex)]
            val fi=Step5Profiles.filaments[filament.selectedItemPosition.coerceIn(0,Step5Profiles.filaments.lastIndex)]
            val machine=Step5Profiles.machine(pr);val material=Step5Profiles.material(fi)
            profileDetails.text="Build ${pr.bedX.toInt()}×${pr.bedY.toInt()}×${pr.bedZ.toInt()} mm • nozzle ${"%.1f".format(pr.nozzleDiameter)} mm\n"+
                "Motion cap ${machine.maxPrintSpeedMmS.toInt()} mm/s • travel ${machine.maxTravelSpeedMmS.toInt()} mm/s • accel ${machine.maxPrintAccelerationMmS2} mm/s²\n"+
                "${fi.material} • ${fi.nozzleTempC}°C nozzle • ${fi.bedTempC}°C bed • ${"%.1f".format(fi.maxVolumetricSpeedMm3s)} mm³/s\n"+
                "Cooling ${material.minFanPercent}–${material.maxFanPercent}% • retract ${"%.1f".format(material.retractDistanceMm)} mm @ ${material.retractSpeedMmS.toInt()} mm/s" +
                if(pr.id.startsWith("bambu_p2s_")) {
                    val env=pendingP2SEnvelope ?: loadP2SEnvelope()
                    "\nP2S controlled bridge: "+if(env!=null)"reference ${env.shortSha} ready • safety-cube only" else "reference not imported • general print blocked"
                } else "\nPrinter-ready export: Step 5.6 preflight enabled"
        }
        var adjustingProfileSelection=false
        fun enforceP2SBalancedFilament(){
            if(adjustingProfileSelection)return
            val pr=Step5Profiles.printers[printer.selectedItemPosition.coerceIn(0,Step5Profiles.printers.lastIndex)]
            val fi=Step5Profiles.filaments[filament.selectedItemPosition.coerceIn(0,Step5Profiles.filaments.lastIndex)]
            val canonical=ProfilePolicy.canonicalFilament(pr,fi)
            if(canonical.id!=fi.id){
                val index=Step5Profiles.filaments.indexOfFirst{it.id==canonical.id}
                if(index>=0){
                    adjustingProfileSelection=true
                    filament.setSelection(index)
                    adjustingProfileSelection=false
                }
            }
        }
        val selectionListener=object:AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){
                enforceP2SBalancedFilament()
                refreshProfileDetails()
            }
            override fun onNothingSelected(parent:AdapterView<*>?){ }
        }
        printer.onItemSelectedListener=selectionListener;filament.onItemSelectedListener=selectionListener
        enforceP2SBalancedFilament()
        box.addView(label("Printer / nozzle"));box.addView(printer);box.addView(label("Filament preset"));box.addView(filament);box.addView(profileDetails);box.addView(label("Process"));box.addView(process)
        refreshProfileDetails()
        box.addView(label("Infill %"));box.addView(infill);box.addView(support);box.addView(label("Support style"));box.addView(supportStyle);box.addView(label("Support overhang angle °"));box.addView(supportAngle);box.addView(label("Support interface layers"));box.addView(interfaceLayers);box.addView(buildPlateOnly);box.addView(label("Brim width mm"));box.addView(brim)
        AlertDialog.Builder(this).setTitle("Print profiles • Step 5.6 Final Audit • Printer + Filament + P2S Safety").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Use profiles"){_,_->
            val base=Step5Profiles.processes[process.selectedItemPosition]
            val selectedSupportStyle=supportStyle.selectedItem.toString()
            // Keep legacy profile field compatible (Tree/Normal) while V2 stores richer runtime mode separately.
            val legacySupportStyle=if(selectedSupportStyle=="Normal")"Normal" else "Tree"
            val brimValue=brim.text.toString().toFloatOrNull()?.takeIf{it.isFinite()}?:base.brimWidthMm
            val q=base.copy(
                infillPercent=(infill.text.toString().toIntOrNull()?:base.infillPercent).coerceIn(0,100),
                supportEnabled=support.isChecked,
                supportStyle=legacySupportStyle,
                brimWidthMm=brimValue.coerceIn(0f,50f)
            )
            val requested=PrintConfiguration(
                Step5Profiles.printers[printer.selectedItemPosition.coerceIn(0,Step5Profiles.printers.lastIndex)],
                Step5Profiles.filaments[filament.selectedItemPosition.coerceIn(0,Step5Profiles.filaments.lastIndex)],
                q
            )
            try{
                val canonical=ProfilePolicy.canonicalize(requested)
                Step5Profiles.validate(canonical)
                SupportSettings.styleOverride=selectedSupportStyle.takeIf{it in supportStyles}
                SupportSettings.overhangDeg=(supportAngle.text.toString().toIntOrNull()?:base.supportOverhangDeg).coerceIn(1,89)
                SupportSettings.interfaceLayers=(interfaceLayers.text.toString().toIntOrNull()?:2).coerceIn(0,6)
                SupportSettings.buildPlateOnly=buildPlateOnly.isChecked
                saveSupportV2Settings()
                printConfig=profileStore.save(canonical)
                invalidateSlice()
                updateProfileLabel()
                statusText.text="Profiles + Supports V2 saved • ${printConfig.filament.name} • re-slice required"
            }catch(t:Throwable){toast(t.message?:"Invalid profile")}
        }.show()
    }

    private fun loadSupportV2Settings(){
        val sp=getSharedPreferences("rudrila_support_v2",MODE_PRIVATE)
        SupportSettings.styleOverride=sp.getString("style",null)?.takeIf{it=="Tree / Organic" || it=="Normal" || it=="Hybrid"}
        SupportSettings.overhangDeg=sp.getInt("angle",printConfig.process.supportOverhangDeg).coerceIn(1,89)
        SupportSettings.interfaceLayers=sp.getInt("interface_layers",2).coerceIn(0,6)
        SupportSettings.buildPlateOnly=sp.getBoolean("build_plate_only",false)
    }

    private fun saveSupportV2Settings(){
        check(getSharedPreferences("rudrila_support_v2",MODE_PRIVATE).edit()
            .putString("style",SupportSettings.styleOverride)
            .putInt("angle",SupportSettings.overhangDeg)
            .putInt("interface_layers",SupportSettings.interfaceLayers)
            .putBoolean("build_plate_only",SupportSettings.buildPlateOnly)
            .commit()){"Could not persist support settings"}
    }

    private fun showObjectsDialog(){
        val items=glView.sceneState.snapshot()
        if(items.isEmpty()){toast("Import a model first");return}
        val names=items.map{if(it.id==glView.sceneState.selectedId)"✓ ${it.name}" else it.name}.toTypedArray()
        AlertDialog.Builder(this).setTitle("Objects on plate").setItems(names){_,which->glView.sceneState.select(items[which].id);glView.refreshScene();updateSelectedLabel()}.setNegativeButton("Close",null).show()
    }

    private fun showExactTransformDialog(){
        val selected=glView.sceneState.selected()?:run{toast("Select a model first");return}
        val current=selected.transform
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(8),dp(22),0)}
        val fields=linkedMapOf<String,EditText>()
        fun addField(label:String,value:Float){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(TextView(this).apply{text=label;setTextColor(Color.DKGRAY)},LinearLayout.LayoutParams(dp(70),dp(48)))
            val edit=EditText(this).apply{setText("%.3f".format(value));inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED;selectAll()}
            row.addView(edit,LinearLayout.LayoutParams(0,dp(48),1f));box.addView(row);fields[label]=edit
        }
        addField("X mm",current.x);addField("Y mm",current.y);addField("Z mm",current.z);addField("Rot X",current.rotationX);addField("Rot Y",current.rotationY);addField("Rot Z",current.rotationZ);addField("Scale",current.scale*100f);addField("Scale X",current.scaleX*100f);addField("Scale Y",current.scaleY*100f);addField("Scale Z",current.scaleZ*100f)
        AlertDialog.Builder(this).setTitle("Exact transform • ${selected.name}").setView(box).setNegativeButton("Cancel",null).setNeutralButton("On bed"){_,_->glView.sceneState.placeSelectedOnBed();invalidateSlice();glView.refreshScene()}.setPositiveButton("Apply"){_,_->
            fun v(k:String,f:Float)=fields[k]?.text?.toString()?.toFloatOrNull()?.takeIf{it.isFinite()}?:f
            fun scale(k:String,f:Float)=(v(k,f*100f)/100f).takeIf{it.isFinite()}?.coerceIn(0.01f,20f)?:f
            glView.sceneState.updateSelected(current.copy(
                x=v("X mm",current.x),y=v("Y mm",current.y),z=v("Z mm",current.z),
                rotationX=v("Rot X",current.rotationX),rotationY=v("Rot Y",current.rotationY),rotationZ=v("Rot Z",current.rotationZ),
                scale=scale("Scale",current.scale),
                scaleX=scale("Scale X",current.scaleX),
                scaleY=scale("Scale Y",current.scaleY),
                scaleZ=scale("Scale Z",current.scaleZ)
            ))
            invalidateSlice();glView.refreshScene();statusText.text="Exact transform applied"
        }.show()
    }

    private fun showSaveModelDialog(){
        val objects=glView.sceneState.snapshot()
        if(objects.isEmpty()){toast("Import a model first");return}
        val tris=objects.sumOf{(it.mesh.vertices.size/9).toLong()}
        val target=if(objects.size==1) objects.first().name else "${objects.size} objects on plate"
        AlertDialog.Builder(this)
            .setTitle("Save model to device")
            .setMessage("$target\n${"%,d".format(tris)} triangles\n\nMove, rotate and size changes will be baked into the saved model. Slicer supports/toolpaths are not added to STL/3MF.")
            .setNegativeButton("Cancel",null)
            .setNeutralButton("Save STL"){_,_->beginModelExport(ModelExportFormat.STL)}
            .setPositiveButton("Save 3MF"){_,_->beginModelExport(ModelExportFormat.THREE_MF)}
            .show()
    }

    private fun beginModelExport(format:ModelExportFormat){
        val objects=glView.sceneState.snapshot()
        if(objects.isEmpty()){toast("Import a model first");return}
        val revision=stateRevision.get()
        pendingModelExportTicket=PendingModelExportTicket(objects,format,revision)
        val base=if(objects.size==1) sanitizeExportBaseName(objects.first().name) else "rudrila_plate"
        val filename="${base}_edited.${format.extension}"
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type="application/octet-stream"
            putExtra(Intent.EXTRA_TITLE,filename)
        }
        runCatching{startActivityForResult(intent,saveModelCode)}.onFailure{
            pendingModelExportTicket=null
            toast(it.message?:"Could not open save picker")
        }
    }

    private fun sanitizeExportBaseName(name:String):String{
        val noExt=name.substringBeforeLast('.',name)
        val cleaned=noExt.replace(Regex("[^A-Za-z0-9._ -]"),"_").trim().trim('.')
        return cleaned.ifBlank{"rudrila_model"}.take(80)
    }

    private fun openModels(){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type="*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent,openCode)
    }

    @Deprecated("Legacy result API avoids another dependency in this prototype")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==p2sReferenceCode){
            val uri=data?.data
            if(resultCode==RESULT_OK && uri!=null){
                val previous=pendingP2SEnvelope
                statusText.text="Validating P2S reference…"
                executor.execute{
                    val result=runCatching{
                        val text=readTextCapped(uri)
                        P2SControlledBridge.parseResolvedReference(text).also{saveP2SEnvelope(it)}
                    }
                    runOnUiThread{
                        if(isFinishing || isDestroyed)return@runOnUiThread
                        result.onSuccess{env->
                            pendingP2SEnvelope=env
                            statusText.text="P2S reference ${env.shortSha} ready • ${env.referenceLayerCount} layers • ${env.referenceNozzleTempC.toInt()}°/${env.referenceBedTempC.toInt()}°C • ${"%.1f".format(env.referenceWidthMm)}×${"%.1f".format(env.referenceDepthMm)}×${"%.1f".format(env.referenceMaxZMm)} mm"
                            toast("P2S safety-cube reference verified")
                        }.onFailure{
                            statusText.text=if(previous!=null)"P2S reference rejected • previous ${previous.shortSha} retained" else "P2S reference rejected"
                            toast(it.message?:"Invalid P2S reference")
                        }
                    }
                }
            }
            return
        }
        if(requestCode==saveModelCode){
            val ticket=pendingModelExportTicket.also{pendingModelExportTicket=null}
            val uri=data?.data
            if(resultCode==RESULT_OK && uri!=null && ticket!=null){
                if(ticket.revision!=stateRevision.get()){
                    statusText.text="Model save canceled • plate changed"
                    toast("Plate changed • tap SAVE again")
                    return
                }
                statusText.text="Saving ${ticket.format.displayName} model…"
                executor.execute{
                    val result=runCatching{
                        check(ticket.revision==stateRevision.get()){"Plate changed • save again"}
                        contentResolver.openOutputStream(uri,"w")?.use{out->
                            ModelExporter.write(ticket.objects,out,ticket.format)
                        }?:error("Could not open output file")
                    }
                    runOnUiThread{
                        if(isFinishing || isDestroyed)return@runOnUiThread
                        result.onSuccess{stats->
                            statusText.text="${ticket.format.displayName} model saved • ${stats.objectCount} object(s) • ${"%,d".format(stats.triangleCount)} triangles"
                            toast("${ticket.format.displayName} saved to device")
                        }.onFailure{
                            statusText.text="Model save failed"
                            toast(it.message?:"Could not save model")
                        }
                    }
                }
            }
            return
        }
        if(requestCode==saveCode){
            val ticket=pendingExportTicket.also{pendingExportTicket=null}
            val uri=data?.data
            if(resultCode==RESULT_OK && uri!=null && ticket!=null){
                if(ticket.revision!=stateRevision.get() || lastToolpaths!==ticket.toolpaths){
                    statusText.text="Export canceled • plate/profile changed"
                    toast("Plate/profile changed • re-slice before export")
                    return
                }
                statusText.text="Writing G-code…"
                executor.execute{
                    val result=runCatching{
                        // Re-check the ticket after the document picker. The exporter also performs
                        // a full safety scan, but this prevents a stale slice from being written.
                        check(ticket.revision==stateRevision.get() && lastToolpaths===ticket.toolpaths){"Plate/profile changed • re-slice before export"}
                        contentResolver.openOutputStream(uri)
                            ?.let{java.io.BufferedWriter(java.io.OutputStreamWriter(it,Charsets.UTF_8),256*1024)}
                            ?.use{GCodeExporter.write(ticket.toolpaths,ticket.config,it,ticket.purpose,ticket.envelope)}
                            ?:error("Could not open output file")
                    }
                    runOnUiThread{
                        if(isFinishing || isDestroyed)return@runOnUiThread
                        result.onSuccess{
                            when(ticket.purpose){
                                ExportPurpose.PRINTER_READY->{statusText.text="Printer-ready G-code exported";toast("G-code saved • preflight PASS")}
                                ExportPurpose.P2S_CONTROLLED_TEST->{statusText.text="P2S controlled-test G-code exported";toast("Controlled P2S cube G-code saved • verify before print")}
                                ExportPurpose.ANALYSIS->{statusText.text="Analysis G-code exported • DO NOT PRINT";toast("Analysis G-code saved • DO NOT PRINT")}
                            }
                        }.onFailure{statusText.text="Export blocked";toast(it.message?:"Could not save G-code")}
                    }
                }
            }
            return
        }
        if(requestCode!=openCode||resultCode!=RESULT_OK)return
        val uris=collectUris(data)
        if(uris.isEmpty()){toast("No file selected");return}
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_:Throwable) {}
        }
        statusText.text="Loading ${uris.size} file${if(uris.size==1)"" else "s"}…"

        // Parse off the UI thread, but only mutate the scene on the UI thread. This prevents GL/UI races
        // while a large STL is being decoded.
        executor.execute{
            val parsed=mutableListOf<Pair<String,com.rudrila.slicer.model.Mesh>>()
            val failures=mutableListOf<String>()
            for(uri in uris){
                val name=runCatching{displayName(uri)}.getOrElse{uri.lastPathSegment?:"model"}
                try{
                    parsed += parseModelUri(uri,name)
                }catch(_:OutOfMemoryError){
                    failures += "$name: model is too large for mobile memory"
                }catch(t:Throwable){
                    failures += "$name: ${t.message?:"import failed"}"
                }
            }
            runOnUiThread{
                if(isFinishing || isDestroyed)return@runOnUiThread
                parsed.forEachIndexed { index,(name,mesh) -> glView.sceneState.add(name,mesh,select=index==parsed.lastIndex) }
                if(parsed.isNotEmpty()){
                    // SceneState.add() already placed each mesh on the bed. Do not rescan a 10M-triangle
                    // mesh a second time just because we centered X/Y.
                    glView.sceneState.centerSelected()
                    glView.slicerRenderer.resetView()
                }
                invalidateSlice();glView.refreshScene(fit=true);selectMode(SlicerGLSurfaceView.InteractionMode.VIEW);updateSelectedLabel()
                statusText.text=when{
                    parsed.isNotEmpty() && failures.isNotEmpty()->"Imported ${parsed.size} object(s) • ${failures.first()}"
                    parsed.isNotEmpty()->"Imported ${parsed.size} object(s) • centered"
                    else->failures.firstOrNull()?:"No models imported"
                }
                if(parsed.isEmpty() && failures.isNotEmpty()){
                    AlertDialog.Builder(this).setTitle("Import failed").setMessage(failures.joinToString("\n")).setPositiveButton("OK",null).show()
                }
            }
        }
    }

    private fun parseModelUri(uri:Uri,displayName:String):List<Pair<String,com.rudrila.slicer.model.Mesh>>{
        val lower=displayName.lowercase()
        val mime=runCatching{contentResolver.getType(uri)?.lowercase()}.getOrNull().orEmpty()
        fun stl()=listOf(displayName.removeSuffixIgnoreCase(".stl") to StlParser.parse(contentResolver,uri))
        fun threeMf()=ThreeMfParser.parseParts(contentResolver,uri).map{it.name to it.mesh}
        return when{
            lower.endsWith(".stl") || mime.contains("stl") -> stl()
            lower.endsWith(".3mf") || mime.contains("3mf") -> threeMf()
            else -> {
                // Some Android providers hide or rewrite the filename extension. Sniff ZIP/3MF first;
                // otherwise try STL and then 3MF so valid model files are not rejected only by their name.
                val sig=runCatching{contentResolver.openInputStream(uri)?.use{input->ByteArray(4).also{b->var o=0;while(o<b.size){val n=input.read(b,o,b.size-o);if(n<0)break;o+=n}}}}.getOrNull()
                val zip=sig!=null && sig.size>=2 && sig[0]==0x50.toByte() && sig[1]==0x4B.toByte()
                if(zip) threeMf()
                else runCatching{stl()}.getOrElse{threeMf()}
            }
        }
    }

    private fun collectUris(data:Intent?):List<Uri>{
        val out=mutableListOf<Uri>();val clip:ClipData?=data?.clipData
        if(clip!=null){for(i in 0 until clip.itemCount)clip.getItemAt(i).uri?.let{out+=it}}else data?.data?.let{out+=it}
        return out.distinct()
    }

    private fun String.removeSuffixIgnoreCase(suffix:String)=if(endsWith(suffix,true))substring(0,length-suffix.length)else this
    private fun displayName(uri:Uri):String{contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())return c.getString(0)?:"model"};return uri.lastPathSegment?:"model"}
    private fun actionButton(text:String,onClick:()->Unit)=Button(this).apply{this.text=text;textSize=12f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(36,150,108));setOnClickListener{onClick()}}
    private fun smallButton(text:String,onClick:()->Unit)=Button(this).apply{this.text=text;textSize=10f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(35,39,43));setOnClickListener{onClick()}}
    private fun toolMini(text:String,onClick:()->Unit)=smallButton(text,onClick).apply{layoutParams=LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(2),0,dp(2),0)}}
    private fun toolButton(text:String,onClick:()->Unit)=Button(this).apply{this.text=text;textSize=9f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(42,47,51));setOnClickListener{onClick()};layoutParams=LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),0,dp(2),0)}}
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()

    override fun onResume(){super.onResume();if(::glView.isInitialized)glView.onResume()}
    override fun onPause(){if(::glView.isInitialized)glView.onPause();super.onPause()}
    override fun onDestroy(){
        stateRevision.incrementAndGet()
        pendingExportTicket=null
        pendingModelExportTicket=null
        executor.shutdownNow()
        super.onDestroy()
    }
}
