package com.rudrila.slicer.model

/**
 * Final-audit policy layer for profile identity and migration.
 *
 * The alpha source historically had legacy Generic PLA/PETG presets and Step 5 balanced presets
 * side-by-side. On P2S, a legacy material selection could therefore round-trip back as the legacy
 * ID and silently close the controlled-test gate. This policy makes the mapping explicit without
 * changing the legacy catalog or generic-printer behaviour.
 */
object ProfilePolicy {
    private val p2sBalancedByMaterial = mapOf(
        "PLA" to "step5_pla",
        "PETG" to "step5_petg",
        "ABS" to "step5_abs",
        "ASA" to "step5_abs",
        "TPU" to "step5_tpu95a"
    )

    fun isP2S(printer: PrinterProfile): Boolean = printer.id.startsWith("bambu_p2s_")

    fun canonicalFilament(printer: PrinterProfile, filament: FilamentProfile): FilamentProfile {
        if (!isP2S(printer)) return filament
        val material = filament.material.trim().uppercase()
        val id = p2sBalancedByMaterial.entries.firstOrNull { (key, _) ->
            material == key || (key == "TPU" && material.startsWith("TPU"))
        }?.value ?: return filament
        return Step5Profiles.filaments.firstOrNull { it.id == id } ?: filament
    }

    fun canonicalize(config: PrintConfiguration): PrintConfiguration {
        val filament = canonicalFilament(config.printer, config.filament)
        return if (filament.id == config.filament.id) config else config.copy(filament = filament)
    }

    /** Fast, deterministic catalog audit run by tests and once on Android startup. */
    fun catalogErrors(): List<String> {
        val errors = mutableListOf<String>()
        fun duplicateIds(label: String, ids: List<String>) {
            ids.groupingBy { it }.eachCount().filterValues { it > 1 }.keys.forEach {
                errors += "$label duplicate id: $it"
            }
        }
        duplicateIds("printer", Step5Profiles.printers.map { it.id })
        duplicateIds("filament", Step5Profiles.filaments.map { it.id })
        duplicateIds("process", Step5Profiles.processes.map { it.id })

        listOf("bambu_p2s_02", "bambu_p2s_04", "bambu_p2s_06", "bambu_p2s_08").forEach { id ->
            if (Step5Profiles.printers.none { it.id == id }) errors += "missing P2S profile: $id"
        }
        listOf("step5_pla", "step5_petg", "step5_abs", "step5_tpu95a").forEach { id ->
            if (Step5Profiles.filaments.none { it.id == id }) errors += "missing Step 5 filament: $id"
        }

        val p2s04 = Step5Profiles.printers.firstOrNull { it.id == "bambu_p2s_04" }
        val legacyPla = Step5Profiles.filaments.firstOrNull { it.material.equals("PLA", true) && it.id != "step5_pla" }
        if (p2s04 != null && legacyPla != null && canonicalFilament(p2s04, legacyPla).id != "step5_pla") {
            errors += "P2S legacy PLA migration is not canonical"
        }
        return errors
    }
}
