package com.rudrila.slicer.model

import kotlin.math.*

enum class PathRole { WALL, SOLID, GAP_FILL, INFILL, SUPPORT, SUPPORT_INTERFACE, BRIM }

data class Toolpath(
    val points: List<Point2>,
    val role: PathRole,
    val closed: Boolean = false,
    val widthMm: Float,
    val speedMmS: Float,
    val flowRatio: Float = 1f,
    val accelerationMmS2: Int = 0,
    val bridge: Boolean = false,
    val ironing: Boolean = false
) {
    val lengthMm: Float get() {
        if (points.size < 2) return 0f
        var total = 0.0
        var prev = points[0]
        for (i in 1 until points.size) {
            val cur = points[i]
            total += hypot((cur.x - prev.x).toDouble(), (cur.y - prev.y).toDouble())
            prev = cur
        }
        return total.toFloat()
    }
}

data class ToolpathLayer(
    val index: Int,
    val z: Float,
    val heightMm: Float,
    val paths: List<Toolpath>
) {
    val pathLengthMm: Float get() {
        var total = 0.0
        for (p in paths) total += p.lengthMm
        return total.toFloat()
    }
    fun count(role: PathRole): Int = paths.count { it.role == role }
}

data class PrintEstimate(
    val pathLengthMm: Float,
    val filamentLengthMm: Float,
    val filamentGrams: Float,
    val timeSeconds: Int
)

data class LayerEstimate(
    val pathLengthMm: Float,
    val filamentLengthMm: Float,
    val timeSeconds: Int
)



data class SupportOptions(
    val style: String,
    val overhangDeg: Int,
    val interfaceLayers: Int,
    val buildPlateOnly: Boolean
)

data class SupportLayerPlan(
    val body: List<List<Point2>> = emptyList(),
    val interfacePaths: List<List<Point2>> = emptyList()
)

/** Runtime support controls kept separate from ProcessProfile so old saved profiles remain compatible. */
object SupportSettings {
    @Volatile var styleOverride: String? = null
    @Volatile var overhangDeg: Int = 50
    @Volatile var interfaceLayers: Int = 2
    @Volatile var buildPlateOnly: Boolean = false

    fun snapshot(defaultStyle: String, defaultAngle: Int): SupportOptions {
        val style = styleOverride?.takeIf { it.isNotBlank() } ?: defaultStyle
        val angle = overhangDeg.takeIf { it in 1..89 } ?: defaultAngle
        return SupportOptions(
            style = style,
            overhangDeg = angle.coerceIn(1, 89),
            interfaceLayers = interfaceLayers.coerceIn(0, 6),
            buildPlateOnly = buildPlateOnly
        )
    }
}
data class ToolpathResult(
    val layers: List<ToolpathLayer>,
    val estimate: PrintEstimate,
    val warningCount: Int = 0,
    val exportBlockReason: String? = null
) {
    val pathCount: Int get() = layers.sumOf { it.paths.size }
    val canExport: Boolean get() = warningCount == 0 && exportBlockReason == null

    fun layerEstimate(index: Int, config: PrintConfiguration): LayerEstimate {
        val layer = layers.getOrNull(index) ?: return LayerEstimate(0f, 0f, 0)
        val filamentArea = Math.PI * (config.printer.filamentDiameter / 2f).pow(2).toDouble()
        var pathLength = 0.0
        var filament = 0.0
        var seconds = 0.0
        var last: Point2? = null
        for (path in layer.paths) {
            if (path.points.size < 2) continue
            last?.let { seconds += hypot((path.points.first().x-it.x).toDouble(), (path.points.first().y-it.y).toDouble()) / 150.0 }
            val len = path.lengthMm.toDouble(); pathLength += len
            filament += (len * path.widthMm * layer.heightMm * path.flowRatio.coerceAtLeast(0f)) / filamentArea
            seconds += len / path.speedMmS.coerceAtLeast(1f)
            last = path.points.last()
        }
        seconds += 0.35
        return LayerEstimate(pathLength.toFloat(), filament.toFloat(), ceil(seconds).toInt())
    }
}

/**
 * Slice Engine V2 toolpath stage.
 *
 * Improvements over the first alpha planner:
 * - hole-aware perimeter offsets using canonical contour nesting from ContourSlicer V2
 * - wall-safe interior region for skin/infill (no full-contour infill overlap)
 * - local top/bottom surface detection, so steps/ledges receive solid skin in the middle of a model
 * - bounded subdivision at surface transitions instead of classifying a whole long line by one midpoint
 * - narrow-region gap-fill fallback
 * - deterministic travel ordering and the existing volumetric-flow cap/safety gates
 */
object ToolpathEngine {
    private const val EPS = 1e-4f
    private const val SURFACE_CLASSIFY_SEGMENT_MM = 1.25f
    private const val BRIDGE_SPEED_MM_S = 25f
    private const val OVERHANG_WALL_SPEED_MM_S = 35f
    private const val IRONING_SPEED_MM_S = 30f
    private const val FIRST_LAYER_FLOW = 1.03f
    private const val BRIDGE_FLOW = 1.05f
    private const val IRONING_FLOW = 0.12f

    private fun packedToolpath(
        points: List<Point2>,
        role: PathRole,
        closed: Boolean,
        width: Float,
        speed: Float,
        flowRatio: Float = 1f,
        accelerationMmS2: Int = 0,
        bridge: Boolean = false,
        ironing: Boolean = false
    ): Toolpath = Toolpath(
        packPoints(points), role, closed, width, speed,
        flowRatio = flowRatio,
        accelerationMmS2 = accelerationMmS2,
        bridge = bridge,
        ironing = ironing
    )

    fun plan(slice: SliceResult, config: PrintConfiguration): ToolpathResult {
        config.validate()
        if (slice.layers.isEmpty()) return ToolpathResult(emptyList(), PrintEstimate(0f,0f,0f,0))
        val lineWidth = config.printer.nozzleDiameter * 1.05f
        val p = config.process
        val layers = ArrayList<ToolpathLayer>(slice.layers.size)
        val supportOptions = SupportSettings.snapshot(p.supportStyle, p.supportOverhangDeg)
        val supportByLayer = if (p.supportEnabled) SupportPlanner.plan(slice, lineWidth, supportOptions) else emptyMap()
        val containment = LayerContainmentIndex(slice)
        val warnings = slice.exportBlockerCount
        val exportBlockReason = slice.exportBlockerSummary()

        slice.layers.forEachIndexed { index, layer ->
            val paths = mutableListOf<Toolpath>()
            val height = if (index == 0) p.firstLayerHeightMm else p.layerHeightMm
            val firstLayer = index == 0
            val layerLineWidth = if (firstLayer) lineWidth * 1.14f else lineWidth
            val firstLayerSpeed = 20f

            fun cappedSpeed(requested: Float, width: Float = layerLineWidth, flow: Float = 1f): Float {
                val volumetricCap = config.filament.maxVolumetricSpeedMm3s /
                    (width * height * flow.coerceAtLeast(0.05f)).coerceAtLeast(0.01f)
                return min(requested, volumetricCap).coerceAtLeast(5f)
            }

            val firstFlow = if (firstLayer) FIRST_LAYER_FLOW else 1f
            val fillSpeed = cappedSpeed(if (firstLayer) firstLayerSpeed else 90f, layerLineWidth, firstFlow)

            // Deterministic rear seam + overhang-aware wall speeds.
            for (loop in layer.loops) {
                val base = normalizeLoop(loop.points)
                if (base.size < 3) continue
                repeat(p.wallLoops) { wallIndex ->
                    val distance = layerLineWidth * (0.5f + wallIndex)
                    val wall = offsetIntoMaterial(loop, base, distance)
                    if (wall.size >= 3 && abs(PolygonOps.area(wall)) > layerLineWidth * layerLineWidth * 0.15f) {
                        val closed = placeRearSeam(close(wall))
                        val unsupported = unsupportedFraction(containment, index, closed)
                        val overhang = index > 0 && unsupported >= 0.22f
                        val requested = when {
                            firstLayer -> firstLayerSpeed
                            overhang -> OVERHANG_WALL_SPEED_MM_S
                            wallIndex == 0 -> 45f
                            else -> 60f
                        }
                        val speed = cappedSpeed(requested, layerLineWidth, firstFlow)
                        val accel = when {
                            firstLayer -> 500
                            overhang -> 1000
                            wallIndex == 0 -> 1500
                            else -> 2200
                        }
                        paths += packedToolpath(
                            closed, PathRole.WALL, true, layerLineWidth, speed,
                            flowRatio = firstFlow, accelerationMmS2 = accel
                        )
                    }
                }
            }

            // Create the region left after wall shells. This prevents skin/infill from occupying the wall band.
            val interiorMargin = layerLineWidth * (p.wallLoops + 0.35f)
            val interiorLoops = materialInteriorLoops(layer.loops, interiorMargin)
            val hasInterior = interiorLoops.any { !it.isHole }

            if (hasInterior) {
                // Local surface skin with bridge detection. Unsupported solid pieces print slower with a slight
                // bridge-flow increase; supported skin uses normal quality settings.
                val skinAngle = if (index % 2 == 0) 45f else -45f
                val skinCandidates = LineFill.generate(interiorLoops, spacing = layerLineWidth * 0.92f, angleDeg = skinAngle)
                for (candidate in skinCandidates) {
                    for (piece in splitLine(candidate, SURFACE_CLASSIFY_SEGMENT_MM)) {
                        val mid = midpoint(piece)
                        if (isSolidSurface(containment, index, mid, p.bottomLayers, p.topLayers)) {
                            val bridge = index > 0 && !containment.inside(index - 1, mid)
                            val flow = when {
                                firstLayer -> FIRST_LAYER_FLOW
                                bridge -> BRIDGE_FLOW
                                else -> 1f
                            }
                            val speed = cappedSpeed(
                                when {
                                    firstLayer -> firstLayerSpeed
                                    bridge -> BRIDGE_SPEED_MM_S
                                    else -> 45f
                                },
                                layerLineWidth, flow
                            )
                            paths += packedToolpath(
                                piece, PathRole.SOLID, false, layerLineWidth, speed,
                                flowRatio = flow,
                                accelerationMmS2 = if (bridge) 900 else if (firstLayer) 500 else 1800,
                                bridge = bridge
                            )
                        }
                    }
                }

                // Sparse infill is emitted only where the same local point is not part of a top/bottom skin zone.
                if (p.infillPercent > 0) {
                    val density = p.infillPercent.coerceIn(1, 100) / 100f
                    val spacing = (layerLineWidth / density).coerceAtLeast(layerLineWidth)
                    val angle = when (p.infillPattern.lowercase()) {
                        "grid" -> if (index % 2 == 0) 0f else 90f
                        "gyroid" -> if (index % 2 == 0) 45f else -45f // bounded mobile approximation
                        else -> if (index % 2 == 0) 45f else -45f
                    }
                    val infillCandidates = LineFill.generate(interiorLoops, spacing, angle)
                    for (candidate in infillCandidates) {
                        for (piece in splitLine(candidate, SURFACE_CLASSIFY_SEGMENT_MM)) {
                            if (!isSolidSurface(containment, index, midpoint(piece), p.bottomLayers, p.topLayers)) {
                                paths += packedToolpath(
                                    piece, PathRole.INFILL, false, layerLineWidth, fillSpeed,
                                    flowRatio = firstFlow,
                                    accelerationMmS2 = if (firstLayer) 500 else 3000
                                )
                            }
                        }
                    }
                }

                // Iron only truly exposed top surfaces. This is intentionally conservative: low flow, moderate
                // spacing and no ironing on layer 0 keeps the alpha engine predictable on mobile.
                if (!firstLayer && p.topLayers > 0) {
                    val ironing = LineFill.generate(
                        interiorLoops,
                        spacing = (layerLineWidth * 1.20f).coerceAtLeast(0.45f),
                        angleDeg = if (index % 2 == 0) 0f else 90f
                    )
                    for (candidate in ironing) {
                        // Ironing can use much longer classification pieces than skin; this keeps the
                        // mobile planner and preview responsive without losing the exposed-top test.
                        for (piece in splitLine(candidate, 4.0f)) {
                            val mid = midpoint(piece)
                            if (isImmediateTopSurface(containment, index, mid)) {
                                paths += packedToolpath(
                                    piece, PathRole.SOLID, false, layerLineWidth,
                                    cappedSpeed(IRONING_SPEED_MM_S, layerLineWidth, IRONING_FLOW),
                                    flowRatio = IRONING_FLOW,
                                    accelerationMmS2 = 1200,
                                    ironing = true
                                )
                            }
                        }
                    }
                }
            } else if (layer.loops.isNotEmpty()) {
                // Thin islands can disappear after N wall offsets. Fill their remaining center region rather than
                // silently leaving a printable-looking shell with an empty narrow gap.
                val nominalGapWidth = (layerLineWidth * 0.82f).coerceAtLeast(config.printer.nozzleDiameter * 0.72f)
                val gap = LineFill.generate(layer.loops, spacing = nominalGapWidth, angleDeg = if (index % 2 == 0) 0f else 90f)
                gap.forEach {
                    if (it.size >= 2) {
                        // Arachne-inspired narrow-gap handling: use local contour clearance to vary
                        // extrusion width instead of forcing every thin feature through one fixed width.
                        val clearance = nearestBoundaryDistance(midpoint(it), layer.loops)
                        val localGapWidth = (clearance * 2f).coerceIn(
                            config.printer.nozzleDiameter * 0.65f,
                            config.printer.nozzleDiameter * 1.20f
                        )
                        paths += packedToolpath(
                            it, PathRole.GAP_FILL, false, localGapWidth,
                            cappedSpeed(if (firstLayer) firstLayerSpeed else 38f, localGapWidth, firstFlow),
                            flowRatio = firstFlow,
                            accelerationMmS2 = if (firstLayer) 500 else 1400
                        )
                    }
                }
            }

            supportByLayer[index]?.let { supportLayer ->
                supportLayer.body.forEach { seg ->
                    paths += packedToolpath(
                        seg, PathRole.SUPPORT, false, layerLineWidth * 0.95f,
                        cappedSpeed(if (firstLayer) firstLayerSpeed else 55f, layerLineWidth * 0.95f, firstFlow),
                        flowRatio = if (firstLayer) firstFlow else 0.96f,
                        accelerationMmS2 = if (firstLayer) 500 else 1800
                    )
                }
                supportLayer.interfacePaths.forEach { seg ->
                    paths += packedToolpath(
                        seg, PathRole.SUPPORT_INTERFACE, false, layerLineWidth,
                        cappedSpeed(if (firstLayer) firstLayerSpeed else 32f, layerLineWidth, if (firstLayer) firstFlow else 0.94f),
                        flowRatio = if (firstLayer) firstFlow else 0.94f,
                        accelerationMmS2 = if (firstLayer) 500 else 1100
                    )
                }
            }

            if (firstLayer && p.brimWidthMm > EPS) {
                val rings = ceil(p.brimWidthMm / layerLineWidth).toInt().coerceAtMost(40)
                for (loop in layer.loops.filter { !it.isHole }) {
                    val base = normalizeLoop(loop.points)
                    repeat(rings) { ring ->
                        val expanded = PolygonOps.outset(base, layerLineWidth * (0.5f + ring))
                        if (expanded.size >= 3) paths += packedToolpath(
                            placeRearSeam(close(expanded)), PathRole.BRIM, true,
                            layerLineWidth, cappedSpeed(firstLayerSpeed, layerLineWidth, FIRST_LAYER_FLOW),
                            flowRatio = FIRST_LAYER_FLOW, accelerationMmS2 = 500
                        )
                    }
                }
            }
            layers += ToolpathLayer(index, layer.z, height, optimizeTravel(paths))
        }

        return ToolpathResult(layers, estimate(layers, config), warnings, exportBlockReason)
    }

    private fun materialInteriorLoops(loops: List<SliceLoop>, distance: Float): List<SliceLoop> {
        val out = ArrayList<SliceLoop>(loops.size)
        for (loop in loops) {
            val base = normalizeLoop(loop.points)
            if (base.size < 3) continue
            val shifted = offsetIntoMaterial(loop, base, distance)
            if (shifted.size >= 3 && abs(PolygonOps.area(shifted)) > EPS) {
                out += loop.copy(points = packPoints(close(shifted)))
            }
        }
        return out
    }

    private fun offsetIntoMaterial(loop: SliceLoop, base: List<Point2>, distance: Float): List<Point2> {
        val shifted = if (loop.isHole) PolygonOps.outset(base, distance) else PolygonOps.inset(base, distance)
        if (shifted.size < 3) return emptyList()
        // A sign flip means a simple miter offset crossed/collapsed itself. Treat that region as
        // collapsed so the narrow-region gap-fill fallback can handle it safely.
        val a0 = PolygonOps.area(base); val a1 = PolygonOps.area(shifted)
        return if (a0 * a1 <= 0f) emptyList() else shifted
    }

    private fun nearestBoundaryDistance(p: Point2, loops: List<SliceLoop>): Float {
        var best = Float.POSITIVE_INFINITY
        for (loop in loops) {
            val pts = normalizeLoop(loop.points)
            if (pts.size < 2) continue
            for (i in pts.indices) {
                val a = pts[i]
                val b = pts[(i + 1) % pts.size]
                val d = pointSegmentDistance(p, a, b)
                if (d < best) best = d
            }
        }
        return if (best.isFinite()) best else 0f
    }

    private fun pointSegmentDistance(p: Point2, a: Point2, b: Point2): Float {
        val vx = b.x - a.x
        val vy = b.y - a.y
        val len2 = vx * vx + vy * vy
        if (len2 <= EPS * EPS) return sqrt(dist2(p, a))
        val t = (((p.x - a.x) * vx + (p.y - a.y) * vy) / len2).coerceIn(0f, 1f)
        val q = Point2(a.x + vx * t, a.y + vy * t)
        return sqrt(dist2(p, q))
    }

    private fun isSolidSurface(containment: LayerContainmentIndex, index: Int, p: Point2, bottomLayers: Int, topLayers: Int): Boolean {
        val bottom = bottomLayers > 0 && !containment.inside(index - bottomLayers, p)
        val top = topLayers > 0 && !containment.inside(index + topLayers, p)
        return bottom || top
    }

    private fun isImmediateTopSurface(containment: LayerContainmentIndex, index: Int, p: Point2): Boolean =
        !containment.inside(index + 1, p)

    /**
     * Deterministic rear seam for closed loops. The highest-Y vertex is used as the seam anchor,
     * with X as a stable tie-breaker. Closed-loop geometry is preserved exactly.
     */
    private fun placeRearSeam(points: List<Point2>): List<Point2> {
        if (points.size < 4) return points
        val closed = dist2(points.first(), points.last()) < EPS * EPS
        val n = if (closed) points.size - 1 else points.size
        if (n < 3) return points
        var best = 0
        for (i in 1 until n) {
            val a = points[i]
            val b = points[best]
            if (a.y > b.y + EPS || (abs(a.y - b.y) <= EPS && a.x < b.x)) best = i
        }
        if (best == 0) return if (closed) points else points + points.first()
        val out = ArrayList<Point2>(n + 1)
        for (k in 0 until n) out += points[(best + k) % n]
        out += out.first()
        return out
    }

    /**
     * Samples a path against the immediately previous layer. This is deliberately bounded so
     * complex models do not pay an expensive per-vertex containment cost.
     */
    private fun unsupportedFraction(containment: LayerContainmentIndex, index: Int, points: List<Point2>): Float {
        if (index <= 0 || points.size < 2) return 0f
        val n = if (dist2(points.first(), points.last()) < EPS * EPS) points.size - 1 else points.size
        if (n <= 0) return 0f
        val stride = max(1, n / 24)
        var samples = 0
        var unsupported = 0
        var i = 0
        while (i < n) {
            samples++
            if (!containment.inside(index - 1, points[i])) unsupported++
            i += stride
        }
        return if (samples == 0) 0f else unsupported.toFloat() / samples.toFloat()
    }

    /** Tiny 4-float bounds per contour make repeated local-surface membership tests much cheaper. */
    private class LayerContainmentIndex(slice: SliceResult) {
        private data class LoopIndex(val loop: SliceLoop, val minX:Float, val minY:Float, val maxX:Float, val maxY:Float)
        private val layers = slice.layers.map { layer -> layer.loops.mapNotNull { loop ->
            val pts=loop.points
            if(pts.size<3)null else LoopIndex(loop,pts.minOf{it.x},pts.minOf{it.y},pts.maxOf{it.x},pts.maxOf{it.y})
        }}
        fun inside(index:Int,p:Point2):Boolean{
            val loops=layers.getOrNull(index)?:return false
            var inside=false
            for(entry in loops){
                if(p.x<entry.minX||p.x>entry.maxX||p.y<entry.minY||p.y>entry.maxY)continue
                val poly=entry.loop.points
                val n=if(poly.size>1&&dist2(poly.first(),poly.last())<EPS*EPS)poly.size-1 else poly.size
                if(n<3)continue
                var j=n-1
                for(i in 0 until n){val a=poly[i];val b=poly[j];if(((a.y>p.y)!=(b.y>p.y))&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y+1e-12f)+a.x)inside=!inside;j=i}
            }
            return inside
        }
    }

    private fun splitLine(points: List<Point2>, maxPieceMm: Float): List<List<Point2>> {
        if (points.size < 2) return emptyList()
        val out = ArrayList<List<Point2>>()
        for (i in 1 until points.size) {
            val a = points[i - 1]; val b = points[i]
            val len = hypot((b.x-a.x).toDouble(), (b.y-a.y).toDouble()).toFloat()
            if (len <= EPS) continue
            val n = ceil(len / maxPieceMm).toInt().coerceAtLeast(1)
            var prev = a
            for (k in 1..n) {
                val t = k.toFloat() / n
                val next = Point2(a.x + (b.x-a.x)*t, a.y + (b.y-a.y)*t)
                out += listOf(prev, next)
                prev = next
            }
        }
        return out
    }

    private fun midpoint(seg: List<Point2>): Point2 {
        val a = seg.first(); val b = seg.last()
        return Point2((a.x+b.x)*0.5f, (a.y+b.y)*0.5f)
    }

    private fun normalizeLoop(points: List<Point2>): List<Point2> =
        if (points.size >= 2 && dist2(points.first(), points.last()) < EPS*EPS) points.dropLast(1) else points

    private fun close(points: List<Point2>): List<Point2> = if (points.isEmpty()) points else points + points.first()

    /**
     * Phase-aware nearest-neighbour ordering. Quality-critical phases stay in a safe print order
     * (walls/skin before sparse infill, ironing always last) while each phase still gets cheap
     * travel optimization on mobile.
     */
    private fun optimizeTravel(paths: List<Toolpath>): List<Toolpath> {
        if (paths.size < 3) return paths
        val phases = listOf<(Toolpath)->Boolean>(
            { it.role == PathRole.BRIM },
            { it.role == PathRole.WALL },
            { it.role == PathRole.SOLID && !it.ironing },
            { it.role == PathRole.GAP_FILL },
            { it.role == PathRole.INFILL },
            { it.role == PathRole.SUPPORT || it.role == PathRole.SUPPORT_INTERFACE },
            { it.ironing }
        )
        val out = ArrayList<Toolpath>(paths.size)
        var cursor = Point2(0f, 0f)

        fun appendGroup(group: List<Toolpath>) {
            if (group.isEmpty()) return
            val remaining = group.toMutableList()
            while (remaining.isNotEmpty()) {
                var best = 0
                var bestD = Float.POSITIVE_INFINITY
                var reverse = false
                for (i in remaining.indices) {
                    val p = remaining[i]
                    if (p.points.isEmpty()) continue
                    val d0 = dist2(cursor, p.points.first())
                    val d1 = if (!p.closed) dist2(cursor, p.points.last()) else d0
                    if (min(d0, d1) < bestD) {
                        bestD = min(d0, d1)
                        best = i
                        reverse = d1 < d0
                    }
                }
                var chosen = remaining.removeAt(best)
                if (reverse) chosen = chosen.copy(points = packPoints(chosen.points.reversed()))
                out += chosen
                if (chosen.points.isNotEmpty()) cursor = chosen.points.last()
            }
        }

        for (phase in phases) appendGroup(paths.filter(phase))
        // Future roles/hints remain printable even if a new phase is added later.
        appendGroup(paths.filterNot { p -> phases.any { it(p) } })
        return out
    }

    private fun estimate(layers: List<ToolpathLayer>, config: PrintConfiguration): PrintEstimate {
        val filamentArea = Math.PI * (config.printer.filamentDiameter/2f).pow(2).toDouble()
        var pathLength=0.0
        var filamentLength=0.0
        var seconds=0.0
        var last:Point2?=null
        for (layer in layers) {
            for (path in layer.paths) {
                if(path.points.size<2)continue
                last?.let { seconds += hypot((path.points.first().x-it.x).toDouble(),(path.points.first().y-it.y).toDouble()) / 150.0 }
                val len=path.lengthMm.toDouble();pathLength+=len
                val volume=len*path.widthMm*layer.heightMm*path.flowRatio.coerceAtLeast(0f)
                filamentLength += volume/filamentArea
                seconds += len/path.speedMmS.coerceAtLeast(1f)
                last=path.points.last()
            }
            seconds += 0.35
        }
        val filamentVolumeMm3=filamentLength*filamentArea
        val grams=filamentVolumeMm3/1000.0*config.filament.densityGcm3
        return PrintEstimate(pathLength.toFloat(),filamentLength.toFloat(),grams.toFloat(),ceil(seconds).toInt())
    }

    private fun dist2(a:Point2,b:Point2):Float{val x=a.x-b.x;val y=a.y-b.y;return x*x+y*y}
}

object PolygonOps {
    private const val EPS=1e-6f
    fun area(poly:List<Point2>):Float{
        if(poly.size<3)return 0f
        var a=0.0
        for(i in poly.indices){val p=poly[i];val q=poly[(i+1)%poly.size];a+=p.x*q.y-q.x*p.y}
        return (a*0.5).toFloat()
    }

    fun inset(poly:List<Point2>,distance:Float)=offset(poly,distance)
    fun outset(poly:List<Point2>,distance:Float)=offset(poly,-distance)

    /** Mitered polygon offset. Falls back to averaged normals at near-parallel corners. */
    private fun offset(poly:List<Point2>, signedDistance:Float):List<Point2>{
        if(poly.size<3)return emptyList()
        val winding=if(area(poly)>=0f)1f else -1f
        val d=signedDistance*winding
        val out=ArrayList<Point2>(poly.size)
        for(i in poly.indices){
            val a=poly[(i-1+poly.size)%poly.size];val b=poly[i];val c=poly[(i+1)%poly.size]
            val l1=offsetLine(a,b,d);val l2=offsetLine(b,c,d)
            val x=intersection(l1.first,l1.second,l2.first,l2.second)
            if(x!=null && hypot((x.x-b.x).toDouble(),(x.y-b.y).toDouble()) <= abs(signedDistance)*8+2.0) out+=x
            else {
                val n1=normal(a,b);val n2=normal(b,c);var nx=n1.x+n2.x;var ny=n1.y+n2.y
                val len=hypot(nx.toDouble(),ny.toDouble()).toFloat().coerceAtLeast(EPS);nx/=len;ny/=len
                out+=Point2(b.x+nx*d,b.y+ny*d)
            }
        }
        return if(abs(area(out))>EPS)out else emptyList()
    }
    private fun normal(a:Point2,b:Point2):Point2{val dx=b.x-a.x;val dy=b.y-a.y;val l=hypot(dx.toDouble(),dy.toDouble()).toFloat().coerceAtLeast(EPS);return Point2(-dy/l,dx/l)}
    private fun offsetLine(a:Point2,b:Point2,d:Float):Pair<Point2,Point2>{val n=normal(a,b);return Point2(a.x+n.x*d,a.y+n.y*d) to Point2(b.x+n.x*d,b.y+n.y*d)}
    private fun intersection(a:Point2,b:Point2,c:Point2,d:Point2):Point2?{
        val x1=a.x;val y1=a.y;val x2=b.x;val y2=b.y;val x3=c.x;val y3=c.y;val x4=d.x;val y4=d.y
        val den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4);if(abs(den)<EPS)return null
        val p1=x1*y2-y1*x2;val p2=x3*y4-y3*x4
        return Point2((p1*(x3-x4)-(x1-x2)*p2)/den,(p1*(y3-y4)-(y1-y2)*p2)/den)
    }
}

object LineFill {
    private const val EPS=1e-5f
    /** Clips equally spaced lines against all contours using an even/odd fill rule, so holes remain empty. */
    fun generate(loops:List<SliceLoop>,spacing:Float,angleDeg:Float):List<List<Point2>>{
        if(loops.isEmpty()||spacing<=0f)return emptyList()
        val polys=loops.map { l -> if(l.points.size>1&&same(l.points.first(),l.points.last()))l.points.dropLast(1) else l.points }.filter{it.size>=3}
        if(polys.isEmpty())return emptyList()
        val angle=Math.toRadians(angleDeg.toDouble());val ca=cos(angle).toFloat();val sa=sin(angle).toFloat()
        fun rot(p:Point2)=Point2(p.x*ca+p.y*sa,-p.x*sa+p.y*ca)
        fun inv(p:Point2)=Point2(p.x*ca-p.y*sa,p.x*sa+p.y*ca)
        val rp=polys.map{it.map(::rot)}
        val minY=rp.minOf{p->p.minOf{it.y}};val maxY=rp.maxOf{p->p.maxOf{it.y}}
        val out=mutableListOf<List<Point2>>();var y=floor(minY/spacing)*spacing;var row=0
        while(y<=maxY+EPS){
            val xs=mutableListOf<Float>()
            for(poly in rp){
                for(i in poly.indices){val a=poly[i];val b=poly[(i+1)%poly.size]
                    if((a.y<=y&&b.y>y)||(b.y<=y&&a.y>y)){val t=(y-a.y)/(b.y-a.y);xs+=a.x+(b.x-a.x)*t}
                }
            }
            xs.sort();var i=0
            while(i+1<xs.size){val x0=xs[i];val x1=xs[i+1];if(x1-x0>EPS){val a=inv(Point2(x0,y));val b=inv(Point2(x1,y));out+=if(row%2==0)listOf(a,b)else listOf(b,a)};i+=2}
            y+=spacing;row++
        }
        return out
    }
    private fun same(a:Point2,b:Point2)=abs(a.x-b.x)<EPS&&abs(a.y-b.y)<EPS
}

/**
 * Memory-bounded raster support foundation. A compact adaptive boolean grid is used instead of object-heavy sets.
 * "Tree" mode gently merges columns toward the workspace centre while "Normal" keeps vertical columns.
 */
object SupportPlanner {
    private data class CellStep(val layer:Int,val x:Int,val y:Int,val interfaceCell:Boolean)

    fun plan(slice:SliceResult,lineWidth:Float,options:SupportOptions):Map<Int,SupportLayerPlan>{
        if(slice.layers.size<2)return emptyMap()
        val bounds=allBounds(slice)?:return emptyMap()
        val width=(bounds[2]-bounds[0]).coerceAtLeast(1f)
        val depth=(bounds[3]-bounds[1]).coerceAtLeast(1f)
        val area=width*depth

        // Fine enough to react to overhang angle while remaining memory bounded on large STLs.
        val targetCellsPerLayer=min(16000,max(1400,6_000_000/slice.layers.size))
        val adaptive=sqrt(area/targetCellsPerLayer.toFloat())
        val cell=max(max(0.55f,lineWidth*1.30f),adaptive)
        val nx=ceil(width/cell).toInt().coerceIn(1,640)
        val ny=ceil(depth/cell).toInt().coerceIn(1,640)
        val cellCount=nx*ny
        val occupied=Array(slice.layers.size){BooleanArray(cellCount)}
        slice.layers.forEachIndexed{i,layer->rasterInto(layer.loops,bounds,cell,nx,ny,occupied[i])}

        val support=Array(slice.layers.size){BooleanArray(cellCount)}
        val iface=Array(slice.layers.size){BooleanArray(cellCount)}
        val angle=options.overhangDeg.coerceIn(1,89)
        val layerStep=(slice.layers.getOrNull(1)?.let{it.z-slice.layers[0].z}?:0.2f).coerceAtLeast(0.05f)
        // The line-width allowance avoids classifying tiny contour jitter as a true unsupported overhang.
        val horizontalAllowance=(layerStep/tan(Math.toRadians(angle.toDouble())).toFloat()+lineWidth*0.50f).coerceAtLeast(0f)
        val supportRadius=floor(horizontalAllowance/cell+0.50f).toInt().coerceIn(0,3)
        val centreX=((nx-1)/2f).roundToInt().coerceIn(0,nx-1)
        val centreY=((ny-1)/2f).roundToInt().coerceIn(0,ny-1)
        val style=options.style.lowercase()
        val organic=style.contains("tree")||style.contains("organic")
        val hybrid=style.contains("hybrid")
        val interfaceCount=options.interfaceLayers.coerceIn(0,6)

        fun idx(x:Int,y:Int)=y*nx+x
        fun expandedSupportMask(below:BooleanArray):BooleanArray{
            if(supportRadius<=0)return below
            val expanded=BooleanArray(cellCount)
            for(y in 0 until ny)for(x in 0 until nx){
                if(!below[idx(x,y)])continue
                for(dy in -supportRadius..supportRadius)for(dx in -supportRadius..supportRadius){
                    if(dx*dx+dy*dy>supportRadius*supportRadius)continue
                    val xx=x+dx;val yy=y+dy
                    if(xx in 0 until nx&&yy in 0 until ny)expanded[idx(xx,yy)]=true
                }
            }
            return expanded
        }

        fun candidateMove(x:Int,y:Int):Pair<Int,Int>{
            val sx=stepToward(x,centreX);val sy=stepToward(y,centreY)
            return (x+sx).coerceIn(0,nx-1) to (y+sy).coerceIn(0,ny-1)
        }

        fun routeContact(topLayer:Int,startX:Int,startY:Int){
            var cx=startX;var cy=startY
            val route=ArrayList<CellStep>(min(topLayer,64))
            var accepted=!options.buildPlateOnly
            for(j in topLayer-1 downTo 0){
                val k=idx(cx,cy)
                // Non-plate-only support is allowed to terminate on model. Plate-only support
                // must either reach layer 0 or merge into an already plate-connected branch.
                if(occupied[j][k])break
                val fromContact=topLayer-j
                val existing=support[j][k]||iface[j][k]
                route+=CellStep(j,cx,cy,fromContact<=interfaceCount)
                // Normal support is vertical, so an existing cell has an identical suffix and can
                // be merged safely. Organic/Hybrid branches keep routing because their later merge
                // cadence depends on distance from this contact; stopping early would subtly alter
                // the generated branch union.
                if(existing&&!organic&&!hybrid){accepted=true;break}
                if(j==0){accepted=true;break}

                val shouldMerge=when{
                    hybrid -> fromContact>max(3,interfaceCount+1)&&(fromContact-interfaceCount)%4==0
                    organic -> fromContact>interfaceCount&&fromContact%3==0
                    else -> false
                }
                if(shouldMerge){
                    val (nx1,ny1)=candidateMove(cx,cy)
                    if(!occupied[j][idx(nx1,ny1)]){cx=nx1;cy=ny1}
                }
            }
            if(route.isEmpty()||!accepted)return
            for(step in route){
                val k=idx(step.x,step.y)
                if(step.interfaceCell)iface[step.layer][k]=true else if(!iface[step.layer][k])support[step.layer][k]=true
            }
        }

        // Find unsupported model cells and grow support downward from each contact. Expanding the
        // previous layer once makes the overhang test O(1) per occupied cell instead of repeatedly
        // scanning the same neighbourhood for every candidate.
        for(i in 1 until occupied.size){
            val cur=occupied[i]
            val supportedMask=expandedSupportMask(occupied[i-1])
            for(y in 0 until ny)for(x in 0 until nx){
                val k=idx(x,y)
                if(!cur[k]||supportedMask[k])continue
                routeContact(i,x,y)
            }
        }

        val out=mutableMapOf<Int,SupportLayerPlan>()
        support.indices.forEach{i->
            // Interface wins where both grids overlap.
            for(k in iface[i].indices)if(iface[i][k])support[i][k]=false
            val bodySegments=gridSegments(support[i],bounds,cell,nx,ny,vertical=(i%2==1),shrink=0.12f)
            val interfaceSegments=gridSegments(iface[i],bounds,cell,nx,ny,vertical=(i%2==0),shrink=0.02f)
            if(bodySegments.isNotEmpty()||interfaceSegments.isNotEmpty())out[i]=SupportLayerPlan(bodySegments,interfaceSegments)
        }
        return out
    }

    private fun gridSegments(grid:BooleanArray,b:FloatArray,cell:Float,nx:Int,ny:Int,vertical:Boolean,shrink:Float):List<List<Point2>>{
        if(grid.none{it})return emptyList()
        val out=mutableListOf<List<Point2>>()
        fun idx(x:Int,y:Int)=y*nx+x
        val pad=(cell*shrink).coerceAtMost(cell*0.30f)
        if(!vertical){
            for(y in 0 until ny){
                var x=0
                while(x<nx){
                    while(x<nx&&!grid[idx(x,y)])x++
                    if(x>=nx)break
                    val x0=x
                    while(x+1<nx&&grid[idx(x+1,y)])x++
                    val x1=x
                    val py=b[1]+(y+0.5f)*cell
                    out+=listOf(Point2(b[0]+x0*cell+pad,py),Point2(b[0]+(x1+1)*cell-pad,py))
                    x++
                }
            }
        }else{
            for(x in 0 until nx){
                var y=0
                while(y<ny){
                    while(y<ny&&!grid[idx(x,y)])y++
                    if(y>=ny)break
                    val y0=y
                    while(y+1<ny&&grid[idx(x,y+1)])y++
                    val y1=y
                    val px=b[0]+(x+0.5f)*cell
                    out+=listOf(Point2(px,b[1]+y0*cell+pad),Point2(px,b[1]+(y1+1)*cell-pad))
                    y++
                }
            }
        }
        return out
    }

    private fun stepToward(v:Int,target:Int)=when{v<target->1;v>target->-1;else->0}
    private fun allBounds(slice:SliceResult):FloatArray?{
        var has=false;var minX=Float.POSITIVE_INFINITY;var minY=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY;var maxY=Float.NEGATIVE_INFINITY
        for(layer in slice.layers)for(loop in layer.loops)for(p in loop.points){
            has=true;minX=min(minX,p.x);minY=min(minY,p.y);maxX=max(maxX,p.x);maxY=max(maxY,p.y)
        }
        return if(has)floatArrayOf(minX,minY,maxX,maxY)else null
    }
    private fun rasterInto(loops:List<SliceLoop>,b:FloatArray,cell:Float,nx:Int,ny:Int,out:BooleanArray){
        if(loops.isEmpty()||nx<=0||ny<=0)return
        // Scanline rasterizer: bucket each contour edge only into the rows it crosses, then apply
        // the same even/odd fill rule by pairing sorted intersections. This preserves holes while
        // avoiding the old grid-cell × every-contour-edge point-in-polygon loop.
        val rows=Array(ny){ArrayList<Float>()}
        val baseY=b[1]
        for(loop in loops){
            val pts=loop.points
            val n=if(pts.size>1&&pts.first()==pts.last())pts.size-1 else pts.size
            if(n<3)continue
            for(i in 0 until n){
                val a=pts[i];val c=pts[(i+1)%n]
                val dy=c.y-a.y
                if(abs(dy)<=1e-12f)continue
                val low=min(a.y,c.y);val high=max(a.y,c.y)
                var r0=ceil((low-baseY)/cell-0.5f).toInt()
                var r1=ceil((high-baseY)/cell-0.5f).toInt()-1 // half-open [low, high)
                if(r1<0||r0>=ny)continue
                r0=r0.coerceAtLeast(0);r1=r1.coerceAtMost(ny-1)
                if(r0>r1)continue
                for(row in r0..r1){
                    val py=baseY+(row+0.5f)*cell
                    val t=(py-a.y)/dy
                    rows[row].add(a.x+(c.x-a.x)*t)
                }
            }
        }
        val baseX=b[0]
        for(y in 0 until ny){
            val xs=rows[y]
            if(xs.size<2)continue
            xs.sort()
            var i=0
            while(i+1<xs.size){
                val x0=xs[i];val x1=xs[i+1]
                if(x1>x0+1e-6f){
                    var ix0=ceil((x0-baseX)/cell-0.5f).toInt()
                    var ix1=ceil((x1-baseX)/cell-0.5f).toInt()-1
                    if(ix1>=0&&ix0<nx){
                        ix0=ix0.coerceAtLeast(0);ix1=ix1.coerceAtMost(nx-1)
                        if(ix0<=ix1)for(x in ix0..ix1)out[y*nx+x]=true
                    }
                }
                i+=2
            }
        }
    }

    private fun insideEvenOdd(p:Point2,loops:List<SliceLoop>):Boolean{
        var inside=false
        for(loop in loops){
            val poly=if(loop.points.size>1&&loop.points.first()==loop.points.last())loop.points.dropLast(1)else loop.points
            if(poly.size<3)continue
            var j=poly.lastIndex
            for(i in poly.indices){
                val a=poly[i];val b=poly[j]
                if(((a.y>p.y)!=(b.y>p.y))&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y+1e-12f)+a.x)inside=!inside
                j=i
            }
        }
        return inside
    }
}

