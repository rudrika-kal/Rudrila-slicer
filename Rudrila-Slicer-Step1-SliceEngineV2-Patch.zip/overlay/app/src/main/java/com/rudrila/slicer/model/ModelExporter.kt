package com.rudrila.slicer.model

import java.io.BufferedOutputStream
import java.io.BufferedWriter
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.sqrt

enum class ModelExportFormat(val extension:String, val displayName:String) {
    STL("stl", "STL"),
    THREE_MF("3mf", "3MF")
}

data class ModelExportStats(
    val objectCount:Int,
    val triangleCount:Long
)

/**
 * Saves the current scene geometry after the app's move / rotate / scale transforms have been baked in.
 * This exporter intentionally writes model geometry only; slicer-only toolpaths, brim, support and G-code
 * remain separate outputs.
 */
object ModelExporter {
    private const val BUFFER_SIZE = 256 * 1024

    fun write(objects:List<SceneObject>, output:OutputStream, format:ModelExportFormat):ModelExportStats {
        require(objects.isNotEmpty()) { "No models on plate" }
        return when(format) {
            ModelExportFormat.STL -> writeBinaryStl(objects, output)
            ModelExportFormat.THREE_MF -> writeThreeMf(objects, output)
        }
    }

    private fun writeBinaryStl(objects:List<SceneObject>, output:OutputStream):ModelExportStats {
        val triangleCount = objects.sumOf { (it.mesh.vertices.size / 9).toLong() }
        require(triangleCount > 0L) { "Model has no triangles" }
        require(triangleCount <= 0xFFFF_FFFFL) { "STL triangle count is too large" }

        val out = BufferedOutputStream(output, BUFFER_SIZE)
        val header = ByteArray(80)
        val label = "RUDRILA SLICER • transformed model".toByteArray(Charsets.US_ASCII)
        System.arraycopy(label, 0, header, 0, minOf(label.size, header.size))
        out.write(header)
        out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(triangleCount.toInt()).array())

        val world = FloatArray(9)
        val record = ByteBuffer.allocate(50).order(ByteOrder.LITTLE_ENDIAN)
        for(obj in objects) {
            val source = obj.mesh.vertices
            val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
            var base = 0
            while(base + 8 < source.size) {
                tx.write(base, world, 0)
                tx.write(base + 3, world, 3)
                tx.write(base + 6, world, 6)

                val ux = world[3] - world[0]
                val uy = world[4] - world[1]
                val uz = world[5] - world[2]
                val vx = world[6] - world[0]
                val vy = world[7] - world[1]
                val vz = world[8] - world[2]
                var nx = uy * vz - uz * vy
                var ny = uz * vx - ux * vz
                var nz = ux * vy - uy * vx
                val mag = sqrt((nx * nx + ny * ny + nz * nz).toDouble()).toFloat()
                if(mag > 1e-12f) {
                    nx /= mag; ny /= mag; nz /= mag
                } else {
                    nx = 0f; ny = 0f; nz = 0f
                }

                record.clear()
                record.putFloat(nx); record.putFloat(ny); record.putFloat(nz)
                for(i in 0 until 9) record.putFloat(world[i])
                record.putShort(0)
                out.write(record.array(), 0, 50)
                base += 9
            }
        }
        out.flush()
        return ModelExportStats(objects.size, triangleCount)
    }

    private fun writeThreeMf(objects:List<SceneObject>, output:OutputStream):ModelExportStats {
        val triangleCount = objects.sumOf { (it.mesh.vertices.size / 9).toLong() }
        require(triangleCount > 0L) { "Model has no triangles" }

        ZipOutputStream(BufferedOutputStream(output, BUFFER_SIZE)).use { zip ->
            putUtf8Entry(
                zip,
                "[Content_Types].xml",
                """<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>
</Types>"""
            )
            putUtf8Entry(
                zip,
                "_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>
</Relationships>"""
            )

            zip.putNextEntry(ZipEntry("3D/3dmodel.model"))
            val writer = BufferedWriter(OutputStreamWriter(zip, Charsets.UTF_8), BUFFER_SIZE)
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            writer.write("<model unit=\"millimeter\" xml:lang=\"en-US\" xmlns=\"http://schemas.microsoft.com/3dmanufacturing/core/2015/02\">\n")
            writer.write("  <metadata name=\"Application\">RUDRILA SLICER</metadata>\n")
            writer.write("  <resources>\n")

            objects.forEachIndexed { index, obj ->
                val id = index + 1
                val source = obj.mesh.vertices
                val vertexCount = source.size / 3
                val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
                val world = FloatArray(3)

                writer.write("    <object id=\""); writer.write(id.toString())
                writer.write("\" type=\"model\" name=\""); writer.write(xmlEscape(obj.name)); writer.write("\">\n")
                writer.write("      <mesh>\n")
                writer.write("        <vertices>\n")
                var offset = 0
                while(offset + 2 < source.size) {
                    tx.write(offset, world, 0)
                    writer.write("          <vertex x=\""); writer.write(world[0].toString())
                    writer.write("\" y=\""); writer.write(world[1].toString())
                    writer.write("\" z=\""); writer.write(world[2].toString()); writer.write("\"/>\n")
                    offset += 3
                }
                writer.write("        </vertices>\n")
                writer.write("        <triangles>\n")
                var v = 0
                while(v + 2 < vertexCount) {
                    writer.write("          <triangle v1=\""); writer.write(v.toString())
                    writer.write("\" v2=\""); writer.write((v + 1).toString())
                    writer.write("\" v3=\""); writer.write((v + 2).toString()); writer.write("\"/>\n")
                    v += 3
                }
                writer.write("        </triangles>\n")
                writer.write("      </mesh>\n")
                writer.write("    </object>\n")
            }

            writer.write("  </resources>\n")
            writer.write("  <build>\n")
            objects.indices.forEach { index ->
                writer.write("    <item objectid=\""); writer.write((index + 1).toString()); writer.write("\"/>\n")
            }
            writer.write("  </build>\n")
            writer.write("</model>\n")
            writer.flush()
            zip.closeEntry()
            zip.finish()
        }
        return ModelExportStats(objects.size, triangleCount)
    }

    private fun putUtf8Entry(zip:ZipOutputStream, name:String, text:String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(text.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun xmlEscape(value:String):String {
        val cleaned = buildString(value.length) {
            for(ch in value) {
                if(ch == '\t' || ch == '\n' || ch == '\r' || ch >= ' ') append(ch)
            }
        }
        return cleaned
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
