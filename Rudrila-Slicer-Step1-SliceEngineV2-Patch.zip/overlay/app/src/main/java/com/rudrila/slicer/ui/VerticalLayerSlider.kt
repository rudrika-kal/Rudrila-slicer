package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/**
 * Bambu-style vertical layer scrubber.
 * Bottom = layer 1, top = highest layer. The callback uses zero-based layer indexes.
 */
class VerticalLayerSlider @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(63, 70, 74) }
    private val activePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(38, 166, 120) }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 212, 215)
        textSize = 24f
        textAlign = Paint.Align.CENTER
    }

    var onProgressChanged: ((Int) -> Unit)? = null
    var onScrubStateChanged: ((Boolean) -> Unit)? = null
    private var callbackPosted = false
    private var pendingCallbackProgress = 0

    var max: Int = 0
        set(value) {
            field = value.coerceAtLeast(0)
            if (progress > field) progress = field
            invalidate()
        }

    var progress: Int = 0
        set(value) {
            val v = value.coerceIn(0, max)
            if (field == v) return
            field = v
            invalidate()
        }

    private val topPad get() = paddingTop + 32f
    private val bottomPad get() = height - paddingBottom - 32f
    private val cx get() = width * 0.5f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (height <= 0 || width <= 0) return
        val top = topPad
        val bottom = bottomPad.coerceAtLeast(top + 1f)
        val track = RectF(cx - 5f, top, cx + 5f, bottom)
        canvas.drawRoundRect(track, 5f, 5f, trackPaint)

        val y = yFor(progress)
        val active = RectF(cx - 5f, y, cx + 5f, bottom)
        canvas.drawRoundRect(active, 5f, 5f, activePaint)
        canvas.drawCircle(cx, y, 15f, thumbPaint)
        canvas.drawCircle(cx, y, 10f, activePaint)

        textPaint.textSize = 22f
        canvas.drawText((max + 1).toString(), cx, top - 10f, textPaint)
        canvas.drawText("1", cx, bottom + 27f, textPaint)
    }

    private fun yFor(value: Int): Float {
        val top = topPad
        val bottom = bottomPad.coerceAtLeast(top + 1f)
        if (max <= 0) return bottom
        val f = value.toFloat() / max.toFloat()
        return bottom - f * (bottom - top)
    }

    private fun dispatchProgressOnFrame(value: Int) {
        pendingCallbackProgress = value
        if (callbackPosted) return
        callbackPosted = true
        postOnAnimation {
            callbackPosted = false
            onProgressChanged?.invoke(pendingCallbackProgress)
        }
    }

    private fun setFromY(y: Float, immediate: Boolean = false) {
        val top = topPad
        val bottom = bottomPad.coerceAtLeast(top + 1f)
        val clamped = y.coerceIn(top, bottom)
        val f = ((bottom - clamped) / (bottom - top)).coerceIn(0f, 1f)
        val next = if (max <= 0) 0 else (f * max).roundToInt().coerceIn(0, max)
        if (next != progress) {
            progress = next
            if (immediate) onProgressChanged?.invoke(next) else dispatchProgressOnFrame(next)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onScrubStateChanged?.invoke(true)
                setFromY(event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                setFromY(event.y)
                return true
            }
            MotionEvent.ACTION_UP -> {
                setFromY(event.y, immediate = true)
                onScrubStateChanged?.invoke(false)
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                onScrubStateChanged?.invoke(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
