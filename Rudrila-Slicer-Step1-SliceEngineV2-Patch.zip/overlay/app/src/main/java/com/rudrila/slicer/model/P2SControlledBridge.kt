package com.rudrila.slicer.model

import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min

/**
 * Step 5.5 controlled P2S bridge.
 *
 * Rudrila does NOT bundle Bambu Studio's AGPL machine template. Instead the user imports one
 * already-resolved P2S G-code file produced by Bambu Studio for the dedicated 20x20x5 safety
 * cube. We retain only its resolved native start/end envelope and reuse that envelope only for
 * the same tightly-gated controlled cube. General P2S printer-ready export remains blocked.
 */
data class P2SNativeEnvelope(
    val startGcode: String,
    val endGcode: String,
    val sourceSha256: String
) {
    val shortSha: String get() = sourceSha256.take(12)
}

object P2SControlledBridge {
    private const val START_MARKER = ";======== P2S start gcode"
    private const val END_MARKER = ";======== P2S end gcode"
    private const val LAYER_MARKER = "; CHANGE_LAYER"
    private const val STORAGE_SPLIT = "\n;__RUDRILA_P2S_ENVELOPE_SPLIT_V1__\n"
    private const val MAX_REFERENCE_CHARS = 64 * 1024 * 1024

    fun parseResolvedReference(gcode: String): P2SNativeEnvelope {
        require(gcode.isNotBlank()) { "Reference G-code is empty" }
        require(gcode.length <= MAX_REFERENCE_CHARS) { "Reference G-code is too large" }
        val startAt = gcode.indexOf(START_MARKER)
        val firstLayerAt = gcode.indexOf(LAYER_MARKER)
        val endAt = gcode.lastIndexOf(END_MARKER)
        require(startAt >= 0) { "Not a resolved Bambu Lab P2S G-code: start marker missing" }
        require(firstLayerAt > startAt) { "Reference G-code first layer marker is missing" }
        require(endAt > firstLayerAt) { "Reference G-code P2S end marker is missing" }

        val start = gcode.substring(startAt, firstLayerAt).trimEnd() + "\n"
        val end = gcode.substring(endAt).trim() + "\n"
        require(start.length in 200..512_000) { "P2S start envelope length is not plausible" }
        require(end.length in 100..256_000) { "P2S end envelope length is not plausible" }
        require("G28" in start && "G29" in start) { "Reference does not contain P2S homing/leveling" }
        require("M190" in start && "M109" in start) { "Reference does not contain resolved bed/nozzle waits" }
        require("M104 S0" in end && "M140 S0" in end) { "Reference P2S shutdown sequence is incomplete" }
        require(!containsUnresolvedMacro(start) && !containsUnresolvedMacro(end)) {
            "Reference still contains slicer placeholders; import exported .gcode, not a template JSON"
        }
        return P2SNativeEnvelope(start, end, sha256(gcode))
    }

    fun encode(envelope: P2SNativeEnvelope): String = buildString {
        append("RUDRILA_P2S_ENVELOPE_V1\n")
        append(envelope.sourceSha256).append('\n')
        append(envelope.startGcode)
        append(STORAGE_SPLIT)
        append(envelope.endGcode)
    }

    fun decode(saved: String): P2SNativeEnvelope {
        require(saved.startsWith("RUDRILA_P2S_ENVELOPE_V1\n")) { "Unsupported P2S envelope cache" }
        val firstNl = saved.indexOf('\n')
        val secondNl = saved.indexOf('\n', firstNl + 1)
        require(secondNl > firstNl) { "Corrupt P2S envelope cache" }
        val sha = saved.substring(firstNl + 1, secondNl).trim()
        val payload = saved.substring(secondNl + 1)
        val splitAt = payload.indexOf(STORAGE_SPLIT)
        require(splitAt > 0) { "Corrupt P2S envelope cache" }
        val start = payload.substring(0, splitAt)
        val end = payload.substring(splitAt + STORAGE_SPLIT.length)
        require(start.contains(START_MARKER) && end.contains(END_MARKER)) { "Corrupt P2S envelope cache" }
        return P2SNativeEnvelope(start, end, sha)
    }

    /** Exact geometry/config gate for the one controlled real-printer test. */
    fun controlledTestErrors(toolpaths: ToolpathResult, config: PrintConfiguration, envelope: P2SNativeEnvelope?): List<String> {
        val errors = mutableListOf<String>()
        if (envelope == null) errors += "Import a resolved Bambu Studio P2S reference G-code first"
        if (config.printer.id != "bambu_p2s_04") errors += "Controlled test requires Bambu Lab P2S 0.4 mm profile"
        if (config.filament.id != "step5_pla") errors += "Controlled test requires Rudrila Generic PLA Balanced preset"
        if (config.process.supportEnabled) errors += "Controlled safety cube must be sliced with supports OFF"
        if (toolpaths.layers.isEmpty()) return errors + "No printable layers"

        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = 0f
        var points = 0L
        for (layer in toolpaths.layers) {
            maxZ = max(maxZ, layer.z)
            for (path in layer.paths) {
                val packed = path.points as? PackedPointList
                if (packed != null) {
                    val xy = packed.packedXYReadOnly()
                    var i = 0
                    while (i + 1 < xy.size) {
                        val x = xy[i]; val y = xy[i + 1]
                        if (x.isFinite() && y.isFinite()) {
                            minX = min(minX, x); maxX = max(maxX, x)
                            minY = min(minY, y); maxY = max(maxY, y); points++
                        }
                        i += 2
                    }
                } else {
                    for (p in path.points) if (p.x.isFinite() && p.y.isFinite()) {
                        minX = min(minX, p.x); maxX = max(maxX, p.x)
                        minY = min(minY, p.y); maxY = max(maxY, p.y); points++
                    }
                }
            }
        }
        if (points == 0L) return errors + "Controlled cube has no extrusion geometry"
        val width = maxX - minX
        val depth = maxY - minY
        val cx = (minX + maxX) * 0.5f
        val cy = (minY + maxY) * 0.5f
        if (width !in 19.0f..21.0f || depth !in 19.0f..21.0f) errors += "Controlled test is locked to the 20x20 mm safety cube footprint"
        if (maxZ !in 4.6f..5.4f) errors += "Controlled test is locked to 5 mm cube height"
        if (kotlin.math.abs(cx) > 1.0f || kotlin.math.abs(cy) > 1.0f) errors += "Controlled safety cube must stay centered on the plate"
        return errors
    }

    private fun containsUnresolvedMacro(s: String): Boolean {
        if (Regex("\\{\\s*(if|elsif|else|endif)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)) return true
        if (Regex("\\[[A-Za-z_][A-Za-z0-9_]*(?:\\[[^]]+])?]", RegexOption.IGNORE_CASE).containsMatchIn(s)) return true
        if (Regex("\\{[A-Za-z_][^}]*}").containsMatchIn(s)) return true
        return false
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
