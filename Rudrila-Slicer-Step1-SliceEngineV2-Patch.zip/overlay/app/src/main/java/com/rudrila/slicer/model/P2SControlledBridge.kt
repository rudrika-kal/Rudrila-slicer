package com.rudrila.slicer.model

import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Step 5.6 controlled P2S bridge.
 *
 * Rudrila does NOT bundle Bambu Studio's AGPL machine template. The user imports one already-
 * resolved P2S G-code produced by Bambu Studio for the dedicated 20x20x5 safety cube. We retain
 * only its native start/end envelope, but first validate that the imported file itself really is a
 * small centered P2S/PLA safety-cube job. General P2S printer-ready export remains blocked.
 */
data class P2SNativeEnvelope(
    val startGcode: String,
    val endGcode: String,
    val sourceSha256: String,
    val referenceWidthMm: Float,
    val referenceDepthMm: Float,
    val referenceMaxZMm: Float,
    val referenceLayerCount: Int,
    val referenceExtrusionMoves: Int,
    val referenceNozzleTempC: Float,
    val referenceBedTempC: Float
) {
    val shortSha: String get() = sourceSha256.take(12)
}

private data class ReferenceBodyStats(
    val widthMm: Float,
    val depthMm: Float,
    val centerX: Float,
    val centerY: Float,
    val maxZMm: Float,
    val layerCount: Int,
    val extrusionMoves: Int
)

object P2SControlledBridge {
    private const val START_MARKER = ";======== P2S start gcode"
    private const val END_MARKER = ";======== P2S end gcode"
    private const val LAYER_MARKER = "; CHANGE_LAYER"
    private const val STORAGE_SPLIT = "\n;__RUDRILA_P2S_ENVELOPE_SPLIT_V3__\n"
    const val MAX_REFERENCE_CHARS = 24 * 1024 * 1024

    private val paramRegex = Regex("([XYZE])(-?\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?)")
    private val tempRegex = Regex("[SR](-?\\d+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE)

    fun parseResolvedReference(gcode: String): P2SNativeEnvelope {
        require(gcode.isNotBlank()) { "Reference G-code is empty" }
        require(gcode.length <= MAX_REFERENCE_CHARS) { "Reference G-code is too large" }
        val startAt = gcode.indexOf(START_MARKER)
        val firstLayerAt = gcode.indexOf(LAYER_MARKER)
        val endAt = gcode.lastIndexOf(END_MARKER)
        require(startAt >= 0) { "Not a resolved Bambu Lab P2S G-code: start marker missing" }
        require(firstLayerAt > startAt) { "Reference G-code first layer marker is missing" }
        require(endAt > firstLayerAt) { "Reference G-code P2S end marker is missing" }

        val start = gcode.substring(startAt, firstLayerAt).trimEnd() + "\n"
        val end = gcode.substring(endAt).trim() + "\n"
        validateNativeEnvelope(start, end)

        // A PLA safety-cube reference must contain resolved, plausible thermal waits. This rejects
        // accidentally imported PETG/ABS jobs even when they are otherwise valid P2S G-code.
        val nozzleWaits = commandTemperatures(start, "M109")
        val bedWaits = commandTemperatures(start, "M190")
        val referenceNozzleTemp=nozzleWaits.lastOrNull { it in 180f..245f }
            ?: error("Reference does not contain a PLA-range resolved nozzle wait")
        val referenceBedTemp=bedWaits.lastOrNull { it in 35f..70f }
            ?: error("Reference does not contain a PLA-range resolved bed wait")

        // If Bambu Studio emitted config metadata, enforce it rather than ignoring a mismatch.
        val nozzleMeta = Regex("(?im)^;\\s*nozzle_diameter\\s*=\\s*([0-9.]+)").findAll(gcode)
            .mapNotNull { it.groupValues.getOrNull(1)?.toFloatOrNull() }.toList()
        if (nozzleMeta.isNotEmpty()) {
            require(nozzleMeta.any { abs(it - 0.4f) <= 0.051f }) { "Reference is not a 0.4 mm nozzle job" }
        }
        val filamentMeta = Regex("(?im)^;\\s*filament_type\\s*=\\s*([A-Za-z0-9_-]+)").findAll(gcode)
            .map { it.groupValues[1].uppercase() }.toList()
        if (filamentMeta.isNotEmpty()) {
            require(filamentMeta.all { it == "PLA" || it.startsWith("PLA-") }) { "Reference is not a PLA job" }
        }

        val stats = inspectReferenceBody(gcode.substring(startAt, endAt))
        require(stats.extrusionMoves >= 100) { "Reference safety cube has too little printable geometry" }
        require(stats.layerCount in 20..30) { "Reference safety cube must be about 25 layers at 0.20 mm" }
        require(stats.widthMm in 18.0f..23.0f && stats.depthMm in 18.0f..23.0f) {
            "Reference is not the 20x20 mm safety cube footprint"
        }
        require(abs(stats.centerX - 128f) <= 3f && abs(stats.centerY - 128f) <= 3f) {
            "Reference safety cube is not centered on the 256 mm P2S plate"
        }
        require(stats.maxZMm in 4.4f..5.6f) { "Reference is not the 5 mm safety cube height" }

        return P2SNativeEnvelope(
            startGcode = start,
            endGcode = end,
            sourceSha256 = sha256(gcode),
            referenceWidthMm = stats.widthMm,
            referenceDepthMm = stats.depthMm,
            referenceMaxZMm = stats.maxZMm,
            referenceLayerCount = stats.layerCount,
            referenceExtrusionMoves = stats.extrusionMoves,
            referenceNozzleTempC = referenceNozzleTemp,
            referenceBedTempC = referenceBedTemp
        )
    }

    fun encode(envelope: P2SNativeEnvelope): String = buildString {
        append("RUDRILA_P2S_ENVELOPE_V3\n")
        append(envelope.sourceSha256).append('\n')
        append(envelope.referenceWidthMm).append(',')
        append(envelope.referenceDepthMm).append(',')
        append(envelope.referenceMaxZMm).append(',')
        append(envelope.referenceLayerCount).append(',')
        append(envelope.referenceExtrusionMoves).append(',')
        append(envelope.referenceNozzleTempC).append(',')
        append(envelope.referenceBedTempC).append('\n')
        append(envelope.startGcode)
        append(STORAGE_SPLIT)
        append(envelope.endGcode)
    }

    fun decode(saved: String): P2SNativeEnvelope {
        require(saved.startsWith("RUDRILA_P2S_ENVELOPE_V3\n")) { "Unsupported P2S envelope cache" }
        val lines = saved.lineSequence().iterator()
        require(lines.hasNext()) { "Corrupt P2S envelope cache" }; lines.next()
        require(lines.hasNext()) { "Corrupt P2S envelope cache" }; val sha = lines.next().trim()
        require(Regex("[0-9a-fA-F]{64}").matches(sha)) { "Corrupt P2S envelope fingerprint" }
        require(lines.hasNext()) { "Corrupt P2S envelope cache" }; val statsText = lines.next()
        val stats = statsText.split(',')
        require(stats.size == 7) { "Corrupt P2S reference statistics" }
        val width = stats[0].toFloatOrNull() ?: error("Corrupt P2S reference width")
        val depth = stats[1].toFloatOrNull() ?: error("Corrupt P2S reference depth")
        val maxZ = stats[2].toFloatOrNull() ?: error("Corrupt P2S reference Z")
        val layers = stats[3].toIntOrNull() ?: error("Corrupt P2S reference layers")
        val moves = stats[4].toIntOrNull() ?: error("Corrupt P2S reference moves")
        val nozzleTemp = stats[5].toFloatOrNull() ?: error("Corrupt P2S reference nozzle temperature")
        val bedTemp = stats[6].toFloatOrNull() ?: error("Corrupt P2S reference bed temperature")
        require(width.isFinite() && depth.isFinite() && maxZ.isFinite() && nozzleTemp.isFinite() && bedTemp.isFinite()) { "Corrupt P2S reference statistics" }
        require(width in 18f..23f && depth in 18f..23f && maxZ in 4.4f..5.6f && layers in 20..30 && moves >= 100 && nozzleTemp in 180f..245f && bedTemp in 35f..70f) {
            "Cached P2S reference is outside controlled-test limits"
        }

        // Locate the payload using line offsets so start G-code remains byte-for-byte stable.
        var newlineCount = 0
        var payloadStart = -1
        for (i in saved.indices) {
            if (saved[i] == '\n' && ++newlineCount == 3) { payloadStart = i + 1; break }
        }
        require(payloadStart > 0) { "Corrupt P2S envelope cache" }
        val payload = saved.substring(payloadStart)
        val splitAt = payload.indexOf(STORAGE_SPLIT)
        require(splitAt > 0) { "Corrupt P2S envelope cache" }
        val start = payload.substring(0, splitAt)
        val end = payload.substring(splitAt + STORAGE_SPLIT.length)
        validateNativeEnvelope(start, end)
        return P2SNativeEnvelope(start, end, sha.lowercase(), width, depth, maxZ, layers, moves, nozzleTemp, bedTemp)
    }

    /** Exact geometry/config gate for the one controlled real-printer test. */
    fun controlledTestErrors(toolpaths: ToolpathResult, config: PrintConfiguration, envelope: P2SNativeEnvelope?): List<String> {
        val errors = mutableListOf<String>()
        if (envelope == null) errors += "Import a resolved Bambu Studio P2S reference G-code first"
        if (config.printer.id != "bambu_p2s_04") errors += "Controlled test requires Bambu Lab P2S 0.4 mm profile"
        if (config.filament.id != "step5_pla") errors += "Controlled test requires Rudrila Generic PLA Balanced preset"
        if (envelope != null) {
            if (abs(envelope.referenceNozzleTempC - config.filament.nozzleTempC) > 5f) errors += "Bambu reference nozzle temperature does not match the Rudrila PLA preset"
            if (abs(envelope.referenceBedTempC - config.filament.bedTempC) > 5f) errors += "Bambu reference bed temperature does not match the Rudrila PLA preset"
        }
        if (config.process.supportEnabled) errors += "Controlled safety cube must be sliced with supports OFF"
        if (config.process.brimWidthMm > 0.05f) errors += "Controlled safety cube requires brim OFF / 0 mm"
        if (config.process.infillPercent != 15) errors += "Controlled safety cube requires the default 15% infill"
        if (toolpaths.layers.isEmpty()) return errors + "No printable layers"
        if (toolpaths.layers.size !in 24..26) errors += "Controlled test requires the 0.20 mm / 25-layer safety cube slice"

        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = 0f
        var points = 0L
        var forbiddenRoles = 0
        for (layer in toolpaths.layers) {
            maxZ = max(maxZ, layer.z)
            for (path in layer.paths) {
                if (path.role == PathRole.SUPPORT || path.role == PathRole.SUPPORT_INTERFACE || path.role == PathRole.BRIM) forbiddenRoles++
                val packed = path.points as? PackedPointList
                if (packed != null) {
                    val xy = packed.packedXYReadOnly()
                    var i = 0
                    while (i + 1 < xy.size) {
                        val x = xy[i]; val y = xy[i + 1]
                        if (x.isFinite() && y.isFinite()) {
                            minX = min(minX, x); maxX = max(maxX, x)
                            minY = min(minY, y); maxY = max(maxY, y); points++
                        }
                        i += 2
                    }
                } else {
                    for (p in path.points) if (p.x.isFinite() && p.y.isFinite()) {
                        minX = min(minX, p.x); maxX = max(maxX, p.x)
                        minY = min(minY, p.y); maxY = max(maxY, p.y); points++
                    }
                }
            }
        }
        if (forbiddenRoles > 0) errors += "Controlled safety cube cannot contain support/interface/brim toolpaths"
        if (points < 500L) return errors + "Controlled cube has too little extrusion geometry"
        val width = maxX - minX
        val depth = maxY - minY
        val cx = (minX + maxX) * 0.5f
        val cy = (minY + maxY) * 0.5f
        if (width !in 19.0f..21.5f || depth !in 19.0f..21.5f) errors += "Controlled test is locked to the 20x20 mm safety cube footprint"
        if (maxZ !in 4.6f..5.4f) errors += "Controlled test is locked to 5 mm cube height"
        if (abs(cx) > 1.0f || abs(cy) > 1.0f) errors += "Controlled safety cube must stay centered on the plate"
        return errors
    }

    private fun validateNativeEnvelope(start: String, end: String) {
        require(start.length in 200..512_000) { "P2S start envelope length is not plausible" }
        require(end.length in 100..256_000) { "P2S end envelope length is not plausible" }
        require(START_MARKER in start && END_MARKER in end) { "P2S native envelope markers are missing" }
        require("G28" in start && "G29" in start) { "Reference does not contain P2S homing/leveling" }
        require("M190" in start && "M109" in start) { "Reference does not contain resolved bed/nozzle waits" }
        val nativeSignals = listOf("M620 M", "G389", "M1002", "M622").count { it in start }
        require(nativeSignals >= 3) { "Reference does not look like a native P2S machine start sequence" }
        require("M104 S0" in end && "M140 S0" in end && "M18" in end) { "Reference P2S shutdown sequence is incomplete" }
        require(!containsUnresolvedMacro(start) && !containsUnresolvedMacro(end)) {
            "Reference still contains slicer placeholders; import exported .gcode, not a template JSON"
        }
    }

    private fun commandTemperatures(gcode: String, command: String): List<Float> = gcode.lineSequence()
        .map { it.substringBefore(';').trim() }
        .filter { it.startsWith(command, ignoreCase = true) }
        .mapNotNull { tempRegex.find(it)?.groupValues?.getOrNull(1)?.toFloatOrNull() }
        .toList()

    /** Reads only extrusion moves from the print body; machine purge/wipe moves live before it. */
    private fun inspectReferenceBody(section: String): ReferenceBodyStats {
        var absoluteXYZ = true
        var relativeE = false
        var inBody = false
        var x = 0f; var y = 0f; var z = 0f; var ePos = 0f
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY
        var maxZ = 0f; var layers = 0; var moves = 0

        fun params(code: String): Map<Char, Float> = paramRegex.findAll(code).mapNotNull { m ->
            val v = m.groupValues[2].toFloatOrNull()
            if (v != null && v.isFinite()) m.groupValues[1][0] to v else null
        }.toMap()
        fun addPoint(px: Float, py: Float) {
            if (!px.isFinite() || !py.isFinite()) return
            minX = min(minX, px); maxX = max(maxX, px)
            minY = min(minY, py); maxY = max(maxY, py)
        }

        for (raw in section.lineSequence()) {
            val trimmed = raw.trimStart()
            if (trimmed.startsWith(LAYER_MARKER)) { inBody = true; layers++; continue }
            val code = raw.substringBefore(';').trim()
            if (code.isEmpty()) continue
            when {
                code.equals("G90", true) -> { absoluteXYZ = true; continue }
                code.equals("G91", true) -> { absoluteXYZ = false; continue }
                code.equals("M82", true) -> { relativeE = false; continue }
                code.equals("M83", true) -> { relativeE = true; continue }
                code.startsWith("G92", true) -> {
                    val p = params(code)
                    p['X']?.let { x = it }; p['Y']?.let { y = it }; p['Z']?.let { z = it }; p['E']?.let { ePos = it }
                    continue
                }
            }
            val move = code.startsWith("G0 ", true) || code.startsWith("G00 ", true) ||
                code.startsWith("G1 ", true) || code.startsWith("G01 ", true) ||
                code.startsWith("G2 ", true) || code.startsWith("G02 ", true) ||
                code.startsWith("G3 ", true) || code.startsWith("G03 ", true)
            if (!move) continue
            val p = params(code)
            val oldX = x; val oldY = y
            val nx = p['X']?.let { if (absoluteXYZ) it else x + it } ?: x
            val ny = p['Y']?.let { if (absoluteXYZ) it else y + it } ?: y
            val nz = p['Z']?.let { if (absoluteXYZ) it else z + it } ?: z
            val eToken = p['E']
            val deltaE = if (eToken == null) 0f else if (relativeE) eToken else eToken - ePos
            if (eToken != null) ePos = if (relativeE) ePos + eToken else eToken
            x = nx; y = ny; z = nz
            if (inBody && deltaE > 0.00001f && (abs(nx - oldX) > 0.00001f || abs(ny - oldY) > 0.00001f)) {
                addPoint(oldX, oldY); addPoint(nx, ny)
                maxZ = max(maxZ, nz)
                moves++
            }
        }
        require(moves > 0 && minX.isFinite() && minY.isFinite() && maxX.isFinite() && maxY.isFinite()) {
            "Reference G-code has no usable safety-cube extrusion body"
        }
        return ReferenceBodyStats(maxX - minX, maxY - minY, (minX + maxX) * 0.5f, (minY + maxY) * 0.5f, maxZ, layers, moves)
    }

    private fun containsUnresolvedMacro(s: String): Boolean {
        if (Regex("\\{\\s*(if|elsif|else|endif)\\b", RegexOption.IGNORE_CASE).containsMatchIn(s)) return true
        if (Regex("\\[[A-Za-z_][A-Za-z0-9_]*(?:\\[[^]]+])?]", RegexOption.IGNORE_CASE).containsMatchIn(s)) return true
        if (Regex("\\{[A-Za-z_][^}]*}").containsMatchIn(s)) return true
        return false
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
