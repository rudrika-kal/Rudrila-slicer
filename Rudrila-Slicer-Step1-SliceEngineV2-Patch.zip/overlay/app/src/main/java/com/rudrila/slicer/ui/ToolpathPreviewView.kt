package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.rudrila.slicer.model.PathRole
import com.rudrila.slicer.model.Point2
import com.rudrila.slicer.model.Toolpath
import com.rudrila.slicer.model.ToolpathLayer
import com.rudrila.slicer.model.ToolpathResult
import kotlin.math.*

/**
 * Step 2.4 Bambu-style mobile toolpath preview.
 *
 * MODEL_3D stacks sliced layers in Z and uses the vertical slider as a cut-height.
 * CURRENT_TOP gives an exact top view for one layer. Rendering is adaptive so large
 * slices remain interactive on phones while the selected layer is always drawn fully.
 */
class ToolpathPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private enum class ViewMode { MODEL_3D, CURRENT_TOP }

    private val bgPaint = Paint().apply { color = Color.rgb(13, 16, 18) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(105, 69, 78, 83)
        strokeWidth = 1f
        style = Paint.Style.STROKE
    }
    private val majorGridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 92, 103, 109)
        strokeWidth = 1.4f
        style = Paint.Style.STROKE
    }
    private val pathPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = false
    }
    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val reusablePath = Path()
    private val projected = FloatArray(2)
    private val travelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.25f
        color = Color.rgb(116, 170, 255)
        pathEffect = DashPathEffect(floatArrayOf(7f, 6f), 0f)
    }
    private val cutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.argb(130, 123, 231, 198)
        pathEffect = DashPathEffect(floatArrayOf(8f, 7f), 0f)
    }

    private var result: ToolpathResult? = null
    private var cumulativePaths = IntArray(0)
    private var cachedLayerBounds: Array<FloatArray> = emptyArray()
    private val visibleRoles = PathRole.values().toMutableSet()

    private var bedX = 256f
    private var bedY = 256f

    private var modelMinX = 0f
    private var modelMinY = 0f
    private var modelMaxX = bedX
    private var modelMaxY = bedY
    private var modelMinZ = 0f
    private var modelMaxZ = 1f

    private var viewMode = ViewMode.MODEL_3D
    private var yaw = Math.toRadians(-35.0).toFloat()
    private var pitch = Math.toRadians(58.0).toFloat()
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var lastCx = 0f
    private var lastCy = 0f
    private var interacting = false
    private var sliderScrubbing = false

    var showTravel: Boolean = false
        set(value) { field = value; invalidate() }

    /** Compatibility with Step 2.1. In 3D mode lower layers are inherently visible. */
    var showBelowLayers: Boolean = true
        set(value) {
            field = value
            viewMode = if (value) ViewMode.MODEL_3D else ViewMode.CURRENT_TOP
            resetViewForMode()
        }

    var layerIndex: Int = 0
        set(value) {
            val count = result?.layers?.size ?: 0
            field = if (count == 0) 0 else value.coerceIn(0, count - 1)
            invalidate()
        }

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                interacting = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val oldZoom = zoom
                val nextZoom = (zoom * detector.scaleFactor).coerceIn(0.32f, 18f)
                if (nextZoom == oldZoom) return true
                val ratio = nextZoom / oldZoom
                val fx = detector.focusX - width * 0.5f
                val fy = detector.focusY - height * 0.5f
                panX = fx - (fx - panX) * ratio
                panY = fy - (fy - panY) * ratio
                zoom = nextZoom
                postInvalidateOnAnimation()
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                interacting = false
                postInvalidateOnAnimation()
            }
        })

    fun setBedSize(x: Float, y: Float) {
        bedX = x.coerceAtLeast(1f)
        bedY = y.coerceAtLeast(1f)
        invalidate()
    }

    fun setResult(value: ToolpathResult) {
        result = value
        computeModelBounds(value)
        cumulativePaths = IntArray(value.layers.size)
        cachedLayerBounds = Array(value.layers.size) { index -> computeBoundsForLayer(value.layers[index]) }
        var sum = 0
        value.layers.forEachIndexed { index, layer ->
            sum += layer.paths.size
            cumulativePaths[index] = sum
        }
        layerIndex = value.layers.lastIndex.coerceAtLeast(0)
        viewMode = ViewMode.MODEL_3D
        resetViewForMode()
    }

    fun setRoleVisible(role: PathRole, visible: Boolean) {
        if (visible) visibleRoles += role else visibleRoles -= role
        invalidate()
    }

    /** Bambu-style stacked preview. Slider becomes the upper visible layer. */
    fun fitToModel() {
        viewMode = ViewMode.MODEL_3D
        showBelowLayers = true
        resetViewForMode()
    }

    /** Exact current-layer top view for inspection. */
    fun fitToCurrentLayer() {
        viewMode = ViewMode.CURRENT_TOP
        showBelowLayers = false
        resetViewForMode()
    }

    fun resetCamera() = resetViewForMode()

    fun setSliderScrubbing(value: Boolean) {
        if (sliderScrubbing == value) return
        sliderScrubbing = value
        postInvalidateOnAnimation()
    }

    fun isModel3D(): Boolean = viewMode == ViewMode.MODEL_3D

    private fun resetViewForMode() {
        zoom = 1f
        panX = 0f
        panY = 0f
        if (viewMode == ViewMode.MODEL_3D) {
            yaw = Math.toRadians(-35.0).toFloat()
            pitch = Math.toRadians(55.0).toFloat()
        } else {
            yaw = 0f
            pitch = 0f
        }
        invalidate()
    }

    private fun computeModelBounds(value: ToolpathResult) {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY
        var count = 0
        for (layer in value.layers) {
            val z = layer.z
            if (z < minZ) minZ = z
            if (z > maxZ) maxZ = z
            for (path in layer.paths) for (p in path.points) {
                if (p.x < minX) minX = p.x
                if (p.y < minY) minY = p.y
                if (p.x > maxX) maxX = p.x
                if (p.y > maxY) maxY = p.y
                count++
            }
        }
        if (count == 0) {
            modelMinX = 0f; modelMinY = 0f; modelMaxX = bedX; modelMaxY = bedY
            modelMinZ = 0f; modelMaxZ = 1f
        } else {
            modelMinX = minX; modelMinY = minY; modelMaxX = maxX; modelMaxY = maxY
            modelMinZ = if (minZ.isFinite()) minZ else 0f
            modelMaxZ = if (maxZ.isFinite()) maxZ else 1f
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (width <= 0 || height <= 0) return
        val r = result ?: return
        if (r.layers.isEmpty()) return

        when (viewMode) {
            ViewMode.MODEL_3D -> drawModel3D(canvas, r)
            ViewMode.CURRENT_TOP -> drawCurrentTop(canvas, r)
        }
    }

    private fun drawModel3D(canvas: Canvas, r: ToolpathResult) {
        val cutoff = layerIndex.coerceIn(0, r.layers.lastIndex)
        val frame = frameForModel()
        draw3DGrid(canvas, frame)

        // Fast Bambu-style scene: lower layers are a light shell, while the selected
        // layer stays full-fidelity. This avoids repainting every infill segment in
        // hundreds of historical layers on every slider/orbit frame.
        val fast = interacting || sliderScrubbing
        val maxGhostLayers = if (fast) 38 else 92
        val layerStride = max(1, ceil((cutoff + 1).toDouble() / maxGhostLayers).toInt())
        val cutoffLayer = r.layers[cutoff]

        var i = 0
        while (i < cutoff) {
            val layer = r.layers[i]
            val depthFraction = if (cutoff <= 0) 1f else i.toFloat() / cutoff.toFloat()
            val alpha = if (fast) {
                (20 + depthFraction * 28).roundToInt().coerceIn(20, 48)
            } else {
                (24 + depthFraction * 48).roundToInt().coerceIn(24, 72)
            }
            drawGhostLayer3D(canvas, layer, frame, alpha, fast)
            i += layerStride
        }

        // Selected layer is always exact and crisp, so moving the layer slider gives
        // a clear layer-by-layer inspection instead of a solid teal blob.
        drawLayer3D(canvas, cutoffLayer, frame, 255, selected = true)
        if (showTravel) drawTravel3D(canvas, cutoffLayer, frame)
        drawCutOutline(canvas, cutoffLayer, frame, cutoff)
    }

    private fun drawCurrentTop(canvas: Canvas, r: ToolpathResult) {
        val layer = r.layers[layerIndex.coerceIn(0, r.layers.lastIndex)]
        val bounds = cachedLayerBounds.getOrNull(layerIndex) ?: computeBoundsForLayer(layer)
        val frame = frameForTop(bounds)
        drawTopGrid(canvas, frame, bounds)
        for (path in layer.paths) {
            if (path.points.size < 2 || path.role !in visibleRoles) continue
            selectedPaint.color = roleColor(path.role)
            selectedPaint.strokeWidth = (path.widthMm * frame.scale).coerceIn(1.2f, 6f)
            drawPathTop(canvas, path, frame, selectedPaint)
        }
        if (showTravel) drawTravelTop(canvas, layer, frame)
    }

    private data class Frame(
        val cx: Float,
        val cy: Float,
        val cz: Float,
        val scale: Float,
        val offsetX: Float,
        val offsetY: Float,
        val cosYaw: Float,
        val sinYaw: Float,
        val cosPitch: Float,
        val sinPitch: Float
    )

    private data class P2(val x: Float, val y: Float)

    private fun frameForModel(): Frame {
        // Stable camera scale: orbiting must rotate the model, not continuously auto-zoom it.
        // A 3D diagonal safely fits every orthographic orientation inside the mobile stage.
        val cx = (modelMinX + modelMaxX) * 0.5f
        val cy = (modelMinY + modelMaxY) * 0.5f
        val cz = (modelMinZ + modelMaxZ) * 0.5f
        val dx = (modelMaxX - modelMinX).coerceAtLeast(1f)
        val dy = (modelMaxY - modelMinY).coerceAtLeast(1f)
        val dz = (modelMaxZ - modelMinZ).coerceAtLeast(1f)
        val diagonal = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1f)
        val base = min(width.toFloat(), height.toFloat()) / diagonal * 0.82f
        return Frame(
            cx, cy, cz, base * zoom, width * 0.5f + panX, height * 0.54f + panY,
            cos(yaw), sin(yaw), cos(pitch), sin(pitch)
        )
    }

    private fun frameForTop(bounds: FloatArray): Frame {
        val minX = bounds[0]; val minY = bounds[1]; val maxX = bounds[2]; val maxY = bounds[3]
        val rawW = (maxX - minX).coerceAtLeast(1f)
        val rawH = (maxY - minY).coerceAtLeast(1f)
        val margin = max(rawW, rawH) * 0.12f + 1f
        val wMm = rawW + margin * 2f
        val hMm = rawH + margin * 2f
        val base = min(width / wMm, height / hMm) * 0.90f
        return Frame(
            (minX + maxX) * 0.5f,
            (minY + maxY) * 0.5f,
            0f,
            base * zoom,
            width * 0.5f + panX,
            height * 0.5f + panY,
            1f, 0f, 1f, 0f
        )
    }

    private fun project3DInto(x: Float, y: Float, z: Float, frame: Frame, out: FloatArray = projected) {
        val dx = x - frame.cx
        val dy = y - frame.cy
        val dz = z - frame.cz
        val x1 = frame.cosYaw * dx - frame.sinYaw * dy
        val y1 = frame.sinYaw * dx + frame.cosYaw * dy
        // Z is printer-up. Positive Z must move upward on screen from the bed (Z=0).
        // The previous sign made higher layers move downward, visually flipping the model
        // and making the bed/grid appear to float above it.
        val y2 = frame.cosPitch * y1 + frame.sinPitch * dz
        out[0] = frame.offsetX + x1 * frame.scale
        out[1] = frame.offsetY - y2 * frame.scale
    }

    private fun project3D(x: Float, y: Float, z: Float, frame: Frame): P2 {
        project3DInto(x, y, z, frame)
        return P2(projected[0], projected[1])
    }

    private fun drawGhostLayer3D(canvas: Canvas, layer: ToolpathLayer, frame: Frame, alpha: Int, fast: Boolean) {
        var wallSeen = 0
        for (path in layer.paths) {
            if (path.points.size < 2) continue
            // Ghost model is intentionally shell-first: walls/brim communicate the
            // printed shape far more clearly than stacking hundreds of infill layers.
            val keep = when (path.role) {
                PathRole.WALL -> true
                PathRole.BRIM -> !fast
                PathRole.SUPPORT, PathRole.SUPPORT_INTERFACE -> !fast && wallSeen % 3 == 0
                else -> false
            }
            if (!keep || path.role !in visibleRoles) continue
            if (path.role == PathRole.WALL) wallSeen++
            pathPaint.color = withAlpha(roleColor(path.role), alpha)
            pathPaint.strokeWidth = (path.widthMm * frame.scale * 0.62f).coerceIn(0.55f, 1.8f)
            drawPath3D(canvas, path, layer.z, frame, pathPaint)
        }
    }

    private fun drawLayer3D(canvas: Canvas, layer: ToolpathLayer, frame: Frame, alpha: Int, selected: Boolean) {
        for (path in layer.paths) {
            if (path.points.size < 2 || path.role !in visibleRoles) continue
            val baseColor = roleColor(path.role)
            val paint = if (selected) selectedPaint else pathPaint
            paint.color = withAlpha(baseColor, alpha)
            val widthBoost = if (selected) 1.08f else 0.70f
            paint.strokeWidth = (path.widthMm * frame.scale * widthBoost).coerceIn(if (selected) 1.05f else 0.55f, if (selected) 4.7f else 2.3f)
            drawPath3D(canvas, path, layer.z, frame, paint)
        }
    }

    private fun drawPath3D(canvas: Canvas, path: Toolpath, z: Float, frame: Frame, paint: Paint) {
        val pts = path.points
        if (pts.size < 2) return
        reusablePath.reset()
        project3DInto(pts[0].x, pts[0].y, z, frame)
        reusablePath.moveTo(projected[0], projected[1])
        for (i in 1 until pts.size) {
            project3DInto(pts[i].x, pts[i].y, z, frame)
            reusablePath.lineTo(projected[0], projected[1])
        }
        if (path.closed && pts.size > 2 && distanceSquared(pts.first(), pts.last()) > 0.0001f) {
            reusablePath.close()
        }
        canvas.drawPath(reusablePath, paint)
    }

    private fun drawPathTop(canvas: Canvas, path: Toolpath, frame: Frame, paint: Paint) {
        val pts = path.points
        if (pts.size < 2) return
        reusablePath.reset()
        var x = frame.offsetX + (pts[0].x - frame.cx) * frame.scale
        var y = frame.offsetY - (pts[0].y - frame.cy) * frame.scale
        reusablePath.moveTo(x, y)
        for (i in 1 until pts.size) {
            x = frame.offsetX + (pts[i].x - frame.cx) * frame.scale
            y = frame.offsetY - (pts[i].y - frame.cy) * frame.scale
            reusablePath.lineTo(x, y)
        }
        if (path.closed && pts.size > 2 && distanceSquared(pts.first(), pts.last()) > 0.0001f) reusablePath.close()
        canvas.drawPath(reusablePath, paint)
    }

    private fun drawTravel3D(canvas: Canvas, layer: ToolpathLayer, frame: Frame) {
        var lastEnd: Point2? = null
        for (path in layer.paths) {
            if (path.points.size < 2) continue
            val start = path.points.first()
            val prev = lastEnd
            if (prev != null && distanceSquared(prev, start) > 0.0001f) {
                val a = project3D(prev.x, prev.y, layer.z, frame)
                val b = project3D(start.x, start.y, layer.z, frame)
                canvas.drawLine(a.x, a.y, b.x, b.y, travelPaint)
            }
            lastEnd = path.points.last()
        }
    }

    private fun drawTravelTop(canvas: Canvas, layer: ToolpathLayer, frame: Frame) {
        var lastEnd: Point2? = null
        for (path in layer.paths) {
            if (path.points.size < 2) continue
            val start = path.points.first()
            val prev = lastEnd
            if (prev != null && distanceSquared(prev, start) > 0.0001f) {
                val ax = frame.offsetX + (prev.x - frame.cx) * frame.scale
                val ay = frame.offsetY - (prev.y - frame.cy) * frame.scale
                val bx = frame.offsetX + (start.x - frame.cx) * frame.scale
                val by = frame.offsetY - (start.y - frame.cy) * frame.scale
                canvas.drawLine(ax, ay, bx, by, travelPaint)
            }
            lastEnd = path.points.last()
        }
    }

    private fun draw3DGrid(canvas: Canvas, frame: Frame) {
        val margin = 18f
        val gx0 = floor(max(0f, modelMinX - margin) / 10f) * 10f
        val gx1 = ceil(min(bedX, modelMaxX + margin) / 10f) * 10f
        val gy0 = floor(max(0f, modelMinY - margin) / 10f) * 10f
        val gy1 = ceil(min(bedY, modelMaxY + margin) / 10f) * 10f
        var x = gx0
        while (x <= gx1 + 0.001f) {
            val a = project3D(x, gy0, 0f, frame)
            val b = project3D(x, gy1, 0f, frame)
            canvas.drawLine(a.x, a.y, b.x, b.y, if (((x / 50f).roundToInt() * 50f - x).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            x += 10f
        }
        var y = gy0
        while (y <= gy1 + 0.001f) {
            val a = project3D(gx0, y, 0f, frame)
            val b = project3D(gx1, y, 0f, frame)
            canvas.drawLine(a.x, a.y, b.x, b.y, if (((y / 50f).roundToInt() * 50f - y).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            y += 10f
        }
    }

    private fun drawTopGrid(canvas: Canvas, frame: Frame, bounds: FloatArray) {
        val minX = max(0f, bounds[0] - 12f)
        val minY = max(0f, bounds[1] - 12f)
        val maxX = min(bedX, bounds[2] + 12f)
        val maxY = min(bedY, bounds[3] + 12f)
        var x = floor(minX / 10f) * 10f
        while (x <= maxX + 0.001f) {
            val sx = frame.offsetX + (x - frame.cx) * frame.scale
            val y0 = frame.offsetY - (minY - frame.cy) * frame.scale
            val y1 = frame.offsetY - (maxY - frame.cy) * frame.scale
            canvas.drawLine(sx, y0, sx, y1, if (((x / 50f).roundToInt() * 50f - x).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            x += 10f
        }
        var y = floor(minY / 10f) * 10f
        while (y <= maxY + 0.001f) {
            val sy = frame.offsetY - (y - frame.cy) * frame.scale
            val x0 = frame.offsetX + (minX - frame.cx) * frame.scale
            val x1 = frame.offsetX + (maxX - frame.cx) * frame.scale
            canvas.drawLine(x0, sy, x1, sy, if (((y / 50f).roundToInt() * 50f - y).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            y += 10f
        }
    }

    private fun drawCutOutline(canvas: Canvas, layer: ToolpathLayer, frame: Frame, index: Int) {
        if (layer.paths.isEmpty()) return
        val b = cachedLayerBounds.getOrNull(index) ?: computeBoundsForLayer(layer)
        val z = layer.z
        val a = project3D(b[0], b[1], z, frame)
        val c = project3D(b[2], b[1], z, frame)
        val d = project3D(b[2], b[3], z, frame)
        val e = project3D(b[0], b[3], z, frame)
        canvas.drawLine(a.x, a.y, c.x, c.y, cutPaint)
        canvas.drawLine(c.x, c.y, d.x, d.y, cutPaint)
        canvas.drawLine(d.x, d.y, e.x, e.y, cutPaint)
        canvas.drawLine(e.x, e.y, a.x, a.y, cutPaint)
    }

    private fun computeBoundsForLayer(layer: ToolpathLayer): FloatArray {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var count = 0
        for (path in layer.paths) for (p in path.points) {
            minX = min(minX, p.x); minY = min(minY, p.y)
            maxX = max(maxX, p.x); maxY = max(maxY, p.y)
            count++
        }
        return if (count == 0) floatArrayOf(modelMinX, modelMinY, modelMaxX, modelMaxY)
        else floatArrayOf(minX, minY, maxX, maxY)
    }

    private fun roleColor(role: PathRole): Int = when (role) {
        PathRole.WALL -> Color.rgb(52, 211, 153)
        PathRole.SOLID -> Color.rgb(251, 191, 36)
        PathRole.GAP_FILL -> Color.rgb(244, 114, 182)
        PathRole.INFILL -> Color.rgb(96, 165, 250)
        PathRole.SUPPORT -> Color.rgb(192, 132, 252)
        PathRole.SUPPORT_INTERFACE -> Color.rgb(167, 139, 250)
        PathRole.BRIM -> Color.rgb(156, 163, 175)
    }

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun distanceSquared(a: Point2, b: Point2): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        return dx * dx + dy * dy
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y
                lastCx = event.x; lastCy = event.y
                interacting = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                val c = centroid(event)
                lastCx = c.x; lastCy = c.y
                interacting = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress) {
                    if (event.pointerCount >= 2) {
                        val c = centroid(event)
                        panX += c.x - lastCx
                        panY += c.y - lastCy
                        lastCx = c.x; lastCy = c.y
                    } else if (event.pointerCount == 1) {
                        val dx = event.x - lastX
                        val dy = event.y - lastY
                        if (viewMode == ViewMode.MODEL_3D) {
                            yaw += dx * 0.0085f
                            pitch = (pitch + dy * 0.0085f).coerceIn(Math.toRadians(14.0).toFloat(), Math.toRadians(82.0).toFloat())
                        } else {
                            panX += dx
                            panY += dy
                        }
                        lastX = event.x; lastY = event.y
                    }
                    postInvalidateOnAnimation()
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount - 1 <= 1) {
                    val keep = if (event.actionIndex == 0) 1 else 0
                    if (keep < event.pointerCount) {
                        lastX = event.getX(keep)
                        lastY = event.getY(keep)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                interacting = false
                performClick()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                interacting = false
                invalidate()
                return true
            }
        }
        return true
    }

    private fun centroid(event: MotionEvent): P2 {
        var x = 0f; var y = 0f
        val n = event.pointerCount.coerceAtLeast(1)
        for (i in 0 until n) { x += event.getX(i); y += event.getY(i) }
        return P2(x / n, y / n)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
