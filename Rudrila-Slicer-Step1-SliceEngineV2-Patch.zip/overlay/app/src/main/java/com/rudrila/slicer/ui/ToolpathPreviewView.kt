package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.rudrila.slicer.model.PathRole
import com.rudrila.slicer.model.Point2
import com.rudrila.slicer.model.Toolpath
import com.rudrila.slicer.model.ToolpathLayer
import com.rudrila.slicer.model.ToolpathResult
import kotlin.math.*

/**
 * Step 2.4 Bambu-style mobile toolpath preview.
 *
 * MODEL_3D stacks sliced layers in Z and uses the vertical slider as a cut-height.
 * CURRENT_TOP gives a detailed inspection view for one layer. Rendering is budgeted so large
 * support-heavy slices remain interactive on phones without changing the underlying toolpaths.
 */
class ToolpathPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private enum class ViewMode { MODEL_3D, CURRENT_TOP }

    private val bgPaint = Paint().apply { color = Color.rgb(13, 16, 18) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(105, 69, 78, 83)
        strokeWidth = 1f
        style = Paint.Style.STROKE
    }
    private val majorGridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(150, 92, 103, 109)
        strokeWidth = 1.4f
        style = Paint.Style.STROKE
    }
    private val pathPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = false
    }
    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val reusablePath = Path()
    private val projected = FloatArray(2)
    private val travelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.25f
        color = Color.rgb(116, 170, 255)
        pathEffect = DashPathEffect(floatArrayOf(7f, 6f), 0f)
    }
    private val cutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.argb(130, 123, 231, 198)
        pathEffect = DashPathEffect(floatArrayOf(8f, 7f), 0f)
    }

    private var result: ToolpathResult? = null
    private var cumulativePaths = IntArray(0)
    private var cachedLayerBounds: Array<FloatArray?> = emptyArray()
    private val visibleRoles = PathRole.values().toMutableSet()

    private var bedX = 256f
    private var bedY = 256f

    private var modelMinX = 0f
    private var modelMinY = 0f
    private var modelMaxX = bedX
    private var modelMaxY = bedY
    private var modelMinZ = 0f
    private var modelMaxZ = 1f

    private var viewMode = ViewMode.MODEL_3D
    private var yaw = Math.toRadians(-35.0).toFloat()
    private var pitch = Math.toRadians(58.0).toFloat()
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var lastCx = 0f
    private var lastCy = 0f
    private var interacting = false
    private var sliderScrubbing = false
    // ADB taps and quick slider moves can otherwise request several expensive full-quality
    // hardware frames back-to-back. Keep those transient frames cheap, then redraw once at
    // full quality after the layer selection has been stable for a moment.
    private var fastRenderUntilMs = 0L
    private val qualityRedraw = Runnable { postInvalidateOnAnimation() }

    var showTravel: Boolean = false
        set(value) { field = value; invalidate() }

    /** Compatibility with Step 2.1. In 3D mode lower layers are inherently visible. */
    var showBelowLayers: Boolean = true
        set(value) {
            field = value
            viewMode = if (value) ViewMode.MODEL_3D else ViewMode.CURRENT_TOP
            resetViewForMode()
        }

    var layerIndex: Int = 0
        set(value) {
            val count = result?.layers?.size ?: 0
            val next = if (count == 0) 0 else value.coerceIn(0, count - 1)
            val changed = field != next
            field = next
            if (changed) {
                fastRenderUntilMs = SystemClock.uptimeMillis() + 1800L
                removeCallbacks(qualityRedraw)
                postDelayed(qualityRedraw, 1850L)
            }
            invalidate()
        }

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                interacting = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val oldZoom = zoom
                val nextZoom = (zoom * detector.scaleFactor).coerceIn(0.32f, 18f)
                if (nextZoom == oldZoom) return true
                val ratio = nextZoom / oldZoom
                val fx = detector.focusX - width * 0.5f
                val fy = detector.focusY - height * 0.5f
                panX = fx - (fx - panX) * ratio
                panY = fy - (fy - panY) * ratio
                zoom = nextZoom
                postInvalidateOnAnimation()
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                interacting = false
                postInvalidateOnAnimation()
            }
        })

    fun setBedSize(x: Float, y: Float) {
        bedX = x.coerceAtLeast(1f)
        bedY = y.coerceAtLeast(1f)
        invalidate()
    }

    fun setResult(value: ToolpathResult) {
        // Preview setup must stay bounded on the Android UI thread. Large support-enabled
        // models can contain millions of points, so initialization never walks every point.
        // Bounds and rendering use deterministic sampling; the underlying toolpaths remain exact.
        result = value
        computeModelBounds(value)
        cumulativePaths = IntArray(value.layers.size)
        cachedLayerBounds = arrayOfNulls(value.layers.size)
        var sum = 0
        value.layers.forEachIndexed { index, layer ->
            sum += layer.paths.size
            cumulativePaths[index] = sum
        }
        val lastPrintable = value.layers.indexOfLast { layer ->
            layer.paths.any { path -> path.points.size >= 2 }
        }
        layerIndex = if (lastPrintable >= 0) lastPrintable else value.layers.lastIndex.coerceAtLeast(0)
        viewMode = ViewMode.MODEL_3D
        resetViewForMode()
    }

    fun setRoleVisible(role: PathRole, visible: Boolean) {
        if (visible) visibleRoles += role else visibleRoles -= role
        invalidate()
    }

    /** Bambu-style stacked preview. Slider becomes the upper visible layer. */
    fun fitToModel() {
        viewMode = ViewMode.MODEL_3D
        showBelowLayers = true
        resetViewForMode()
    }

    /** Exact current-layer top view for inspection. */
    fun fitToCurrentLayer() {
        viewMode = ViewMode.CURRENT_TOP
        showBelowLayers = false
        resetViewForMode()
    }

    fun resetCamera() = resetViewForMode()

    fun setSliderScrubbing(value: Boolean) {
        if (sliderScrubbing == value) return
        sliderScrubbing = value
        postInvalidateOnAnimation()
    }

    fun isModel3D(): Boolean = viewMode == ViewMode.MODEL_3D

    private fun resetViewForMode() {
        zoom = 1f
        panX = 0f
        panY = 0f
        if (viewMode == ViewMode.MODEL_3D) {
            yaw = Math.toRadians(-35.0).toFloat()
            pitch = Math.toRadians(55.0).toFloat()
        } else {
            yaw = 0f
            pitch = 0f
        }
        invalidate()
    }

    private fun computeModelBounds(value: ToolpathResult) {
        if (value.layers.isEmpty()) {
            modelMinX = -bedX * 0.5f; modelMinY = -bedY * 0.5f
            modelMaxX = bedX * 0.5f; modelMaxY = bedY * 0.5f
            modelMinZ = 0f; modelMaxZ = 1f
            return
        }

        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var count = 0

        // Hard upper bounds keep dialog creation responsive even for support-heavy slices.
        // Sample <=16 layers, <=160 paths/layer and <=7 points/path.
        val layerSamples = 16
        val layerStride = max(1, ceil(value.layers.size.toDouble() / layerSamples.toDouble()).toInt())
        var li = 0
        while (li < value.layers.size) {
            val paths = value.layers[li].paths
            val pathStride = max(1, ceil(paths.size.toDouble() / 160.0).toInt())
            var pi = 0
            while (pi < paths.size) {
                val pts = paths[pi].points
                if (pts.isNotEmpty()) {
                    val samples = min(7, pts.size)
                    if (samples == 1) {
                        val p = pts[0]
                        minX = min(minX, p.x); minY = min(minY, p.y)
                        maxX = max(maxX, p.x); maxY = max(maxY, p.y); count++
                    } else {
                        for (s in 0 until samples) {
                            val idx = ((pts.lastIndex.toLong() * s) / (samples - 1)).toInt()
                            val p = pts[idx]
                            minX = min(minX, p.x); minY = min(minY, p.y)
                            maxX = max(maxX, p.x); maxY = max(maxY, p.y); count++
                        }
                    }
                }
                pi += pathStride
            }
            li += layerStride
        }

        modelMinZ = value.layers.first().z.coerceAtLeast(0f)
        modelMaxZ = value.layers.last().z.coerceAtLeast(modelMinZ + 0.01f)
        if (count == 0 || !minX.isFinite() || !minY.isFinite() || !maxX.isFinite() || !maxY.isFinite()) {
            modelMinX = -bedX * 0.5f; modelMinY = -bedY * 0.5f
            modelMaxX = bedX * 0.5f; modelMaxY = bedY * 0.5f
        } else {
            val pad = 2f
            modelMinX = (minX - pad).coerceAtLeast(-bedX * 0.5f)
            modelMinY = (minY - pad).coerceAtLeast(-bedY * 0.5f)
            modelMaxX = (maxX + pad).coerceAtMost(bedX * 0.5f)
            modelMaxY = (maxY + pad).coerceAtMost(bedY * 0.5f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (width <= 0 || height <= 0) return
        val r = result ?: return
        if (r.layers.isEmpty()) return

        when (viewMode) {
            ViewMode.MODEL_3D -> drawModel3D(canvas, r)
            ViewMode.CURRENT_TOP -> drawCurrentTop(canvas, r)
        }
    }

    private fun drawModel3D(canvas: Canvas, r: ToolpathResult) {
        val cutoff = layerIndex.coerceIn(0, r.layers.lastIndex)
        val frame = frameForModel()
        draw3DGrid(canvas, frame)

        // Rendering is intentionally budgeted. The slicer result stays full fidelity; only the
        // mobile preview is sampled so one pathological layer can never stall the UI thread.
        val fast = interacting || sliderScrubbing || SystemClock.uptimeMillis() < fastRenderUntilMs
        // Keep the 3D model visually continuous. Step 4.4 used only 12 ghost layers, which
        // made tall models look like a handful of floating contour rings. We still keep a hard
        // budget, but distribute many more lightweight wall silhouettes through Z.
        val maxGhostLayers = if (fast) 10 else 64
        val layerStride = max(1, ceil((cutoff + 1).toDouble() / maxGhostLayers.toDouble()).toInt())
        val cutoffLayer = r.layers[cutoff]

        var i = 0
        while (i < cutoff) {
            val layer = r.layers[i]
            val depthFraction = if (cutoff <= 0) 1f else i.toFloat() / cutoff.toFloat()
            val alpha = if (fast) {
                (18 + depthFraction * 20).roundToInt().coerceIn(18, 38)
            } else {
                (22 + depthFraction * 30).roundToInt().coerceIn(22, 52)
            }
            drawGhostLayer3D(canvas, layer, frame, alpha, fast)
            i += layerStride
        }

        drawLayer3D(canvas, cutoffLayer, frame, 255, selected = true)
        if (showTravel && !fast) drawTravel3D(canvas, cutoffLayer, frame)
        drawCutOutline(canvas, cutoffLayer, frame, cutoff)
    }

    private fun drawCurrentTop(canvas: Canvas, r: ToolpathResult) {
        val layer = r.layers[layerIndex.coerceIn(0, r.layers.lastIndex)]
        val bounds = layerBounds(layerIndex, layer)
        val frame = frameForTop(bounds)
        drawTopGrid(canvas, frame, bounds)

        val maxPaths = if (interacting || sliderScrubbing) 120 else 240
        val pathStride = max(1, ceil(layer.paths.size.toDouble() / maxPaths.toDouble()).toInt())
        var i = 0
        while (i < layer.paths.size) {
            val path = layer.paths[i]
            if (path.points.size >= 2 && path.role in visibleRoles) {
                selectedPaint.color = roleColor(path.role)
                selectedPaint.strokeWidth = (path.widthMm * frame.scale).coerceIn(1.2f, 6f)
                drawPathTopSampled(canvas, path, frame, selectedPaint, if (interacting || sliderScrubbing) 72 else 180)
            }
            i += pathStride
        }
        if (showTravel && !interacting && !sliderScrubbing) drawTravelTop(canvas, layer, frame)
    }

    private data class Frame(
        val cx: Float,
        val cy: Float,
        val cz: Float,
        val scale: Float,
        val offsetX: Float,
        val offsetY: Float,
        val cosYaw: Float,
        val sinYaw: Float,
        val cosPitch: Float,
        val sinPitch: Float
    )

    private data class P2(val x: Float, val y: Float)

    private fun frameForModel(): Frame {
        // Stable camera scale: orbiting must rotate the model, not continuously auto-zoom it.
        // A 3D diagonal safely fits every orthographic orientation inside the mobile stage.
        val cx = (modelMinX + modelMaxX) * 0.5f
        val cy = (modelMinY + modelMaxY) * 0.5f
        val cz = (modelMinZ + modelMaxZ) * 0.5f
        val dx = (modelMaxX - modelMinX).coerceAtLeast(1f)
        val dy = (modelMaxY - modelMinY).coerceAtLeast(1f)
        val dz = (modelMaxZ - modelMinZ).coerceAtLeast(1f)
        val diagonal = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1f)
        val base = min(width.toFloat(), height.toFloat()) / diagonal * 0.82f
        return Frame(
            cx, cy, cz, base * zoom, width * 0.5f + panX, height * 0.54f + panY,
            cos(yaw), sin(yaw), cos(pitch), sin(pitch)
        )
    }

    private fun frameForTop(bounds: FloatArray): Frame {
        val minX = bounds[0]; val minY = bounds[1]; val maxX = bounds[2]; val maxY = bounds[3]
        val rawW = (maxX - minX).coerceAtLeast(1f)
        val rawH = (maxY - minY).coerceAtLeast(1f)
        val margin = max(rawW, rawH) * 0.12f + 1f
        val wMm = rawW + margin * 2f
        val hMm = rawH + margin * 2f
        val base = min(width / wMm, height / hMm) * 0.90f
        return Frame(
            (minX + maxX) * 0.5f,
            (minY + maxY) * 0.5f,
            0f,
            base * zoom,
            width * 0.5f + panX,
            height * 0.5f + panY,
            1f, 0f, 1f, 0f
        )
    }

    private fun project3DInto(x: Float, y: Float, z: Float, frame: Frame, out: FloatArray = projected) {
        val dx = x - frame.cx
        val dy = y - frame.cy
        val dz = z - frame.cz
        val x1 = frame.cosYaw * dx - frame.sinYaw * dy
        val y1 = frame.sinYaw * dx + frame.cosYaw * dy
        // Z is printer-up. Positive Z must move upward on screen from the bed (Z=0).
        // The previous sign made higher layers move downward, visually flipping the model
        // and making the bed/grid appear to float above it.
        val y2 = frame.cosPitch * y1 + frame.sinPitch * dz
        out[0] = frame.offsetX + x1 * frame.scale
        out[1] = frame.offsetY - y2 * frame.scale
    }

    private fun project3D(x: Float, y: Float, z: Float, frame: Frame): P2 {
        project3DInto(x, y, z, frame)
        return P2(projected[0], projected[1])
    }

    private fun drawGhostLayer3D(canvas: Canvas, layer: ToolpathLayer, frame: Frame, alpha: Int, fast: Boolean) {
        // Role-aware budget: sampling every Nth path can accidentally skip all walls when a layer
        // contains lots of infill/support paths. Walk path metadata only and preferentially draw
        // walls, which restores the recognizable full-object silhouette without revisiting every
        // geometry point.
        val maxWallPaths = if (fast) 14 else 40
        val maxSupportPaths = if (fast) 0 else 8
        var wallDrawn = 0
        var supportDrawn = 0

        for (path in layer.paths) {
            if (path.points.size < 2 || path.role !in visibleRoles) continue
            val allowed = when (path.role) {
                PathRole.WALL -> wallDrawn < maxWallPaths
                PathRole.BRIM -> !fast && wallDrawn < maxWallPaths
                PathRole.SUPPORT, PathRole.SUPPORT_INTERFACE -> !fast && supportDrawn < maxSupportPaths
                else -> false
            }
            if (!allowed) continue

            // Step 5.3 used a second, wide anti-aliased under-stroke on every sampled wall.
            // It looked solid, but doubled HWUI path work and could starve Android input dispatch
            // on the emulator during rapid layer scans. A single slightly wider non-AA pass keeps
            // the dense/solid silhouette while returning render cost close to the proven Step 5.2
            // budget (one drawPath per sampled toolpath).
            pathPaint.color = withAlpha(
                roleColor(path.role),
                if (fast) (alpha * 0.78f).roundToInt().coerceIn(16, 34)
                else (alpha * 0.96f).roundToInt().coerceIn(20, 52)
            )
            pathPaint.strokeWidth = if (fast) {
                (path.widthMm * frame.scale * 0.62f).coerceIn(0.55f, 1.55f)
            } else {
                (path.widthMm * frame.scale * 0.96f).coerceIn(0.82f, 2.75f)
            }
            drawPath3DSampled(canvas, path, layer.z, frame, pathPaint, if (fast) 18 else 28)

            when (path.role) {
                PathRole.WALL, PathRole.BRIM -> wallDrawn++
                PathRole.SUPPORT, PathRole.SUPPORT_INTERFACE -> supportDrawn++
                else -> Unit
            }
            if (wallDrawn >= maxWallPaths && (fast || supportDrawn >= maxSupportPaths)) break
        }
    }

    private fun drawLayer3D(canvas: Canvas, layer: ToolpathLayer, frame: Frame, alpha: Int, selected: Boolean) {
        val maxPaths = if (interacting || sliderScrubbing) 100 else 180
        val pathStride = max(1, ceil(layer.paths.size.toDouble() / maxPaths.toDouble()).toInt())
        var i = 0
        while (i < layer.paths.size) {
            val path = layer.paths[i]
            if (path.points.size >= 2 && path.role in visibleRoles) {
                val baseColor = roleColor(path.role)
                val paint = if (selected) selectedPaint else pathPaint
                paint.color = withAlpha(baseColor, alpha)
                val widthBoost = if (selected) 1.08f else 0.70f
                paint.strokeWidth = (path.widthMm * frame.scale * widthBoost).coerceIn(
                    if (selected) 1.05f else 0.55f,
                    if (selected) 4.7f else 2.3f
                )
                drawPath3DSampled(
                    canvas, path, layer.z, frame, paint,
                    if (interacting || sliderScrubbing) 72 else 140
                )
            }
            i += pathStride
        }
    }

    private fun drawPath3DSampled(
        canvas: Canvas,
        path: Toolpath,
        z: Float,
        frame: Frame,
        paint: Paint,
        maxSegments: Int
    ) {
        val pts = path.points
        if (pts.size < 2) return
        reusablePath.reset()
        project3DInto(pts[0].x, pts[0].y, z, frame)
        reusablePath.moveTo(projected[0], projected[1])

        val lastIndex = pts.lastIndex
        val stride = max(1, ceil(lastIndex.toDouble() / maxSegments.coerceAtLeast(1).toDouble()).toInt())
        var i = stride
        while (i < lastIndex) {
            project3DInto(pts[i].x, pts[i].y, z, frame)
            reusablePath.lineTo(projected[0], projected[1])
            i += stride
        }
        project3DInto(pts[lastIndex].x, pts[lastIndex].y, z, frame)
        reusablePath.lineTo(projected[0], projected[1])
        if (path.closed && pts.size > 2 && distanceSquared(pts.first(), pts.last()) > 0.0001f) {
            reusablePath.close()
        }
        canvas.drawPath(reusablePath, paint)
    }

    private fun drawPathTopSampled(
        canvas: Canvas,
        path: Toolpath,
        frame: Frame,
        paint: Paint,
        maxSegments: Int
    ) {
        val pts = path.points
        if (pts.size < 2) return
        reusablePath.reset()
        var x = frame.offsetX + (pts[0].x - frame.cx) * frame.scale
        var y = frame.offsetY - (pts[0].y - frame.cy) * frame.scale
        reusablePath.moveTo(x, y)

        val lastIndex = pts.lastIndex
        val stride = max(1, ceil(lastIndex.toDouble() / maxSegments.coerceAtLeast(1).toDouble()).toInt())
        var i = stride
        while (i < lastIndex) {
            x = frame.offsetX + (pts[i].x - frame.cx) * frame.scale
            y = frame.offsetY - (pts[i].y - frame.cy) * frame.scale
            reusablePath.lineTo(x, y)
            i += stride
        }
        x = frame.offsetX + (pts[lastIndex].x - frame.cx) * frame.scale
        y = frame.offsetY - (pts[lastIndex].y - frame.cy) * frame.scale
        reusablePath.lineTo(x, y)
        if (path.closed && pts.size > 2 && distanceSquared(pts.first(), pts.last()) > 0.0001f) reusablePath.close()
        canvas.drawPath(reusablePath, paint)
    }

    private fun drawTravel3D(canvas: Canvas, layer: ToolpathLayer, frame: Frame) {
        var lastEnd: Point2? = null
        for (path in layer.paths) {
            if (path.points.size < 2) continue
            val start = path.points.first()
            val prev = lastEnd
            if (prev != null && distanceSquared(prev, start) > 0.0001f) {
                val a = project3D(prev.x, prev.y, layer.z, frame)
                val b = project3D(start.x, start.y, layer.z, frame)
                canvas.drawLine(a.x, a.y, b.x, b.y, travelPaint)
            }
            lastEnd = path.points.last()
        }
    }

    private fun drawTravelTop(canvas: Canvas, layer: ToolpathLayer, frame: Frame) {
        var lastEnd: Point2? = null
        for (path in layer.paths) {
            if (path.points.size < 2) continue
            val start = path.points.first()
            val prev = lastEnd
            if (prev != null && distanceSquared(prev, start) > 0.0001f) {
                val ax = frame.offsetX + (prev.x - frame.cx) * frame.scale
                val ay = frame.offsetY - (prev.y - frame.cy) * frame.scale
                val bx = frame.offsetX + (start.x - frame.cx) * frame.scale
                val by = frame.offsetY - (start.y - frame.cy) * frame.scale
                canvas.drawLine(ax, ay, bx, by, travelPaint)
            }
            lastEnd = path.points.last()
        }
    }

    private fun draw3DGrid(canvas: Canvas, frame: Frame) {
        val margin = 18f
        // Preview uses the same centered model-space as ToolpathEngine/GCodeExporter:
        // machineX = modelX + bedX/2, machineY = modelY + bedY/2.
        // Therefore the physical bed in preview is [-bed/2, +bed/2], not [0, bed].
        val bedMinX = -bedX * 0.5f
        val bedMaxX = bedX * 0.5f
        val bedMinY = -bedY * 0.5f
        val bedMaxY = bedY * 0.5f
        val gx0 = floor(max(bedMinX, modelMinX - margin) / 10f) * 10f
        val gx1 = ceil(min(bedMaxX, modelMaxX + margin) / 10f) * 10f
        val gy0 = floor(max(bedMinY, modelMinY - margin) / 10f) * 10f
        val gy1 = ceil(min(bedMaxY, modelMaxY + margin) / 10f) * 10f
        var x = gx0
        while (x <= gx1 + 0.001f) {
            val a = project3D(x, gy0, 0f, frame)
            val b = project3D(x, gy1, 0f, frame)
            canvas.drawLine(a.x, a.y, b.x, b.y, if (((x / 50f).roundToInt() * 50f - x).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            x += 10f
        }
        var y = gy0
        while (y <= gy1 + 0.001f) {
            val a = project3D(gx0, y, 0f, frame)
            val b = project3D(gx1, y, 0f, frame)
            canvas.drawLine(a.x, a.y, b.x, b.y, if (((y / 50f).roundToInt() * 50f - y).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            y += 10f
        }
    }

    private fun drawTopGrid(canvas: Canvas, frame: Frame, bounds: FloatArray) {
        val bedMinX = -bedX * 0.5f
        val bedMaxX = bedX * 0.5f
        val bedMinY = -bedY * 0.5f
        val bedMaxY = bedY * 0.5f
        val minX = max(bedMinX, bounds[0] - 12f)
        val minY = max(bedMinY, bounds[1] - 12f)
        val maxX = min(bedMaxX, bounds[2] + 12f)
        val maxY = min(bedMaxY, bounds[3] + 12f)
        var x = floor(minX / 10f) * 10f
        while (x <= maxX + 0.001f) {
            val sx = frame.offsetX + (x - frame.cx) * frame.scale
            val y0 = frame.offsetY - (minY - frame.cy) * frame.scale
            val y1 = frame.offsetY - (maxY - frame.cy) * frame.scale
            canvas.drawLine(sx, y0, sx, y1, if (((x / 50f).roundToInt() * 50f - x).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            x += 10f
        }
        var y = floor(minY / 10f) * 10f
        while (y <= maxY + 0.001f) {
            val sy = frame.offsetY - (y - frame.cy) * frame.scale
            val x0 = frame.offsetX + (minX - frame.cx) * frame.scale
            val x1 = frame.offsetX + (maxX - frame.cx) * frame.scale
            canvas.drawLine(x0, sy, x1, sy, if (((y / 50f).roundToInt() * 50f - y).absoluteValue < 0.01f) majorGridPaint else gridPaint)
            y += 10f
        }
    }

    private fun drawCutOutline(canvas: Canvas, layer: ToolpathLayer, frame: Frame, index: Int) {
        if (layer.paths.isEmpty()) return
        val b = layerBounds(index, layer)
        val z = layer.z
        val a = project3D(b[0], b[1], z, frame)
        val c = project3D(b[2], b[1], z, frame)
        val d = project3D(b[2], b[3], z, frame)
        val e = project3D(b[0], b[3], z, frame)
        canvas.drawLine(a.x, a.y, c.x, c.y, cutPaint)
        canvas.drawLine(c.x, c.y, d.x, d.y, cutPaint)
        canvas.drawLine(d.x, d.y, e.x, e.y, cutPaint)
        canvas.drawLine(e.x, e.y, a.x, a.y, cutPaint)
    }


    private fun layerBounds(index: Int, layer: ToolpathLayer): FloatArray {
        val cached = cachedLayerBounds.getOrNull(index)
        if (cached != null) return cached
        val computed = computeBoundsForLayer(layer)
        if (index in cachedLayerBounds.indices) cachedLayerBounds[index] = computed
        return computed
    }

    private fun computeBoundsForLayer(layer: ToolpathLayer): FloatArray {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var count = 0

        val pathStride = max(1, ceil(layer.paths.size.toDouble() / 220.0).toInt())
        var pi = 0
        while (pi < layer.paths.size) {
            val pts = layer.paths[pi].points
            if (pts.isNotEmpty()) {
                val samples = min(9, pts.size)
                if (samples == 1) {
                    val p = pts[0]
                    minX = min(minX, p.x); minY = min(minY, p.y)
                    maxX = max(maxX, p.x); maxY = max(maxY, p.y); count++
                } else {
                    for (s in 0 until samples) {
                        val idx = ((pts.lastIndex.toLong() * s) / (samples - 1)).toInt()
                        val p = pts[idx]
                        minX = min(minX, p.x); minY = min(minY, p.y)
                        maxX = max(maxX, p.x); maxY = max(maxY, p.y); count++
                    }
                }
            }
            pi += pathStride
        }
        return if (count == 0) floatArrayOf(modelMinX, modelMinY, modelMaxX, modelMaxY)
        else floatArrayOf(minX, minY, maxX, maxY)
    }

    private fun roleColor(role: PathRole): Int = when (role) {
        PathRole.WALL -> Color.rgb(52, 211, 153)
        PathRole.SOLID -> Color.rgb(251, 191, 36)
        PathRole.GAP_FILL -> Color.rgb(244, 114, 182)
        PathRole.INFILL -> Color.rgb(96, 165, 250)
        PathRole.SUPPORT -> Color.rgb(192, 132, 252)
        PathRole.SUPPORT_INTERFACE -> Color.rgb(167, 139, 250)
        PathRole.BRIM -> Color.rgb(156, 163, 175)
    }

    private fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun distanceSquared(a: Point2, b: Point2): Float {
        val dx = a.x - b.x
        val dy = a.y - b.y
        return dx * dx + dy * dy
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y
                lastCx = event.x; lastCy = event.y
                interacting = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                val c = centroid(event)
                lastCx = c.x; lastCy = c.y
                interacting = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress) {
                    if (event.pointerCount >= 2) {
                        val c = centroid(event)
                        panX += c.x - lastCx
                        panY += c.y - lastCy
                        lastCx = c.x; lastCy = c.y
                    } else if (event.pointerCount == 1) {
                        val dx = event.x - lastX
                        val dy = event.y - lastY
                        if (viewMode == ViewMode.MODEL_3D) {
                            yaw += dx * 0.0085f
                            pitch = (pitch + dy * 0.0085f).coerceIn(Math.toRadians(14.0).toFloat(), Math.toRadians(82.0).toFloat())
                        } else {
                            panX += dx
                            panY += dy
                        }
                        lastX = event.x; lastY = event.y
                    }
                    postInvalidateOnAnimation()
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount - 1 <= 1) {
                    val keep = if (event.actionIndex == 0) 1 else 0
                    if (keep < event.pointerCount) {
                        lastX = event.getX(keep)
                        lastY = event.getY(keep)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                interacting = false
                performClick()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                interacting = false
                invalidate()
                return true
            }
        }
        return true
    }

    private fun centroid(event: MotionEvent): P2 {
        var x = 0f; var y = 0f
        val n = event.pointerCount.coerceAtLeast(1)
        for (i in 0 until n) { x += event.getX(i); y += event.getY(i) }
        return P2(x / n, y / n)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
