package com.rudrila.slicer.model

import android.content.Context

/**
 * Profile persistence with deterministic ID migration and verified writes.
 *
 * Step 5.6 final-audit rules:
 * - P2S + legacy material IDs migrate to the matching Step 5 balanced/safe preset.
 * - writes use commit() and are verified immediately, so a quick activity/app restart cannot
 *   expose a stale legacy profile after the UI said "saved".
 * - corrupt/non-finite numeric preferences are ignored independently instead of resetting the
 *   entire profile selection.
 */
class ProfileStore(
    context: Context,
    private val prefsName: String = PREFS_NAME
) {
    private val prefs = context.getSharedPreferences(prefsName, Context.MODE_PRIVATE)

    fun load(): PrintConfiguration {
        val fallback = Step5Profiles.defaultConfiguration()
        val printerId = prefs.getString("printer", fallback.printer.id)
        val filamentId = prefs.getString("filament", fallback.filament.id)
        val processId = prefs.getString("process", fallback.process.id)

        val printer = Step5Profiles.printers.firstOrNull { it.id == printerId } ?: fallback.printer
        val filament = Step5Profiles.filaments.firstOrNull { it.id == filamentId } ?: fallback.filament
        val processBase = Step5Profiles.processes.firstOrNull { it.id == processId } ?: fallback.process
        val savedBrim = prefs.getFloat("brim_width_mm", processBase.brimWidthMm)
        val supportStyle = prefs.getString("support_style", processBase.supportStyle)
            ?.takeIf { it == "Tree" || it == "Normal" }
            ?: processBase.supportStyle
        val process = processBase.copy(
            infillPercent = prefs.getInt("infill_percent", processBase.infillPercent).coerceIn(0, 100),
            brimWidthMm = if (savedBrim.isFinite()) savedBrim.coerceIn(0f, 50f) else processBase.brimWidthMm,
            supportEnabled = prefs.getBoolean("support_enabled", processBase.supportEnabled),
            supportStyle = supportStyle
        )

        val raw = PrintConfiguration(printer, filament, process)
        val canonical = runCatching {
            ProfilePolicy.canonicalize(raw).also { Step5Profiles.validate(it) }
        }.getOrElse { fallback }

        // Persist one-time migrations so the next process launch loads the exact same IDs.
        if (canonical.printer.id != printerId || canonical.filament.id != filamentId || canonical.process.id != processId) {
            saveInternal(canonical)
        }
        return canonical
    }

    /** Saves and returns the exact canonical configuration that was persisted. */
    fun save(config: PrintConfiguration): PrintConfiguration {
        val canonical = ProfilePolicy.canonicalize(config)
        Step5Profiles.validate(canonical)
        check(saveInternal(canonical)) { "Could not persist print profile" }

        // Verify the identity fields immediately. This directly guards the reported P2S PLA
        // Balanced -> legacy Generic PLA regression.
        check(prefs.getString("printer", null) == canonical.printer.id) { "Printer profile did not persist" }
        check(prefs.getString("filament", null) == canonical.filament.id) { "Filament profile did not persist" }
        check(prefs.getString("process", null) == canonical.process.id) { "Process profile did not persist" }
        return canonical
    }

    private fun saveInternal(config: PrintConfiguration): Boolean = prefs.edit()
        .putString("printer", config.printer.id)
        .putString("filament", config.filament.id)
        .putString("process", config.process.id)
        .putInt("infill_percent", config.process.infillPercent)
        .putFloat("brim_width_mm", config.process.brimWidthMm)
        .putBoolean("support_enabled", config.process.supportEnabled)
        .putString("support_style", config.process.supportStyle)
        .commit()

    companion object {
        private const val PREFS_NAME = "rudrila_slicer_profiles"
        private const val SELFTEST_PREFS = "rudrila_slicer_profile_selftest_v2"

        /**
         * One-time real Android SharedPreferences round-trip. It writes only to an isolated test
         * preference file and clears it after success. Returning null means PASS.
         */
        fun runPersistenceSelfTest(context: Context): String? = runCatching {
            val audit = ProfilePolicy.catalogErrors()
            check(audit.isEmpty()) { audit.joinToString("; ") }

            val testPrefs = context.getSharedPreferences(SELFTEST_PREFS, Context.MODE_PRIVATE)
            if (testPrefs.getBoolean("passed", false)) return@runCatching
            check(testPrefs.edit().clear().commit()) { "Could not prepare profile self-test" }

            val store = ProfileStore(context, SELFTEST_PREFS)
            val generic = Step5Profiles.defaultConfiguration()
            val p2s = Step5Profiles.printers.first { it.id == "bambu_p2s_04" }
            val legacyPla = Step5Profiles.filaments.firstOrNull {
                it.material.equals("PLA", true) && it.id != "step5_pla"
            } ?: Step5Profiles.filaments.first { it.id == "step5_pla" }

            val saved = store.save(PrintConfiguration(p2s, legacyPla, generic.process))
            check(saved.filament.id == "step5_pla") { "P2S PLA canonical save failed" }
            val loaded = store.load()
            check(loaded.printer.id == "bambu_p2s_04" && loaded.filament.id == "step5_pla") {
                "P2S PLA persistence round-trip failed"
            }

            // Generic printers retain the legacy profile identity for backwards compatibility.
            val legacyGeneric = store.save(PrintConfiguration(generic.printer, legacyPla, generic.process))
            check(legacyGeneric.filament.id == legacyPla.id) { "Generic legacy profile compatibility changed" }

            check(testPrefs.edit().clear().putBoolean("passed", true).commit()) {
                "Could not finalize profile self-test"
            }
        }.exceptionOrNull()?.message
    }
}
