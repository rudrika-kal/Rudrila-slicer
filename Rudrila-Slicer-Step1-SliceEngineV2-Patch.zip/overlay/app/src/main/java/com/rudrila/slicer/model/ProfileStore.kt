package com.rudrila.slicer.model

import android.content.Context

/** Step 5 profile persistence with backwards compatibility for older profile IDs. */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("rudrila_slicer_profiles", Context.MODE_PRIVATE)

    fun load(): PrintConfiguration {
        val fallback = Step5Profiles.defaultConfiguration()
        val printerId = prefs.getString("printer", fallback.printer.id)
        val filamentId = prefs.getString("filament", fallback.filament.id)
        val processId = prefs.getString("process", fallback.process.id)

        val printer = Step5Profiles.printers.firstOrNull { it.id == printerId } ?: fallback.printer
        val filament = Step5Profiles.filaments.firstOrNull { it.id == filamentId } ?: fallback.filament
        val processBase = Step5Profiles.processes.firstOrNull { it.id == processId } ?: fallback.process
        val process = processBase.copy(
            infillPercent = prefs.getInt("infill_percent", processBase.infillPercent).coerceIn(0, 100),
            brimWidthMm = prefs.getFloat("brim_width_mm", processBase.brimWidthMm).coerceIn(0f, 50f),
            supportEnabled = prefs.getBoolean("support_enabled", processBase.supportEnabled),
            supportStyle = prefs.getString("support_style", processBase.supportStyle) ?: processBase.supportStyle
        )

        return runCatching {
            PrintConfiguration(printer, filament, process).also { Step5Profiles.validate(it) }
        }.getOrElse { fallback }
    }

    fun save(config: PrintConfiguration) {
        Step5Profiles.validate(config)
        prefs.edit()
            .putString("printer", config.printer.id)
            .putString("filament", config.filament.id)
            .putString("process", config.process.id)
            .putInt("infill_percent", config.process.infillPercent)
            .putFloat("brim_width_mm", config.process.brimWidthMm)
            .putBoolean("support_enabled", config.process.supportEnabled)
            .putString("support_style", config.process.supportStyle)
            .apply()
    }
}
