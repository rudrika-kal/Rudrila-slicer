package com.rudrila.slicer.model

import kotlin.math.max

/**
 * Step 5.6 export intent. ANALYSIS may be saved for inspection, but is explicitly marked
 * DO_NOT_PRINT. PRINTER_READY must pass every machine/geometry gate.
 */
enum class ExportPurpose { ANALYSIS, PRINTER_READY, P2S_CONTROLLED_TEST }

data class GCodeSafetyReport(
    val purpose: ExportPurpose,
    val errors: List<String>,
    val warnings: List<String>,
    val pointCount: Long,
    val maxZMm: Float,
    val maxRequestedSpeedMmS: Float,
    val maxEffectiveVolumetricMm3s: Float,
    val speedCappedPathCount: Int,
    val accelerationCappedPathCount: Int
) {
    val passed: Boolean get() = errors.isEmpty()
    val statusLabel: String get() = when {
        passed && purpose != ExportPurpose.ANALYSIS -> "PASS • printer-ready"
        passed -> "PASS • analysis only"
        else -> "BLOCKED • ${errors.firstOrNull() ?: "safety gate"}"
    }

    fun details(maxItems: Int = 6): String = buildString {
        append(if (passed) "Preflight PASS" else "Preflight BLOCKED")
        append(" • ").append(pointCount).append(" points checked")
        append(" • max Z ").append("%.2f".format(maxZMm)).append(" mm")
        append("\nMax requested speed ").append("%.1f".format(maxRequestedSpeedMmS)).append(" mm/s")
        append(" • max effective flow ").append("%.2f".format(maxEffectiveVolumetricMm3s)).append(" mm³/s")
        if (errors.isNotEmpty()) {
            append("\n\nBLOCKERS:")
            errors.take(maxItems).forEach { append("\n• ").append(it) }
            if (errors.size > maxItems) append("\n• +").append(errors.size - maxItems).append(" more")
        }
        if (warnings.isNotEmpty()) {
            append("\n\nWarnings:")
            warnings.take(maxItems).forEach { append("\n• ").append(it) }
            if (warnings.size > maxItems) append("\n• +").append(warnings.size - maxItems).append(" more")
        }
    }
}

object GCodeSafety {
    fun isP2S(config: PrintConfiguration): Boolean = config.printer.id.startsWith("bambu_p2s_")

    fun inspect(
        toolpaths: ToolpathResult,
        config: PrintConfiguration,
        purpose: ExportPurpose = ExportPurpose.PRINTER_READY
    ): GCodeSafetyReport {
        val errors = linkedSetOf<String>()
        val warnings = linkedSetOf<String>()

        runCatching { Step5Profiles.validate(config) }
            .onFailure { errors += (it.message ?: "Invalid printer/filament profile") }

        if (!toolpaths.canExport) {
            errors += (toolpaths.exportBlockReason ?: "Slice geometry contains export blockers")
        }
        if (toolpaths.layers.isEmpty()) errors += "No printable layers"

        if (config.filament.nozzleTempC < 120 || config.filament.nozzleTempC > config.printer.maxHotendTempC) {
            errors += "Nozzle temperature ${config.filament.nozzleTempC}°C is outside safe printer range 120–${config.printer.maxHotendTempC}°C"
        }
        if (config.filament.bedTempC < 0 || config.filament.bedTempC > config.printer.maxBedTempC) {
            errors += "Bed temperature ${config.filament.bedTempC}°C exceeds printer limit ${config.printer.maxBedTempC}°C"
        }

        // The official P2S machine profile uses a large printer-specific start/end sequence with
        // plate detection, homing/leveling, calibration, AMS/tool handling and proprietary commands.
        // Until that native machine template is implemented here, generic startup G-code must never
        // be presented as printer-ready for P2S.
        if (purpose == ExportPurpose.PRINTER_READY && isP2S(config)) {
            errors += "P2S native machine start/end sequence is not integrated yet; generic G-code is analysis-only"
        }

        val machine = Step5Profiles.machine(config.printer)
        val nozzle = config.printer.nozzleDiameter.coerceAtLeast(0.01f)
        val maxLayerHeight = nozzle * 0.80f + 0.0001f
        var pointCount = 0L
        var extrusionSegmentCount = 0L
        var outOfBounds = 0L
        var badNumbers = 0L
        var maxZ = 0f
        var maxRequestedSpeed = 0f
        var maxEffectiveVol = 0f
        var speedCapped = 0
        var accelCapped = 0
        var lastZ = -Float.MAX_VALUE
        var tallLayerCount = 0
        var oddWidthCount = 0

        for (layer in toolpaths.layers) {
            val z = layer.z
            val h = layer.heightMm
            if (!z.isFinite() || !h.isFinite()) {
                badNumbers++
                continue
            }
            maxZ = max(maxZ, z)
            if (z < -0.001f || z > config.printer.bedZ + 0.001f) {
                errors += "Layer Z ${"%.2f".format(z)} mm is outside printer Z range 0–${config.printer.bedZ.toInt()} mm"
            }
            if (z + 0.0001f < lastZ) errors += "Layer Z order is not monotonic"
            lastZ = z
            if (h <= 0f || h > 2f) errors += "Invalid layer height ${"%.3f".format(h)} mm"
            if (h > maxLayerHeight) tallLayerCount++

            for (path in layer.paths) {
                if (path.points.size >= 2) extrusionSegmentCount += (path.points.size - 1).toLong()
                if (!path.widthMm.isFinite() || !path.speedMmS.isFinite() || !path.flowRatio.isFinite()) {
                    badNumbers++
                    continue
                }
                if (path.widthMm <= 0f || path.widthMm > nozzle * 2.5f) {
                    errors += "Unsafe line width ${"%.3f".format(path.widthMm)} mm for ${"%.1f".format(nozzle)} mm nozzle"
                } else if (path.widthMm < nozzle * 0.45f || path.widthMm > nozzle * 1.8f) {
                    oddWidthCount++
                }
                if (path.speedMmS <= 0f) errors += "Non-positive extrusion speed"
                if (path.flowRatio <= 0f || path.flowRatio > 2.5f) errors += "Unsafe extrusion flow ratio ${"%.2f".format(path.flowRatio)}"

                maxRequestedSpeed = max(maxRequestedSpeed, path.speedMmS)
                val safeSpeed = Step5Profiles.capExtrusionSpeedMmS(
                    path.speedMmS.coerceAtLeast(1f), config, path.widthMm.coerceAtLeast(0.01f), h.coerceAtLeast(0.01f), path.flowRatio.coerceAtLeast(0.01f)
                )
                if (safeSpeed + 0.01f < path.speedMmS) speedCapped++
                val effectiveVol = safeSpeed * path.widthMm.coerceAtLeast(0f) * h.coerceAtLeast(0f) * path.flowRatio.coerceAtLeast(0f)
                maxEffectiveVol = max(maxEffectiveVol, effectiveVol)
                if (effectiveVol > config.filament.maxVolumetricSpeedMm3s + 0.05f) {
                    errors += "Effective volumetric flow exceeds filament limit"
                }
                if (path.accelerationMmS2 > machine.maxPrintAccelerationMmS2) accelCapped++

                val packed = path.points as? PackedPointList
                if (packed != null) {
                    // Hot path for real slices: scan primitive XY storage directly. Calling
                    // PackedPointList.get() for every point allocates a Point2 each time; on a
                    // 153 MB model that transient allocation pressure can trigger Android ANR
                    // immediately after slicing when Preview attaches. This scan is still exact.
                    val xy = packed.packedXYReadOnly()
                    var pi = 0
                    while (pi + 1 < xy.size) {
                        pointCount++
                        val x = xy[pi]
                        val y = xy[pi + 1]
                        if (!x.isFinite() || !y.isFinite()) {
                            badNumbers++
                        } else {
                            val mx = x + config.printer.bedX / 2f
                            val my = y + config.printer.bedY / 2f
                            if (mx < -0.001f || mx > config.printer.bedX + 0.001f || my < -0.001f || my > config.printer.bedY + 0.001f) outOfBounds++
                        }
                        pi += 2
                    }
                } else {
                    for (p in path.points) {
                        pointCount++
                        if (!p.x.isFinite() || !p.y.isFinite()) {
                            badNumbers++
                            continue
                        }
                        val mx = p.x + config.printer.bedX / 2f
                        val my = p.y + config.printer.bedY / 2f
                        if (mx < -0.001f || mx > config.printer.bedX + 0.001f || my < -0.001f || my > config.printer.bedY + 0.001f) outOfBounds++
                    }
                }
            }
        }

        if (badNumbers > 0) errors += "$badNumbers non-finite/invalid toolpath value(s) detected"
        if (outOfBounds > 0) errors += "$outOfBounds toolpath point(s) fall outside the build plate"
        if (tallLayerCount > 0) errors += "$tallLayerCount layer(s) exceed 80% of nozzle diameter; choose a compatible process/nozzle"
        if (oddWidthCount > 0) warnings += "$oddWidthCount path(s) use unusual line width for the selected nozzle"
        if (speedCapped > 0) warnings += "$speedCapped path(s) are speed-capped by machine/volumetric limits"
        if (accelCapped > 0) warnings += "$accelCapped path(s) are acceleration-capped by the machine profile"
        if (pointCount == 0L || extrusionSegmentCount == 0L) errors += "No printable extrusion segments found in sliced layers"

        return GCodeSafetyReport(
            purpose = purpose,
            errors = errors.toList(),
            warnings = warnings.toList(),
            pointCount = pointCount,
            maxZMm = maxZ,
            maxRequestedSpeedMmS = maxRequestedSpeed,
            maxEffectiveVolumetricMm3s = maxEffectiveVol,
            speedCappedPathCount = speedCapped,
            accelerationCappedPathCount = accelCapped
        )
    }
}
