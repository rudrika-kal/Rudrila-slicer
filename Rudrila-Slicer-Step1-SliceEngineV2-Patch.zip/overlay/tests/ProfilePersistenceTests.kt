import android.content.Context
import com.rudrila.slicer.model.*

fun main(){
    val context=Context()
    val store=ProfileStore(context)
    val generic=DefaultProfiles.defaultConfiguration()
    val p2s=Step5Profiles.printers.first{it.id=="bambu_p2s_04"}
    val legacyPla=DefaultProfiles.filaments.first()

    val saved=store.save(PrintConfiguration(p2s,legacyPla,generic.process))
    check(saved.filament.id=="step5_pla")
    val loaded=ProfileStore(context).load()
    check(loaded.printer.id==p2s.id && loaded.filament.id=="step5_pla")

    val genericSaved=store.save(PrintConfiguration(generic.printer,legacyPla,generic.process))
    check(genericSaved.filament.id==legacyPla.id)
    check(ProfileStore(context).load().filament.id==legacyPla.id)

    // Corrupt/non-finite brim values are sanitized independently without losing identities.
    context.getSharedPreferences("rudrila_slicer_profiles",Context.MODE_PRIVATE).edit()
        .putString("printer",p2s.id).putString("filament",legacyPla.id).putString("process",generic.process.id)
        .putFloat("brim_width_mm",Float.NaN).commit()
    val migrated=ProfileStore(context).load()
    check(migrated.filament.id=="step5_pla")
    check(migrated.process.brimWidthMm.isFinite())

    check(ProfileStore.runPersistenceSelfTest(context)==null)
    println("PROFILE_PERSISTENCE_FINAL_AUDIT_PASS ${migrated.filament.name}")
}
