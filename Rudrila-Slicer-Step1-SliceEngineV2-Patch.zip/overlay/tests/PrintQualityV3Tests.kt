import com.rudrila.slicer.model.*
import kotlin.math.abs

private fun qSquare(x0:Float,y0:Float,s:Float):SliceLoop{
    val p=listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s))
    return SliceLoop(p+p.first(),false,0)
}

fun main(){
    val base=DefaultProfiles.defaultConfiguration()
    val cfg=base.copy(process=base.process.copy(
        supportEnabled=false,brimWidthMm=0f,wallLoops=2,bottomLayers=0,topLayers=2,infillPercent=15
    ))
    val slice=SliceResult(listOf(
        SliceLayer(0,0.2f,listOf(qSquare(-8f,-8f,16f)),emptyList()),
        SliceLayer(1,0.4f,listOf(qSquare(-12f,-12f,24f)),emptyList()),
        SliceLayer(2,0.6f,listOf(qSquare(-12f,-12f,24f)),emptyList())
    ),1)
    val planned=ToolpathEngine.plan(slice,cfg)

    val firstWall=planned.layers[0].paths.first{it.role==PathRole.WALL}
    check(firstWall.flowRatio>1f)
    check(firstWall.accelerationMmS2==500)

    val overhangWall=planned.layers[1].paths.first{it.role==PathRole.WALL}
    val maxY=overhangWall.points.dropLast(1).maxOf{it.y}
    check(abs(overhangWall.points.first().y-maxY)<1e-4f)
    check(overhangWall.speedMmS<=35.01f)

    val bridge=planned.layers[1].paths.filter{it.bridge}
    check(bridge.isNotEmpty())
    check(bridge.all{it.speedMmS<=25.01f})

    val ironing=planned.layers[2].paths.filter{it.ironing}
    check(ironing.isNotEmpty())
    check(ironing.all{it.flowRatio in 0.11f..0.13f})
    val lastNonEmpty=planned.layers[2].paths.indexOfLast{!it.ironing}
    val firstIron=planned.layers[2].paths.indexOfFirst{it.ironing}
    check(firstIron<0 || firstIron>lastNonEmpty){"ironing must remain after normal extrusion phases"}

    val islands=SliceResult(listOf(
        SliceLayer(0,0.2f,listOf(qSquare(-30f,-5f,10f),qSquare(20f,-5f,10f)),emptyList())
    ),1)
    val islandCfg=cfg.copy(process=cfg.process.copy(topLayers=0,infillPercent=0))
    val gcode=GCodeExporter.generate(ToolpathEngine.plan(islands,islandCfg),islandCfg)
    check("M204 S" in gcode)
    check("G1 E-0.800" in gcode && "G1 E0.800" in gcode)
    check(";SEAM:REAR" in gcode)

    val qualityGcode=GCodeExporter.generate(planned,cfg)
    check(";QUALITY:BRIDGE" in qualityGcode)
    check(";QUALITY:IRONING" in qualityGcode)
    println("PRINT_QUALITY_V3_TESTS_PASS bridge=${bridge.size} ironing=${ironing.size}")
}
