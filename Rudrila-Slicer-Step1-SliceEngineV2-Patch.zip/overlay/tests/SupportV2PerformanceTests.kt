// Step 4.2 branch-propagation performance regression
import com.rudrila.slicer.model.*
import kotlin.math.*
private fun poly(cx:Float,cy:Float,rx:Float,ry:Float,n:Int,hole:Boolean=false):SliceLoop{
 val p=ArrayList<Point2>(n+1)
 for(i in 0 until n){val a=2.0*Math.PI*i/n; val w=1.0+0.10*sin(7*a)+0.04*cos(19*a); p+=Point2((cx+rx*cos(a)*w).toFloat(),(cy+ry*sin(a)*w).toFloat())};p+=p.first();return SliceLoop(p,hole,if(hole)1 else 0)
}
fun main(){
 val ls=ArrayList<SliceLayer>(500)
 for(i in 0 until 500){
   val t=i/499.0; val cx=(sin(t*10.0)*5.0 + if(i>250) 4.0 else 0.0).toFloat(); val cy=(cos(t*7.0)*2.5).toFloat()
   val rx=(14.0+3.0*sin(t*16.0)).toFloat(); val ry=(11.0+2.0*cos(t*13.0)).toFloat()
   val loops=mutableListOf<SliceLoop>(poly(cx,cy,rx,ry,220,false))
   if(i in 40..440) loops+=poly(cx+1.1f,cy,3.0f,2.2f,80,true)
   if(i%5<3 && i>80) loops+=poly(cx-12f,cy+8f,3.2f,2.6f,72,false)
   ls+=SliceLayer(i,(i+1)*0.2f,loops,emptyList())
 }
 val base=DefaultProfiles.defaultConfiguration(); val cfg=base.copy(process=base.process.copy(wallLoops=0,bottomLayers=0,topLayers=0,infillPercent=0,brimWidthMm=0f,supportEnabled=true,supportStyle="Tree",supportOverhangDeg=50))
 SupportSettings.styleOverride="Tree / Organic";SupportSettings.overhangDeg=50;SupportSettings.interfaceLayers=2;SupportSettings.buildPlateOnly=false
 val t0=System.nanoTime(); val r=ToolpathEngine.plan(SliceResult(ls,1),cfg); val ms=(System.nanoTime()-t0)/1_000_000
 val s=r.layers.sumOf{l->l.paths.count{it.role==PathRole.SUPPORT}};val f=r.layers.sumOf{l->l.paths.count{it.role==PathRole.SUPPORT_INTERFACE}}
 println("SUPPORT_PERF_PASS ms=$ms support=$s interface=$f layers=${r.layers.size}")
 check(s>0&&f>0&&r.layers.size==500)
}
