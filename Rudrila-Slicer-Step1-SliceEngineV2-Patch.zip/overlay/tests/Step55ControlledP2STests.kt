import com.rudrila.slicer.model.*

fun main(){
    val start = buildString {
        append(";======== P2S start gcode==========\n")
        append("; resolved native P2S safety-cube reference\n".repeat(8))
        append("M620 M\n")
        append("G389\n")
        append("M1002 set_gcode_claim_action : 2\n")
        append("M622 J1\n")
        append("M140 S55\nM104 S220\nG28\nG29\nM190 S55\nM109 S220\n")
        append("G90\nM83\nG92 E0\n")
    }
    val body = buildString {
        for(layer in 0 until 25){
            val z=(layer+1)*0.2f
            append("; CHANGE_LAYER\n")
            append("G0 Z${"%.1f".format(java.util.Locale.US,z)}\n")
            append("G0 X118 Y118\n")
            append("G1 X138 Y118 E1.0\n")
            append("G1 X138 Y138 E1.0\n")
            append("G1 X118 Y138 E1.0\n")
            append("G1 X118 Y118 E1.0\n")
        }
    }
    val end = buildString {
        append(";======== P2S end gcode ==========\n")
        append("M400\nM104 S0\nM140 S0\n")
        append("; native P2S shutdown and finalization\n".repeat(8))
        append("M18\n")
    }
    val reference=start+body+end
    val env=P2SControlledBridge.parseResolvedReference(reference)
    check(env.startGcode.contains("P2S start gcode"))
    check(env.endGcode.contains("P2S end gcode"))
    check(env.referenceLayerCount==25)
    check(env.referenceExtrusionMoves>=100)
    check(env.referenceWidthMm in 19.9f..20.1f && env.referenceDepthMm in 19.9f..20.1f)
    check(env.referenceMaxZMm in 4.99f..5.01f)
    check(P2SControlledBridge.decode(P2SControlledBridge.encode(env))==env)
    check(runCatching{
        P2SControlledBridge.parseResolvedReference(reference.replace("M190 S55","M190 S[bed_temperature_initial_layer_single]"))
    }.isFailure)
    check(runCatching{
        P2SControlledBridge.parseResolvedReference(reference.replace("X118 Y118","X80 Y80"))
    }.isFailure)

    val base=DefaultProfiles.defaultConfiguration()
    val cfg=PrintConfiguration(
        Step5Profiles.printers.first{it.id=="bambu_p2s_04"},
        Step5Profiles.filaments.first{it.id=="step5_pla"},
        base.process.copy(infillPercent=15,supportEnabled=false,brimWidthMm=0f)
    )
    val square=listOf(Point2(-10f,-10f),Point2(10f,-10f),Point2(10f,10f),Point2(-10f,10f),Point2(-10f,-10f))
    val paths=List(6){Toolpath(square,PathRole.WALL,true,0.42f,50f,1f,1200)}
    val layers=(0 until 25).map{i->ToolpathLayer(i,(i+1)*0.2f,0.2f,paths)}
    val result=ToolpathResult(layers,PrintEstimate(600f,40f,0.12f,300))

    check(P2SControlledBridge.controlledTestErrors(result,cfg,env).isEmpty()){
        P2SControlledBridge.controlledTestErrors(result,cfg,env).joinToString()
    }
    check(P2SControlledBridge.controlledTestErrors(
        result,cfg.copy(printer=Step5Profiles.printers.first{it.id=="bambu_p2s_06"}),env
    ).isNotEmpty())
    check(P2SControlledBridge.controlledTestErrors(
        result,cfg.copy(filament=DefaultProfiles.filaments.first()),env
    ).any{it.contains("Balanced")})
    check(P2SControlledBridge.controlledTestErrors(
        result,cfg.copy(process=cfg.process.copy(brimWidthMm=2f)),env
    ).any{it.contains("brim",true)})
    val shifted=result.copy(layers=result.layers.map{layer->
        layer.copy(paths=layer.paths.map{p->p.copy(points=p.points.map{Point2(it.x+5f,it.y)})})
    })
    check(P2SControlledBridge.controlledTestErrors(shifted,cfg,env).any{it.contains("centered")})

    val g=GCodeExporter.generate(result,cfg,ExportPurpose.P2S_CONTROLLED_TEST,env)
    check("; P2S_CONTROLLED_TEST=20x20x5_CUBE_ONLY" in g)
    check("; native_reference_layers=25" in g)
    check("; RUDRILA_CONTROLLED_BODY_BEGIN" in g && "; RUDRILA_CONTROLLED_BODY_END" in g)
    check(g.indexOf("P2S start gcode") < g.indexOf("RUDRILA_CONTROLLED_BODY_BEGIN"))
    check(g.indexOf("RUDRILA_CONTROLLED_BODY_END") < g.indexOf("P2S end gcode"))
    check("M73 L1" in g && "M991 S0 P0" in g)
    check(g.split("G28").size-1==1) { "generic startup was duplicated" }
    check(runCatching{GCodeExporter.generate(result,cfg,ExportPurpose.P2S_CONTROLLED_TEST,null)}.isFailure)
    check(runCatching{GCodeExporter.generate(shifted,cfg,ExportPurpose.P2S_CONTROLLED_TEST,env)}.isFailure)

    println("STEP56_CONTROLLED_P2S_TESTS_PASS ref=${env.shortSha}")
}
