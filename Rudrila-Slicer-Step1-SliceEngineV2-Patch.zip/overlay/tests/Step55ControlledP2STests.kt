import com.rudrila.slicer.model.*

fun main(){
    val start = buildString {
        append(";======== P2S start gcode==========\n")
        append("; resolved native reference\n".repeat(12))
        append("M140 S55\nM104 S220\nG28\nG29\nM190 S55\nM109 S220\n")
    }
    val end = buildString {
        append(";======== P2S end gcode ==========\n")
        append("M400\nM104 S0\nM140 S0\n")
        append("; native shutdown\n".repeat(8))
        append("M18\n")
    }
    val reference = start + "; CHANGE_LAYER\n; synthetic body from Bambu Studio\nG1 X1 Y1\n" + end
    val env=P2SControlledBridge.parseResolvedReference(reference)
    check(env.startGcode.contains("P2S start gcode"))
    check(env.endGcode.contains("P2S end gcode"))
    check(P2SControlledBridge.decode(P2SControlledBridge.encode(env))==env)
    check(runCatching{P2SControlledBridge.parseResolvedReference(reference.replace("M190 S55","M190 S[bed_temperature_initial_layer_single]"))}.isFailure)

    val base=DefaultProfiles.defaultConfiguration()
    val cfg=PrintConfiguration(
        Step5Profiles.printers.first{it.id=="bambu_p2s_04"},
        Step5Profiles.filaments.first{it.id=="step5_pla"},
        base.process.copy(supportEnabled=false)
    )
    val square=listOf(Point2(-10f,-10f),Point2(10f,-10f),Point2(10f,10f),Point2(-10f,10f),Point2(-10f,-10f))
    val path=Toolpath(square,PathRole.WALL,true,0.42f,50f,1f,1200)
    val result=ToolpathResult(
        listOf(
            ToolpathLayer(0,0.20f,0.20f,listOf(path)),
            ToolpathLayer(24,5.00f,0.20f,listOf(path))
        ),
        PrintEstimate(160f,7f,0.02f,20)
    )
    check(P2SControlledBridge.controlledTestErrors(result,cfg,env).isEmpty())
    check(P2SControlledBridge.controlledTestErrors(result,cfg.copy(printer=Step5Profiles.printers.first{it.id=="bambu_p2s_06"}),env).isNotEmpty())
    val shifted=result.copy(layers=result.layers.map{layer->layer.copy(paths=layer.paths.map{p->p.copy(points=p.points.map{Point2(it.x+5f,it.y)})})})
    check(P2SControlledBridge.controlledTestErrors(shifted,cfg,env).any{it.contains("centered")})

    val g=GCodeExporter.generate(result,cfg,ExportPurpose.P2S_CONTROLLED_TEST,env)
    check("; P2S_CONTROLLED_TEST=20x20x5_CUBE_ONLY" in g)
    check("; RUDRILA_CONTROLLED_BODY_BEGIN" in g && "; RUDRILA_CONTROLLED_BODY_END" in g)
    check(g.indexOf("P2S start gcode") < g.indexOf("RUDRILA_CONTROLLED_BODY_BEGIN"))
    check(g.indexOf("RUDRILA_CONTROLLED_BODY_END") < g.indexOf("P2S end gcode"))
    check("M73 L1" in g && "M991 S0 P0" in g)
    check(g.split("G28").size-1==1) { "generic startup was duplicated" }
    check(runCatching{GCodeExporter.generate(result,cfg,ExportPurpose.P2S_CONTROLLED_TEST,null)}.isFailure)
    check(runCatching{GCodeExporter.generate(shifted,cfg,ExportPurpose.P2S_CONTROLLED_TEST,env)}.isFailure)

    println("STEP55_CONTROLLED_P2S_TESTS_PASS ref=${env.shortSha}")
}
