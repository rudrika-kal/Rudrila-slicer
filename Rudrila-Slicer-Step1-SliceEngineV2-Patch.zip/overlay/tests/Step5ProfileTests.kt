import com.rudrila.slicer.model.*

fun main(){
    val p2s=Step5Profiles.printers.filter{it.id.startsWith("bambu_p2s_")}
    check(p2s.size==4)
    check(p2s.map{it.nozzleDiameter}.toSet()==setOf(0.2f,0.4f,0.6f,0.8f))
    check(p2s.all{it.bedX==256f&&it.bedY==256f&&it.bedZ==256f&&it.maxHotendTempC==300&&it.maxBedTempC==110})

    val materials=Step5Profiles.filaments.filter{it.id.startsWith("step5_")}.associateBy{it.material}
    check(listOf("PLA","PETG","ABS","TPU").all{it in materials})
    check(materials.getValue("TPU").maxVolumetricSpeedMm3s < materials.getValue("PLA").maxVolumetricSpeedMm3s)

    val legacy=DefaultProfiles.defaultConfiguration()
    val cfg=PrintConfiguration(
        Step5Profiles.printers.first{it.id=="bambu_p2s_04"},
        Step5Profiles.filaments.first{it.id=="step5_pla"},
        legacy.process
    )
    Step5Profiles.validate(cfg)
    val cap=Step5Profiles.capExtrusionSpeedMmS(500f,cfg,0.42f,0.2f,1f)
    check(cap in 210f..216f)
    check(Step5Profiles.fanPercentForLayer(cfg.filament,0)==0)
    check(Step5Profiles.fanPercentForLayer(cfg.filament,4)==100)

    val path=Toolpath(listOf(Point2(-10f,0f),Point2(10f,0f)),PathRole.WALL,true,0.42f,500f,1f,1500)
    val result=ToolpathResult(
        listOf(
            ToolpathLayer(0,0.24f,0.24f,listOf(path)),
            ToolpathLayer(1,0.44f,0.20f,listOf(path.copy(points=listOf(Point2(-9f,0f),Point2(9f,0f)))))
        ),
        PrintEstimate(38f,6f,0.02f,2)
    )
    val g=GCodeExporter.generate(result,cfg,ExportPurpose.ANALYSIS)
    check("; Step 5 Printer + Filament Profiles" in g)
    check("; DO_NOT_PRINT=ANALYSIS_ONLY" in g)
    check("M140 S55" in g && "M104 S220" in g)
    check("G0 Z0.240 F1200" in g)
    check("G0 X" in g && "F36000" in g)
    check("G1 E-0.600 F2100" in g)
    check("M106 S" in g)

    val legacyG=GCodeExporter.generate(result,legacy,ExportPurpose.PRINTER_READY)
    check("G1 E-0.800 F2100" in legacyG) { "legacy Step 4 retract compatibility changed" }

    val tooHigh=result.copy(layers=listOf(ToolpathLayer(0,257f,0.2f,listOf(path))))
    check(runCatching{GCodeExporter.generate(tooHigh,cfg,ExportPurpose.ANALYSIS)}.isFailure)

    println("STEP5_PROFILE_TESTS_PASS p2s=${p2s.size} materials=${materials.keys.sorted()} cap=$cap")
}
