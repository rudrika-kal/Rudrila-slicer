import com.rudrila.slicer.model.*

private fun s4Square(x0:Float,y0:Float,s:Float):SliceLoop {
    val p=listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s))
    return SliceLoop(p+p.first(),false,0)
}

fun main(){
    val slice=SliceResult(listOf(
        SliceLayer(0,0.2f,listOf(s4Square(-5f,-5f,10f)),emptyList()),
        SliceLayer(1,0.4f,listOf(s4Square(-5f,-5f,10f)),emptyList()),
        SliceLayer(2,0.6f,listOf(s4Square(-5f,-5f,10f)),emptyList()),
        SliceLayer(3,0.8f,listOf(s4Square(-5f,-5f,10f)),emptyList()),
        SliceLayer(4,1.0f,listOf(s4Square(-5f,-5f,10f)),emptyList()),
        SliceLayer(5,1.2f,listOf(s4Square(-10f,-5f,20f)),emptyList()),
        SliceLayer(6,1.4f,listOf(s4Square(-10f,-5f,20f)),emptyList())
    ),1)
    val base=DefaultProfiles.defaultConfiguration()
    val cfg=base.copy(process=base.process.copy(supportEnabled=true,supportStyle="Tree",supportOverhangDeg=50,brimWidthMm=0f,bottomLayers=0,topLayers=0,infillPercent=0))
    for(style in listOf("Normal","Tree / Organic","Hybrid")){
        SupportSettings.styleOverride=style
        SupportSettings.overhangDeg=50
        SupportSettings.interfaceLayers=2
        SupportSettings.buildPlateOnly=false
        val result=ToolpathEngine.plan(slice,cfg)
        val support=result.layers.sumOf{l->l.paths.count{it.role==PathRole.SUPPORT}}
        val iface=result.layers.sumOf{l->l.paths.count{it.role==PathRole.SUPPORT_INTERFACE}}
        check(support>0){"support body missing for $style"}
        check(iface>0){"support interface missing for $style"}
    }
    SupportSettings.styleOverride="Normal"
    SupportSettings.buildPlateOnly=true
    val plateOnly=ToolpathEngine.plan(slice,cfg)
    check(plateOnly.layers.any{l->l.paths.any{it.role==PathRole.SUPPORT||it.role==PathRole.SUPPORT_INTERFACE}})
    println("SUPPORT_V2_TESTS_PASS")
}
