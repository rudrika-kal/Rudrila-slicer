import java.util.Locale
import kotlin.math.abs
import kotlin.random.Random

private fun oldFormat(v: Float): String = String.format(Locale.US, "%.3f", v)

private fun fastFormat(v: Float): String {
    val x = v.toDouble() * 1000.0
    val scaled = (if (x >= 0.0) kotlin.math.floor(x + 0.5) else kotlin.math.ceil(x - 0.5)).toInt()
    if (scaled == 0) return if (v < 0f) "-0.000" else "0.000"
    val negative = scaled < 0
    val a = if (scaled == Int.MIN_VALUE) Int.MAX_VALUE else abs(scaled)
    val whole = a / 1000
    val frac = a % 1000
    return buildString(16) {
        if (negative) append('-')
        append(whole).append('.')
        if (frac < 100) append('0')
        if (frac < 10) append('0')
        append(frac)
    }
}

fun main() {
    val fixed = floatArrayOf(
        -256f, -32.6875f, -5.0625f, -0.00049f, -0.0005f, -0.0015f,
        -1.2345f, -1.2344f, 0f, 0.00049f, 0.0005f, 0.0015f,
        1.2344f, 1.2345f, 255.9999f, 521.6745f
    )
    for (v in fixed) check(oldFormat(v) == fastFormat(v)) { "$v old=${oldFormat(v)} fast=${fastFormat(v)}" }

    val rnd = Random(42)
    repeat(500_000) {
        val v = rnd.nextFloat() * 700f - 100f
        check(oldFormat(v) == fastFormat(v)) { "$v old=${oldFormat(v)} fast=${fastFormat(v)}" }
    }

    val values = FloatArray(250_000) { rnd.nextFloat() * 700f - 100f }
    var sink = 0
    val oldStart = System.nanoTime()
    repeat(2) { for (v in values) sink += oldFormat(v).length }
    val oldMs = (System.nanoTime() - oldStart) / 1e6
    val newStart = System.nanoTime()
    repeat(2) { for (v in values) sink += fastFormat(v).length }
    val newMs = (System.nanoTime() - newStart) / 1e6

    println("GCODE_FORMAT_EQUIVALENCE_PASS samples=500016")
    println("old_ms=$oldMs fast_ms=$newMs speedup=${oldMs / newMs} sink=$sink")
    check(newMs < oldMs)
}
