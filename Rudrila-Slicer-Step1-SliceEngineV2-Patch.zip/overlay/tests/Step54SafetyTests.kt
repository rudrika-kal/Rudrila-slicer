import com.rudrila.slicer.model.*

fun main(){
    val legacy=DefaultProfiles.defaultConfiguration()
    val p2s=PrintConfiguration(
        Step5Profiles.printers.first{it.id=="bambu_p2s_04"},
        Step5Profiles.filaments.first{it.id=="step5_pla"},
        legacy.process
    )
    val path=Toolpath(listOf(Point2(-10f,0f),Point2(10f,0f)),PathRole.WALL,true,0.42f,60f,1f,1500)
    val result=ToolpathResult(
        listOf(
            ToolpathLayer(0,0.24f,0.24f,listOf(path)),
            ToolpathLayer(1,0.44f,0.20f,listOf(path.copy(points=listOf(Point2(-9f,0f),Point2(9f,0f)))))
        ),
        PrintEstimate(38f,6f,0.02f,2)
    )

    val analysis=GCodeSafety.inspect(result,p2s,ExportPurpose.ANALYSIS)
    check(analysis.passed){analysis.details()}
    val printerReady=GCodeSafety.inspect(result,p2s,ExportPurpose.PRINTER_READY)
    check(!printerReady.passed)
    check(printerReady.errors.any{it.contains("P2S native machine start/end")})

    val analysisG=GCodeExporter.generate(result,p2s,ExportPurpose.ANALYSIS)
    check("; DO_NOT_PRINT=ANALYSIS_ONLY" in analysisG)
    check("; safety_status=PASS" in analysisG)
    check(runCatching{buildString{GCodeExporter.write(result,p2s,this,ExportPurpose.PRINTER_READY)}}.isFailure)

    val genericReport=GCodeSafety.inspect(result,legacy,ExportPurpose.PRINTER_READY)
    check(genericReport.passed){genericReport.details()}
    val genericG=GCodeExporter.generate(result,legacy,ExportPurpose.PRINTER_READY)
    check("; export_purpose=PRINTER_READY" in genericG)
    check("; DO_NOT_PRINT=ANALYSIS_ONLY" !in genericG)

    val offBed=ToolpathResult(
        listOf(ToolpathLayer(0,0.2f,0.2f,listOf(path.copy(points=listOf(Point2(-500f,0f),Point2(500f,0f)))))),
        PrintEstimate(1000f,10f,0.1f,10)
    )
    val offBedReport=GCodeSafety.inspect(offBed,legacy,ExportPurpose.PRINTER_READY)
    check(!offBedReport.passed)
    check(offBedReport.errors.any{it.contains("outside the build plate")})

    val p2s02=p2s.copy(printer=Step5Profiles.printers.first{it.id=="bambu_p2s_02"})
    val tall=GCodeSafety.inspect(result,p2s02,ExportPurpose.ANALYSIS)
    check(!tall.passed)
    check(tall.errors.any{it.contains("80% of nozzle diameter")})

    println("STEP54_SAFETY_TESTS_PASS points=${analysis.pointCount} generic=${genericReport.statusLabel}")
}
