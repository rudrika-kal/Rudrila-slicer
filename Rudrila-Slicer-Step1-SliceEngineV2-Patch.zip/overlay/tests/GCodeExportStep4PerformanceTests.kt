import java.util.Locale
import kotlin.math.abs

private fun fastF3(v:Float):String {
    if(!v.isFinite()) return v.toString()
    val scaled = java.lang.Math.round(abs(v.toDouble()) * 1000.0)
    val whole = scaled / 1000L
    val frac = (scaled % 1000L).toInt()
    return buildString(16) {
        if(java.lang.Float.floatToRawIntBits(v) < 0) append('-')
        append(whole).append('.')
        if(frac < 100) append('0')
        if(frac < 10) append('0')
        append(frac)
    }
}

fun main(){
    val edge = floatArrayOf(0f,-0f,0.0004f,-0.0004f,0.0005f,-0.0005f,1.2345f,-1.2345f,255.9995f)
    for(v in edge) check(fastF3(v)==String.format(Locale.US,"%.3f",v)) { "format mismatch $v" }
    val r=java.util.Random(1)
    repeat(1_000_000){
        val v=r.nextFloat()*600f-300f
        check(fastF3(v)==String.format(Locale.US,"%.3f",v)) { "format mismatch $v" }
    }
    println("GCODE_STEP4_FORMAT_EQUIVALENCE_PASS")
}
