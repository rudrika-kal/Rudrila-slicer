import com.rudrila.slicer.model.*

fun main(){
    check(ProfilePolicy.catalogErrors().isEmpty()){ProfilePolicy.catalogErrors().joinToString()}
    val generic=DefaultProfiles.defaultConfiguration()
    val p2s=Step5Profiles.printers.first{it.id=="bambu_p2s_04"}
    val migrated=ProfilePolicy.canonicalize(PrintConfiguration(p2s,DefaultProfiles.filaments.first(),generic.process))
    check(migrated.filament.id=="step5_pla")
    check(ProfilePolicy.canonicalize(generic).filament.id==generic.filament.id)

    val single=Toolpath(listOf(Point2(0f,0f)),PathRole.WALL,true,0.42f,40f,1f,1000)
    val noSegments=ToolpathResult(listOf(ToolpathLayer(0,0.2f,0.2f,listOf(single))),PrintEstimate(0f,0f,0f,0))
    val noSegmentsReport=GCodeSafety.inspect(noSegments,generic,ExportPurpose.PRINTER_READY)
    check(!noSegmentsReport.passed && noSegmentsReport.errors.any{it.contains("No printable extrusion")})

    // Exact preflight tolerance and writer tolerance must agree: this point is 0.0005 mm beyond
    // mathematical X=0 after centering, which preflight accepts and writer clamps to exactly 0.
    val boundaryPath=Toolpath(
        listOf(Point2(-128.0005f,0f),Point2(-127f,0f)),PathRole.WALL,false,0.42f,40f,1f,1000
    )
    val boundary=ToolpathResult(listOf(ToolpathLayer(0,0.2f,0.2f,listOf(boundaryPath))),PrintEstimate(1f,1f,0.01f,1))
    val boundaryReport=GCodeSafety.inspect(boundary,generic,ExportPurpose.PRINTER_READY)
    check(boundaryReport.passed){boundaryReport.details()}
    val boundaryG=GCodeExporter.generate(boundary,generic,ExportPurpose.PRINTER_READY)
    check("X0.000 Y128.000" in boundaryG){"writer did not clamp accepted edge coordinate"}

    val tallPath=Toolpath(listOf(Point2(-1f,0f),Point2(1f,0f)),PathRole.WALL,false,0.42f,40f,1f,1000)
    val tall=ToolpathResult(listOf(ToolpathLayer(0,255.9f,0.2f,listOf(tallPath))),PrintEstimate(2f,1f,0.01f,1))
    val tallReport=GCodeSafety.inspect(tall,generic,ExportPurpose.PRINTER_READY)
    check(tallReport.passed){tallReport.details()}
    val tallG=GCodeExporter.generate(tall,generic,ExportPurpose.PRINTER_READY)
    check("G1 Z256.000" in tallG){"tall print did not clamp park Z to build height"}
    check("G1 Z260" !in tallG && "G1 Z261" !in tallG)

    println("FINAL_AUDIT_MODEL_TESTS_PASS")
}
