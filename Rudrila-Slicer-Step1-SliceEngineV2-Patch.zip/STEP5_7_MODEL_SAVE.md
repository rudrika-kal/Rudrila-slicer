# Step 5.7 — Save edited model to device

Added a top-level SAVE action that is independent of slicing.

- Save current transformed plate as binary STL.
- Save current transformed plate as standard 3MF.
- Move / rotate / scale / lay-face / center / bed / arrange transforms are baked into exported geometry through the same TransformMath path used by slicing.
- Multiple objects are preserved as separate 3MF objects; STL is a single transformed triangle stream.
- Android ACTION_CREATE_DOCUMENT lets the user choose Downloads or another device folder.
- Save is available before or after slicing.
- Support, brim and G-code toolpaths are intentionally not baked into model exports.
- Existing P2S G-code safety gate is unchanged.
- A stale-ticket revision guard prevents saving if the plate changes while the Android file picker is open.

Local exporter regression: PASS (binary STL triangle count/size and zipped 3MF package/XML parsed successfully).
