RUDRILA Slicer - Slice Engine V2.2 contour repair patch

Changes from V2.1:
- Repairs endpoint cracks even when spatial-hash rounding placed near-identical points in neighbouring keys.
- Conservatively bridges disconnected contour fragments up to 0.15 mm when the bridge does not cross existing geometry.
- Treats non-adjacent endpoint touches as touching-shell geometry rather than a self-intersection.
- Still blocks proper X/self crossings, meaningful overlaps, unresolved branches, and larger open gaps.
- Existing walls/top-bottom/infill/gap-fill and G-code safety gate remain active.
