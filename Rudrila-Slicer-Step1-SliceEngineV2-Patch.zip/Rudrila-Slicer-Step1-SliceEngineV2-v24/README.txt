RUDRILA Slicer — Slice Engine V2.4 mobile-memory patch

Purpose
- Fix Android OutOfMemoryError on the exact 3,066,808-triangle Hanuman STL used in phone testing.
- Preserve V2.3 contour-cycle repair and hard geometry safety gate.

Key changes
1. Primitive segment buckets during triangle slicing; no persistent Segment/Point2 object graph per layer hit.
2. One-layer-at-a-time materialization and release.
3. Primitive-backed PackedPointList for final slice contours and toolpaths.
4. Allocation-free toolpath length calculation.
5. V2.3 exact endpoint-cycle repair retained.

Validation
- Exact obj_1_Object_1.stl: 500 layers, 0 blockers.
- V2.3 reproduced OOM at 192 MB heap.
- V2.4 exact contour passes at 160 MB heap.
- V2.4 exact contour + toolpath pipeline passes at 192 MB heap with canExport=true.
- Real 0.20 mm cracks and true self-crossings still block export.
