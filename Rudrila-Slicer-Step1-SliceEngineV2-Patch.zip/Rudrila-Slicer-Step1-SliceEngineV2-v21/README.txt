RUDRILA Slicer — Slice Engine V2.1 auto-repair patch

Adds conservative mesh-contour repair on top of Step 1 V2:
- exact per-layer contour slicing retained
- tiny same-contour gaps up to 0.05 mm can be auto-closed
- tiny dangling spur cleanup
- degree-4 touching-shell vertices can be decomposed into separate simple loops
- true larger gaps remain blocked
- true self-crossing contours remain blocked
- G-code export safety gate remains active for unresolved geometry

Important: auto-heal never globally snaps all nearby geometry. Gap endpoints must already belong to the same connected contour component and the bridge may not cross existing contour edges.
