import com.rudrila.slicer.model.*
import kotlin.math.abs

private fun square(x0:Float,y0:Float,s:Float,hole:Boolean=false,depth:Int=if(hole)1 else 0):SliceLoop{
    var pts=listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s))
    // canonical convention: outer CCW, holes CW
    if(hole)pts=pts.reversed()
    return SliceLoop(pts+pts.first(),hole,depth)
}

private fun tubeMesh():Mesh{
    val v=ArrayList<Float>()
    fun tri(a:FloatArray,b:FloatArray,c:FloatArray){for(p in arrayOf(a,b,c)){v+=p[0];v+=p[1];v+=p[2]}}
    fun wall(a0:FloatArray,b0:FloatArray,a1:FloatArray,b1:FloatArray){tri(a0,b0,b1);tri(a0,b1,a1)}
    val ob=arrayOf(floatArrayOf(0f,0f,0f),floatArrayOf(20f,0f,0f),floatArrayOf(20f,20f,0f),floatArrayOf(0f,20f,0f))
    val ot=ob.map{floatArrayOf(it[0],it[1],20f)}.toTypedArray()
    val ib=arrayOf(floatArrayOf(5f,5f,0f),floatArrayOf(15f,5f,0f),floatArrayOf(15f,15f,0f),floatArrayOf(5f,15f,0f))
    val it=ib.map{floatArrayOf(it[0],it[1],20f)}.toTypedArray()
    for(i in 0..3){val n=(i+1)%4;wall(ob[i],ob[n],ot[i],ot[n]);wall(ib[n],ib[i],it[n],it[i])}
    val arr=v.toFloatArray()
    return Mesh(arr,FloatArray(arr.size),0f,0f,0f,20f,20f,20f)
}

private fun touchingBoxesMesh():Mesh{
    val v=ArrayList<Float>()
    fun tri(a:FloatArray,b:FloatArray,c:FloatArray){for(p in arrayOf(a,b,c)){v+=p[0];v+=p[1];v+=p[2]}}
    fun wall(a0:FloatArray,b0:FloatArray,a1:FloatArray,b1:FloatArray){tri(a0,b0,b1);tri(a0,b1,a1)}
    fun boxWalls(x0:Float,y0:Float,x1:Float,y1:Float){
        val b=arrayOf(floatArrayOf(x0,y0,0f),floatArrayOf(x1,y0,0f),floatArrayOf(x1,y1,0f),floatArrayOf(x0,y1,0f))
        val t=b.map{floatArrayOf(it[0],it[1],20f)}.toTypedArray()
        for(i in 0..3){val n=(i+1)%4;wall(b[i],b[n],t[i],t[n])}
    }
    // The two shells touch at exactly one XY vertex: topologically non-manifold for a slice contour graph.
    boxWalls(0f,0f,10f,10f)
    boxWalls(10f,10f,20f,20f)
    val arr=v.toFloatArray()
    return Mesh(arr,FloatArray(arr.size),0f,0f,0f,20f,20f,20f)
}

private fun crackedBoxMesh(gapMm:Float=0.01f):Mesh{
    val v=ArrayList<Float>()
    fun tri(a:FloatArray,b:FloatArray,c:FloatArray){for(p in arrayOf(a,b,c)){v+=p[0];v+=p[1];v+=p[2]}}
    fun wall(a0:FloatArray,b0:FloatArray,a1:FloatArray,b1:FloatArray){tri(a0,b0,b1);tri(a0,b1,a1)}
    val b=arrayOf(
        floatArrayOf(0f,0f,0f),
        floatArrayOf(20f,0f,0f),
        floatArrayOf(20f,20f,0f),
        floatArrayOf(0f,20f,0f),
        floatArrayOf(0f,gapMm,0f)
    )
    for(i in 0 until 4){
        val a=b[i];val c=b[i+1]
        wall(a,c,floatArrayOf(a[0],a[1],20.1f),floatArrayOf(c[0],c[1],20.1f))
    }
    val arr=v.toFloatArray()
    return Mesh(arr,FloatArray(arr.size),0f,0f,0f,20f,20f,20.1f)
}

private fun bowTieMesh():Mesh{
    val v=ArrayList<Float>()
    fun tri(a:FloatArray,b:FloatArray,c:FloatArray){for(p in arrayOf(a,b,c)){v+=p[0];v+=p[1];v+=p[2]}}
    fun wall(a0:FloatArray,b0:FloatArray,a1:FloatArray,b1:FloatArray){tri(a0,b0,b1);tri(a0,b1,a1)}
    val p=arrayOf(floatArrayOf(0f,0f,0f),floatArrayOf(20f,20f,0f),floatArrayOf(0f,20f,0f),floatArrayOf(20f,0f,0f))
    for(i in 0..3){val n=(i+1)%4;val a=p[i];val b=p[n];wall(a,b,floatArrayOf(a[0],a[1],20f),floatArrayOf(b[0],b[1],20f))}
    val arr=v.toFloatArray()
    return Mesh(arr,FloatArray(arr.size),0f,0f,0f,20f,20f,20f)
}

fun main(){
    val cfg=DefaultProfiles.defaultConfiguration()

    // Contour V2: nested loops are classified and wound deterministically.
    val mesh=tubeMesh()
    val obj=SceneObject(1,"tube",mesh,TransformMath.placedOnBed(mesh,TransformState()))
    val sliced=ContourSlicer.slice(listOf(obj),cfg.process)
    val loops=sliced.layers[10].loops
    check(loops.size==2){"expected outer+hole, got ${loops.size}"}
    val outer=loops.single{!it.isHole};val hole=loops.single{it.isHole}
    check(outer.nestingDepth==0 && hole.nestingDepth==1)
    check(PolygonOps.area(outer.points.dropLast(1))>0f){"outer must be CCW"}
    check(PolygonOps.area(hole.points.dropLast(1))<0f){"hole must be CW"}
    check(sliced.openPathCount==0)

    // Toolpath V2: hole walls must offset toward material, i.e. the hole-side wall grows beyond 10 mm.
    val one=SliceResult(listOf(SliceLayer(0,0.2f,listOf(square(0f,0f,20f),square(5f,5f,10f,true)),emptyList())),1)
    val holeTool=ToolpathEngine.plan(one,cfg.copy(process=cfg.process.copy(bottomLayers=0,topLayers=0,infillPercent=0)))
    val wallBoxes=holeTool.layers[0].paths.filter{it.role==PathRole.WALL}.map{p->
        val w=p.points.maxOf{it.x}-p.points.minOf{it.x};val h=p.points.maxOf{it.y}-p.points.minOf{it.y};w to h
    }
    check(wallBoxes.any{it.first>10f && it.first<15f}){"hole wall did not move toward material: $wallBoxes"}
    check(wallBoxes.any{it.first<20f && it.first>15f}){"outer wall did not inset: $wallBoxes"}

    // Local top-surface test: shoulder layer must contain both solid skin and internal infill.
    val layers=(0 until 12).map{i->
        val loop=if(i<=5)square(0f,0f,20f) else square(5f,5f,10f)
        SliceLayer(i,0.2f+i*0.2f,listOf(loop),emptyList())
    }
    val stepped=SliceResult(layers,1)
    val planned=ToolpathEngine.plan(stepped,cfg.copy(process=cfg.process.copy(supportEnabled=false,brimWidthMm=0f,infillPercent=20)))
    val shoulder=planned.layers[5]
    check(shoulder.paths.any{it.role==PathRole.SOLID}){"shoulder missing local solid skin"}
    check(shoulder.paths.any{it.role==PathRole.INFILL}){"shoulder center should remain infill"}

    // Open contours are a hard G-code export gate, not a cosmetic warning.
    val openSlice=SliceResult(
        listOf(SliceLayer(0,0.2f,listOf(square(0f,0f,20f)),listOf(listOf(Point2(0f,0f),Point2(5f,0f))))),
        1
    )
    val openToolpaths=ToolpathEngine.plan(openSlice,cfg)
    check(!openToolpaths.canExport)
    check(openToolpaths.exportBlockReason?.contains("open contour")==true)
    var openBlocked=false
    try{GCodeExporter.generate(openToolpaths,cfg)}catch(e:IllegalArgumentException){openBlocked=true}
    check(openBlocked){"open contour G-code export must be blocked"}

    // Common STL/numeric cracks below 0.05 mm are auto-healed, but larger real gaps remain blocked.
    val crackedMesh=crackedBoxMesh(0.01f)
    val crackedObj=SceneObject(3,"tiny-crack",crackedMesh,TransformMath.placedOnBed(crackedMesh,TransformState()))
    val crackedSlice=ContourSlicer.slice(listOf(crackedObj),cfg.process)
    check(crackedSlice.diagnostics.tinyGapsHealed>0){"expected tiny crack auto-heal"}
    check(crackedSlice.openPathCount==0){"tiny crack should be healed, open=${crackedSlice.openPathCount}"}
    check(ToolpathEngine.plan(crackedSlice,cfg).canExport){"healed tiny crack should export"}

    val largeGapMesh=crackedBoxMesh(0.20f)
    val largeGapObj=SceneObject(5,"real-gap",largeGapMesh,TransformMath.placedOnBed(largeGapMesh,TransformState()))
    val largeGapSlice=ContourSlicer.slice(listOf(largeGapObj),cfg.process)
    check(largeGapSlice.openPathCount>0){"0.20 mm real gap must remain open"}
    check(largeGapSlice.diagnostics.tinyGapsHealed==0){"large gap must not be silently healed"}
    check(!ToolpathEngine.plan(largeGapSlice,cfg).canExport)

    // A closed bow-tie contour has degree 2 but is still geometrically invalid.
    val bowMesh=bowTieMesh()
    val bowObj=SceneObject(4,"bow",bowMesh,TransformMath.placedOnBed(bowMesh,TransformState()))
    val bowSlice=ContourSlicer.slice(listOf(bowObj),cfg.process)
    check(bowSlice.diagnostics.selfIntersectingLoops>0){"expected self-intersection diagnostic"}
    check(!ToolpathEngine.plan(bowSlice,cfg).canExport)

    // A degree-4 touching-shell vertex that decomposes into two simple rings is repaired safely.
    val touchingMesh=touchingBoxesMesh()
    val touchingObj=SceneObject(2,"touching",touchingMesh,TransformMath.placedOnBed(touchingMesh,TransformState()))
    val touchingSlice=ContourSlicer.slice(listOf(touchingObj),cfg.process)
    check(touchingSlice.diagnostics.touchingVerticesResolved>0){"expected touching vertex repair"}
    check(touchingSlice.diagnostics.nonManifoldVertices==0){"resolved touching branch must not remain a blocker"}
    check(touchingSlice.isWatertightForExport)
    check(ToolpathEngine.plan(touchingSlice,cfg).canExport)

    // Clean manifold slice still exports normally.
    check(holeTool.canExport)
    check(GCodeExporter.generate(holeTool,cfg).contains(";LAYER:0"))

    println("SLICE_ENGINE_V2_1_TESTS_PASS loops=${loops.size} shoulderPaths=${shoulder.paths.size} healed=${crackedSlice.diagnostics.tinyGapsHealed} largeGapOpen=${largeGapSlice.openPathCount} touchingResolved=${touchingSlice.diagnostics.touchingVerticesResolved} selfCross=${bowSlice.diagnostics.selfIntersectingLoops}")
}
