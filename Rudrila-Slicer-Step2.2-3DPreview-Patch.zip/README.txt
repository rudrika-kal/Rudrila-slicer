RUDRILA SLICER — STEP 2.2 3D TOOLPATH PREVIEW

Carries forward the phone-validated Slice Engine V2.4 and Step 2.1 UI, then upgrades Preview from a flat layer viewer to a Bambu-style 3D sliced-model view.

Preview behavior:
- opens in full 3D model mode at the highest layer
- vertical layer slider acts as a cut-height: layers above the selected layer disappear
- selected/cut layer is always drawn at full fidelity and higher contrast
- lower visible layers are stacked at their real Z heights
- one-finger drag orbits the 3D model
- two-finger drag pans; pinch zooms around the gesture focus
- stable full-model camera frame while scrubbing the layer slider
- current-layer exact top view remains available for inspection
- local 3D bed grid gives depth/scale context without shrinking the model to the whole 256 mm bed
- Wall / Skin / Infill / Gap / Support / Interface / Brim colors remain distinct
- Travel can be toggled for the selected layer
- 3D MODEL / LAYER TOP / RESET controls fit the mobile layout
- adaptive layer sampling caps interactive draw load on large slices; the selected layer is never sampled

Slice-engine, geometry gate and G-code exporter files are unchanged.
