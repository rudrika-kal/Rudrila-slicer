RUDRILA SLICER — STEP 2 LAYER PREVIEW

Carries forward Slice Engine V2.4 and adds a mobile Bambu-style toolpath preview:
- vertical layer scrubber (layer 1 at bottom, highest layer at top)
- current-layer toolpath view
- role filtering: walls, skin, gap fill, infill, support, support interface, brim
- optional dashed travel moves
- optional ghosted lower layers
- pinch zoom + drag pan + reset camera
- per-layer Z, layer height, path count, role counts, travel estimate, layer path length, filament length and time
- total layers, filament grams, estimated time and total path count
- responsive preview height for smaller Android screens

Step 1 V2.4 safety and low-memory geometry changes are preserved.
