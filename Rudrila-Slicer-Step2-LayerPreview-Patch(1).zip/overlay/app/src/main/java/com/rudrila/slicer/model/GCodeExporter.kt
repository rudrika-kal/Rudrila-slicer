package com.rudrila.slicer.model

import java.util.Locale
import kotlin.math.PI
import kotlin.math.hypot

object GCodeExporter {
    fun generate(toolpaths:ToolpathResult, config:PrintConfiguration):String = buildString { write(toolpaths,config,this) }

    /** Streams G-code to any Appendable so Android export does not need to keep a huge file in RAM. */
    fun write(toolpaths:ToolpathResult, config:PrintConfiguration, out:Appendable) {
        config.validate()
        require(toolpaths.canExport) {
            toolpaths.exportBlockReason ?: "Slice geometry is not export-safe; repair the model before G-code export"
        }
        fun f(v:Float)=String.format(Locale.US,"%.3f",v)
        fun line(s:String){out.append(s).append('\n')}
        line("; Rudrila Slicer Alpha 0.7")
        line("; printer=${config.printer.name}")
        line("; filament=${config.filament.name}")
        line("; process=${config.process.name}")
        line("; estimated_time_s=${toolpaths.estimate.timeSeconds}")
        line("; filament_mm=${f(toolpaths.estimate.filamentLengthMm)}")
        line("G90 ; absolute XYZ")
        line("M83 ; relative extrusion")
        line("M140 S${config.filament.bedTempC}")
        line("M104 S${config.filament.nozzleTempC}")
        line("G28")
        line("M190 S${config.filament.bedTempC}")
        line("M109 S${config.filament.nozzleTempC}")
        line("G92 E0")
        val filamentArea=(PI*(config.printer.filamentDiameter/2f)*(config.printer.filamentDiameter/2f)).toFloat()
        var last:Point2?=null
        fun machine(p:Point2)=Point2(p.x+config.printer.bedX/2f,p.y+config.printer.bedY/2f)
        fun checkBed(p:Point2){require(p.x in 0f..config.printer.bedX && p.y in 0f..config.printer.bedY) { "Toolpath is outside printer bed" }}
        toolpaths.layers.forEach{layer->
            line(";LAYER:${layer.index}")
            line("G0 Z${f(layer.z)} F900")
            for(path in layer.paths){
                if(path.points.size<2)continue
                val start=path.points.first();val ms=machine(start);checkBed(ms)
                if(last==null || hypot((start.x-last!!.x).toDouble(),(start.y-last!!.y).toDouble())>0.01) line("G0 X${f(ms.x)} Y${f(ms.y)} F9000")
                line(";TYPE:${path.role.name}")
                val feed=(path.speedMmS*60f).toInt().coerceAtLeast(60)
                var prev=start
                for(i in 1 until path.points.size){
                    val cur=path.points[i];val len=hypot((cur.x-prev.x).toDouble(),(cur.y-prev.y).toDouble()).toFloat()
                    val mc=machine(cur);checkBed(mc)
                    if(len>1e-5f){val e=(len*path.widthMm*layer.heightMm)/filamentArea;line("G1 X${f(mc.x)} Y${f(mc.y)} E${f(e)} F$feed")}
                    prev=cur
                }
                last=path.points.last()
            }
        }
        line("M400")
        line("M104 S0")
        line("M140 S0")
        line("G91")
        line("G1 Z5 F600")
        line("G90")
        line("M84")
    }
}
