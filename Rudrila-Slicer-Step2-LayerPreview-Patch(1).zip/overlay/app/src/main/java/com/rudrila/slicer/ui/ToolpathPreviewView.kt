package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.rudrila.slicer.model.PathRole
import com.rudrila.slicer.model.Point2
import com.rudrila.slicer.model.Toolpath
import com.rudrila.slicer.model.ToolpathResult
import kotlin.math.max
import kotlin.math.min

/**
 * Mobile layer preview focused on toolpath inspection rather than model rendering.
 * - one selectable layer at a time
 * - optional faint lower layers
 * - role filters (wall/skin/gap/infill/support/interface/brim)
 * - optional travel moves between extrusion paths
 * - pinch zoom + one-finger pan
 */
class ToolpathPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val bgPaint = Paint().apply { color = Color.rgb(15, 18, 20) }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(48, 55, 59)
        strokeWidth = 1f
        style = Paint.Style.STROKE
    }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(82, 92, 97)
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }
    private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ghostPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.argb(54, 180, 190, 194)
        strokeCap = Paint.Cap.ROUND
    }
    private val travelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.rgb(90, 150, 255)
        pathEffect = DashPathEffect(floatArrayOf(8f, 7f), 0f)
    }

    private var result: ToolpathResult? = null
    private var bedX = 256f
    private var bedY = 256f
    private val visibleRoles = PathRole.values().toMutableSet()

    var showTravel: Boolean = false
        set(value) { field = value; invalidate() }

    var showBelowLayers: Boolean = false
        set(value) { field = value; invalidate() }

    var layerIndex: Int = 0
        set(value) {
            val count = result?.layers?.size ?: 0
            field = if (count == 0) 0 else value.coerceIn(0, count - 1)
            invalidate()
        }

    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private var fitMinX = 0f
    private var fitMinY = 0f
    private var fitMaxX = bedX
    private var fitMaxY = bedY

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val old = zoom
            zoom = (zoom * detector.scaleFactor).coerceIn(0.35f, 12f)
            if (old != zoom) invalidate()
            return true
        }
    })

    fun setBedSize(x: Float, y: Float) {
        bedX = x.coerceAtLeast(1f)
        bedY = y.coerceAtLeast(1f)
        if (result == null) {
            fitMinX = 0f; fitMinY = 0f; fitMaxX = bedX; fitMaxY = bedY
        }
        invalidate()
    }

    fun setResult(value: ToolpathResult) {
        result = value
        layerIndex = layerIndex
        computeFitBounds(value)
        resetCamera()
    }

    fun setRoleVisible(role: PathRole, visible: Boolean) {
        if (visible) visibleRoles += role else visibleRoles -= role
        invalidate()
    }

    fun resetCamera() {
        zoom = 1f
        panX = 0f
        panY = 0f
        invalidate()
    }

    private fun computeFitBounds(value: ToolpathResult) {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        for (layer in value.layers) for (path in layer.paths) for (p in path.points) {
            if (p.x < minX) minX = p.x
            if (p.y < minY) minY = p.y
            if (p.x > maxX) maxX = p.x
            if (p.y > maxY) maxY = p.y
        }
        if (!minX.isFinite() || !minY.isFinite() || !maxX.isFinite() || !maxY.isFinite()) {
            minX = 0f; minY = 0f; maxX = bedX; maxY = bedY
        }
        val w = (maxX - minX).coerceAtLeast(10f)
        val h = (maxY - minY).coerceAtLeast(10f)
        val margin = max(w, h) * 0.08f + 2f
        fitMinX = minX - margin
        fitMinY = minY - margin
        fitMaxX = maxX + margin
        fitMaxY = maxY + margin
    }

    private var drawScale = 1f
    private var drawCxMm = 0f
    private var drawCyMm = 0f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        if (width <= 0 || height <= 0) return

        drawScale = baseScale() * zoom
        drawCxMm = (fitMinX + fitMaxX) * 0.5f
        drawCyMm = (fitMinY + fitMaxY) * 0.5f
        drawGrid(canvas)
        val r = result ?: return
        val current = r.layers.getOrNull(layerIndex) ?: return

        if (showBelowLayers && layerIndex > 0) {
            val stride = max(1, layerIndex / 40)
            var i = 0
            while (i < layerIndex) {
                val layer = r.layers[i]
                for (path in layer.paths) if (path.role in visibleRoles) drawPath(canvas, path, ghostPaint, false)
                i += stride
            }
        }

        var lastEnd: Point2? = null
        for (path in current.paths) {
            if (path.points.size < 2) continue
            if (showTravel) {
                val start = path.points.first()
                val prev = lastEnd
                if (prev != null && distanceSquared(prev, start) > 0.0001f) {
                    drawSegment(canvas, prev, start, travelPaint)
                }
            }
            if (path.role in visibleRoles) {
                pathPaint.color = roleColor(path.role)
                pathPaint.strokeWidth = (path.widthMm * drawScale).coerceIn(1.35f, 7f)
                drawPath(canvas, path, pathPaint, true)
            }
            lastEnd = path.points.last()
        }
    }

    private fun drawGrid(canvas: Canvas) {
        val step = 20f
        var x = 0f
        while (x <= bedX + 0.001f) {
            canvas.drawLine(toScreenX(x), toScreenY(0f), toScreenX(x), toScreenY(bedY), if (x == 0f) axisPaint else gridPaint)
            x += step
        }
        var y = 0f
        while (y <= bedY + 0.001f) {
            canvas.drawLine(toScreenX(0f), toScreenY(y), toScreenX(bedX), toScreenY(y), if (y == 0f) axisPaint else gridPaint)
            y += step
        }
    }

    private fun drawPath(canvas: Canvas, path: Toolpath, paint: Paint, emphasize: Boolean) {
        val pts = path.points
        if (pts.size < 2) return
        var prevX = toScreenX(pts[0].x)
        var prevY = toScreenY(pts[0].y)
        for (i in 1 until pts.size) {
            val p = pts[i]
            val x = toScreenX(p.x)
            val y = toScreenY(p.y)
            canvas.drawLine(prevX, prevY, x, y, paint)
            prevX = x; prevY = y
        }
        if (emphasize && path.closed && pts.size > 2 && distanceSquared(pts.first(), pts.last()) > 0.0001f) {
            canvas.drawLine(prevX, prevY, toScreenX(pts.first().x), toScreenY(pts.first().y), paint)
        }
    }

    private fun drawSegment(canvas: Canvas, a: Point2, b: Point2, paint: Paint) {
        canvas.drawLine(toScreenX(a.x), toScreenY(a.y), toScreenX(b.x), toScreenY(b.y), paint)
    }

    private fun roleColor(role: PathRole): Int = when (role) {
        PathRole.WALL -> Color.rgb(52, 211, 153)
        PathRole.SOLID -> Color.rgb(251, 191, 36)
        PathRole.GAP_FILL -> Color.rgb(244, 114, 182)
        PathRole.INFILL -> Color.rgb(96, 165, 250)
        PathRole.SUPPORT -> Color.rgb(192, 132, 252)
        PathRole.SUPPORT_INTERFACE -> Color.rgb(167, 139, 250)
        PathRole.BRIM -> Color.rgb(156, 163, 175)
    }

    private fun baseScale(): Float {
        val wMm = (fitMaxX - fitMinX).coerceAtLeast(1f)
        val hMm = (fitMaxY - fitMinY).coerceAtLeast(1f)
        return min(width / wMm, height / hMm) * 0.92f
    }

    private fun toScreenX(x: Float): Float = width * 0.5f + (x - drawCxMm) * drawScale + panX
    private fun toScreenY(y: Float): Float = height * 0.5f - (y - drawCyMm) * drawScale + panY

    private fun distanceSquared(a: Point2, b: Point2): Float {
        val dx = a.x - b.x; val dy = a.y - b.y
        return dx * dx + dy * dy
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y; dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && !scaleDetector.isInProgress && event.pointerCount == 1) {
                    panX += event.x - lastX
                    panY += event.y - lastY
                    lastX = event.x; lastY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                dragging = false
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; return true }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
