#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
K="kotlinc"
MODEL=app/src/main/java/com/rudrila/slicer/model
STUBS=(tests/stubs/android/net/Uri.kt tests/stubs/android/content/res/AssetFileDescriptor.kt tests/stubs/android/content/ContentResolver.kt)
runjar(){ local name="$1"; shift; local jar="/tmp/rudrila_${name}.jar"; rm -f "$jar"; "$K" "$@" -include-runtime -d "$jar" >/tmp/${name}_compile.log 2>&1; java -jar "$jar"; }
for pass in 1 2; do
  echo "=== STEP1 VERIFY PASS $pass ==="
  runjar core_${pass} "$MODEL/Mesh.kt" "$MODEL/TransformState.kt" "$MODEL/SceneState.kt" tests/CoreTests.kt
  runjar profile_${pass} "$MODEL/PrintProfiles.kt" tests/ProfileTests.kt
  runjar slice_${pass} "$MODEL/Mesh.kt" "$MODEL/TransformState.kt" "$MODEL/SceneState.kt" "$MODEL/PrintProfiles.kt" "$MODEL/ContourSlicer.kt" tests/SliceTests.kt
  runjar tool_${pass} "$MODEL/Mesh.kt" "$MODEL/TransformState.kt" "$MODEL/SceneState.kt" "$MODEL/PrintProfiles.kt" "$MODEL/ContourSlicer.kt" "$MODEL/ToolpathEngine.kt" "$MODEL/GCodeExporter.kt" tests/ToolpathTests.kt
  runjar v2_${pass} "$MODEL/Mesh.kt" "$MODEL/TransformState.kt" "$MODEL/SceneState.kt" "$MODEL/PrintProfiles.kt" "$MODEL/ContourSlicer.kt" "$MODEL/ToolpathEngine.kt" "$MODEL/GCodeExporter.kt" tests/SliceEngineV2Tests.kt
  runjar preview_${pass} "$MODEL/Mesh.kt" "$MODEL/PreviewMeshBuilder.kt" tests/PreviewMeshTests.kt
  runjar stl_${pass} "${STUBS[@]}" "$MODEL/Mesh.kt" "$MODEL/StlParser.kt" tests/StlParserTests.kt
  runjar threemf_${pass} "${STUBS[@]}" "$MODEL/Mesh.kt" "$MODEL/ThreeMfParser.kt" tests/ThreeMfTests.kt
  echo "=== PASS $pass COMPLETE ==="
done
