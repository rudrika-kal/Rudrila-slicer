import com.rudrila.slicer.model.*
fun main(){
    val c=DefaultProfiles.defaultConfiguration(); c.validate()
    check(c.printer.bedX==256f)
    check(DefaultProfiles.filaments.map{it.material}.containsAll(listOf("PLA","PETG","ABS","TPU")))
    check(DefaultProfiles.processes.all { runCatching{it.validate(c.printer)}.isSuccess })
    val bad=c.process.copy(layerHeightMm=1.0f)
    check(runCatching{bad.validate(c.printer)}.isFailure)
    println("PROFILE_TESTS_PASS")
}
