import com.rudrila.slicer.model.*
import kotlin.math.abs

fun cubeMesh(size:Float=20f):Mesh{
    val p=arrayOf(
        floatArrayOf(0f,0f,0f),floatArrayOf(size,0f,0f),floatArrayOf(size,size,0f),floatArrayOf(0f,size,0f),
        floatArrayOf(0f,0f,size),floatArrayOf(size,0f,size),floatArrayOf(size,size,size),floatArrayOf(0f,size,size)
    )
    val tris=arrayOf(
        intArrayOf(0,2,1),intArrayOf(0,3,2),intArrayOf(4,5,6),intArrayOf(4,6,7),
        intArrayOf(0,1,5),intArrayOf(0,5,4),intArrayOf(1,2,6),intArrayOf(1,6,5),
        intArrayOf(2,3,7),intArrayOf(2,7,6),intArrayOf(3,0,4),intArrayOf(3,4,7)
    )
    val v=FloatArray(tris.size*9);var o=0
    for(t in tris)for(i in t){val q=p[i];v[o++]=q[0];v[o++]=q[1];v[o++]=q[2]}
    return Mesh(v,FloatArray(v.size),0f,0f,0f,size,size,size)
}

fun main(){
    val mesh=cubeMesh()
    val obj=SceneObject(1,"cube",mesh,TransformMath.placedOnBed(mesh,TransformState()))
    val p=DefaultProfiles.processes.first{it.id=="standard_020"}
    val result=ContourSlicer.slice(listOf(obj),p)
    check(result.layerCount==100) { "layers=${result.layerCount}" }
    check(result.openPathCount==0) { "open=${result.openPathCount}" }
    check(result.layers.dropLast(1).all{it.loops.size==1}) { "unexpected loop counts" }
    val loop=result.layers[10].loops.single().points
    val minX=loop.minOf{it.x}; val maxX=loop.maxOf{it.x}; val minY=loop.minOf{it.y}; val maxY=loop.maxOf{it.y}
    check(abs((maxX-minX)-20f)<0.01f)
    check(abs((maxY-minY)-20f)<0.01f)

    val obj2=SceneObject(2,"cube2",mesh,TransformMath.placedOnBed(mesh,TransformState(x=30f)))
    val multi=ContourSlicer.slice(listOf(obj,obj2),p)
    check(multi.layers[10].loops.size==2)

    // Per-axis physical scaling must reach the slicing pipeline, not only the renderer.
    val stretched=SceneObject(3,"stretched",mesh,TransformMath.placedOnBed(mesh,TransformState(scaleX=1.5f,scaleY=0.5f,scaleZ=2f)))
    val nonUniform=ContourSlicer.slice(listOf(stretched),p)
    check(nonUniform.layerCount==200) { "nonuniform layers=${nonUniform.layerCount}" }
    val stretchedLoop=nonUniform.layers[10].loops.single().points
    val sx=stretchedLoop.maxOf{it.x}-stretchedLoop.minOf{it.x}
    val sy=stretchedLoop.maxOf{it.y}-stretchedLoop.minOf{it.y}
    check(abs(sx-30f)<0.01f) { "nonuniform X=$sx" }
    check(abs(sy-10f)<0.01f) { "nonuniform Y=$sy" }
    println("SLICE_TESTS_PASS")
}
