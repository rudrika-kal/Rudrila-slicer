import com.rudrila.slicer.model.*
import kotlin.math.abs

fun cubeMesh(size:Float=20f):Mesh{
    val p=arrayOf(
        floatArrayOf(0f,0f,0f),floatArrayOf(size,0f,0f),floatArrayOf(size,size,0f),floatArrayOf(0f,size,0f),
        floatArrayOf(0f,0f,size),floatArrayOf(size,0f,size),floatArrayOf(size,size,size),floatArrayOf(0f,size,size)
    )
    val tris=arrayOf(
        intArrayOf(0,2,1),intArrayOf(0,3,2),intArrayOf(4,5,6),intArrayOf(4,6,7),
        intArrayOf(0,1,5),intArrayOf(0,5,4),intArrayOf(1,2,6),intArrayOf(1,6,5),
        intArrayOf(2,3,7),intArrayOf(2,7,6),intArrayOf(3,0,4),intArrayOf(3,4,7)
    )
    val v=FloatArray(tris.size*9);var o=0
    for(t in tris)for(i in t){val q=p[i];v[o++]=q[0];v[o++]=q[1];v[o++]=q[2]}
    return Mesh(v,FloatArray(v.size),0f,0f,0f,size,size,size)
}


fun hollowSideMesh(outer:Float=30f, innerMin:Float=10f, innerMax:Float=20f, height:Float=20f):Mesh{
    val tris=mutableListOf<Float>()
    fun quad(ax:Float,ay:Float,bx:Float,by:Float, reverse:Boolean=false){
        val a=floatArrayOf(ax,ay,0f); val b=floatArrayOf(bx,by,0f)
        val c=floatArrayOf(bx,by,height); val d=floatArrayOf(ax,ay,height)
        val order=if(!reverse) arrayOf(a,b,c,a,c,d) else arrayOf(a,c,b,a,d,c)
        for(v in order){tris+=v[0];tris+=v[1];tris+=v[2]}
    }
    quad(0f,0f,outer,0f);quad(outer,0f,outer,outer);quad(outer,outer,0f,outer);quad(0f,outer,0f,0f)
    // Reverse inner wall winding: printable material lies outside this ring.
    quad(innerMin,innerMin,innerMin,innerMax,true);quad(innerMin,innerMax,innerMax,innerMax,true)
    quad(innerMax,innerMax,innerMax,innerMin,true);quad(innerMax,innerMin,innerMin,innerMin,true)
    val v=tris.toFloatArray()
    return Mesh(v,FloatArray(v.size),0f,0f,0f,outer,outer,height)
}

fun signedArea(points:List<Point2>):Float{
    val p=if(points.size>1&&points.first()==points.last())points.dropLast(1)else points
    var a=0f
    for(i in p.indices){val q=p[(i+1)%p.size];a+=p[i].x*q.y-q.x*p[i].y}
    return a*0.5f
}

fun main(){
    val mesh=cubeMesh()
    val obj=SceneObject(1,"cube",mesh,TransformMath.placedOnBed(mesh,TransformState()))
    val p=DefaultProfiles.processes.first{it.id=="standard_020"}
    val result=ContourSlicer.slice(listOf(obj),p)
    check(result.layerCount==100) { "layers=${result.layerCount}" }
    check(result.openPathCount==0) { "open=${result.openPathCount}" }
    check(result.layers.dropLast(1).all{it.loops.size==1}) { "unexpected loop counts" }
    val loop=result.layers[10].loops.single().points
    val minX=loop.minOf{it.x}; val maxX=loop.maxOf{it.x}; val minY=loop.minOf{it.y}; val maxY=loop.maxOf{it.y}
    check(abs((maxX-minX)-20f)<0.01f)
    check(abs((maxY-minY)-20f)<0.01f)

    val obj2=SceneObject(2,"cube2",mesh,TransformMath.placedOnBed(mesh,TransformState(x=30f)))
    val multi=ContourSlicer.slice(listOf(obj,obj2),p)
    check(multi.layers[10].loops.size==2)

    // Per-axis physical scaling must reach the slicing pipeline, not only the renderer.
    val stretched=SceneObject(3,"stretched",mesh,TransformMath.placedOnBed(mesh,TransformState(scaleX=1.5f,scaleY=0.5f,scaleZ=2f)))
    val nonUniform=ContourSlicer.slice(listOf(stretched),p)
    check(nonUniform.layerCount==200) { "nonuniform layers=${nonUniform.layerCount}" }
    val stretchedLoop=nonUniform.layers[10].loops.single().points
    val sx=stretchedLoop.maxOf{it.x}-stretchedLoop.minOf{it.x}
    val sy=stretchedLoop.maxOf{it.y}-stretchedLoop.minOf{it.y}
    check(abs(sx-30f)<0.01f) { "nonuniform X=$sx" }
    check(abs(sy-10f)<0.01f) { "nonuniform Y=$sy" }

    // Slice Engine V2: nested contours must be explicitly classified and orientation-normalized.
    val hollow=hollowSideMesh()
    val hollowObj=SceneObject(4,"hollow",hollow,TransformMath.placedOnBed(hollow,TransformState()))
    val hollowSlice=ContourSlicer.slice(listOf(hollowObj),p)
    val rings=hollowSlice.layers[10].loops
    check(rings.size==2) { "expected outer+hole, got ${rings.size}" }
    check(rings.count{!it.isHole}==1 && rings.count{it.isHole}==1) { "nesting classification failed: ${rings.map{it.nestingDepth}}" }
    val outer=rings.first{!it.isHole}; val hole=rings.first{it.isHole}
    check(signedArea(outer.points)>0f) { "outer not CCW" }
    check(signedArea(hole.points)<0f) { "hole not CW" }
    check(hollowSlice.openPathCount==0) { "hollow open=${hollowSlice.openPathCount}" }
    println("SLICE_TESTS_PASS")
}
