import com.rudrila.slicer.model.*
import kotlin.math.abs

fun toolCube(size:Float=20f):Mesh{
    val p=arrayOf(
        floatArrayOf(0f,0f,0f),floatArrayOf(size,0f,0f),floatArrayOf(size,size,0f),floatArrayOf(0f,size,0f),
        floatArrayOf(0f,0f,size),floatArrayOf(size,0f,size),floatArrayOf(size,size,size),floatArrayOf(0f,size,size)
    )
    val tris=arrayOf(
        intArrayOf(0,2,1),intArrayOf(0,3,2),intArrayOf(4,5,6),intArrayOf(4,6,7),
        intArrayOf(0,1,5),intArrayOf(0,5,4),intArrayOf(1,2,6),intArrayOf(1,6,5),
        intArrayOf(2,3,7),intArrayOf(2,7,6),intArrayOf(3,0,4),intArrayOf(3,4,7)
    )
    val v=FloatArray(tris.size*9);var o=0
    for(t in tris)for(i in t){val q=p[i];v[o++]=q[0];v[o++]=q[1];v[o++]=q[2]}
    return Mesh(v,FloatArray(v.size),0f,0f,0f,size,size,size)
}

fun main(){
    val mesh=toolCube()
    val obj=SceneObject(1,"cube",mesh,TransformMath.placedOnBed(mesh,TransformState()))
    val config=DefaultProfiles.defaultConfiguration()
    val slice=ContourSlicer.slice(listOf(obj),config.process)
    val tool=ToolpathEngine.plan(slice,config)
    check(tool.layers.size==slice.layers.size)
    check(tool.pathCount>300) { "too few paths ${tool.pathCount}" }
    check(tool.layers.first().paths.any{it.role==PathRole.SOLID})
    check(tool.layers.first().paths.count{it.role==PathRole.WALL}>=config.process.wallLoops)
    val mid=tool.layers[50]
    check(mid.paths.any{it.role==PathRole.INFILL})
    check(mid.paths.count{it.role==PathRole.WALL}>=config.process.wallLoops)
    val top=tool.layers.last()
    check(top.paths.any{it.role==PathRole.SOLID})
    check(tool.estimate.filamentLengthMm>0f)
    check(tool.estimate.filamentGrams>0f)
    check(tool.estimate.timeSeconds>0)

    val g=GCodeExporter.generate(tool,config)
    check(g.contains(";LAYER:0"))
    check(g.contains(";TYPE:WALL"))
    check(g.contains(";TYPE:INFILL"))
    check(g.contains("M104 S${config.filament.nozzleTempC}"))
    check(g.contains("M140 S${config.filament.bedTempC}"))
    check(g.lines().count{it.startsWith("G1 X")}>100)
    check(!g.contains("NaN") && !g.contains("Infinity"))
    // Workspace is centered; exporter must translate to machine bed coordinates.
    check(g.lines().filter{it.startsWith("G0 X")||it.startsWith("G1 X")}.none{Regex("X-").containsMatchIn(it)})

    val brimConfig=config.copy(process=config.process.copy(brimWidthMm=3f))
    val brim=ToolpathEngine.plan(slice,brimConfig)
    check(brim.layers.first().paths.any{it.role==PathRole.BRIM})

    // Even/odd fill must preserve holes.
    fun loop(x0:Float,y0:Float,s:Float)=SliceLoop(listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s),Point2(x0,y0)))
    val donutLines=LineFill.generate(listOf(loop(0f,0f,30f),loop(10f,10f,10f)),1.5f,0f)
    check(donutLines.isNotEmpty())
    check(donutLines.none{seg-> val mx=(seg[0].x+seg[1].x)/2f;val my=(seg[0].y+seg[1].y)/2f;mx>10f&&mx<20f&&my>10f&&my<20f}) { "infill crossed hole" }

    // Slice Engine V2: wall offsets must move into printable material on BOTH outer and hole boundaries.
    val outerLoop=SliceLoop(listOf(Point2(0f,0f),Point2(30f,0f),Point2(30f,30f),Point2(0f,30f),Point2(0f,0f)),0)
    val holeLoop=SliceLoop(listOf(Point2(10f,10f),Point2(10f,20f),Point2(20f,20f),Point2(20f,10f),Point2(10f,10f)),1)
    val ringSlice=SliceResult(listOf(SliceLayer(0,0.2f,listOf(outerLoop,holeLoop),emptyList())),1)
    val ringCfg=config.copy(process=config.process.copy(wallLoops=1,topLayers=0,bottomLayers=0,infillPercent=0,brimWidthMm=0f))
    val ringTool=ToolpathEngine.plan(ringSlice,ringCfg)
    val ringWalls=ringTool.layers.single().paths.filter{it.role==PathRole.WALL}
    check(ringWalls.size==2) { "expected two ring walls, got ${ringWalls.size}" }
    val widths=ringWalls.map{w->w.points.maxOf{it.x}-w.points.minOf{it.x}}.sorted()
    check(widths[0]>10f) { "hole wall did not expand into material: ${widths[0]}" }
    check(widths[1]<30f) { "outer wall did not inset: ${widths[1]}" }

    // Volumetric flow cap must limit requested path speed for slow filament.
    val tpuCfg=config.copy(filament=DefaultProfiles.filaments.first{it.material=="TPU"})
    val tpu=ToolpathEngine.plan(slice,tpuCfg)
    val maxExpected=tpuCfg.filament.maxVolumetricSpeedMm3s/(tpuCfg.printer.nozzleDiameter*1.05f*tpuCfg.process.layerHeightMm)
    check(tpu.layers[10].paths.filter{it.role==PathRole.WALL||it.role==PathRole.INFILL}.all{it.speedMmS<=maxExpected+0.01f})

    // Synthetic unsupported island: support planner must place support below it when enabled.
    fun square(x0:Float,y0:Float,s:Float)=SliceLoop(listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s),Point2(x0,y0)))
    val synthetic=SliceResult(listOf(
        SliceLayer(0,0.2f,listOf(square(0f,0f,10f)),emptyList()),
        SliceLayer(1,0.4f,listOf(square(0f,0f,10f)),emptyList()),
        SliceLayer(2,0.6f,listOf(square(20f,0f,10f)),emptyList())
    ),1)
    val supportCfg=config.copy(process=config.process.copy(supportEnabled=true,bottomLayers=0,topLayers=0))
    val supported=ToolpathEngine.plan(synthetic,supportCfg)
    check(supported.layers[0].paths.any{it.role==PathRole.SUPPORT}) { "support missing" }
    check(supported.layers[1].paths.any{it.role==PathRole.SUPPORT}) { "support missing under island" }
    val normalCfg=supportCfg.copy(process=supportCfg.process.copy(supportStyle="Normal"))
    val normal=ToolpathEngine.plan(synthetic,normalCfg)
    check(normal.layers.any{l->l.paths.any{it.role==PathRole.SUPPORT}})

    // Export must refuse known-bad geometry and out-of-bed toolpaths.
    val bad=tool.copy(warningCount=1)
    check(runCatching{GCodeExporter.generate(bad,config)}.isFailure)
    val shiftedObj=SceneObject(2,"far",mesh,TransformMath.placedOnBed(mesh,TransformState(x=300f)))
    val shiftedSlice=ContourSlicer.slice(listOf(shiftedObj),config.process)
    val shiftedTool=ToolpathEngine.plan(shiftedSlice,config)
    check(runCatching{GCodeExporter.generate(shiftedTool,config)}.isFailure)
    println("TOOLPATH_TESTS_PASS paths=${tool.pathCount} filament=${"%.2f".format(tool.estimate.filamentGrams)}g")
}
