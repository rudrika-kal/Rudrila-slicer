import com.rudrila.slicer.model.*
import kotlin.math.abs

fun toolCube(size:Float=20f):Mesh{
    val p=arrayOf(
        floatArrayOf(0f,0f,0f),floatArrayOf(size,0f,0f),floatArrayOf(size,size,0f),floatArrayOf(0f,size,0f),
        floatArrayOf(0f,0f,size),floatArrayOf(size,0f,size),floatArrayOf(size,size,size),floatArrayOf(0f,size,size)
    )
    val tris=arrayOf(
        intArrayOf(0,2,1),intArrayOf(0,3,2),intArrayOf(4,5,6),intArrayOf(4,6,7),
        intArrayOf(0,1,5),intArrayOf(0,5,4),intArrayOf(1,2,6),intArrayOf(1,6,5),
        intArrayOf(2,3,7),intArrayOf(2,7,6),intArrayOf(3,0,4),intArrayOf(3,4,7)
    )
    val v=FloatArray(tris.size*9);var o=0
    for(t in tris)for(i in t){val q=p[i];v[o++]=q[0];v[o++]=q[1];v[o++]=q[2]}
    return Mesh(v,FloatArray(v.size),0f,0f,0f,size,size,size)
}

fun main(){
    val mesh=toolCube()
    val obj=SceneObject(1,"cube",mesh,TransformMath.placedOnBed(mesh,TransformState()))
    val config=DefaultProfiles.defaultConfiguration()
    val slice=ContourSlicer.slice(listOf(obj),config.process)
    val tool=ToolpathEngine.plan(slice,config)
    check(tool.layers.size==slice.layers.size)
    check(tool.pathCount>250) { "too few paths ${tool.pathCount}" }
    check(tool.layers.first().paths.any{it.role==PathRole.BOTTOM_SURFACE})
    check(tool.layers.first().paths.count{it.role==PathRole.OUTER_WALL}>=1)
    check(tool.layers.first().paths.count{it.role==PathRole.INNER_WALL}>=config.process.wallLoops-1)
    val mid=tool.layers[50]
    check(mid.paths.any{it.role==PathRole.INFILL})
    check(mid.paths.any{it.role==PathRole.OUTER_WALL})
    val top=tool.layers.last()
    check(top.paths.any{it.role==PathRole.TOP_SURFACE})
    check(tool.estimate.filamentLengthMm>0f)
    check(tool.estimate.filamentGrams>0f)
    check(tool.estimate.timeSeconds>0)
    check(tool.estimate.travelLengthMm>0f)
    check(mid.travelMoves.isNotEmpty())

    // V2 print phase order: inner wall should be emitted before outer wall when both exist.
    val firstInner=mid.paths.indexOfFirst{it.role==PathRole.INNER_WALL}
    val firstOuter=mid.paths.indexOfFirst{it.role==PathRole.OUTER_WALL}
    check(firstInner in 0 until firstOuter) { "wall order inner=$firstInner outer=$firstOuter" }

    val g=GCodeExporter.generate(tool,config)
    check(g.contains(";LAYER:0"))
    check(g.contains(";TYPE:OUTER_WALL"))
    check(g.contains(";TYPE:INNER_WALL"))
    check(g.contains(";TYPE:INFILL"))
    check(g.contains("M104 S${config.filament.nozzleTempC}"))
    check(g.contains("M140 S${config.filament.bedTempC}"))
    check(g.lines().count{it.startsWith("G1 X")}>100)
    check(!g.contains("NaN") && !g.contains("Infinity"))
    check(g.lines().filter{it.startsWith("G0 X")||it.startsWith("G1 X")}.none{Regex("X-").containsMatchIn(it)})

    val brimConfig=config.copy(process=config.process.copy(brimWidthMm=3f))
    val brim=ToolpathEngine.plan(slice,brimConfig)
    check(brim.layers.first().paths.any{it.role==PathRole.BRIM})

    // Even/odd fill must preserve holes.
    fun loop(x0:Float,y0:Float,s:Float,hole:Boolean=false)=SliceLoop(listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s),Point2(x0,y0)),if(hole)1 else 0,hole)
    val donutLines=LineFill.generate(listOf(loop(0f,0f,30f),loop(10f,10f,10f,true)),1.5f,0f)
    check(donutLines.isNotEmpty())
    check(donutLines.none{seg-> val mx=(seg[0].x+seg[1].x)/2f;val my=(seg[0].y+seg[1].y)/2f;mx>10f&&mx<20f&&my>10f&&my<20f}) { "infill crossed hole" }

    // Hole wall must offset into material, so its toolpath box is larger than the void boundary.
    val donutSlice=SliceResult(List(8){i->SliceLayer(i,0.2f+i*0.2f,listOf(loop(-15f,-15f,30f),loop(-5f,-5f,10f,true)),emptyList())},1)
    val donutTool=ToolpathEngine.plan(donutSlice,config.copy(process=config.process.copy(topLayers=1,bottomLayers=1)))
    val holeOuter=donutTool.layers[3].paths.filter{it.role==PathRole.OUTER_WALL}.minByOrNull{path->
        val xs=path.points.map{it.x};(xs.maxOrNull()!!-xs.minOrNull()!!)
    }?:error("hole wall missing")
    val holeWidth=holeOuter.points.maxOf{it.x}-holeOuter.points.minOf{it.x}
    check(holeWidth>10f) { "hole wall did not offset into material: $holeWidth" }

    // Volumetric flow cap must limit requested path speed for slow filament.
    val tpuCfg=config.copy(filament=DefaultProfiles.filaments.first{it.material=="TPU"})
    val tpu=ToolpathEngine.plan(slice,tpuCfg)
    val maxExpected=tpuCfg.filament.maxVolumetricSpeedMm3s/(tpuCfg.printer.nozzleDiameter*1.05f*tpuCfg.process.layerHeightMm)
    check(tpu.layers[10].paths.filter{it.role in setOf(PathRole.OUTER_WALL,PathRole.INNER_WALL,PathRole.INFILL)}.all{it.speedMmS<=maxExpected+0.01f})

    // Synthetic unsupported island: support planner must place support below it when enabled.
    fun square(x0:Float,y0:Float,s:Float)=SliceLoop(listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s),Point2(x0,y0)))
    val synthetic=SliceResult(listOf(
        SliceLayer(0,0.2f,listOf(square(0f,0f,10f)),emptyList()),
        SliceLayer(1,0.4f,listOf(square(0f,0f,10f)),emptyList()),
        SliceLayer(2,0.6f,listOf(square(20f,0f,10f)),emptyList())
    ),1)
    val supportCfg=config.copy(process=config.process.copy(supportEnabled=true,bottomLayers=0,topLayers=0))
    val supported=ToolpathEngine.plan(synthetic,supportCfg)
    check(supported.layers[0].paths.any{it.role==PathRole.SUPPORT}) { "support missing" }
    check(supported.layers[1].paths.any{it.role==PathRole.SUPPORT}) { "support missing under island" }
    val normalCfg=supportCfg.copy(process=supportCfg.process.copy(supportStyle="Normal"))
    val normal=ToolpathEngine.plan(synthetic,normalCfg)
    check(normal.layers.any{l->l.paths.any{it.role==PathRole.SUPPORT}})

    // Export must refuse known-bad geometry and out-of-bed toolpaths.
    val bad=tool.copy(warningCount=1,warningMessages=listOf("test"))
    check(runCatching{GCodeExporter.generate(bad,config)}.isFailure)
    val shiftedObj=SceneObject(2,"far",mesh,TransformMath.placedOnBed(mesh,TransformState(x=300f)))
    val shiftedSlice=ContourSlicer.slice(listOf(shiftedObj),config.process)
    val shiftedTool=ToolpathEngine.plan(shiftedSlice,config)
    check(runCatching{GCodeExporter.generate(shiftedTool,config)}.isFailure)
    println("TOOLPATH_TESTS_PASS paths=${tool.pathCount} filament=${"%.2f".format(tool.estimate.filamentGrams)}g travel=${"%.1f".format(tool.estimate.travelLengthMm)}mm")
}
