package android.content.res
import java.io.Closeable
open class AssetFileDescriptor(val length: Long): Closeable { override fun close() {} }
