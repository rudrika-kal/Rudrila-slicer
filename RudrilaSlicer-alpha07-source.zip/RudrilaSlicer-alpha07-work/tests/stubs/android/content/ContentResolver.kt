package android.content
import android.net.Uri
import android.content.res.AssetFileDescriptor
import java.io.InputStream
open class ContentResolver {
    open fun openInputStream(uri: Uri): InputStream? = null
    open fun openAssetFileDescriptor(uri: Uri, mode: String): AssetFileDescriptor? = null
}
