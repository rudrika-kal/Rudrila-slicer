package android.content
import android.net.Uri
import java.io.InputStream
open class ContentResolver { open fun openInputStream(uri: Uri): InputStream? = null }
