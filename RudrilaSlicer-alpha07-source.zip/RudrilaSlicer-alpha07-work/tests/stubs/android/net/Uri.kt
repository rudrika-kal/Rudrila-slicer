package android.net
open class Uri
