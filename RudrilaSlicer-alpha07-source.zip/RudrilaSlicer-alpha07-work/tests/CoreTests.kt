import com.rudrila.slicer.model.*
import kotlin.math.abs

fun cube(size: Float = 20f): Mesh {
    val p = arrayOf(
        floatArrayOf(0f,0f,0f), floatArrayOf(size,0f,0f), floatArrayOf(size,size,0f), floatArrayOf(0f,size,0f),
        floatArrayOf(0f,0f,size), floatArrayOf(size,0f,size), floatArrayOf(size,size,size), floatArrayOf(0f,size,size)
    )
    val tris = arrayOf(
        intArrayOf(0,2,1),intArrayOf(0,3,2), // bottom
        intArrayOf(4,5,6),intArrayOf(4,6,7), // top
        intArrayOf(0,1,5),intArrayOf(0,5,4),
        intArrayOf(1,2,6),intArrayOf(1,6,5),
        intArrayOf(2,3,7),intArrayOf(2,7,6),
        intArrayOf(3,0,4),intArrayOf(3,4,7)
    )
    val v=FloatArray(tris.size*9); var o=0
    for(t in tris) for(i in t){ val q=p[i]; v[o++]=q[0];v[o++]=q[1];v[o++]=q[2] }
    val n=FloatArray(v.size)
    return Mesh(v,n,0f,0f,0f,size,size,size)
}

fun main(){
    val m=cube()
    val scene=SceneState()
    val a=scene.add("Cube",m)
    check(scene.size()==1 && scene.selectedId==a.id)
    val b=scene.duplicateSelected()
    check(b!=null && scene.size()==2 && scene.selectedId==b.id)
    check(b!!.name=="Cube (2)")
    scene.select(a.id)
    scene.updateSelected(a.transform.copy(rotationX=37f,rotationY=21f,rotationZ=-13f),placeOnBed=true)
    val rotated=scene.selected()!!
    check(abs(TransformMath.transformedMinZ(m,rotated.transform)) < 0.0005f)

    // Lay a side triangle flat. Selected face should end at bed and all geometry must be on/above bed.
    val laid=TransformMath.layTriangleOnBed(m,TransformState(rotationX=17f,rotationY=-28f,rotationZ=33f),4)
    val faceZ=TransformMath.triangleAverageWorldZ(m,4,laid)
    val bounds=TransformMath.transformedBounds(m,laid)
    check(abs(faceZ) < 0.002f) { "faceZ=$faceZ" }
    check(bounds.minZ >= -0.002f) { "minZ=${bounds.minZ}" }

    // Alpha 0.8 import-centering invariant.
    scene.select(a.id)
    scene.updateSelected(scene.selected()!!.transform.copy(x=75f,y=-40f))
    scene.centerSelected()
    val centered=scene.selected()!!
    check(abs(centered.transform.x)<0.0001f && abs(centered.transform.y)<0.0001f)


    // Physical XYZ dimensions shown in the UI must scale linearly in millimetres.
    scene.select(a.id)
    scene.updateSelected(TransformState(scale=1f))
    val size1=TransformMath.transformedBoxBounds(m,scene.selected()!!.transform)
    check(abs(size1.width-20f)<0.001f && abs(size1.depth-20f)<0.001f && abs(size1.height-20f)<0.001f)
    val ratio=35f/size1.width
    scene.updateSelected(scene.selected()!!.transform.copy(scale=scene.selected()!!.transform.scale*ratio),placeOnBed=true)
    val size2=TransformMath.transformedBoxBounds(m,scene.selected()!!.transform)
    check(abs(size2.width-35f)<0.002f && abs(size2.depth-35f)<0.002f && abs(size2.height-35f)<0.002f)

    scene.select(b.id)
    val removed=scene.deleteSelected()
    check(removed?.id==b.id && scene.size()==1 && scene.selectedId==a.id)
    scene.autoArrange()
    check(scene.selected()!=null)
    println("CORE_TESTS_PASS")
}
