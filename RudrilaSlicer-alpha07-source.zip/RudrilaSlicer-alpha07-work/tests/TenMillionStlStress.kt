import android.content.ContentResolver
import android.content.res.AssetFileDescriptor
import android.net.Uri
import com.rudrila.slicer.model.StlParser
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

private class U: Uri()

private class BinaryStlStream(private val triangles: Int): InputStream() {
    private val total = 84L + triangles.toLong() * 50L
    private var pos = 0L
    private val record = ByteArray(50).also { r ->
        val b = ByteBuffer.wrap(r).order(ByteOrder.LITTLE_ENDIAN)
        // normal
        b.putFloat(0f); b.putFloat(0f); b.putFloat(1f)
        // triangle
        b.putFloat(0f); b.putFloat(0f); b.putFloat(0f)
        b.putFloat(1f); b.putFloat(0f); b.putFloat(0f)
        b.putFloat(0f); b.putFloat(1f); b.putFloat(0f)
        b.putShort(0)
    }
    private val count = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(triangles).array()

    override fun read(): Int {
        val one = ByteArray(1)
        val n = read(one,0,1)
        return if (n < 0) -1 else one[0].toInt() and 0xff
    }

    override fun read(dst: ByteArray, off: Int, len: Int): Int {
        if (pos >= total) return -1
        val n = minOf(len.toLong(), total - pos).toInt()
        var out = off
        val end = pos + n
        while (pos < end) {
            val value: Byte = when {
                pos < 80L -> 0
                pos < 84L -> count[(pos - 80L).toInt()]
                else -> record[((pos - 84L) % 50L).toInt()]
            }
            dst[out++] = value
            pos++
        }
        return n
    }
}

private class R(private val triangles:Int): ContentResolver() {
    override fun openInputStream(uri: Uri): InputStream = BinaryStlStream(triangles)
    override fun openAssetFileDescriptor(uri: Uri, mode: String) = AssetFileDescriptor(-1L)
}

fun main() {
    val n=10_000_000
    val start=System.nanoTime()
    val mesh=StlParser.parse(R(n), U())
    val seconds=(System.nanoTime()-start)/1e9
    check(mesh.vertexCount == n*3) { "vertex count ${mesh.vertexCount}" }
    check(mesh.minX == 0f && mesh.maxX == 1f && mesh.minY == 0f && mesh.maxY == 1f)
    println("TEN_MILLION_STL_PASS vertices=${mesh.vertexCount} seconds=%.2f".format(seconds))
}
