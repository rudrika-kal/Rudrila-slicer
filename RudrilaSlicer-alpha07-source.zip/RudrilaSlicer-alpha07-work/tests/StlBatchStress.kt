import com.rudrila.slicer.model.*
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

private fun loadBinary(path:String):Mesh{
    DataInputStream(BufferedInputStream(FileInputStream(path),1024*1024)).use { input ->
        val h=ByteArray(80);input.readFully(h);val cb=ByteArray(4);input.readFully(cb)
        val n=ByteBuffer.wrap(cb).order(ByteOrder.LITTLE_ENDIAN).int
        val v=FloatArray(n*9);val rec=ByteArray(50);val b=ByteBuffer.wrap(rec).order(ByteOrder.LITTLE_ENDIAN);var o=0
        var minX=Float.POSITIVE_INFINITY;var minY=Float.POSITIVE_INFINITY;var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY;var maxY=Float.NEGATIVE_INFINITY;var maxZ=Float.NEGATIVE_INFINITY
        repeat(n){input.readFully(rec);b.position(12);repeat(3){val x=b.float;val y=b.float;val z=b.float;v[o++]=x;v[o++]=y;v[o++]=z;minX=min(minX,x);minY=min(minY,y);minZ=min(minZ,z);maxX=max(maxX,x);maxY=max(maxY,y);maxZ=max(maxZ,z)}}
        return Mesh(v,FloatArray(0),minX,minY,minZ,maxX,maxY,maxZ)
    }
}
fun main(args:Array<String>){
    check(args.isNotEmpty())
    val cfg=DefaultProfiles.defaultConfiguration()
    for(path in args){
        val m=loadBinary(path);val tri=m.vertexCount/3
        val obj=SceneObject(1,path.substringAfterLast('/'),m,TransformState())
        val p=ToolpathEngine.planScene(listOf(obj),cfg)
        check(p.layerCount>0);check(p.toolpaths.pathCount>0)
        println("STL_PASS ${path.substringAfterLast('/')} triangles=$tri layers=${p.layerCount} paths=${p.toolpaths.pathCount}")
    }
    println("STL_BATCH_PASS count=${args.size}")
}
