import com.rudrila.slicer.model.*
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

private fun loadBinaryStl(path:String):Mesh{
    DataInputStream(BufferedInputStream(FileInputStream(path),1024*1024)).use { input ->
        val header=ByteArray(80);input.readFully(header)
        val cb=ByteArray(4);input.readFully(cb)
        val n=ByteBuffer.wrap(cb).order(ByteOrder.LITTLE_ENDIAN).int
        val vertices=FloatArray(n*9)
        val rec=ByteArray(50);val b=ByteBuffer.wrap(rec).order(ByteOrder.LITTLE_ENDIAN)
        var o=0
        var minX=Float.POSITIVE_INFINITY;var minY=Float.POSITIVE_INFINITY;var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY;var maxY=Float.NEGATIVE_INFINITY;var maxZ=Float.NEGATIVE_INFINITY
        repeat(n){
            input.readFully(rec);b.position(12)
            repeat(3){
                val x=b.float;val y=b.float;val z=b.float
                vertices[o++]=x;vertices[o++]=y;vertices[o++]=z
                minX=min(minX,x);minY=min(minY,y);minZ=min(minZ,z)
                maxX=max(maxX,x);maxY=max(maxY,y);maxZ=max(maxZ,z)
            }
        }
        return Mesh(vertices,FloatArray(0),minX,minY,minZ,maxX,maxY,maxZ)
    }
}

fun main(args:Array<String>){
    val path=args.firstOrNull()?:error("path required")
    val mesh=loadBinaryStl(path)
    check(mesh.vertexCount/3==3_066_808){"triangles=${mesh.vertexCount/3}"}
    val obj=SceneObject(1,"stress",mesh,TransformState())
    val config=DefaultProfiles.defaultConfiguration()
    var last=0
    val start=System.nanoTime()
    val planned=ToolpathEngine.planScene(listOf(obj),config){done,total->if(done==total||done-last>=100){println("PROGRESS $done/$total");last=done}}
    val sec=(System.nanoTime()-start)/1_000_000_000.0
    check(planned.layerCount==500){"layers=${planned.layerCount}"}
    check(planned.toolpaths.layers.size==500)
    check(planned.toolpaths.pathCount>0)
    check(planned.toolpaths.estimate.filamentGrams>0f)
    println("LARGE_STRESS_PASS layers=${planned.layerCount} paths=${planned.toolpaths.pathCount} grams=${planned.toolpaths.estimate.filamentGrams} sec=${"%.1f".format(sec)}")
}
