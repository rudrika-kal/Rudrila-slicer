import android.content.ContentResolver
import android.content.res.AssetFileDescriptor
import android.net.Uri
import com.rudrila.slicer.model.StlParser
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

private class StlTestUri: Uri()
private class StlBytesResolver(private val data: ByteArray, private val reportedLength: Long = -1L): ContentResolver() {
    override fun openInputStream(uri: Uri) = ByteArrayInputStream(data)
    override fun openAssetFileDescriptor(uri: Uri, mode: String) = AssetFileDescriptor(reportedLength)
}

private fun oneTriangleBinary(headerText: String = "binary"): ByteArray {
    val out = ByteArray(84 + 50)
    val header = headerText.toByteArray(Charsets.US_ASCII)
    header.copyInto(out, 0, 0, minOf(80, header.size))
    ByteBuffer.wrap(out, 80, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(1)
    val b = ByteBuffer.wrap(out, 84, 50).order(ByteOrder.LITTLE_ENDIAN)
    b.putFloat(0f); b.putFloat(0f); b.putFloat(1f)
    b.putFloat(0f); b.putFloat(0f); b.putFloat(0f)
    b.putFloat(1f); b.putFloat(0f); b.putFloat(0f)
    b.putFloat(0f); b.putFloat(1f); b.putFloat(0f)
    b.putShort(0)
    return out
}

fun main() {
    val uri = StlTestUri()

    // SAF length unknown: valid binary STL must still import.
    check(StlParser.parse(StlBytesResolver(oneTriangleBinary(), -1L), uri).vertexCount == 3)

    // Binary STL is legally allowed to start with "solid".
    check(StlParser.parse(StlBytesResolver(oneTriangleBinary("solid sneaky binary"), -1L), uri).vertexCount == 3)

    // Exact provider length remains a definitive binary signal.
    val exact = oneTriangleBinary()
    check(StlParser.parse(StlBytesResolver(exact, exact.size.toLong()), uri).vertexCount == 3)

    // Normal ASCII STL must remain supported.
    val ascii = """solid x
facet normal 0 0 1
 outer loop
  vertex 0 0 0
  vertex 1 0 0
  vertex 0 1 0
 endloop
endfacet
endsolid x
""".toByteArray()
    check(StlParser.parse(StlBytesResolver(ascii, -1L), uri).vertexCount == 3)

    // Dense binary STL must report the real mobile-size issue, never "Invalid ASCII STL".
    val dense = ByteArray(84)
    ByteBuffer.wrap(dense, 80, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(10_000_001)
    val error = runCatching { StlParser.parse(StlBytesResolver(dense, -1L), uri) }.exceptionOrNull()
    check(error is IllegalArgumentException && error.message?.contains("too large") == true) {
        "wrong dense-binary error: $error"
    }

    println("STL_PARSER_TESTS_PASS")
}
