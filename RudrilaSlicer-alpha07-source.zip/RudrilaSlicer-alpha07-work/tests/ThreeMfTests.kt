import com.rudrila.slicer.model.ThreeMfParser
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs

fun make3mf(): ByteArray {
    val xml = """<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">
<resources>
<object id="1" name="A"><mesh><vertices>
<vertex x="0" y="0" z="0"/><vertex x="10" y="0" z="0"/><vertex x="0" y="10" z="0"/>
</vertices><triangles><triangle v1="0" v2="1" v3="2"/></triangles></mesh></object>
<object id="2" name="B"><mesh><vertices>
<vertex x="0" y="0" z="0"/><vertex x="5" y="0" z="0"/><vertex x="0" y="5" z="0"/>
</vertices><triangles><triangle v1="0" v2="1" v3="2"/></triangles></mesh></object>
</resources>
<build><item objectid="1"/><item objectid="2" transform="1 0 0 0 1 0 0 0 1 20 30 0"/></build>
</model>""".trimIndent()
    val out=ByteArrayOutputStream()
    ZipOutputStream(out).use { z -> z.putNextEntry(ZipEntry("3D/3dmodel.model")); z.write(xml.toByteArray()); z.closeEntry() }
    return out.toByteArray()
}
fun main(){
    val parts=ThreeMfParser.parseParts(ByteArrayInputStream(make3mf()))
    check(parts.size==2)
    check(parts[0].name=="A" && parts[1].name=="B")
    check(abs(parts[1].mesh.minX-20f)<0.0001f) { "minX=${parts[1].mesh.minX}" }
    check(abs(parts[1].mesh.minY-30f)<0.0001f) { "minY=${parts[1].mesh.minY}" }
    println("THREEMF_TESTS_PASS")
}
