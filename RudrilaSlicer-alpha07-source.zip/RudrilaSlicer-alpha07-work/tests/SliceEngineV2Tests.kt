import com.rudrila.slicer.model.*
import kotlin.math.abs

private fun square(x0:Float,y0:Float,s:Float,hole:Boolean=false,depth:Int=if(hole)1 else 0):SliceLoop{
    var pts=listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s))
    // canonical convention: outer CCW, holes CW
    if(hole)pts=pts.reversed()
    return SliceLoop(pts+pts.first(),hole,depth)
}

private fun tubeMesh():Mesh{
    val v=ArrayList<Float>()
    fun tri(a:FloatArray,b:FloatArray,c:FloatArray){for(p in arrayOf(a,b,c)){v+=p[0];v+=p[1];v+=p[2]}}
    fun wall(a0:FloatArray,b0:FloatArray,a1:FloatArray,b1:FloatArray){tri(a0,b0,b1);tri(a0,b1,a1)}
    val ob=arrayOf(floatArrayOf(0f,0f,0f),floatArrayOf(20f,0f,0f),floatArrayOf(20f,20f,0f),floatArrayOf(0f,20f,0f))
    val ot=ob.map{floatArrayOf(it[0],it[1],20f)}.toTypedArray()
    val ib=arrayOf(floatArrayOf(5f,5f,0f),floatArrayOf(15f,5f,0f),floatArrayOf(15f,15f,0f),floatArrayOf(5f,15f,0f))
    val it=ib.map{floatArrayOf(it[0],it[1],20f)}.toTypedArray()
    for(i in 0..3){val n=(i+1)%4;wall(ob[i],ob[n],ot[i],ot[n]);wall(ib[n],ib[i],it[n],it[i])}
    val arr=v.toFloatArray()
    return Mesh(arr,FloatArray(arr.size),0f,0f,0f,20f,20f,20f)
}

fun main(){
    val cfg=DefaultProfiles.defaultConfiguration()

    // Contour V2: nested loops are classified and wound deterministically.
    val mesh=tubeMesh()
    val obj=SceneObject(1,"tube",mesh,TransformMath.placedOnBed(mesh,TransformState()))
    val sliced=ContourSlicer.slice(listOf(obj),cfg.process)
    val loops=sliced.layers[10].loops
    check(loops.size==2){"expected outer+hole, got ${loops.size}"}
    val outer=loops.single{!it.isHole};val hole=loops.single{it.isHole}
    check(outer.nestingDepth==0 && hole.nestingDepth==1)
    check(PolygonOps.area(outer.points.dropLast(1))>0f){"outer must be CCW"}
    check(PolygonOps.area(hole.points.dropLast(1))<0f){"hole must be CW"}
    check(sliced.openPathCount==0)

    // Toolpath V2: hole walls must offset toward material, i.e. the hole-side wall grows beyond 10 mm.
    val one=SliceResult(listOf(SliceLayer(0,0.2f,listOf(square(0f,0f,20f),square(5f,5f,10f,true)),emptyList())),1)
    val holeTool=ToolpathEngine.plan(one,cfg.copy(process=cfg.process.copy(bottomLayers=0,topLayers=0,infillPercent=0)))
    val wallBoxes=holeTool.layers[0].paths.filter{it.role==PathRole.WALL}.map{p->
        val w=p.points.maxOf{it.x}-p.points.minOf{it.x};val h=p.points.maxOf{it.y}-p.points.minOf{it.y};w to h
    }
    check(wallBoxes.any{it.first>10f && it.first<15f}){"hole wall did not move toward material: $wallBoxes"}
    check(wallBoxes.any{it.first<20f && it.first>15f}){"outer wall did not inset: $wallBoxes"}

    // Local top-surface test: shoulder layer must contain both solid skin and internal infill.
    val layers=(0 until 12).map{i->
        val loop=if(i<=5)square(0f,0f,20f) else square(5f,5f,10f)
        SliceLayer(i,0.2f+i*0.2f,listOf(loop),emptyList())
    }
    val stepped=SliceResult(layers,1)
    val planned=ToolpathEngine.plan(stepped,cfg.copy(process=cfg.process.copy(supportEnabled=false,brimWidthMm=0f,infillPercent=20)))
    val shoulder=planned.layers[5]
    check(shoulder.paths.any{it.role==PathRole.SOLID}){"shoulder missing local solid skin"}
    check(shoulder.paths.any{it.role==PathRole.INFILL}){"shoulder center should remain infill"}

    // Warnings remain an explicit export gate.
    check(!planned.copy(warningCount=1).canExport)

    println("SLICE_ENGINE_V2_TESTS_PASS loops=${loops.size} shoulderPaths=${shoulder.paths.size}")
}
