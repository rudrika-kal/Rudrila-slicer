import com.rudrila.slicer.model.*
import kotlin.math.abs

private fun ringWallMesh(outer:Float=30f,inner:Float=10f,height:Float=20f):Mesh{
    val o=outer/2f; val i=inner/2f
    val outerPts=arrayOf(floatArrayOf(-o,-o),floatArrayOf(o,-o),floatArrayOf(o,o),floatArrayOf(-o,o))
    val innerPts=arrayOf(floatArrayOf(-i,-i),floatArrayOf(-i,i),floatArrayOf(i,i),floatArrayOf(i,-i)) // CW viewed from +Z
    val verts=ArrayList<Float>()
    fun tri(a:FloatArray,b:FloatArray,c:FloatArray,z0:Float,z1:Float,z2:Float){
        verts += a[0];verts += a[1];verts += z0
        verts += b[0];verts += b[1];verts += z1
        verts += c[0];verts += c[1];verts += z2
    }
    fun walls(points:Array<FloatArray>){
        for(k in points.indices){
            val a=points[k];val b=points[(k+1)%points.size]
            tri(a,b,b,0f,0f,height)
            tri(a,b,a,0f,height,height)
        }
    }
    walls(outerPts);walls(innerPts)
    val v=verts.toFloatArray()
    return Mesh(v,FloatArray(v.size),-o,-o,0f,o,o,height)
}

private fun square(x0:Float,y0:Float,s:Float,hole:Boolean=false)=SliceLoop(
    listOf(Point2(x0,y0),Point2(x0+s,y0),Point2(x0+s,y0+s),Point2(x0,y0+s),Point2(x0,y0)),
    if(hole)1 else 0,hole
)

fun main(){
    val process=DefaultProfiles.processes.first{it.id=="standard_020"}
    val ring=ringWallMesh()
    val obj=SceneObject(1,"ring",ring,TransformMath.placedOnBed(ring,TransformState()))
    val ringSlice=ContourSlicer.slice(listOf(obj),process)
    val mid=ringSlice.layers[20]
    check(mid.openPaths.isEmpty()) { "ring open contours=${mid.openPaths.size}" }
    check(mid.loops.size==2) { "ring loops=${mid.loops.size}" }
    check(mid.loops.count{it.isHole}==1) { "hole classification failed ${mid.loops.map{it.isHole}}" }
    val outer=mid.loops.first{!it.isHole};val hole=mid.loops.first{it.isHole}
    check(PolygonOps.area(outer.points)>0f) { "outer winding not CCW" }
    check(PolygonOps.area(hole.points)<0f) { "hole winding not CW" }

    // Duplicate facets must not erase valid contours.
    val dupVerts=FloatArray(ring.vertices.size*2)
    ring.vertices.copyInto(dupVerts,0);ring.vertices.copyInto(dupVerts,ring.vertices.size)
    val dup=Mesh(dupVerts,FloatArray(dupVerts.size),ring.minX,ring.minY,ring.minZ,ring.maxX,ring.maxY,ring.maxZ)
    val dupSlice=ContourSlicer.slice(listOf(SceneObject(2,"dup",dup,TransformMath.placedOnBed(dup,TransformState()))),process)
    check(dupSlice.layers[20].loops.size==2) { "duplicate facets erased contour" }
    check(dupSlice.layers[20].openPaths.isEmpty())

    // Local top-surface detection: a wide lower body transitions to a narrow tower.
    val layers=mutableListOf<SliceLayer>()
    repeat(5){i->layers+=SliceLayer(i,0.2f+i*0.2f,listOf(square(-15f,-15f,30f)),emptyList())}
    repeat(5){j->val i=j+5;layers+=SliceLayer(i,0.2f+i*0.2f,listOf(square(-5f,-5f,10f)),emptyList())}
    val synthetic=SliceResult(layers,1)
    val cfg=DefaultProfiles.defaultConfiguration().copy(process=process.copy(wallLoops=2,topLayers=2,bottomLayers=2,infillPercent=20))
    val tool=ToolpathEngine.plan(synthetic,cfg)
    val transition=tool.layers[4]
    check(transition.paths.any{it.role==PathRole.TOP_SURFACE}) { "local top skin missing" }
    check(transition.paths.any{it.role==PathRole.INFILL}) { "covered center should remain infill" }
    val topOutside=transition.paths.filter{it.role==PathRole.TOP_SURFACE}.any{path->path.points.any{abs(it.x)>6f||abs(it.y)>6f}}
    check(topOutside) { "top skin not present on exposed shoulder" }
    val infillPaths=transition.paths.filter{it.role==PathRole.INFILL}
    val centerInfill=infillPaths.any{path->
        val a=path.points.first();val b=path.points.last();val mx=(a.x+b.x)/2f;val my=(a.y+b.y)/2f
        abs(mx)<4f&&abs(my)<4f
    }
    check(centerInfill) { "covered center should remain sparse infill" }

    // Very narrow material that cannot fit requested walls must get gap fill rather than an empty core.
    val narrow=SliceResult(List(4){i->SliceLayer(i,0.2f+i*0.2f,listOf(square(-0.6f,-5f,1.2f)),emptyList())},1)
    val narrowTool=ToolpathEngine.plan(narrow,cfg.copy(process=cfg.process.copy(wallLoops=3,topLayers=0,bottomLayers=0,infillPercent=0)))
    check(narrowTool.layers.any{layer->layer.paths.any{it.role==PathRole.GAP_FILL}}) { "gap-fill fallback missing" }

    // Preview foundation includes non-extruding travel separately from extrusion paths.
    check(tool.layers.any{it.travelMoves.isNotEmpty()})
    check(tool.estimate.travelLengthMm>0f)
    println("SLICE_ENGINE_V2_TESTS_PASS ringHoles=${ringSlice.holeCount} paths=${tool.pathCount}")
}
