import com.rudrila.slicer.model.Mesh
import com.rudrila.slicer.model.PreviewMeshBuilder
import kotlin.math.abs

private fun gridMesh(nx:Int, ny:Int): Mesh {
    val verts=FloatArray(nx*ny*2*9)
    var o=0
    for(y in 0 until ny) for(x in 0 until nx){
        val x0=x.toFloat(); val x1=(x+1).toFloat(); val y0=y.toFloat(); val y1=(y+1).toFloat()
        val z00=((x+y)%7)*0.01f; val z10=((x+1+y)%7)*0.01f; val z01=((x+y+1)%7)*0.01f; val z11=((x+y+2)%7)*0.01f
        val tri=floatArrayOf(x0,y0,z00, x1,y0,z10, x1,y1,z11, x0,y0,z00, x1,y1,z11, x0,y1,z01)
        tri.copyInto(verts,o);o+=18
    }
    return Mesh(verts,FloatArray(0),0f,0f,0f,nx.toFloat(),ny.toFloat(),0.06f)
}

fun main(){
    val tiny=gridMesh(4,4)
    val exact=PreviewMeshBuilder.build(tiny,maxPreviewTriangles=1000,exactTriangleLimit=1000)
    check(!exact.simplified)
    check(exact.triangleCount==32)
    check(exact.normals.limit()==exact.vertices.limit())

    val dense=gridMesh(180,180) // 64,800 triangles
    val simplified=PreviewMeshBuilder.build(dense,maxPreviewTriangles=12_000,exactTriangleLimit=1_000)
    check(simplified.simplified)
    check(simplified.triangleCount in 1..12_000)
    check(simplified.normals.limit()==simplified.vertices.limit())
    check(simplified.gridResolution>0)
    val b=simplified.vertices.duplicate(); b.position(0)
    var minX=Float.POSITIVE_INFINITY;var maxX=Float.NEGATIVE_INFINITY
    var minY=Float.POSITIVE_INFINITY;var maxY=Float.NEGATIVE_INFINITY
    while(b.remaining()>=3){val x=b.get();val y=b.get();b.get();if(x<minX)minX=x;if(x>maxX)maxX=x;if(y<minY)minY=y;if(y>maxY)maxY=y}
    check(minX<=0.01f && maxX>=179f)
    check(minY<=0.01f && maxY>=179f)
    val n=simplified.normals.duplicate(); n.position(0)
    var checked=0
    while(n.remaining()>=3 && checked<1000){
        val nx=n.get();val ny=n.get();val nz=n.get();val len=kotlin.math.sqrt(nx*nx+ny*ny+nz*nz)
        check(len in 0.98f..1.02f)
        checked++
    }
    println("PASS preview mesh exact=${exact.triangleCount} simplified=${simplified.triangleCount} grid=${simplified.gridResolution} smoothNormals=$checked")
}
