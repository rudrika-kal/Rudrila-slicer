# Alpha 0.11 quality gates

A build is not considered ready until both passes complete.

1. Kotlin compile gate for renderer + touch interaction (Android stubs) x2.
2. Core/Profile/Slice/3MF/Toolpath tests x2.
3. Five STL sizes/shapes x2.
4. Exact user 3,066,808-triangle STL slicing under 256MB Java heap x2.
5. GitHub Android build Pass 1 + Verify, clean rebuild Pass 2 + Verify.
6. Real-device gate: app launches, imported mesh renders as a continuous solid surface, touch-drag moves it, then Slice and Preview are checked.

Note: local JVM tests cannot prove GPU-driver behavior on the user's Android device. The real-device gate remains mandatory before calling the release final.
