# Rudrila Slicer quality gates

Every milestone must pass two checks before being called complete.

## Gate A — engineering check
- Compiles without errors/warnings that affect correctness
- Core geometry/parser unit tests pass
- Invalid/corrupt input fails safely
- Large allocations are bounded
- No model transform may silently move geometry below Z=0 after Place on Bed

## Gate B — user-flow check
- App can complete the feature from touch UI without hidden steps
- Back/cancel paths work
- State shown to the user matches internal state
- No destructive action without an obvious recovery path once undo/redo is added
- Performance remains interactive on a representative phone

## Release-only gates
- Signed release APK
- Clean install + upgrade test
- At least two real Android devices
- Real STL and 3MF corpus
- Compare slices against a trusted desktop slicer before enabling G-code export for real printing

## Alpha 0.4 gates
- [x] Scene add/select/duplicate/delete tested twice with JVM core test.
- [x] Arbitrary rotation + place-on-bed tested twice.
- [x] Triangle lay-on-face produces selected face at Z≈0 and keeps mesh above bed; tested twice.
- [x] 3MF direct multi-object import preserves separate objects; tested twice.
- [x] 3MF build-item translation transform baked into geometry; tested twice.
- [ ] Android APK compile/install test: pending Android SDK/build runner.
- [ ] Real-device GPU/touch test: pending physical Android install.

## Alpha 0.5 gates
- [x] Generic printer/filament/process profile validation tested twice.
- [x] Profile choices are persisted locally through SharedPreferences.
- [x] Current toolchain versions re-verified: AGP 9.4.0 / Gradle 9.6 / Kotlin 2.4.20.
- [ ] Full Android compile: blocked only by missing Android SDK/build runner in this execution environment.

## Alpha 0.6 gates
- [x] Geometry contour slicer added (triangle/plane intersections + segment stitching).
- [x] 20 mm cube at 0.20 mm process produces 100 layers; tested twice.
- [x] Cube contour has correct 20 × 20 mm bounds and no open paths; tested twice.
- [x] Two separated cubes produce two closed contours on the same layer; tested twice.
- [x] Floating-point layer-count boundary bug found during first check and fixed before packaging.
- [ ] Perimeters/infill/support toolpaths: not implemented yet.
- [ ] G-code generation: not implemented yet.
- [ ] Full Android APK compile/install: pending Android SDK/build runner.

## Alpha 0.7 gates
- [x] Perimeter/wall path generation added and verified on deterministic cube geometry; tested twice.
- [x] Bottom/top solid skin added; exact-top floating-point boundary regression found and fixed.
- [x] Even/odd infill clipping preserves holes; tested twice.
- [x] Normal + tree-support foundation added with adaptive memory-bounded raster; tested twice.
- [x] Brim generation added; tested twice.
- [x] Filament volumetric-flow speed cap added and tested with low-flow TPU profile.
- [x] Extrusion, filament grams/length and time estimate added; tested twice.
- [x] Mobile layer preview UI + slider added; source syntax parse checked (full Android compile still pending SDK).
- [x] G-code export added with streaming writer, bed-coordinate conversion and bed-boundary guard; tested twice.
- [x] Open contours block G-code export; tested twice.
- [x] Geometry/profile edits invalidate stale slice/toolpath data before preview/export.
- [ ] Full Android APK compile/install: pending Android SDK/build runner.
- [ ] Real printer G-code validation: pending device-specific profile and comparison against trusted desktop slicer.

## Alpha 0.8.4: 10M-triangle STL import gate
- Binary STL import cap: 10,000,000 triangles.
- Exact binary mesh keeps XYZ only (~360 MB at 10M triangles); file normals are not duplicated.
- Binary parser writes directly into the final vertex array to avoid 10M temporary per-triangle arrays / GC churn.
- OpenGL preview remains sampled/bounded to 250,000 triangles; exact geometry stays available to model operations.
- Import no longer performs a redundant second full-mesh place-on-bed scan after centering.
- `android:largeHeap=true` remains required for multi-million-triangle exact meshes. Actual success still depends on device heap capacity; low-memory devices can reject/close under OS memory pressure.

## 10M STL gate (Alpha 0.8.4)
1. Exact binary STL count up to 10,000,000 is accepted; 10,000,001+ is rejected before mesh allocation.
2. Parser keeps one exact XYZ FloatArray and does not duplicate STL normals or create per-triangle coordinate arrays.
3. Renderer preview is capped at 250,000 sampled triangles.
4. Contour slicing must not allocate a second full transformed mesh.
5. Default/no-X-Y-tilt placement on bed must avoid a full vertex scan.
6. Rotate/scale interaction must defer exact bed settling until gesture end.
7. 10,000,000-triangle synthetic binary parser stress test must pass twice at -Xmx384m.
8. Final acceptance requires GitHub Android build pass 1 + pass 2 and a real-device 10M STL import test.

## Alpha 0.8.5 dense preview / size gates

- Dense preview must preserve whole-model coverage; isolated uniform triangle stride sampling is forbidden.
- Display geometry must stay bounded to 800k triangles while exact source geometry remains unchanged for slicing.
- Selected object UI must expose X/Y/Z size in millimetres without scanning every source vertex on each frame.
- SIZE editing is proportional/uniform in this alpha: editing any one dimension updates all three dimensions together.
- 3M and ~10M synthetic preview stress cases must complete without allocating a second full exact mesh.
- APK requires two clean GitHub Actions builds and real-device import/visual check before release confidence.
