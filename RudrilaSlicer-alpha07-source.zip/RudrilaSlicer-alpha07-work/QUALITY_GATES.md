# Rudrila Slicer Alpha 0.9 quality gates

- Large STL import path retains one vertex array and a decimated GPU preview.
- UI camera-fit and object selection avoid full-triangle scans on the main thread.
- Contour slicing uses bounded primitive segment chunks; no full transformed mesh copy.
- Default no-support toolpath planning streams layers and does not retain the full contour stack.
- Models over 1,000,000 triangles with support generation enabled are stopped with a clear message instead of risking an Android OOM.
- Exact uploaded 3,066,808-triangle / 146 MiB STL stress test must pass twice under a 256 MiB JVM heap.
- Core, profile, contour and toolpath suites must pass twice.
- Android APK build must pass twice before release.
