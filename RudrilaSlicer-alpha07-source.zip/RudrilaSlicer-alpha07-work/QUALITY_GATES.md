# Rudrila Slicer Alpha 0.10 quality gates

- Grid vertex shader uses `uMvp * vec4(aPos, 1.0)`; no undefined `world` identifier.
- Shader initialization failures are caught so the app does not terminate on the GL render thread.
- Invalid/stale stored profiles fall back to known-good defaults instead of crashing `MainActivity.onCreate`.
- Alpha 0.9 bounded-memory large-STL import and slicing protections remain intact.
- Exact uploaded 3,066,808-triangle / 146 MiB STL core stress must pass twice under a 256 MiB JVM heap.
- Core/profile/contour/toolpath suites must pass twice.
- Android APK build and APK ZIP verification must pass twice before release.
- Real-device launch/import/slice remains the final release gate.
