# Rudrila Slicer quality gates

Every milestone must pass two checks before being called complete.

## Gate A — engineering check
- Compiles without errors/warnings that affect correctness
- Core geometry/parser unit tests pass
- Invalid/corrupt input fails safely
- Large allocations are bounded
- No model transform may silently move geometry below Z=0 after Place on Bed

## Gate B — user-flow check
- App can complete the feature from touch UI without hidden steps
- Back/cancel paths work
- State shown to the user matches internal state
- No destructive action without an obvious recovery path once undo/redo is added
- Performance remains interactive on a representative phone

## Release-only gates
- Signed release APK
- Clean install + upgrade test
- At least two real Android devices
- Real STL and 3MF corpus
- Compare slices against a trusted desktop slicer before enabling G-code export for real printing

## Alpha 0.4 gates
- [x] Scene add/select/duplicate/delete tested twice with JVM core test.
- [x] Arbitrary rotation + place-on-bed tested twice.
- [x] Triangle lay-on-face produces selected face at Z≈0 and keeps mesh above bed; tested twice.
- [x] 3MF direct multi-object import preserves separate objects; tested twice.
- [x] 3MF build-item translation transform baked into geometry; tested twice.
- [ ] Android APK compile/install test: pending Android SDK/build runner.
- [ ] Real-device GPU/touch test: pending physical Android install.

## Alpha 0.5 gates
- [x] Generic printer/filament/process profile validation tested twice.
- [x] Profile choices are persisted locally through SharedPreferences.
- [x] Current toolchain versions re-verified: AGP 9.4.0 / Gradle 9.6 / Kotlin 2.4.20.
- [ ] Full Android compile: blocked only by missing Android SDK/build runner in this execution environment.

## Alpha 0.6 gates
- [x] Geometry contour slicer added (triangle/plane intersections + segment stitching).
- [x] 20 mm cube at 0.20 mm process produces 100 layers; tested twice.
- [x] Cube contour has correct 20 × 20 mm bounds and no open paths; tested twice.
- [x] Two separated cubes produce two closed contours on the same layer; tested twice.
- [x] Floating-point layer-count boundary bug found during first check and fixed before packaging.
- [ ] Perimeters/infill/support toolpaths: not implemented yet.
- [ ] G-code generation: not implemented yet.
- [ ] Full Android APK compile/install: pending Android SDK/build runner.

## Alpha 0.7 gates
- [x] Perimeter/wall path generation added and verified on deterministic cube geometry; tested twice.
- [x] Bottom/top solid skin added; exact-top floating-point boundary regression found and fixed.
- [x] Even/odd infill clipping preserves holes; tested twice.
- [x] Normal + tree-support foundation added with adaptive memory-bounded raster; tested twice.
- [x] Brim generation added; tested twice.
- [x] Filament volumetric-flow speed cap added and tested with low-flow TPU profile.
- [x] Extrusion, filament grams/length and time estimate added; tested twice.
- [x] Mobile layer preview UI + slider added; source syntax parse checked (full Android compile still pending SDK).
- [x] G-code export added with streaming writer, bed-coordinate conversion and bed-boundary guard; tested twice.
- [x] Open contours block G-code export; tested twice.
- [x] Geometry/profile edits invalidate stale slice/toolpath data before preview/export.
- [ ] Full Android APK compile/install: pending Android SDK/build runner.
- [ ] Real printer G-code validation: pending device-specific profile and comparison against trusted desktop slicer.
