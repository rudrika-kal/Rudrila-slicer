package com.rudrila.slicer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import com.rudrila.slicer.model.StlParser
import com.rudrila.slicer.model.DefaultProfiles
import com.rudrila.slicer.model.ContourSlicer
import com.rudrila.slicer.model.SliceResult
import com.rudrila.slicer.model.PrintConfiguration
import com.rudrila.slicer.model.ProfileStore
import com.rudrila.slicer.model.ThreeMfParser
import com.rudrila.slicer.model.TransformState
import com.rudrila.slicer.model.ToolpathEngine
import com.rudrila.slicer.model.ToolpathResult
import com.rudrila.slicer.model.GCodeExporter
import com.rudrila.slicer.ui.SlicerGLSurfaceView
import com.rudrila.slicer.ui.ToolpathPreviewView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var glView:SlicerGLSurfaceView
    private lateinit var statusText:TextView
    private lateinit var modeText:TextView
    private lateinit var selectedText:TextView
    private lateinit var profileText:TextView
    private lateinit var profileStore:ProfileStore
    private lateinit var printConfig:PrintConfiguration
    @Volatile private var lastSlice:SliceResult?=null
    @Volatile private var lastToolpaths:ToolpathResult?=null
    private val executor=Executors.newSingleThreadExecutor()
    private val openCode=7001
    private val saveCode=7002

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.rgb(16,18,20);window.navigationBarColor=Color.rgb(16,18,20)
        profileStore=ProfileStore(this);printConfig=profileStore.load()
        setContentView(buildUi())
    }

    private fun buildUi():View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(16,18,20))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(10),dp(12),dp(10))}
        val titleWrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val title=TextView(this).apply{text="RUDRILA SLICER";textSize=19f;setTextColor(Color.WHITE);setTypeface(typeface,1)}
        statusText=TextView(this).apply{text="Mobile slicing workspace • Alpha 0.7";textSize=11f;setTextColor(Color.rgb(155,165,170))}
        titleWrap.addView(title);titleWrap.addView(statusText);top.addView(titleWrap,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f))
        top.addView(actionButton("IMPORT"){openModels()});top.addView(actionButton("SLICE"){slicePlate()});top.addView(actionButton("PREVIEW"){showPreview()});root.addView(top)

        modeText=TextView(this).apply{text="VIEW • tap model to select • orbit / pan / zoom";gravity=Gravity.CENTER;setPadding(8,dp(6),8,dp(6));setTextColor(Color.rgb(126,224,187));textSize=11f}
        root.addView(modeText)
        profileText=TextView(this).apply{gravity=Gravity.CENTER;setPadding(8,dp(6),8,dp(6));setTextColor(Color.rgb(190,195,198));textSize=10f;setBackgroundColor(Color.rgb(22,25,28));setOnClickListener{showProfileDialog()}}
        root.addView(profileText);updateProfileLabel()

        glView=SlicerGLSurfaceView(this).apply{
            onSelectionChanged={runOnUiThread{updateSelectedLabel()}}
            onStatus={msg->runOnUiThread{statusText.text=msg}}
            onSceneChanged={invalidateSlice()}
        }
        root.addView(glView,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1f))

        val selection=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(3),dp(8),dp(3))}
        selection.addView(smallButton("◀"){glView.sceneState.selectNext(-1);glView.refreshScene();updateSelectedLabel()},LinearLayout.LayoutParams(dp(52),dp(40)))
        selectedText=TextView(this).apply{text="No model";gravity=Gravity.CENTER;setTextColor(Color.WHITE);textSize=11f;setOnClickListener{showObjectsDialog()}}
        selection.addView(selectedText,LinearLayout.LayoutParams(0,dp(40),1f))
        selection.addView(smallButton("▶"){glView.sceneState.selectNext(1);glView.refreshScene();updateSelectedLabel()},LinearLayout.LayoutParams(dp(52),dp(40)))
        selection.addView(smallButton("EXACT"){showExactTransformDialog()},LinearLayout.LayoutParams(dp(72),dp(40)))
        root.addView(selection)

        val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(3),dp(6),dp(3))}
        quick.addView(toolMini("CENTER"){glView.sceneState.centerSelected();invalidateSlice();glView.refreshScene();statusText.text="Selected model centered"})
        quick.addView(toolMini("BED"){glView.sceneState.placeSelectedOnBed();invalidateSlice();glView.refreshScene();statusText.text="Selected model placed on bed"})
        quick.addView(toolMini("DUP"){val x=glView.sceneState.duplicateSelected();if(x!=null)invalidateSlice();glView.refreshScene();statusText.text=if(x!=null)"Duplicated ${x.name}" else "Select a model first"})
        quick.addView(toolMini("DEL"){val x=glView.sceneState.deleteSelected();if(x!=null)invalidateSlice();glView.refreshScene();statusText.text=if(x!=null)"Deleted ${x.name}" else "Select a model first"})
        quick.addView(toolMini("ARRANGE"){glView.sceneState.autoArrange();invalidateSlice();glView.refreshScene(true);statusText.text="Models auto-arranged"})
        root.addView(quick)

        val tools=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(4),dp(6),dp(12));setBackgroundColor(Color.rgb(22,25,28))}
        tools.addView(toolButton("VIEW"){selectMode(SlicerGLSurfaceView.InteractionMode.VIEW)})
        tools.addView(toolButton("MOVE"){selectMode(SlicerGLSurfaceView.InteractionMode.MOVE)})
        tools.addView(toolButton("ROTATE"){selectMode(SlicerGLSurfaceView.InteractionMode.ROTATE)})
        tools.addView(toolButton("SCALE"){selectMode(SlicerGLSurfaceView.InteractionMode.SCALE)})
        tools.addView(toolButton("FACE"){selectMode(SlicerGLSurfaceView.InteractionMode.LAY_FACE)})
        root.addView(tools)
        return root
    }

    private fun selectMode(mode:SlicerGLSurfaceView.InteractionMode){
        glView.interactionMode=mode
        modeText.text=when(mode){
            SlicerGLSurfaceView.InteractionMode.VIEW->"VIEW • tap model to select • orbit / pan / zoom"
            SlicerGLSurfaceView.InteractionMode.MOVE->"MOVE • drag selected model across build plate"
            SlicerGLSurfaceView.InteractionMode.ROTATE->"ROTATE • horizontal = Z • vertical = X"
            SlicerGLSurfaceView.InteractionMode.SCALE->"SCALE • drag vertically or pinch"
            SlicerGLSurfaceView.InteractionMode.LAY_FACE->"FACE • tap the face you want placed on the bed"
        }
    }

    private fun updateSelectedLabel(){
        val s=glView.sceneState.selected()
        selectedText.text=if(s==null)"No model" else "${s.name}  •  ${glView.sceneState.size()} object${if(glView.sceneState.size()==1)"" else "s"}"
    }

    private fun slicePlate(){
        val scene=glView.sceneState.snapshot()
        if(scene.isEmpty()){toast("Import a model first");return}
        statusText.text="Slicing ${scene.size} object(s)…"
        executor.execute{
            try{
                val result=ContourSlicer.slice(scene,printConfig.process)
                val toolpaths=ToolpathEngine.plan(result,printConfig)
                lastSlice=result;lastToolpaths=toolpaths
                runOnUiThread{
                    val mins=toolpaths.estimate.timeSeconds/60
                    statusText.text="${result.layerCount} layers • ${toolpaths.pathCount} paths • ~${mins} min"
                    AlertDialog.Builder(this)
                        .setTitle("Slice complete")
                        .setMessage("Objects: ${result.sourceObjectCount}\nLayers: ${result.layerCount}\nToolpaths: ${toolpaths.pathCount}\nFilament: ${"%.1f".format(toolpaths.estimate.filamentGrams)} g\nEstimated time: ${mins/60}h ${mins%60}m${if(toolpaths.warningCount>0)"\nWarnings: ${toolpaths.warningCount} open contour(s)" else ""}\n\n${printConfig.process.name} • ${printConfig.filament.name}")
                        .setNegativeButton("Close",null)
                        .setNeutralButton("Export G-code"){_,_->exportGcode()}
                        .setPositiveButton("Preview"){_,_->showPreview()}.show()
                }
            }catch(t:Throwable){runOnUiThread{statusText.text="Slice failed";toast(t.message?:"Could not slice plate")}}
        }
    }

    private fun invalidateSlice(){lastSlice=null;lastToolpaths=null}

    private fun showPreview(){
        val tool=lastToolpaths?:run{toast("Slice the plate first");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),0)}
        val label=TextView(this).apply{setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;textSize=12f}
        val preview=ToolpathPreviewView(this).apply{setResult(tool)}
        val seek=SeekBar(this).apply{max=(tool.layers.size-1).coerceAtLeast(0);progress=0}
        fun update(i:Int){preview.layerIndex=i;val layer=tool.layers[i];label.text="Layer ${i+1}/${tool.layers.size} • Z ${"%.2f".format(layer.z)} mm • ${layer.paths.size} paths"}
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,from:Boolean){update(p)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}})
        box.addView(label,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(38)))
        box.addView(preview,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(420)))
        box.addView(seek,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(52)));update(0)
        AlertDialog.Builder(this).setTitle("Layer preview").setView(box).setNegativeButton("Close",null).setPositiveButton("Export G-code"){_,_->exportGcode()}.show()
    }

    private fun exportGcode(){
        val tool=lastToolpaths?:run{toast("Slice the plate first");return}
        if(tool.warningCount>0){toast("Repair open contours before export");return}
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/plain";putExtra(Intent.EXTRA_TITLE,"rudrila_print.gcode")}
        startActivityForResult(intent,saveCode)
    }

    private fun updateProfileLabel(){
        if(!::profileText.isInitialized)return
        profileText.text="${printConfig.printer.name} • ${printConfig.filament.name} • ${printConfig.process.name}  ›"
    }

    private fun showProfileDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(12),dp(22),0)}
        fun label(text:String)=TextView(this).apply{this.text=text;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))}
        val printer=Spinner(this);printer.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,DefaultProfiles.printers.map{it.name})
        val filament=Spinner(this);filament.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,DefaultProfiles.filaments.map{it.name})
        val process=Spinner(this);process.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,DefaultProfiles.processes.map{it.name})
        val support=CheckBox(this).apply{text="Generate supports";isChecked=printConfig.process.supportEnabled}
        val supportStyle=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Tree","Normal"));setSelection(if(printConfig.process.supportStyle=="Normal")1 else 0)}
        val infill=EditText(this).apply{setText(printConfig.process.infillPercent.toString());inputType=InputType.TYPE_CLASS_NUMBER}
        val brim=EditText(this).apply{setText(printConfig.process.brimWidthMm.toString());inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        printer.setSelection(DefaultProfiles.printers.indexOfFirst{it.id==printConfig.printer.id}.coerceAtLeast(0))
        filament.setSelection(DefaultProfiles.filaments.indexOfFirst{it.id==printConfig.filament.id}.coerceAtLeast(0))
        process.setSelection(DefaultProfiles.processes.indexOfFirst{it.id==printConfig.process.id}.coerceAtLeast(0))
        box.addView(label("Printer"));box.addView(printer);box.addView(label("Filament"));box.addView(filament);box.addView(label("Process"));box.addView(process)
        box.addView(label("Infill %"));box.addView(infill);box.addView(support);box.addView(label("Support style"));box.addView(supportStyle);box.addView(label("Brim width mm"));box.addView(brim)
        AlertDialog.Builder(this).setTitle("Print profiles").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Use profiles"){_,_->
            val base=DefaultProfiles.processes[process.selectedItemPosition]
            val q=base.copy(infillPercent=(infill.text.toString().toIntOrNull()?:base.infillPercent).coerceIn(0,100),supportEnabled=support.isChecked,supportStyle=supportStyle.selectedItem.toString(),brimWidthMm=(brim.text.toString().toFloatOrNull()?:base.brimWidthMm).coerceIn(0f,50f))
            val c=PrintConfiguration(DefaultProfiles.printers[printer.selectedItemPosition],DefaultProfiles.filaments[filament.selectedItemPosition],q)
            try{c.validate();printConfig=c;profileStore.save(c);invalidateSlice();updateProfileLabel();statusText.text="Profiles saved locally • re-slice required"}catch(t:Throwable){toast(t.message?:"Invalid profile")}
        }.show()
    }

    private fun showObjectsDialog(){
        val items=glView.sceneState.snapshot()
        if(items.isEmpty()){toast("Import a model first");return}
        val names=items.map{if(it.id==glView.sceneState.selectedId)"✓ ${it.name}" else it.name}.toTypedArray()
        AlertDialog.Builder(this).setTitle("Objects on plate").setItems(names){_,which->glView.sceneState.select(items[which].id);glView.refreshScene();updateSelectedLabel()}.setNegativeButton("Close",null).show()
    }

    private fun showExactTransformDialog(){
        val selected=glView.sceneState.selected()?:run{toast("Select a model first");return}
        val current=selected.transform
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(8),dp(22),0)}
        val fields=linkedMapOf<String,EditText>()
        fun addField(label:String,value:Float){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(TextView(this).apply{text=label;setTextColor(Color.DKGRAY)},LinearLayout.LayoutParams(dp(70),dp(48)))
            val edit=EditText(this).apply{setText("%.3f".format(value));inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED;selectAll()}
            row.addView(edit,LinearLayout.LayoutParams(0,dp(48),1f));box.addView(row);fields[label]=edit
        }
        addField("X mm",current.x);addField("Y mm",current.y);addField("Z mm",current.z);addField("Rot X",current.rotationX);addField("Rot Y",current.rotationY);addField("Rot Z",current.rotationZ);addField("Scale",current.scale*100f)
        AlertDialog.Builder(this).setTitle("Exact transform • ${selected.name}").setView(box).setNegativeButton("Cancel",null).setNeutralButton("On bed"){_,_->glView.sceneState.placeSelectedOnBed();invalidateSlice();glView.refreshScene()}.setPositiveButton("Apply"){_,_->
            fun v(k:String,f:Float)=fields[k]?.text?.toString()?.toFloatOrNull()?:f
            glView.sceneState.updateSelected(TransformState(v("X mm",current.x),v("Y mm",current.y),v("Z mm",current.z),v("Rot X",current.rotationX),v("Rot Y",current.rotationY),v("Rot Z",current.rotationZ),(v("Scale",current.scale*100f)/100f).coerceIn(0.01f,20f)))
            invalidateSlice();glView.refreshScene();statusText.text="Exact transform applied"
        }.show()
    }

    private fun openModels(){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)}
        startActivityForResult(intent,openCode)
    }

    @Deprecated("Legacy result API avoids another dependency in this prototype")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==saveCode){
            val uri=data?.data;val tool=lastToolpaths;val config=printConfig
            if(resultCode==RESULT_OK && uri!=null && tool!=null){
                statusText.text="Writing G-code…"
                executor.execute{
                    val result=runCatching{contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{GCodeExporter.write(tool,config,it)}?:error("Could not open output file")}
                    runOnUiThread{result.onSuccess{statusText.text="G-code exported";toast("G-code saved")}.onFailure{statusText.text="Export blocked";toast(it.message?:"Could not save G-code")}}
                }
            }
            return
        }
        if(requestCode!=openCode||resultCode!=RESULT_OK)return
        val uris=collectUris(data)
        if(uris.isEmpty())return
        statusText.text="Loading ${uris.size} file${if(uris.size==1)"" else "s"}…"
        executor.execute{
            var imported=0
            var failure:String?=null
            try{
                for(uri in uris){
                    val name=displayName(uri)
                    when{
                        name.endsWith(".stl",true)->{glView.sceneState.add(name.removeSuffixIgnoreCase(".stl"),StlParser.parse(contentResolver,uri));imported++}
                        name.endsWith(".3mf",true)->{
                            val parts=ThreeMfParser.parseParts(contentResolver,uri)
                            parts.forEach{glView.sceneState.add(it.name,it.mesh,select=false)}
                            if(parts.isNotEmpty()){glView.sceneState.selectNext(0);imported+=parts.size}
                        }
                        else->failure="Skipped unsupported file: $name"
                    }
                }
            }catch(t:Throwable){failure=t.message?:"Import failed"}
            runOnUiThread{
                invalidateSlice();glView.refreshScene(fit=true);selectMode(SlicerGLSurfaceView.InteractionMode.VIEW);updateSelectedLabel()
                statusText.text=when{imported>0&&failure!=null->"Imported $imported object(s) • $failure";imported>0->"Imported $imported object(s)";else->failure?:"No models imported"}
            }
        }
    }

    private fun collectUris(data:Intent?):List<Uri>{
        val out=mutableListOf<Uri>();val clip:ClipData?=data?.clipData
        if(clip!=null){for(i in 0 until clip.itemCount)clip.getItemAt(i).uri?.let{out+=it}}else data?.data?.let{out+=it}
        return out.distinct()
    }

    private fun String.removeSuffixIgnoreCase(suffix:String)=if(endsWith(suffix,true))substring(0,length-suffix.length)else this
    private fun displayName(uri:Uri):String{contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())return c.getString(0)?:"model"};return uri.lastPathSegment?:"model"}
    private fun actionButton(text:String,onClick:()->Unit)=Button(this).apply{this.text=text;textSize=12f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(36,150,108));setOnClickListener{onClick()}}
    private fun smallButton(text:String,onClick:()->Unit)=Button(this).apply{this.text=text;textSize=10f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(35,39,43));setOnClickListener{onClick()}}
    private fun toolMini(text:String,onClick:()->Unit)=smallButton(text,onClick).apply{layoutParams=LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(2),0,dp(2),0)}}
    private fun toolButton(text:String,onClick:()->Unit)=Button(this).apply{this.text=text;textSize=9f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(42,47,51));setOnClickListener{onClick()};layoutParams=LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),0,dp(2),0)}}
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
    private fun dp(value:Int)=(value*resources.displayMetrics.density).toInt()

    override fun onResume(){super.onResume();if(::glView.isInitialized)glView.onResume()}
    override fun onPause(){if(::glView.isInitialized)glView.onPause();super.onPause()}
    override fun onDestroy(){executor.shutdownNow();super.onDestroy()}
}
