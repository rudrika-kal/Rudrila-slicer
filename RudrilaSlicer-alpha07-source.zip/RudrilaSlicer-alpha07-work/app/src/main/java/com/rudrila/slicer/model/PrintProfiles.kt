package com.rudrila.slicer.model

data class PrinterProfile(
    val id: String,
    val name: String,
    val bedX: Float,
    val bedY: Float,
    val bedZ: Float,
    val nozzleDiameter: Float = 0.4f,
    val filamentDiameter: Float = 1.75f,
    val maxHotendTempC: Int = 300,
    val maxBedTempC: Int = 110
) {
    fun validate() {
        require(id.isNotBlank() && name.isNotBlank())
        require(bedX > 0f && bedY > 0f && bedZ > 0f)
        require(nozzleDiameter in 0.1f..2.0f)
        require(filamentDiameter in 1.0f..3.5f)
    }
}

data class FilamentProfile(
    val id: String,
    val name: String,
    val material: String,
    val nozzleTempC: Int,
    val bedTempC: Int,
    val densityGcm3: Float,
    val maxVolumetricSpeedMm3s: Float
) {
    fun validate(printer: PrinterProfile? = null) {
        require(id.isNotBlank() && name.isNotBlank())
        require(nozzleTempC in 120..450 && bedTempC in 0..180)
        require(densityGcm3 in 0.5f..3.0f)
        require(maxVolumetricSpeedMm3s > 0f)
        if (printer != null) {
            require(nozzleTempC <= printer.maxHotendTempC) { "Nozzle temperature exceeds printer limit" }
            require(bedTempC <= printer.maxBedTempC) { "Bed temperature exceeds printer limit" }
        }
    }
}

data class ProcessProfile(
    val id: String,
    val name: String,
    val layerHeightMm: Float,
    val firstLayerHeightMm: Float,
    val wallLoops: Int,
    val topLayers: Int,
    val bottomLayers: Int,
    val infillPercent: Int,
    val infillPattern: String,
    val supportEnabled: Boolean,
    val supportOverhangDeg: Int,
    val brimWidthMm: Float,
    val supportStyle: String = "Tree"
) {
    fun validate(printer: PrinterProfile? = null) {
        require(id.isNotBlank() && name.isNotBlank())
        require(layerHeightMm in 0.04f..1.2f && firstLayerHeightMm in 0.04f..1.2f)
        require(wallLoops in 1..20 && topLayers in 0..30 && bottomLayers in 0..30)
        require(infillPercent in 0..100)
        require(supportOverhangDeg in 0..90)
        require(brimWidthMm in 0f..50f)
        require(supportStyle in setOf("Normal","Tree"))
        if (printer != null) require(layerHeightMm <= printer.nozzleDiameter * 0.8f) { "Layer height is too large for selected nozzle" }
    }
}

data class PrintConfiguration(
    val printer: PrinterProfile,
    val filament: FilamentProfile,
    val process: ProcessProfile
) {
    fun validate() { printer.validate(); filament.validate(printer); process.validate(printer) }
}

object DefaultProfiles {
    // Generic presets are intentionally vendor-neutral until device-specific values are verified against the user's printer.
    val printers = listOf(
        PrinterProfile("generic_256", "Generic CoreXY 256", 256f,256f,256f,0.4f),
        PrinterProfile("generic_220", "Generic FDM 220", 220f,220f,250f,0.4f)
    )
    val filaments = listOf(
        FilamentProfile("pla", "Generic PLA", "PLA", 220,55,1.24f,12f),
        FilamentProfile("petg", "Generic PETG", "PETG", 245,70,1.27f,10f),
        FilamentProfile("abs", "Generic ABS", "ABS", 255,95,1.04f,10f),
        FilamentProfile("tpu", "Generic TPU 95A", "TPU", 225,45,1.21f,4f)
    )
    val processes = listOf(
        ProcessProfile("draft_028", "0.28 mm Draft", 0.28f,0.24f,2,4,3,15,"Grid",false,55,0f),
        ProcessProfile("standard_020", "0.20 mm Standard", 0.20f,0.20f,3,5,4,15,"Gyroid",false,55,0f),
        ProcessProfile("fine_012", "0.12 mm Fine", 0.12f,0.20f,3,7,5,15,"Gyroid",false,55,0f)
    )

    fun defaultConfiguration() = PrintConfiguration(printers.first(), filaments.first(), processes[1]).also { it.validate() }
}
