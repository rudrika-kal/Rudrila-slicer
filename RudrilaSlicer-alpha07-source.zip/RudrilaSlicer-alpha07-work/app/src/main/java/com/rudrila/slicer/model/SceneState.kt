package com.rudrila.slicer.model

import java.util.concurrent.atomic.AtomicLong

/** One independently transformable model on the build plate. */
data class SceneObject(
    val id: Long,
    val name: String,
    val mesh: Mesh,
    val transform: TransformState = TransformState()
)

/**
 * UI-owned scene model. Rendering receives immutable snapshots so drag updates do not mutate GL state mid-frame.
 */
class SceneState {
    private val ids = AtomicLong(1L)
    private val objects = mutableListOf<SceneObject>()
    var selectedId: Long? = null
        private set

    @Synchronized
    fun snapshot(): List<SceneObject> = objects.map { it.copy(transform = it.transform.copy()) }

    @Synchronized
    fun size(): Int = objects.size

    @Synchronized
    fun selected(): SceneObject? = objects.firstOrNull { it.id == selectedId }

    @Synchronized
    fun add(name: String, mesh: Mesh, transform: TransformState = TransformState(), select: Boolean = true): SceneObject {
        val objectName = uniqueName(name.ifBlank { "Model" })
        val placed = TransformMath.placedOnBed(mesh, transform)
        val obj = SceneObject(ids.getAndIncrement(), objectName, mesh, placed)
        objects += obj
        if (select || selectedId == null) selectedId = obj.id
        return obj
    }

    @Synchronized
    fun addAll(parts: List<Pair<String, Mesh>>): List<SceneObject> {
        val added = parts.map { (name, mesh) -> add(name, mesh, select = false) }
        if (added.isNotEmpty()) selectedId = added.last().id
        return added
    }

    @Synchronized
    fun clear() {
        objects.clear()
        selectedId = null
    }

    @Synchronized
    fun select(id: Long?): Boolean {
        if (id == null) { selectedId = null; return true }
        if (objects.none { it.id == id }) return false
        selectedId = id
        return true
    }

    @Synchronized
    fun selectNext(delta: Int = 1): SceneObject? {
        if (objects.isEmpty()) { selectedId = null; return null }
        val current = objects.indexOfFirst { it.id == selectedId }.let { if (it < 0) 0 else it }
        val next = ((current + delta) % objects.size + objects.size) % objects.size
        selectedId = objects[next].id
        return objects[next]
    }

    @Synchronized
    fun updateSelected(transform: TransformState, placeOnBed: Boolean = false): SceneObject? {
        val index = objects.indexOfFirst { it.id == selectedId }
        if (index < 0) return null
        val old = objects[index]
        val bounded = transform.copy(scale = transform.scale.coerceIn(0.01f, 20f))
        val final = if (placeOnBed) TransformMath.placedOnBed(old.mesh, bounded) else bounded
        objects[index] = old.copy(transform = final)
        return objects[index]
    }

    @Synchronized
    fun transformSelected(block: (SceneObject) -> TransformState): SceneObject? {
        val selected = selected() ?: return null
        return updateSelected(block(selected))
    }

    @Synchronized
    fun centerSelected(): SceneObject? = transformSelected { it.transform.copy(x = 0f, y = 0f) }

    @Synchronized
    fun placeSelectedOnBed(): SceneObject? = transformSelected { TransformMath.placedOnBed(it.mesh, it.transform) }

    @Synchronized
    fun resetSelected(): SceneObject? = transformSelected { TransformMath.placedOnBed(it.mesh, TransformState()) }

    @Synchronized
    fun duplicateSelected(offsetMm: Float = 12f): SceneObject? {
        val src = selected() ?: return null
        val copy = SceneObject(
            id = ids.getAndIncrement(),
            name = uniqueName(src.name),
            mesh = src.mesh,
            transform = src.transform.copy(x = src.transform.x + offsetMm, y = src.transform.y + offsetMm)
        )
        objects += copy
        selectedId = copy.id
        return copy
    }

    @Synchronized
    fun deleteSelected(): SceneObject? {
        val index = objects.indexOfFirst { it.id == selectedId }
        if (index < 0) return null
        val removed = objects.removeAt(index)
        selectedId = if (objects.isEmpty()) null else objects[index.coerceAtMost(objects.lastIndex)].id
        return removed
    }

    /** Simple deterministic grid arrangement, centered on a square build plate. */
    @Synchronized
    fun autoArrange(spacingMm: Float = 8f, plateSizeMm: Float = 256f) {
        if (objects.isEmpty()) return
        val columns = kotlin.math.ceil(kotlin.math.sqrt(objects.size.toDouble())).toInt().coerceAtLeast(1)
        val cell = plateSizeMm / columns
        objects.indices.forEach { i ->
            val row = i / columns
            val col = i % columns
            val x = -plateSizeMm / 2f + cell * (col + 0.5f)
            val y = -plateSizeMm / 2f + cell * (row + 0.5f)
            val obj = objects[i]
            val box = TransformMath.transformedBoxBounds(obj.mesh, obj.transform.copy(x = 0f, y = 0f))
            val halfW = box.width / 2f
            val halfD = box.depth / 2f
            val minX = -plateSizeMm / 2f + halfW + spacingMm / 2f
            val maxX = plateSizeMm / 2f - halfW - spacingMm / 2f
            val minY = -plateSizeMm / 2f + halfD + spacingMm / 2f
            val maxY = plateSizeMm / 2f - halfD - spacingMm / 2f
            val safeX = if (minX <= maxX) x.coerceIn(minX, maxX) else 0f
            val safeY = if (minY <= maxY) y.coerceIn(minY, maxY) else 0f
            objects[i] = obj.copy(transform = obj.transform.copy(x = safeX, y = safeY))
        }
    }

    private fun uniqueName(base: String): String {
        if (objects.none { it.name == base }) return base
        var n = 2
        while (objects.any { it.name == "$base ($n)" }) n++
        return "$base ($n)"
    }
}
