package com.rudrila.slicer.model

import kotlin.math.*

/** Model-space transform used by both the renderer and later slicing pipeline. */
data class TransformState(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f,
    val rotationX: Float = 0f,
    val rotationY: Float = 0f,
    val rotationZ: Float = 0f,
    val scale: Float = 1f
)

data class Bounds3(
    val minX: Float, val minY: Float, val minZ: Float,
    val maxX: Float, val maxY: Float, val maxZ: Float
) {
    val width get() = maxX - minX
    val depth get() = maxY - minY
    val height get() = maxZ - minZ
}

object TransformMath {
    private data class Mat3(val v: FloatArray) {
        operator fun times(o: Mat3): Mat3 {
            val a = v; val b = o.v; val r = FloatArray(9)
            for (row in 0..2) for (col in 0..2) {
                r[row * 3 + col] = a[row * 3] * b[col] + a[row * 3 + 1] * b[3 + col] + a[row * 3 + 2] * b[6 + col]
            }
            return Mat3(r)
        }
        fun apply(x: Float, y: Float, z: Float): FloatArray = floatArrayOf(
            v[0]*x + v[1]*y + v[2]*z,
            v[3]*x + v[4]*y + v[5]*z,
            v[6]*x + v[7]*y + v[8]*z
        )
    }

    fun transformedMinZ(mesh: Mesh, state: TransformState): Float = transformedBounds(mesh, state).minZ

    /** Fast conservative bounds from the mesh AABB corners. Suitable for camera fitting and hit selection. */
    fun transformedBoundsFast(mesh: Mesh, state: TransformState): Bounds3 {
        val r = rotationMatrix(state)
        val rv = r.v
        val xs = floatArrayOf(mesh.minX, mesh.maxX)
        val ys = floatArrayOf(mesh.minY, mesh.maxY)
        val zs = floatArrayOf(mesh.minZ, mesh.maxZ)
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
        for (x0 in xs) for (y0 in ys) for (z0 in zs) {
            val x=(x0-mesh.centerX)*state.scale; val y=(y0-mesh.centerY)*state.scale; val z=(z0-mesh.minZ)*state.scale
            val wx=rv[0]*x+rv[1]*y+rv[2]*z+state.x
            val wy=rv[3]*x+rv[4]*y+rv[5]*z+state.y
            val wz=rv[6]*x+rv[7]*y+rv[8]*z+state.z
            minX=min(minX,wx);minY=min(minY,wy);minZ=min(minZ,wz)
            maxX=max(maxX,wx);maxY=max(maxY,wy);maxZ=max(maxZ,wz)
        }
        return Bounds3(minX,minY,minZ,maxX,maxY,maxZ)
    }

    fun transformedBounds(mesh: Mesh, state: TransformState): Bounds3 {
        val r = rotationMatrix(state)
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
        val v = mesh.vertices
        var i = 0
        while (i < v.size) {
            val lx = (v[i] - mesh.centerX) * state.scale
            val ly = (v[i + 1] - mesh.centerY) * state.scale
            val lz = (v[i + 2] - mesh.minZ) * state.scale
            // Inline matrix multiply to avoid one FloatArray allocation per vertex on huge meshes.
            val rv = r.v
            val x = rv[0]*lx + rv[1]*ly + rv[2]*lz + state.x
            val y = rv[3]*lx + rv[4]*ly + rv[5]*lz + state.y
            val z = rv[6]*lx + rv[7]*ly + rv[8]*lz + state.z
            minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
            maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
            i += 3
        }
        if (!minZ.isFinite()) return Bounds3(0f,0f,0f,0f,0f,0f)
        return Bounds3(minX,minY,minZ,maxX,maxY,maxZ)
    }

    fun placedOnBed(mesh: Mesh, state: TransformState): TransformState {
        val withoutZ = state.copy(z = 0f)
        return withoutZ.copy(z = -transformedMinZ(mesh, withoutZ))
    }

    /**
     * Rotates the selected triangle until its plane lies on the bed, then drops the object to Z=0.
     * Both normal directions are evaluated; the candidate that actually places the tapped face lowest wins.
     */
    fun layTriangleOnBed(mesh: Mesh, state: TransformState, triangleIndex: Int): TransformState {
        require(triangleIndex >= 0 && triangleIndex * 9 + 8 < mesh.vertices.size) { "Triangle index out of range" }
        val normal = triangleNormal(mesh, triangleIndex)
        if (length(normal) < 1e-7f) return placedOnBed(mesh, state)
        val current = rotationMatrix(state)
        val worldNormal = current.apply(normal[0], normal[1], normal[2]).normalized()

        val down = candidateForTarget(mesh, state, triangleIndex, current, worldNormal, floatArrayOf(0f,0f,-1f))
        val up = candidateForTarget(mesh, state, triangleIndex, current, worldNormal, floatArrayOf(0f,0f,1f))
        return if (down.second <= up.second) down.first else up.first
    }

    private fun candidateForTarget(
        mesh: Mesh,
        state: TransformState,
        triangleIndex: Int,
        current: Mat3,
        from: FloatArray,
        target: FloatArray
    ): Pair<TransformState, Float> {
        val delta = rotationFromTo(from, target)
        val combined = delta * current
        val euler = matrixToEuler(combined)
        val candidate = placedOnBed(mesh, state.copy(rotationX=euler[0], rotationY=euler[1], rotationZ=euler[2], z=0f))
        val faceZ = triangleAverageWorldZ(mesh, triangleIndex, candidate)
        return candidate to abs(faceZ)
    }

    fun triangleAverageWorldZ(mesh: Mesh, triangleIndex: Int, state: TransformState): Float {
        val r = rotationMatrix(state)
        val base = triangleIndex * 9
        var sum = 0f
        repeat(3) { k ->
            val i = base + k*3
            val p = r.apply(
                (mesh.vertices[i]-mesh.centerX)*state.scale,
                (mesh.vertices[i+1]-mesh.centerY)*state.scale,
                (mesh.vertices[i+2]-mesh.minZ)*state.scale
            )
            sum += p[2] + state.z
        }
        return sum / 3f
    }

    fun transformedPoint(mesh: Mesh, state: TransformState, vertexOffset: Int): FloatArray {
        val r = rotationMatrix(state)
        val p = r.apply(
            (mesh.vertices[vertexOffset]-mesh.centerX)*state.scale,
            (mesh.vertices[vertexOffset+1]-mesh.centerY)*state.scale,
            (mesh.vertices[vertexOffset+2]-mesh.minZ)*state.scale
        )
        p[0] += state.x; p[1] += state.y; p[2] += state.z
        return p
    }

    private fun triangleNormal(mesh: Mesh, tri: Int): FloatArray {
        val i = tri * 9
        val ax = mesh.vertices[i+3]-mesh.vertices[i]; val ay = mesh.vertices[i+4]-mesh.vertices[i+1]; val az = mesh.vertices[i+5]-mesh.vertices[i+2]
        val bx = mesh.vertices[i+6]-mesh.vertices[i]; val by = mesh.vertices[i+7]-mesh.vertices[i+1]; val bz = mesh.vertices[i+8]-mesh.vertices[i+2]
        return floatArrayOf(ay*bz-az*by, az*bx-ax*bz, ax*by-ay*bx).normalized()
    }

    private fun rotationMatrix(s: TransformState): Mat3 {
        val x = Math.toRadians(s.rotationX.toDouble()).toFloat(); val y = Math.toRadians(s.rotationY.toDouble()).toFloat(); val z = Math.toRadians(s.rotationZ.toDouble()).toFloat()
        val cx=cos(x); val sx=sin(x); val cy=cos(y); val sy=sin(y); val cz=cos(z); val sz=sin(z)
        // Rz * Ry * Rx
        return Mat3(floatArrayOf(
            cz*cy, cz*sy*sx - sz*cx, cz*sy*cx + sz*sx,
            sz*cy, sz*sy*sx + cz*cx, sz*sy*cx - cz*sx,
            -sy,   cy*sx,                cy*cx
        ))
    }

    private fun rotationFromTo(fromRaw: FloatArray, toRaw: FloatArray): Mat3 {
        val from = fromRaw.normalized(); val to = toRaw.normalized()
        val dot = (from[0]*to[0] + from[1]*to[1] + from[2]*to[2]).coerceIn(-1f,1f)
        if (dot > 0.999999f) return Mat3(floatArrayOf(1f,0f,0f, 0f,1f,0f, 0f,0f,1f))
        if (dot < -0.999999f) {
            var axis = cross(from, floatArrayOf(1f,0f,0f))
            if (length(axis) < 1e-4f) axis = cross(from, floatArrayOf(0f,1f,0f))
            return axisAngle(axis.normalized(), PI.toFloat())
        }
        val axis = cross(from,to)
        val angle = acos(dot)
        return axisAngle(axis.normalized(), angle)
    }

    private fun axisAngle(a: FloatArray, angle: Float): Mat3 {
        val x=a[0]; val y=a[1]; val z=a[2]; val c=cos(angle); val s=sin(angle); val t=1f-c
        return Mat3(floatArrayOf(
            t*x*x+c,   t*x*y-s*z, t*x*z+s*y,
            t*x*y+s*z, t*y*y+c,   t*y*z-s*x,
            t*x*z-s*y, t*y*z+s*x, t*z*z+c
        ))
    }

    private fun matrixToEuler(m: Mat3): FloatArray {
        val r=m.v
        val sy = (-r[6]).coerceIn(-1f,1f)
        val y = asin(sy)
        val cy = cos(y)
        val x: Float
        val z: Float
        if (abs(cy) > 1e-6f) {
            x = atan2(r[7], r[8])
            z = atan2(r[3], r[0])
        } else {
            x = atan2(-r[5], r[4])
            z = 0f
        }
        val d = 180f / PI.toFloat()
        return floatArrayOf(normalizeAngle(x*d), normalizeAngle(y*d), normalizeAngle(z*d))
    }

    private fun cross(a: FloatArray,b:FloatArray)=floatArrayOf(a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
    private fun length(a:FloatArray)=sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2])
    private fun FloatArray.normalized():FloatArray { val l=length(this); return if(l<1e-9f) floatArrayOf(0f,0f,0f) else floatArrayOf(this[0]/l,this[1]/l,this[2]/l) }
    private fun normalizeAngle(v:Float):Float { var a=v%360f; if(a>180f)a-=360f; if(a<-180f)a+=360f; return a }
}
