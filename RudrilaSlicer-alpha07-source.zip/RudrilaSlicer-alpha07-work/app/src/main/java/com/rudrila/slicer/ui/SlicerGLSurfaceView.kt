package com.rudrila.slicer.ui

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.rudrila.slicer.model.SceneObject
import com.rudrila.slicer.model.SceneState
import com.rudrila.slicer.model.TransformMath
import com.rudrila.slicer.render.SlicerRenderer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class SlicerGLSurfaceView(context: Context) : GLSurfaceView(context) {
    enum class InteractionMode { VIEW, MOVE, ROTATE, SCALE, LAY_FACE }

    val slicerRenderer = SlicerRenderer()
    val sceneState = SceneState()
    var interactionMode: InteractionMode = InteractionMode.VIEW
    var onSelectionChanged: ((SceneObject?) -> Unit)? = null
    var onStatus: ((String) -> Unit)? = null
    var onSceneChanged: (() -> Unit)? = null

    private val scaleDetector: ScaleGestureDetector
    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var lastTwoFingerX = 0f
    private var lastTwoFingerY = 0f

    init {
        setEGLContextClientVersion(3)
        setRenderer(slicerRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
        scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (interactionMode == InteractionMode.SCALE) {
                    editSelected(placeOnBed = false) { it.copy(scale = (it.scale * detector.scaleFactor).coerceIn(0.01f,20f)) }
                } else {
                    slicerRenderer.distance = (slicerRenderer.distance / detector.scaleFactor).coerceIn(35f,2200f)
                }
                return true
            }
        })
    }

    fun refreshScene(fit: Boolean = false) {
        slicerRenderer.setScene(sceneState.snapshot(), sceneState.selectedId)
        if (fit) slicerRenderer.fitSceneToView()
        onSelectionChanged?.invoke(sceneState.selected())
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX=event.x; lastY=event.y; downX=event.x; downY=event.y
            }
            MotionEvent.ACTION_POINTER_DOWN -> if(event.pointerCount>=2){lastTwoFingerX=midpointX(event);lastTwoFingerY=midpointY(event)}
            MotionEvent.ACTION_MOVE -> if(!scaleDetector.isInProgress){
                if(event.pointerCount==1){
                    val dx=event.x-lastX; val dy=event.y-lastY
                    when(interactionMode){
                        InteractionMode.VIEW, InteractionMode.LAY_FACE -> {
                            slicerRenderer.yaw += dx*0.35f
                            slicerRenderer.pitch=(slicerRenderer.pitch+dy*0.28f).coerceIn(-82f,82f)
                        }
                        InteractionMode.MOVE -> moveSelectedOnPlate(dx,dy)
                        InteractionMode.ROTATE -> editSelected(placeOnBed = false){ s -> s.copy(rotationZ=norm(s.rotationZ+dx*0.35f), rotationX=norm(s.rotationX+dy*0.28f)) }
                        InteractionMode.SCALE -> {
                            val factor=(1f-dy*0.006f).coerceIn(0.90f,1.10f)
                            editSelected(placeOnBed = false){ it.copy(scale=(it.scale*factor).coerceIn(0.01f,20f)) }
                        }
                    }
                    lastX=event.x; lastY=event.y
                } else if(event.pointerCount>=2 && interactionMode==InteractionMode.VIEW){
                    val mx=midpointX(event); val my=midpointY(event); val scale=slicerRenderer.distance/900f
                    slicerRenderer.panX-=(mx-lastTwoFingerX)*scale; slicerRenderer.panY+=(my-lastTwoFingerY)*scale
                    lastTwoFingerX=mx;lastTwoFingerY=my
                }
            }
            MotionEvent.ACTION_UP -> {
                // Dense meshes must not run an exact min-Z scan on every drag frame. During rotate/scale
                // we update interactively, then settle the model onto the bed once when the gesture ends.
                if (interactionMode == InteractionMode.ROTATE || interactionMode == InteractionMode.SCALE) {
                    sceneState.placeSelectedOnBed()
                    onSceneChanged?.invoke()
                    refreshScene()
                }
                val tap = abs(event.x-downX) < 16f && abs(event.y-downY) < 16f
                if(tap && !scaleDetector.isInProgress){
                    if(interactionMode==InteractionMode.LAY_FACE){
                        val tri=slicerRenderer.pickSelectedTriangle(event.x,event.y)
                        val selected=sceneState.selected()
                        if(tri!=null && selected!=null){
                            sceneState.updateSelected(TransformMath.layTriangleOnBed(selected.mesh,selected.transform,tri))
                            onSceneChanged?.invoke()
                            refreshScene()
                            onStatus?.invoke("Face laid flat on bed")
                        } else onStatus?.invoke("Tap a face on the selected model")
                    } else if(interactionMode==InteractionMode.VIEW){
                        val id=slicerRenderer.pickObject(event.x,event.y)
                        if(id!=null){sceneState.select(id);refreshScene();onStatus?.invoke("Selected ${sceneState.selected()?.name ?: "model"}")}
                    }
                }
            }
        }
        return true
    }

    private fun editSelected(placeOnBed:Boolean=false, block:(com.rudrila.slicer.model.TransformState)->com.rudrila.slicer.model.TransformState){
        val obj=sceneState.selected()?:return
        sceneState.updateSelected(block(obj.transform),placeOnBed)
        onSceneChanged?.invoke()
        refreshScene()
    }

    private fun moveSelectedOnPlate(dx:Float,dy:Float){
        val obj=sceneState.selected()?:return
        val mmPerPx=slicerRenderer.distance/900f; val a=Math.toRadians(slicerRenderer.yaw.toDouble()).toFloat()
        val rightX=cos(a);val rightY=sin(a);val upX=-sin(a);val upY=cos(a)
        val wx=(dx*rightX-dy*upX)*mmPerPx;val wy=(dx*rightY-dy*upY)*mmPerPx
        sceneState.updateSelected(obj.transform.copy(x=(obj.transform.x+wx).coerceIn(-300f,300f),y=(obj.transform.y+wy).coerceIn(-300f,300f)))
        onSceneChanged?.invoke()
        refreshScene()
    }

    private fun norm(v:Float):Float{var a=v%360f;if(a>180f)a-=360f;if(a<-180f)a+=360f;return a}
    private fun midpointX(e:MotionEvent)=(e.getX(0)+e.getX(1))*0.5f
    private fun midpointY(e:MotionEvent)=(e.getY(0)+e.getY(1))*0.5f
}
