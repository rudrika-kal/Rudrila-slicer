package com.rudrila.slicer.model

import android.content.Context

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("rudrila_slicer_profiles", Context.MODE_PRIVATE)

    fun load(): PrintConfiguration {
        val pId=prefs.getString("printer",null)
        val fId=prefs.getString("filament",null)
        val qId=prefs.getString("process",null)
        val p=DefaultProfiles.printers.firstOrNull{it.id==pId}?:DefaultProfiles.printers.first()
        val f=DefaultProfiles.filaments.firstOrNull{it.id==fId}?:DefaultProfiles.filaments.first()
        val base=DefaultProfiles.processes.firstOrNull{it.id==qId}?:DefaultProfiles.processes[1]
        val q=base.copy(
            layerHeightMm=prefs.getFloat("layer_height",base.layerHeightMm),
            infillPercent=prefs.getInt("infill",base.infillPercent).coerceIn(0,100),
            supportEnabled=prefs.getBoolean("support",base.supportEnabled),
            brimWidthMm=prefs.getFloat("brim",base.brimWidthMm).coerceIn(0f,50f),
            supportStyle=prefs.getString("support_style",base.supportStyle)?.takeIf{it=="Normal"||it=="Tree"}?:base.supportStyle
        )
        return PrintConfiguration(p,f,q).also{it.validate()}
    }

    fun save(config: PrintConfiguration) {
        config.validate()
        prefs.edit()
            .putString("printer",config.printer.id)
            .putString("filament",config.filament.id)
            .putString("process",config.process.id)
            .putFloat("layer_height",config.process.layerHeightMm)
            .putInt("infill",config.process.infillPercent)
            .putBoolean("support",config.process.supportEnabled)
            .putFloat("brim",config.process.brimWidthMm)
            .putString("support_style",config.process.supportStyle)
            .apply()
    }
}
