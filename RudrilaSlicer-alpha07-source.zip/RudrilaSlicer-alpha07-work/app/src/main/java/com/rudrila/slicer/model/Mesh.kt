package com.rudrila.slicer.model

data class Mesh(
    val vertices: FloatArray,
    val normals: FloatArray,
    val minX: Float,
    val minY: Float,
    val minZ: Float,
    val maxX: Float,
    val maxY: Float,
    val maxZ: Float
) {
    val vertexCount: Int get() = vertices.size / 3
    val width: Float get() = maxX - minX
    val depth: Float get() = maxY - minY
    val height: Float get() = maxZ - minZ
    val centerX: Float get() = (minX + maxX) * 0.5f
    val centerY: Float get() = (minY + maxY) * 0.5f
    val centerZ: Float get() = (minZ + maxZ) * 0.5f
}
