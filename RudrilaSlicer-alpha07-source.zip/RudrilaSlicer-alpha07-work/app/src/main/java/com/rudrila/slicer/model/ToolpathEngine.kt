package com.rudrila.slicer.model

import kotlin.math.*

/** Path roles are intentionally explicit so layer preview and G-code can distinguish print intent. */
enum class PathRole {
    OUTER_WALL,
    INNER_WALL,
    TOP_SURFACE,
    BOTTOM_SURFACE,
    INFILL,
    GAP_FILL,
    SUPPORT,
    SUPPORT_INTERFACE,
    BRIM,
    // Legacy roles retained for backward-compatible saved/test data.
    WALL,
    SOLID
}

data class Toolpath(
    val points: List<Point2>,
    val role: PathRole,
    val closed: Boolean = false,
    val widthMm: Float,
    val speedMmS: Float
) {
    val lengthMm: Float by lazy {
        if (points.size < 2) 0f else points.zipWithNext().sumOf { (a,b) -> hypot((b.x-a.x).toDouble(), (b.y-a.y).toDouble()) }.toFloat()
    }
}

data class ToolpathLayer(
    val index: Int,
    val z: Float,
    val heightMm: Float,
    val paths: List<Toolpath>,
    /** Non-extruding XY moves, exposed only to preview/statistics. */
    val travelMoves: List<List<Point2>> = emptyList()
) {
    val extrusionLengthMm: Float by lazy { paths.sumOf { it.lengthMm.toDouble() }.toFloat() }
    val travelLengthMm: Float by lazy {
        travelMoves.sumOf { move ->
            if (move.size < 2) 0.0 else move.zipWithNext().sumOf { (a,b) -> hypot((b.x-a.x).toDouble(),(b.y-a.y).toDouble()) }
        }.toFloat()
    }
    fun roleLength(role:PathRole):Float = paths.filter { it.role==role }.sumOf { it.lengthMm.toDouble() }.toFloat()
}

data class PrintEstimate(
    val pathLengthMm: Float,
    val filamentLengthMm: Float,
    val filamentGrams: Float,
    val timeSeconds: Int,
    val travelLengthMm: Float = 0f
)

data class ToolpathResult(
    val layers: List<ToolpathLayer>,
    val estimate: PrintEstimate,
    val warningCount: Int = 0,
    val warningMessages: List<String> = emptyList()
) {
    val pathCount: Int get() = layers.sumOf { it.paths.size }
}

/**
 * Rudrila Slice Engine V2 foundation.
 *
 * This planner is still deliberately JVM-testable and Android-independent, but now separates outer/inner walls,
 * understands contour holes, creates local top/bottom skin instead of treating whole layers as solid, keeps
 * infill out of local skin regions, provides a narrow-region gap-fill fallback, and exposes travel moves to preview.
 */
object ToolpathEngine {
    private const val EPS = 1e-4f
    private const val MIN_PATH_MM = 0.05f

    fun plan(slice: SliceResult, config: PrintConfiguration): ToolpathResult {
        config.validate()
        if (slice.layers.isEmpty()) return ToolpathResult(emptyList(), PrintEstimate(0f,0f,0f,0))
        val lineWidth = config.printer.nozzleDiameter * 1.05f
        val p = config.process
        val layers = ArrayList<ToolpathLayer>(slice.layers.size)
        val supportByLayer = if (p.supportEnabled) SupportPlanner.plan(slice, lineWidth, p.supportOverhangDeg, p.supportStyle) else emptyMap()
        val regionIndex = LayerRegionIndex(slice)
        val warnings = mutableListOf<String>()
        if(slice.openPathCount>0)warnings += "${slice.openPathCount} open contour(s) detected; G-code export is blocked until repaired."

        slice.layers.forEachIndexed { index, layer ->
            val paths = mutableListOf<Toolpath>()
            val height = if (index == 0) p.firstLayerHeightMm else p.layerHeightMm
            val firstLayerSpeed = 25f
            fun cappedSpeed(requested:Float):Float {
                val volumetricCap=config.filament.maxVolumetricSpeedMm3s/(lineWidth*height).coerceAtLeast(0.01f)
                return min(requested,volumetricCap).coerceAtLeast(5f)
            }
            val outerWallSpeed = cappedSpeed(if (index == 0) firstLayerSpeed else 45f)
            val innerWallSpeed = cappedSpeed(if (index == 0) firstLayerSpeed else 65f)
            val fillSpeed = cappedSpeed(if (index == 0) firstLayerSpeed else 90f)
            val surfaceSpeed = cappedSpeed(if (index == 0) firstLayerSpeed else 55f)

            // Walls: normalized contour metadata means holes are offset into material (outward from the void).
            val wallPaths = mutableListOf<Pair<Int,Toolpath>>()
            for (loop in layer.loops) {
                val base = normalizeLoop(loop.points)
                if (base.size < 3) continue
                repeat(p.wallLoops) { wallIndex ->
                    val distance = lineWidth * (0.5f + wallIndex)
                    val offset = if(loop.isHole) PolygonOps.outset(base, distance) else PolygonOps.inset(base, distance)
                    if (offset.size >= 3 && abs(PolygonOps.area(offset)) > lineWidth * lineWidth * 0.2f) {
                        val role=if(wallIndex==0)PathRole.OUTER_WALL else PathRole.INNER_WALL
                        val speed=if(wallIndex==0)outerWallSpeed else innerWallSpeed
                        wallPaths += wallIndex to Toolpath(close(offset), role, true, lineWidth, speed)
                    }
                }
            }
            // Inner-to-outer wall ordering improves dimensional/surface consistency compared with arbitrary loop order.
            wallPaths.sortedByDescending { it.first }.forEach { paths += it.second }

            // Build a wall-cleared interior region for skin/infill. Holes grow while material outlines shrink.
            val fillInset = lineWidth * (p.wallLoops + 0.15f)
            val fillLoops=mutableListOf<SliceLoop>()
            for(loop in layer.loops){
                val base=normalizeLoop(loop.points)
                val offset=if(loop.isHole)PolygonOps.outset(base,fillInset)else PolygonOps.inset(base,fillInset)
                if(offset.size>=3 && abs(PolygonOps.area(offset))>lineWidth*lineWidth*0.1f){
                    fillLoops += SliceLoop(close(offset),loop.nestingDepth,loop.isHole)
                }
            }

            if(fillLoops.isNotEmpty()){
                val surfaces=SurfacePlanner.plan(slice,index,fillLoops,regionIndex,lineWidth,p)
                surfaces.bottom.forEach { paths += Toolpath(it,PathRole.BOTTOM_SURFACE,false,lineWidth,surfaceSpeed) }
                surfaces.top.forEach { paths += Toolpath(it,PathRole.TOP_SURFACE,false,lineWidth,surfaceSpeed) }
                surfaces.infill.forEach { paths += Toolpath(it,PathRole.INFILL,false,lineWidth,fillSpeed) }
            } else if(layer.loops.any{!it.isHole}) {
                // Narrow cross-sections can collapse after requested wall offsets. Fill them rather than silently leaving voids.
                val angle=if(index%2==0)45f else -45f
                val narrow=LineFill.generate(layer.loops,lineWidth*0.88f,angle)
                narrow.filter{polylineLength(it)>=MIN_PATH_MM}.forEach {
                    paths += Toolpath(it,PathRole.GAP_FILL,false,lineWidth,cappedSpeed(40f))
                }
            }

            supportByLayer[index]?.let { supportSegments ->
                supportSegments.filter{polylineLength(it)>=MIN_PATH_MM}.forEach { seg ->
                    paths += Toolpath(seg, PathRole.SUPPORT, false, lineWidth, cappedSpeed(55f))
                }
            }

            if (index == 0 && p.brimWidthMm > EPS) {
                val rings = ceil(p.brimWidthMm / lineWidth).toInt().coerceAtMost(40)
                for (loop in layer.loops.filter{!it.isHole}) {
                    val base = normalizeLoop(loop.points)
                    repeat(rings) { ring ->
                        val expanded = PolygonOps.outset(base, lineWidth * (0.5f + ring))
                        if (expanded.size >= 3) paths += Toolpath(close(expanded), PathRole.BRIM, true, lineWidth, cappedSpeed(firstLayerSpeed))
                    }
                }
            }

            val printable=paths.filter{it.closed || it.lengthMm>=MIN_PATH_MM}
            val ordered=optimizeTravelPhased(printable)
            layers += ToolpathLayer(index, layer.z, height, ordered, buildTravelMoves(ordered))
        }

        val estimate = estimate(layers, config)
        return ToolpathResult(layers, estimate, slice.openPathCount, warnings)
    }

    private fun normalizeLoop(points: List<Point2>): List<Point2> =
        if (points.size >= 2 && dist2(points.first(), points.last()) < EPS*EPS) points.dropLast(1) else points

    private fun close(points: List<Point2>): List<Point2> = if (points.isEmpty()) points else if(dist2(points.first(),points.last())<EPS*EPS)points else points + points.first()

    /** Preserve print-phase ordering while still applying cheap nearest-neighbour travel optimization inside each phase. */
    private fun optimizeTravelPhased(paths:List<Toolpath>):List<Toolpath>{
        if(paths.size<3)return paths
        val priority=listOf(
            PathRole.BRIM,
            PathRole.SUPPORT,PathRole.SUPPORT_INTERFACE,
            PathRole.INNER_WALL,
            PathRole.OUTER_WALL,
            PathRole.GAP_FILL,
            PathRole.BOTTOM_SURFACE,PathRole.TOP_SURFACE,
            PathRole.INFILL,
            PathRole.WALL,PathRole.SOLID
        )
        val out=ArrayList<Toolpath>(paths.size)
        var cursor=Point2(0f,0f)
        for(role in priority){
            val group=paths.filter{it.role==role}.toMutableList()
            while(group.isNotEmpty()){
                var best=0;var bestD=Float.POSITIVE_INFINITY;var reverse=false
                for(i in group.indices){
                    val path=group[i];if(path.points.isEmpty())continue
                    val d0=dist2(cursor,path.points.first())
                    val d1=if(!path.closed)dist2(cursor,path.points.last())else d0
                    if(min(d0,d1)<bestD){bestD=min(d0,d1);best=i;reverse=d1<d0}
                }
                var chosen=group.removeAt(best)
                if(reverse)chosen=chosen.copy(points=chosen.points.reversed())
                out+=chosen;if(chosen.points.isNotEmpty())cursor=chosen.points.last()
            }
        }
        // Future roles remain printable even if not added to the priority table.
        val seen=out.toHashSet();paths.filterNot{it in seen}.forEach{out+=it}
        return out
    }

    private fun buildTravelMoves(paths:List<Toolpath>):List<List<Point2>>{
        val out=mutableListOf<List<Point2>>();var last:Point2?=null
        for(path in paths){
            val first=path.points.firstOrNull()?:continue
            val prev=last
            if(prev!=null && dist2(prev,first)>0.02f*0.02f)out+=listOf(prev,first)
            last=path.points.lastOrNull()
        }
        return out
    }

    private fun estimate(layers: List<ToolpathLayer>, config: PrintConfiguration): PrintEstimate {
        val filamentArea = Math.PI * (config.printer.filamentDiameter/2f).pow(2).toDouble()
        var pathLength=0.0;var travelLength=0.0;var filamentLength=0.0;var seconds=0.0
        for (layer in layers) {
            travelLength+=layer.travelLengthMm
            seconds+=layer.travelLengthMm/150.0
            for (path in layer.paths) {
                if(path.points.size<2)continue
                val len=path.lengthMm.toDouble();pathLength+=len
                val volume=len*path.widthMm*layer.heightMm
                filamentLength += volume/filamentArea
                seconds += len/path.speedMmS.coerceAtLeast(1f)
            }
            seconds += 0.35
        }
        val filamentVolumeMm3=filamentLength*filamentArea
        val grams=filamentVolumeMm3/1000.0*config.filament.densityGcm3
        return PrintEstimate(pathLength.toFloat(),filamentLength.toFloat(),grams.toFloat(),ceil(seconds).toInt(),travelLength.toFloat())
    }

    private fun polylineLength(points:List<Point2>):Float=points.zipWithNext().sumOf{(a,b)->hypot((b.x-a.x).toDouble(),(b.y-a.y).toDouble())}.toFloat()
    private fun dist2(a:Point2,b:Point2):Float{val x=a.x-b.x;val y=a.y-b.y;return x*x+y*y}
}

/** Fast per-layer containment helper with per-loop bounding boxes. */
private class LayerRegionIndex(slice:SliceResult){
    private data class LoopBox(val loop:SliceLoop,val minX:Float,val minY:Float,val maxX:Float,val maxY:Float)
    private val layers=Array(slice.layers.size){i->
        slice.layers[i].loops.mapNotNull{loop->
            val pts=if(loop.points.size>1&&loop.points.first()==loop.points.last())loop.points.dropLast(1)else loop.points
            if(pts.size<3)null else LoopBox(loop,pts.minOf{it.x},pts.minOf{it.y},pts.maxOf{it.x},pts.maxOf{it.y})
        }
    }
    fun contains(layerIndex:Int,p:Point2):Boolean{
        if(layerIndex !in layers.indices)return false
        var inside=false
        for(box in layers[layerIndex]){
            if(p.x<box.minX||p.x>box.maxX||p.y<box.minY||p.y>box.maxY)continue
            val poly=if(box.loop.points.size>1&&box.loop.points.first()==box.loop.points.last())box.loop.points.dropLast(1)else box.loop.points
            if(pointInPolygon(p,poly))inside=!inside
        }
        return inside
    }
    private fun pointInPolygon(p:Point2,poly:List<Point2>):Boolean{
        var inside=false;var j=poly.lastIndex
        for(i in poly.indices){val a=poly[i];val b=poly[j];if(((a.y>p.y)!=(b.y>p.y))&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y+1e-20f)+a.x)inside=!inside;j=i}
        return inside
    }
}

/** Local skin classifier: dense lines only where a floor/ceiling exists; sparse infill elsewhere. */
private object SurfacePlanner{
    data class Result(val top:List<List<Point2>>,val bottom:List<List<Point2>>,val infill:List<List<Point2>>)
    private enum class Region{TOP,BOTTOM,INTERIOR}

    fun plan(slice:SliceResult,index:Int,fillLoops:List<SliceLoop>,regions:LayerRegionIndex,lineWidth:Float,p:ProcessProfile):Result{
        val top=mutableListOf<List<Point2>>();val bottom=mutableListOf<List<Point2>>();val infill=mutableListOf<List<Point2>>()
        val solidAngle=if(index%2==0)45f else -45f
        val chunk=max(2.5f,lineWidth*6f)
        val dense=LineFill.generate(fillLoops,lineWidth*0.92f,solidAngle)
        for(seg in dense){
            partition(seg,chunk){pt->classify(pt,index,slice.layers.lastIndex,regions,p)}.forEach{(role,line)->
                when(role){Region.TOP->top+=line;Region.BOTTOM->bottom+=line;Region.INTERIOR->Unit}
            }
        }
        if(p.infillPercent>0){
            val density=p.infillPercent.coerceIn(1,100)/100f
            val spacing=(lineWidth/density).coerceAtLeast(lineWidth)
            val angle=when(p.infillPattern.lowercase()){
                "grid"->if(index%2==0)0f else 90f
                "gyroid"->if(index%2==0)45f else -45f
                else->if(index%2==0)45f else -45f
            }
            for(seg in LineFill.generate(fillLoops,spacing,angle)){
                partition(seg,chunk){pt->classify(pt,index,slice.layers.lastIndex,regions,p)}.filter{it.first==Region.INTERIOR}.forEach{infill+=it.second}
            }
        }
        return Result(top,bottom,infill)
    }

    private fun classify(pt:Point2,index:Int,last:Int,regions:LayerRegionIndex,p:ProcessProfile):Region{
        var bottom=false
        if(p.bottomLayers>0){
            for(d in 1..p.bottomLayers){val li=index-d;if(li<0 || !regions.contains(li,pt)){bottom=true;break}}
        }
        var top=false
        if(p.topLayers>0){
            for(d in 1..p.topLayers){val li=index+d;if(li>last || !regions.contains(li,pt)){top=true;break}}
        }
        return when{top->Region.TOP;bottom->Region.BOTTOM;else->Region.INTERIOR}
    }

    /** Split only for classification, then merge adjacent chunks with the same region into long printable lines. */
    private fun partition(seg:List<Point2>,maxChunk:Float,classifier:(Point2)->Region):List<Pair<Region,List<Point2>>>{
        if(seg.size<2)return emptyList()
        val a=seg.first();val b=seg.last();val len=hypot((b.x-a.x).toDouble(),(b.y-a.y).toDouble()).toFloat()
        if(len<1e-5f)return emptyList()
        val count=ceil(len/maxChunk).toInt().coerceAtLeast(1)
        val out=mutableListOf<Pair<Region,List<Point2>>>()
        var active:Region?=null;var start=a;var end=a
        fun point(t:Float)=Point2(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t)
        for(i in 0 until count){
            val t0=i.toFloat()/count;val t1=(i+1).toFloat()/count
            val p0=point(t0);val p1=point(t1);val mid=point((t0+t1)*0.5f);val role=classifier(mid)
            if(active==role){end=p1}else{
                val old=active;if(old!=null && hypot((end.x-start.x).toDouble(),(end.y-start.y).toDouble())>0.04)out+=old to listOf(start,end)
                active=role;start=p0;end=p1
            }
        }
        val old=active;if(old!=null && hypot((end.x-start.x).toDouble(),(end.y-start.y).toDouble())>0.04)out+=old to listOf(start,end)
        return out
    }
}

object PolygonOps {
    private const val EPS=1e-6f
    fun area(poly:List<Point2>):Float{if(poly.size<3)return 0f;var a=0.0;for(i in poly.indices){val p=poly[i];val q=poly[(i+1)%poly.size];a+=p.x*q.y-q.x*p.y};return (a*0.5).toFloat()}
    fun inset(poly:List<Point2>,distance:Float)=offset(poly,distance)
    fun outset(poly:List<Point2>,distance:Float)=offset(poly,-distance)

    /** Mitered polygon offset. Falls back to averaged normals at near-parallel corners. */
    private fun offset(poly:List<Point2>, signedDistance:Float):List<Point2>{
        if(poly.size<3)return emptyList()
        val winding=if(area(poly)>=0f)1f else -1f
        val d=signedDistance*winding
        val out=ArrayList<Point2>(poly.size)
        for(i in poly.indices){
            val a=poly[(i-1+poly.size)%poly.size];val b=poly[i];val c=poly[(i+1)%poly.size]
            val l1=offsetLine(a,b,d);val l2=offsetLine(b,c,d)
            val x=intersection(l1.first,l1.second,l2.first,l2.second)
            if(x!=null && hypot((x.x-b.x).toDouble(),(x.y-b.y).toDouble()) <= abs(signedDistance)*8+2.0) out+=x
            else {
                val n1=normal(a,b);val n2=normal(b,c);var nx=n1.x+n2.x;var ny=n1.y+n2.y
                val len=hypot(nx.toDouble(),ny.toDouble()).toFloat().coerceAtLeast(EPS);nx/=len;ny/=len
                out+=Point2(b.x+nx*d,b.y+ny*d)
            }
        }
        // Reject a collapsed / flipped offset rather than emitting a self-crossing path.
        val a0=area(poly);val a1=area(out)
        if(abs(a1)<=EPS || sign(a0)!=sign(a1))return emptyList()
        val before=abs(a0);val after=abs(a1)
        // A valid inward offset cannot grow the polygon; a valid outward offset cannot shrink it.
        // Rejecting this common post-collapse inversion prevents bogus "inside-out" wall/fill regions.
        if(signedDistance>EPS && after>=before-EPS)return emptyList()
        if(signedDistance< -EPS && after<=before+EPS)return emptyList()
        return out
    }
    private fun normal(a:Point2,b:Point2):Point2{val dx=b.x-a.x;val dy=b.y-a.y;val l=hypot(dx.toDouble(),dy.toDouble()).toFloat().coerceAtLeast(EPS);return Point2(-dy/l,dx/l)}
    private fun offsetLine(a:Point2,b:Point2,d:Float):Pair<Point2,Point2>{val n=normal(a,b);return Point2(a.x+n.x*d,a.y+n.y*d) to Point2(b.x+n.x*d,b.y+n.y*d)}
    private fun intersection(a:Point2,b:Point2,c:Point2,d:Point2):Point2?{
        val x1=a.x;val y1=a.y;val x2=b.x;val y2=b.y;val x3=c.x;val y3=c.y;val x4=d.x;val y4=d.y
        val den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4);if(abs(den)<EPS)return null
        val p1=x1*y2-y1*x2;val p2=x3*y4-y3*x4
        return Point2((p1*(x3-x4)-(x1-x2)*p2)/den,(p1*(y3-y4)-(y1-y2)*p2)/den)
    }
}

object LineFill {
    private const val EPS=1e-5f
    /** Clips equally spaced lines against all contours using an even/odd fill rule, so holes remain empty. */
    fun generate(loops:List<SliceLoop>,spacing:Float,angleDeg:Float):List<List<Point2>>{
        if(loops.isEmpty()||spacing<=0f)return emptyList()
        val polys=loops.map { l -> if(l.points.size>1&&same(l.points.first(),l.points.last()))l.points.dropLast(1) else l.points }.filter{it.size>=3}
        if(polys.isEmpty())return emptyList()
        val angle=Math.toRadians(angleDeg.toDouble());val ca=cos(angle).toFloat();val sa=sin(angle).toFloat()
        fun rot(p:Point2)=Point2(p.x*ca+p.y*sa,-p.x*sa+p.y*ca)
        fun inv(p:Point2)=Point2(p.x*ca-p.y*sa,p.x*sa+p.y*ca)
        val rp=polys.map{it.map(::rot)}
        val minY=rp.minOf{p->p.minOf{it.y}};val maxY=rp.maxOf{p->p.maxOf{it.y}}
        val out=mutableListOf<List<Point2>>();var y=floor(minY/spacing)*spacing;var row=0
        while(y<=maxY+EPS){
            val xs=mutableListOf<Float>()
            for(poly in rp){
                for(i in poly.indices){val a=poly[i];val b=poly[(i+1)%poly.size]
                    if((a.y<=y&&b.y>y)||(b.y<=y&&a.y>y)){val t=(y-a.y)/(b.y-a.y);xs+=a.x+(b.x-a.x)*t}
                }
            }
            xs.sort();var i=0
            while(i+1<xs.size){val x0=xs[i];val x1=xs[i+1];if(x1-x0>EPS){val a=inv(Point2(x0,y));val b=inv(Point2(x1,y));out+=if(row%2==0)listOf(a,b)else listOf(b,a)};i+=2}
            y+=spacing;row++
        }
        return out
    }
    private fun same(a:Point2,b:Point2)=abs(a.x-b.x)<EPS&&abs(a.y-b.y)<EPS
}

/**
 * Memory-bounded raster support foundation. A compact adaptive boolean grid is used instead of object-heavy sets.
 * "Tree" mode gently merges columns toward the workspace centre while "Normal" keeps vertical columns.
 */
object SupportPlanner {
    fun plan(slice:SliceResult,lineWidth:Float,overhangDeg:Int,style:String="Tree"):Map<Int,List<List<Point2>>>{
        if(slice.layers.size<2)return emptyMap()
        val bounds=allBounds(slice)?:return emptyMap()
        val width=(bounds[2]-bounds[0]).coerceAtLeast(1f);val height=(bounds[3]-bounds[1]).coerceAtLeast(1f)
        val area=width*height
        val targetCellsPerLayer=min(12000,max(800,4_000_000/slice.layers.size))
        val adaptive=sqrt(area/targetCellsPerLayer.toFloat())
        val cell=max(max(1.2f,lineWidth*3f),adaptive)
        val nx=ceil(width/cell).toInt().coerceIn(1,512);val ny=ceil(height/cell).toInt().coerceIn(1,512)
        val cellCount=nx*ny
        val occupied=Array(slice.layers.size){BooleanArray(cellCount)}
        slice.layers.forEachIndexed{i,layer->rasterInto(layer.loops,bounds,cell,nx,ny,occupied[i])}
        val support=Array(slice.layers.size){BooleanArray(cellCount)}
        val angle=overhangDeg.coerceIn(1,89)
        val layerStep=(slice.layers.getOrNull(1)?.let{it.z-slice.layers[0].z}?:0.2f).coerceAtLeast(0.05f)
        val horizontalAllowance=max(cell,layerStep/tan(Math.toRadians(angle.toDouble())).toFloat())
        val radius=ceil(horizontalAllowance/cell).toInt().coerceIn(1,3)
        val targetX=((0f-bounds[0])/cell).roundToInt().coerceIn(0,nx-1)
        val targetY=((0f-bounds[1])/cell).roundToInt().coerceIn(0,ny-1)

        fun idx(x:Int,y:Int)=y*nx+x
        fun supportedBelow(x:Int,y:Int,below:BooleanArray):Boolean{
            for(dy in -radius..radius)for(dx in -radius..radius){val xx=x+dx;val yy=y+dy;if(xx in 0 until nx&&yy in 0 until ny&&below[idx(xx,yy)])return true}
            return false
        }
        for(i in 1 until occupied.size){
            val cur=occupied[i];val below=occupied[i-1]
            for(y in 0 until ny)for(x in 0 until nx){
                if(!cur[idx(x,y)]||supportedBelow(x,y,below))continue
                var cx=x;var cy=y
                for(j in i-1 downTo 0){
                    if(occupied[j][idx(cx,cy)])break
                    support[j][idx(cx,cy)]=true
                    if(style=="Tree"&&(i-j)%4==0){cx=(cx+stepToward(cx,targetX)).coerceIn(0,nx-1);cy=(cy+stepToward(cy,targetY)).coerceIn(0,ny-1)}
                }
            }
        }
        val out=mutableMapOf<Int,List<List<Point2>>>()
        support.forEachIndexed{i,grid->
            val segs=mutableListOf<List<Point2>>()
            for(y in 0 until ny)for(x in 0 until nx)if(grid[idx(x,y)]){
                val px=bounds[0]+(x+0.5f)*cell;val py=bounds[1]+(y+0.5f)*cell
                segs+=listOf(Point2(px-cell*0.34f,py),Point2(px+cell*0.34f,py))
            }
            if(segs.isNotEmpty())out[i]=segs
        }
        return out
    }
    private fun stepToward(v:Int,target:Int)=when{v<target->1;v>target->-1;else->0}
    private fun allBounds(slice:SliceResult):FloatArray?{val pts=slice.layers.flatMap{l->l.loops.flatMap{it.points}};if(pts.isEmpty())return null;return floatArrayOf(pts.minOf{it.x},pts.minOf{it.y},pts.maxOf{it.x},pts.maxOf{it.y})}
    private fun rasterInto(loops:List<SliceLoop>,b:FloatArray,cell:Float,nx:Int,ny:Int,out:BooleanArray){
        if(loops.isEmpty())return
        for(y in 0 until ny)for(x in 0 until nx){val p=Point2(b[0]+(x+0.5f)*cell,b[1]+(y+0.5f)*cell);if(insideEvenOdd(p,loops))out[y*nx+x]=true}
    }
    private fun insideEvenOdd(p:Point2,loops:List<SliceLoop>):Boolean{var inside=false;for(loop in loops){val poly=if(loop.points.size>1&&loop.points.first()==loop.points.last())loop.points.dropLast(1)else loop.points;if(poly.size<3)continue;var j=poly.lastIndex;for(i in poly.indices){val a=poly[i];val b=poly[j];if(((a.y>p.y)!=(b.y>p.y))&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y+1e-12f)+a.x)inside=!inside;j=i}};return inside}
}
