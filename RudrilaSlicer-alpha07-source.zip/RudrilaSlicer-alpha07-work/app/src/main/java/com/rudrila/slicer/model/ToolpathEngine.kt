package com.rudrila.slicer.model

import kotlin.math.*

enum class PathRole { WALL, SOLID, INFILL, SUPPORT, SUPPORT_INTERFACE, BRIM }

data class Toolpath(
    val points: List<Point2>,
    val role: PathRole,
    val closed: Boolean = false,
    val widthMm: Float,
    val speedMmS: Float
) {
    val lengthMm: Float by lazy {
        if (points.size < 2) 0f else points.zipWithNext().sumOf { (a,b) -> hypot((b.x-a.x).toDouble(), (b.y-a.y).toDouble()) }.toFloat()
    }
}

data class ToolpathLayer(
    val index: Int,
    val z: Float,
    val heightMm: Float,
    val paths: List<Toolpath>
)

data class PrintEstimate(
    val pathLengthMm: Float,
    val filamentLengthMm: Float,
    val filamentGrams: Float,
    val timeSeconds: Int
)

data class ToolpathResult(
    val layers: List<ToolpathLayer>,
    val estimate: PrintEstimate,
    val warningCount: Int = 0
) {
    val pathCount: Int get() = layers.sumOf { it.paths.size }
}

/**
 * Mobile-friendly deterministic toolpath planner.
 *
 * The planner intentionally has no Android dependency, so the exact same geometry code can be unit-tested on JVM.
 * It produces printable wall/solid/infill/support/brim paths from ContourSlicer output. Complex self-intersecting
 * polygon repair is still a release-gate item; simple and moderately concave manifold models are handled here.
 */
object ToolpathEngine {
    private const val EPS = 1e-4f

    fun plan(slice: SliceResult, config: PrintConfiguration): ToolpathResult {
        config.validate()
        if (slice.layers.isEmpty()) return ToolpathResult(emptyList(), PrintEstimate(0f,0f,0f,0))
        val lineWidth = config.printer.nozzleDiameter * 1.05f
        val p = config.process
        val layers = ArrayList<ToolpathLayer>(slice.layers.size)
        val supportByLayer = if (p.supportEnabled) SupportPlanner.plan(slice, lineWidth, p.supportOverhangDeg, p.supportStyle) else emptyMap()
        var warnings = slice.openPathCount

        slice.layers.forEachIndexed { index, layer ->
            val paths = mutableListOf<Toolpath>()
            val height = if (index == 0) p.firstLayerHeightMm else p.layerHeightMm
            val firstLayerSpeed = 25f
            fun cappedSpeed(requested:Float):Float {
                val volumetricCap=config.filament.maxVolumetricSpeedMm3s/(lineWidth*height).coerceAtLeast(0.01f)
                return min(requested,volumetricCap).coerceAtLeast(5f)
            }
            val wallSpeed = cappedSpeed(if (index == 0) firstLayerSpeed else 60f)
            val fillSpeed = cappedSpeed(if (index == 0) firstLayerSpeed else 90f)

            // Perimeters / walls. Offset each closed contour toward its own interior.
            for (loop in layer.loops) {
                val base = normalizeLoop(loop.points)
                if (base.size < 3) continue
                repeat(p.wallLoops) { wallIndex ->
                    val distance = lineWidth * (0.5f + wallIndex)
                    val inset = PolygonOps.inset(base, distance)
                    if (inset.size >= 3 && abs(PolygonOps.area(inset)) > lineWidth * lineWidth) {
                        paths += Toolpath(close(inset), PathRole.WALL, true, lineWidth, wallSpeed)
                    }
                }
            }

            // Bottom/top skin is global by layer in this milestone. Alternating direction reduces stress.
            val isBottom = index < p.bottomLayers
            val isTop = index >= slice.layers.size - p.topLayers
            if (isBottom || isTop) {
                val angle = if (index % 2 == 0) 45f else -45f
                val skin = LineFill.generate(layer.loops, spacing = lineWidth * 0.92f, angleDeg = angle)
                skin.forEach { paths += Toolpath(it, PathRole.SOLID, false, lineWidth, fillSpeed * 0.75f) }
            } else if (p.infillPercent > 0) {
                val density = p.infillPercent.coerceIn(1,100) / 100f
                val spacing = (lineWidth / density).coerceAtLeast(lineWidth)
                val angles = when (p.infillPattern.lowercase()) {
                    "grid" -> if (index % 2 == 0) listOf(0f) else listOf(90f)
                    "gyroid" -> listOf(if (index % 2 == 0) 45f else -45f) // continuous alternating diagonal approximation
                    else -> listOf(if (index % 2 == 0) 45f else -45f)
                }
                for (angle in angles) {
                    val infill = LineFill.generate(layer.loops, spacing, angle)
                    infill.forEach { paths += Toolpath(it, PathRole.INFILL, false, lineWidth, fillSpeed) }
                }
            }

            supportByLayer[index]?.let { supportSegments ->
                supportSegments.forEach { seg -> paths += Toolpath(seg, PathRole.SUPPORT, false, lineWidth, cappedSpeed(55f)) }
            }

            if (index == 0 && p.brimWidthMm > EPS) {
                val rings = ceil(p.brimWidthMm / lineWidth).toInt().coerceAtMost(40)
                for (loop in layer.loops) {
                    val base = normalizeLoop(loop.points)
                    repeat(rings) { ring ->
                        val expanded = PolygonOps.outset(base, lineWidth * (0.5f + ring))
                        if (expanded.size >= 3) paths += Toolpath(close(expanded), PathRole.BRIM, true, lineWidth, cappedSpeed(firstLayerSpeed))
                    }
                }
            }
            layers += ToolpathLayer(index, layer.z, height, optimizeTravel(paths))
        }

        val estimate = estimate(layers, config)
        return ToolpathResult(layers, estimate, warnings)
    }

    private fun normalizeLoop(points: List<Point2>): List<Point2> =
        if (points.size >= 2 && dist2(points.first(), points.last()) < EPS*EPS) points.dropLast(1) else points

    private fun close(points: List<Point2>): List<Point2> = if (points.isEmpty()) points else points + points.first()

    /** Nearest-neighbour ordering keeps travel reasonable without heavy TSP work on mobile. */
    private fun optimizeTravel(paths: List<Toolpath>): List<Toolpath> {
        if (paths.size < 3) return paths
        val remaining = paths.toMutableList()
        val out = ArrayList<Toolpath>(paths.size)
        var cursor = Point2(0f,0f)
        while (remaining.isNotEmpty()) {
            var best = 0
            var bestD = Float.POSITIVE_INFINITY
            var reverse = false
            for (i in remaining.indices) {
                val p = remaining[i]
                if (p.points.isEmpty()) continue
                val d0 = dist2(cursor,p.points.first())
                val d1 = if (!p.closed) dist2(cursor,p.points.last()) else d0
                if (min(d0,d1) < bestD) { bestD=min(d0,d1);best=i;reverse=d1<d0 }
            }
            var chosen = remaining.removeAt(best)
            if (reverse) chosen = chosen.copy(points=chosen.points.reversed())
            out += chosen
            if (chosen.points.isNotEmpty()) cursor=chosen.points.last()
        }
        return out
    }

    private fun estimate(layers: List<ToolpathLayer>, config: PrintConfiguration): PrintEstimate {
        val filamentArea = Math.PI * (config.printer.filamentDiameter/2f).pow(2).toDouble()
        var pathLength=0.0
        var filamentLength=0.0
        var seconds=0.0
        var last:Point2?=null
        for (layer in layers) {
            for (path in layer.paths) {
                if(path.points.size<2)continue
                last?.let { seconds += hypot((path.points.first().x-it.x).toDouble(),(path.points.first().y-it.y).toDouble()) / 150.0 }
                val len=path.lengthMm.toDouble();pathLength+=len
                val volume=len*path.widthMm*layer.heightMm
                filamentLength += volume/filamentArea
                seconds += len/path.speedMmS.coerceAtLeast(1f)
                last=path.points.last()
            }
            seconds += 0.35 // conservative Z/layer overhead
        }
        val filamentVolumeMm3=filamentLength*filamentArea
        val grams=filamentVolumeMm3/1000.0*config.filament.densityGcm3
        return PrintEstimate(pathLength.toFloat(),filamentLength.toFloat(),grams.toFloat(),ceil(seconds).toInt())
    }

    private fun dist2(a:Point2,b:Point2):Float{val x=a.x-b.x;val y=a.y-b.y;return x*x+y*y}
}

object PolygonOps {
    private const val EPS=1e-6f
    fun area(poly:List<Point2>):Float{
        if(poly.size<3)return 0f
        var a=0.0
        for(i in poly.indices){val p=poly[i];val q=poly[(i+1)%poly.size];a+=p.x*q.y-q.x*p.y}
        return (a*0.5).toFloat()
    }

    fun inset(poly:List<Point2>,distance:Float)=offset(poly,distance)
    fun outset(poly:List<Point2>,distance:Float)=offset(poly,-distance)

    /** Mitered polygon offset. Falls back to averaged normals at near-parallel corners. */
    private fun offset(poly:List<Point2>, signedDistance:Float):List<Point2>{
        if(poly.size<3)return emptyList()
        val winding=if(area(poly)>=0f)1f else -1f
        val d=signedDistance*winding
        val out=ArrayList<Point2>(poly.size)
        for(i in poly.indices){
            val a=poly[(i-1+poly.size)%poly.size];val b=poly[i];val c=poly[(i+1)%poly.size]
            val l1=offsetLine(a,b,d);val l2=offsetLine(b,c,d)
            val x=intersection(l1.first,l1.second,l2.first,l2.second)
            if(x!=null && hypot((x.x-b.x).toDouble(),(x.y-b.y).toDouble()) <= abs(signedDistance)*8+2.0) out+=x
            else {
                val n1=normal(a,b);val n2=normal(b,c);var nx=n1.x+n2.x;var ny=n1.y+n2.y
                val len=hypot(nx.toDouble(),ny.toDouble()).toFloat().coerceAtLeast(EPS);nx/=len;ny/=len
                out+=Point2(b.x+nx*d,b.y+ny*d)
            }
        }
        return if(abs(area(out))>EPS)out else emptyList()
    }
    private fun normal(a:Point2,b:Point2):Point2{val dx=b.x-a.x;val dy=b.y-a.y;val l=hypot(dx.toDouble(),dy.toDouble()).toFloat().coerceAtLeast(EPS);return Point2(-dy/l,dx/l)}
    private fun offsetLine(a:Point2,b:Point2,d:Float):Pair<Point2,Point2>{val n=normal(a,b);return Point2(a.x+n.x*d,a.y+n.y*d) to Point2(b.x+n.x*d,b.y+n.y*d)}
    private fun intersection(a:Point2,b:Point2,c:Point2,d:Point2):Point2?{
        val x1=a.x;val y1=a.y;val x2=b.x;val y2=b.y;val x3=c.x;val y3=c.y;val x4=d.x;val y4=d.y
        val den=(x1-x2)*(y3-y4)-(y1-y2)*(x3-x4);if(abs(den)<EPS)return null
        val p1=x1*y2-y1*x2;val p2=x3*y4-y3*x4
        return Point2((p1*(x3-x4)-(x1-x2)*p2)/den,(p1*(y3-y4)-(y1-y2)*p2)/den)
    }
}

object LineFill {
    private const val EPS=1e-5f
    /** Clips equally spaced lines against all contours using an even/odd fill rule, so holes remain empty. */
    fun generate(loops:List<SliceLoop>,spacing:Float,angleDeg:Float):List<List<Point2>>{
        if(loops.isEmpty()||spacing<=0f)return emptyList()
        val polys=loops.map { l -> if(l.points.size>1&&same(l.points.first(),l.points.last()))l.points.dropLast(1) else l.points }.filter{it.size>=3}
        if(polys.isEmpty())return emptyList()
        val angle=Math.toRadians(angleDeg.toDouble());val ca=cos(angle).toFloat();val sa=sin(angle).toFloat()
        fun rot(p:Point2)=Point2(p.x*ca+p.y*sa,-p.x*sa+p.y*ca)
        fun inv(p:Point2)=Point2(p.x*ca-p.y*sa,p.x*sa+p.y*ca)
        val rp=polys.map{it.map(::rot)}
        val minY=rp.minOf{p->p.minOf{it.y}};val maxY=rp.maxOf{p->p.maxOf{it.y}}
        val out=mutableListOf<List<Point2>>();var y=floor(minY/spacing)*spacing;var row=0
        while(y<=maxY+EPS){
            val xs=mutableListOf<Float>()
            for(poly in rp){
                for(i in poly.indices){val a=poly[i];val b=poly[(i+1)%poly.size]
                    if((a.y<=y&&b.y>y)||(b.y<=y&&a.y>y)){val t=(y-a.y)/(b.y-a.y);xs+=a.x+(b.x-a.x)*t}
                }
            }
            xs.sort();var i=0
            while(i+1<xs.size){val x0=xs[i];val x1=xs[i+1];if(x1-x0>EPS){val a=inv(Point2(x0,y));val b=inv(Point2(x1,y));out+=if(row%2==0)listOf(a,b)else listOf(b,a)};i+=2}
            y+=spacing;row++
        }
        return out
    }
    private fun same(a:Point2,b:Point2)=abs(a.x-b.x)<EPS&&abs(a.y-b.y)<EPS
}

/**
 * Memory-bounded raster support foundation. A compact adaptive boolean grid is used instead of object-heavy sets.
 * "Tree" mode gently merges columns toward the workspace centre while "Normal" keeps vertical columns.
 */
object SupportPlanner {
    fun plan(slice:SliceResult,lineWidth:Float,overhangDeg:Int,style:String="Tree"):Map<Int,List<List<Point2>>>{
        if(slice.layers.size<2)return emptyMap()
        val bounds=allBounds(slice)?:return emptyMap()
        val width=(bounds[2]-bounds[0]).coerceAtLeast(1f);val height=(bounds[3]-bounds[1]).coerceAtLeast(1f)
        val area=width*height
        val targetCellsPerLayer=min(12000,max(800,4_000_000/slice.layers.size))
        val adaptive=sqrt(area/targetCellsPerLayer.toFloat())
        val cell=max(max(1.2f,lineWidth*3f),adaptive)
        val nx=ceil(width/cell).toInt().coerceIn(1,512);val ny=ceil(height/cell).toInt().coerceIn(1,512)
        val cellCount=nx*ny
        val occupied=Array(slice.layers.size){BooleanArray(cellCount)}
        slice.layers.forEachIndexed{i,layer->rasterInto(layer.loops,bounds,cell,nx,ny,occupied[i])}
        val support=Array(slice.layers.size){BooleanArray(cellCount)}
        val angle=overhangDeg.coerceIn(1,89)
        val layerStep=(slice.layers.getOrNull(1)?.let{it.z-slice.layers[0].z}?:0.2f).coerceAtLeast(0.05f)
        val horizontalAllowance=max(cell,layerStep/tan(Math.toRadians(angle.toDouble())).toFloat())
        val radius=ceil(horizontalAllowance/cell).toInt().coerceIn(1,3)
        val targetX=((0f-bounds[0])/cell).roundToInt().coerceIn(0,nx-1)
        val targetY=((0f-bounds[1])/cell).roundToInt().coerceIn(0,ny-1)

        fun idx(x:Int,y:Int)=y*nx+x
        fun supportedBelow(x:Int,y:Int,below:BooleanArray):Boolean{
            for(dy in -radius..radius)for(dx in -radius..radius){val xx=x+dx;val yy=y+dy;if(xx in 0 until nx&&yy in 0 until ny&&below[idx(xx,yy)])return true}
            return false
        }
        for(i in 1 until occupied.size){
            val cur=occupied[i];val below=occupied[i-1]
            for(y in 0 until ny)for(x in 0 until nx){
                if(!cur[idx(x,y)]||supportedBelow(x,y,below))continue
                var cx=x;var cy=y
                for(j in i-1 downTo 0){
                    if(occupied[j][idx(cx,cy)])break
                    support[j][idx(cx,cy)]=true
                    if(style=="Tree"&&(i-j)%4==0){cx=(cx+stepToward(cx,targetX)).coerceIn(0,nx-1);cy=(cy+stepToward(cy,targetY)).coerceIn(0,ny-1)}
                }
            }
        }
        val out=mutableMapOf<Int,List<List<Point2>>>()
        support.forEachIndexed{i,grid->
            val segs=mutableListOf<List<Point2>>()
            for(y in 0 until ny)for(x in 0 until nx)if(grid[idx(x,y)]){
                val px=bounds[0]+(x+0.5f)*cell;val py=bounds[1]+(y+0.5f)*cell
                segs+=listOf(Point2(px-cell*0.34f,py),Point2(px+cell*0.34f,py))
            }
            if(segs.isNotEmpty())out[i]=segs
        }
        return out
    }
    private fun stepToward(v:Int,target:Int)=when{v<target->1;v>target->-1;else->0}
    private fun allBounds(slice:SliceResult):FloatArray?{val pts=slice.layers.flatMap{l->l.loops.flatMap{it.points}};if(pts.isEmpty())return null;return floatArrayOf(pts.minOf{it.x},pts.minOf{it.y},pts.maxOf{it.x},pts.maxOf{it.y})}
    private fun rasterInto(loops:List<SliceLoop>,b:FloatArray,cell:Float,nx:Int,ny:Int,out:BooleanArray){
        if(loops.isEmpty())return
        for(y in 0 until ny)for(x in 0 until nx){val p=Point2(b[0]+(x+0.5f)*cell,b[1]+(y+0.5f)*cell);if(insideEvenOdd(p,loops))out[y*nx+x]=true}
    }
    private fun insideEvenOdd(p:Point2,loops:List<SliceLoop>):Boolean{var inside=false;for(loop in loops){val poly=if(loop.points.size>1&&loop.points.first()==loop.points.last())loop.points.dropLast(1)else loop.points;if(poly.size<3)continue;var j=poly.lastIndex;for(i in poly.indices){val a=poly[i];val b=poly[j];if(((a.y>p.y)!=(b.y>p.y))&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y+1e-12f)+a.x)inside=!inside;j=i}};return inside}
}

