package com.rudrila.slicer.render

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.rudrila.slicer.model.Mesh
import com.rudrila.slicer.model.SceneObject
import com.rudrila.slicer.model.TransformMath
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.IdentityHashMap
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class SlicerRenderer : GLSurfaceView.Renderer {
    @Volatile private var scene: List<SceneObject> = emptyList()
    @Volatile var selectedId: Long? = null

    private data class GpuMesh(val vertices: FloatBuffer, val vertexCount: Int)
    private val gpuCache = IdentityHashMap<Mesh, GpuMesh>()

    private var program = 0
    private var gridProgram = 0
    private var gridBuffer: FloatBuffer? = null
    private var gridVertexCount = 0
    private var viewportW = 1
    private var viewportH = 1

    @Volatile var yaw = -35f
    @Volatile var pitch = 28f
    @Volatile var distance = 320f
    @Volatile var panX = 0f
    @Volatile var panY = 0f

    private val view = FloatArray(16)
    private val proj = FloatArray(16)
    private val modelM = FloatArray(16)
    private val mvp = FloatArray(16)
    private val vp = FloatArray(16)
    private val matrixLock = Any()

    fun setScene(value: List<SceneObject>, selected: Long?) {
        scene = value
        selectedId = selected
    }

    fun resetView() { yaw=-35f; pitch=28f; distance=320f; panX=0f; panY=0f }

    fun fitSceneToView() {
        val items = scene
        if (items.isEmpty()) return
        var span = 1f
        for (item in items) {
            val b = TransformMath.transformedBounds(item.mesh, item.transform)
            span = max(span, max(b.width, max(b.depth, b.height)))
        }
        distance = (span * 2.5f).coerceIn(120f, 1600f)
        panX = 0f; panY = 0f
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.055f,0.063f,0.071f,1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)
        program = GlUtil.createProgram(MESH_VERTEX, MESH_FRAGMENT)
        gridProgram = GlUtil.createProgram(GRID_VERTEX, GRID_FRAGMENT)
        buildGrid(256f,10f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportW=max(1,width); viewportH=max(1,height)
        GLES30.glViewport(0,0,width,height)
        val aspect=width.toFloat()/max(1,height).toFloat()
        synchronized(matrixLock){ Matrix.perspectiveM(proj,0,45f,aspect,1f,3000f) }
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        setupCamera()
        drawGrid()
        scene.forEach { drawObject(it, it.id == selectedId) }
    }

    private fun setupCamera() {
        val yr=Math.toRadians(yaw.toDouble()).toFloat(); val pr=Math.toRadians(pitch.toDouble()).toFloat(); val cp=cos(pr)
        val x=distance*cp*sin(yr)+panX; val y=-distance*cp*cos(yr)+panY; val z=distance*sin(pr)+90f
        synchronized(matrixLock){
            Matrix.setLookAtM(view,0,x,y,z,panX,panY,0f,0f,0f,1f)
            Matrix.multiplyMM(vp,0,proj,0,view,0)
        }
    }

    private fun drawObject(item: SceneObject, selected: Boolean) {
        val gpu = gpuCache[item.mesh] ?: buildPreviewMesh(item.mesh).also { gpuCache[item.mesh]=it }
        buildModelMatrix(item)
        synchronized(matrixLock){ Matrix.multiplyMM(mvp,0,vp,0,modelM,0) }
        GLES30.glUseProgram(program)
        val pos=GLES30.glGetAttribLocation(program,"aPos")
        GLES30.glEnableVertexAttribArray(pos); GLES30.glVertexAttribPointer(pos,3,GLES30.GL_FLOAT,false,0,gpu.vertices)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program,"uMvp"),1,false,mvp,0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program,"uModel"),1,false,modelM,0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program,"uSelected"),if(selected) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES,0,gpu.vertexCount)
        GLES30.glDisableVertexAttribArray(pos)
    }

    private fun buildPreviewMesh(mesh: Mesh): GpuMesh {
        val triangles = mesh.vertexCount / 3
        if (triangles <= MAX_PREVIEW_TRIANGLES) return GpuMesh(mesh.vertices.toDirectBuffer(), mesh.vertexCount)
        val stride = ceil(triangles.toDouble() / MAX_PREVIEW_TRIANGLES.toDouble()).toInt().coerceAtLeast(1)
        val sampledTriangles = (triangles + stride - 1) / stride
        val buffer = ByteBuffer.allocateDirect(sampledTriangles * 9 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        var t = 0
        while (t < triangles) {
            val base = t * 9
            for (i in 0 until 9) buffer.put(mesh.vertices[base + i])
            t += stride
        }
        buffer.position(0)
        return GpuMesh(buffer, sampledTriangles * 3)
    }

    private fun buildModelMatrix(item: SceneObject) {
        val m=item.mesh; val s=item.transform
        Matrix.setIdentityM(modelM,0)
        Matrix.translateM(modelM,0,s.x,s.y,s.z)
        Matrix.rotateM(modelM,0,s.rotationZ,0f,0f,1f)
        Matrix.rotateM(modelM,0,s.rotationY,0f,1f,0f)
        Matrix.rotateM(modelM,0,s.rotationX,1f,0f,0f)
        Matrix.scaleM(modelM,0,s.scale,s.scale,s.scale)
        Matrix.translateM(modelM,0,-m.centerX,-m.centerY,-m.minZ)
    }

    private fun drawGrid() {
        val gb=gridBuffer?:return
        Matrix.setIdentityM(modelM,0)
        synchronized(matrixLock){ Matrix.multiplyMM(mvp,0,vp,0,modelM,0) }
        GLES30.glUseProgram(gridProgram)
        val pos=GLES30.glGetAttribLocation(gridProgram,"aPos")
        GLES30.glEnableVertexAttribArray(pos); GLES30.glVertexAttribPointer(pos,3,GLES30.GL_FLOAT,false,0,gb)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(gridProgram,"uMvp"),1,false,mvp,0)
        GLES30.glDrawArrays(GLES30.GL_LINES,0,gridVertexCount); GLES30.glDisableVertexAttribArray(pos)
    }

    /** Returns closest object hit by a screen tap, or null if the ray misses every triangle. */
    fun pickObject(screenX: Float, screenY: Float): Long? {
        val ray = screenRay(screenX,screenY) ?: return null
        var best=Float.POSITIVE_INFINITY; var bestId:Long?=null
        for(item in scene){
            val hit=nearestTriangleHit(item,ray.first,ray.second)
            if(hit != null && hit.second<best){best=hit.second;bestId=item.id}
        }
        return bestId
    }

    /** Returns closest triangle index on currently selected object. */
    fun pickSelectedTriangle(screenX: Float, screenY: Float): Int? {
        val id=selectedId?:return null
        val item=scene.firstOrNull{it.id==id}?:return null
        val ray=screenRay(screenX,screenY)?:return null
        return nearestTriangleHit(item,ray.first,ray.second)?.first
    }

    private fun screenRay(sx:Float,sy:Float):Pair<FloatArray,FloatArray>?{
        val inverse=FloatArray(16); val vpCopy=FloatArray(16)
        synchronized(matrixLock){ System.arraycopy(vp,0,vpCopy,0,16) }
        if(!Matrix.invertM(inverse,0,vpCopy,0)) return null
        val nx=2f*sx/viewportW-1f; val ny=1f-2f*sy/viewportH
        val near=unproject(inverse,nx,ny,-1f); val far=unproject(inverse,nx,ny,1f)
        val d=floatArrayOf(far[0]-near[0],far[1]-near[1],far[2]-near[2])
        val len=sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]); if(len<1e-8f)return null
        d[0]/=len;d[1]/=len;d[2]/=len
        return near to d
    }

    private fun unproject(inv:FloatArray,x:Float,y:Float,z:Float):FloatArray{
        val src=floatArrayOf(x,y,z,1f); val out=FloatArray(4); Matrix.multiplyMV(out,0,inv,0,src,0)
        val w=if(abs(out[3])<1e-8f)1f else out[3]
        return floatArrayOf(out[0]/w,out[1]/w,out[2]/w)
    }

    private fun nearestTriangleHit(item:SceneObject,origin:FloatArray,dir:FloatArray):Pair<Int,Float>?{
        val count=item.mesh.vertexCount/3
        val stride=ceil(count.toDouble()/MAX_PICK_TRIANGLES.toDouble()).toInt().coerceAtLeast(1)
        var best=Float.POSITIVE_INFINITY; var bestTri=-1
        var t=0
        while(t<count){
            val base=t*9
            val a=TransformMath.transformedPoint(item.mesh,item.transform,base)
            val b=TransformMath.transformedPoint(item.mesh,item.transform,base+3)
            val c=TransformMath.transformedPoint(item.mesh,item.transform,base+6)
            val hit=rayTriangle(origin,dir,a,b,c)
            if(hit != null && hit<best){best=hit;bestTri=t}
            t += stride
        }
        return if(bestTri>=0) bestTri to best else null
    }

    private fun rayTriangle(o:FloatArray,d:FloatArray,a:FloatArray,b:FloatArray,c:FloatArray):Float?{
        val e1=floatArrayOf(b[0]-a[0],b[1]-a[1],b[2]-a[2]); val e2=floatArrayOf(c[0]-a[0],c[1]-a[1],c[2]-a[2])
        val p=cross(d,e2); val det=dot(e1,p); if(abs(det)<1e-7f)return null
        val inv=1f/det; val s=floatArrayOf(o[0]-a[0],o[1]-a[1],o[2]-a[2]); val u=dot(s,p)*inv
        if(u<0f||u>1f)return null
        val q=cross(s,e1); val v=dot(d,q)*inv; if(v<0f||u+v>1f)return null
        val t=dot(e2,q)*inv
        return if(t>1e-4f)t else null
    }
    private fun dot(a:FloatArray,b:FloatArray)=a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    private fun cross(a:FloatArray,b:FloatArray)=floatArrayOf(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])

    private fun buildGrid(size:Float,spacing:Float){
        val half=size/2f; val lines=(size/spacing).toInt()+1; val data=FloatArray(lines*12); var i=0; var p=-half
        repeat(lines){data[i++]=p;data[i++]=-half;data[i++]=0f;data[i++]=p;data[i++]=half;data[i++]=0f;data[i++]=-half;data[i++]=p;data[i++]=0f;data[i++]=half;data[i++]=p;data[i++]=0f;p+=spacing}
        gridBuffer=data.toDirectBuffer();gridVertexCount=data.size/3
    }
    private fun FloatArray.toDirectBuffer():FloatBuffer=ByteBuffer.allocateDirect(size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(this@toDirectBuffer);position(0)}

    companion object{
        private const val MAX_PREVIEW_TRIANGLES = 350_000
        private const val MAX_PICK_TRIANGLES = 200_000
        private const val MESH_VERTEX="""#version 300 es
            uniform mat4 uMvp; uniform mat4 uModel; in vec3 aPos; out vec3 vWorldPos;
            void main(){ vec4 world=uModel*vec4(aPos,1.0); vWorldPos=world.xyz; gl_Position=uMvp*vec4(aPos,1.0); }
        """
        private const val MESH_FRAGMENT="""#version 300 es
            precision mediump float; in vec3 vWorldPos; uniform float uSelected; out vec4 fragColor;
            void main(){ vec3 n=normalize(cross(dFdx(vWorldPos),dFdy(vWorldPos))); vec3 light=normalize(vec3(-0.35,-0.45,0.82)); float diff=max(dot(n,light),0.0); float rim=pow(1.0-max(abs(n.z),0.0),2.0)*0.15; vec3 normalBase=vec3(0.30,0.82,0.62); vec3 selectedBase=vec3(0.93,0.67,0.20); vec3 base=mix(normalBase,selectedBase,uSelected); fragColor=vec4(base*(0.30+0.70*diff)+rim,1.0); }
        """
        private const val GRID_VERTEX="""#version 300 es
            uniform mat4 uMvp; in vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0);}
        """
        private const val GRID_FRAGMENT="""#version 300 es
            precision mediump float; out vec4 fragColor; void main(){fragColor=vec4(0.30,0.34,0.37,0.70);}
        """
    }
}
