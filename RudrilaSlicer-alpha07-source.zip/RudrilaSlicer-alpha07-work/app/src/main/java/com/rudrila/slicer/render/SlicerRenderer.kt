package com.rudrila.slicer.render

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.rudrila.slicer.model.Mesh
import com.rudrila.slicer.model.SceneObject
import com.rudrila.slicer.model.TransformMath
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.IdentityHashMap
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class SlicerRenderer : GLSurfaceView.Renderer {
    @Volatile private var scene: List<SceneObject> = emptyList()
    @Volatile var selectedId: Long? = null

    private data class GpuMesh(val vbo: Int, val vertexCount: Int)
    private val gpuCache = IdentityHashMap<Mesh, GpuMesh>()
    private val pendingDeleteVbos = mutableListOf<Int>()

    private var program = 0
    private var gridProgram = 0
    private var gridBuffer: FloatBuffer? = null
    private var gridVertexCount = 0
    private var viewportW = 1
    private var viewportH = 1

    @Volatile var yaw = -35f
    @Volatile var pitch = 28f
    @Volatile var distance = 320f
    @Volatile var panX = 0f
    @Volatile var panY = 0f
    @Volatile var targetZ = 0f

    private val view = FloatArray(16)
    private val proj = FloatArray(16)
    private val modelM = FloatArray(16)
    private val mvp = FloatArray(16)
    private val vp = FloatArray(16)
    private val matrixLock = Any()

    fun setScene(value: List<SceneObject>, selected: Long?) {
        scene = value
        selectedId = selected
        val keep = value.map { it.mesh }
        val it = gpuCache.entries.iterator()
        while (it.hasNext()) {
            val entry = it.next()
            if (keep.none { candidate -> candidate === entry.key }) {
                synchronized(pendingDeleteVbos) { pendingDeleteVbos += entry.value.vbo }
                it.remove()
            }
        }
    }

    fun resetView() { yaw=-35f; pitch=28f; distance=320f; panX=0f; panY=0f; targetZ=0f }

    fun fitSceneToView() {
        val items = scene
        if (items.isEmpty()) return
        var minX=Float.POSITIVE_INFINITY; var minY=Float.POSITIVE_INFINITY; var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY; var maxY=Float.NEGATIVE_INFINITY; var maxZ=Float.NEGATIVE_INFINITY
        for (item in items) {
            val b = TransformMath.transformedBoundsFast(item.mesh, item.transform)
            minX=min(minX,b.minX); minY=min(minY,b.minY); minZ=min(minZ,b.minZ)
            maxX=max(maxX,b.maxX); maxY=max(maxY,b.maxY); maxZ=max(maxZ,b.maxZ)
        }
        if (!minX.isFinite()) return
        val span = max(1f, max(maxX-minX, max(maxY-minY, maxZ-minZ)))
        panX = (minX+maxX)*0.5f
        panY = (minY+maxY)*0.5f
        targetZ = (minZ+maxZ)*0.5f
        distance = (span * 2.15f).coerceIn(95f, 1800f)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.055f,0.063f,0.071f,1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        // STL files often contain mixed triangle winding. Bambu-style preview must remain solid
        // even when faces are not consistently oriented, so render both sides.
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        gpuCache.clear() // GL context may have been recreated; old VBO ids are no longer valid.
        // A shader compile error must never kill the entire Android app.
        // Keep the workspace usable and log the failure so import/slicing can still be tested.
        program = try { GlUtil.createProgram(MESH_VERTEX, MESH_FRAGMENT) } catch (t: Throwable) {
            Log.e("RudrilaSlicer", "Mesh shader init failed", t)
            0
        }
        gridProgram = try { GlUtil.createProgram(GRID_VERTEX, GRID_FRAGMENT) } catch (t: Throwable) {
            Log.e("RudrilaSlicer", "Grid shader init failed; continuing without grid", t)
            0
        }
        if (gridProgram != 0) buildGrid(256f,10f)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportW=max(1,width); viewportH=max(1,height)
        GLES30.glViewport(0,0,width,height)
        val aspect=width.toFloat()/max(1,height).toFloat()
        synchronized(matrixLock){ Matrix.perspectiveM(proj,0,45f,aspect,1f,3000f) }
    }

    override fun onDrawFrame(gl: GL10?) {
        deletePendingVbos()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        setupCamera()
        if (gridProgram != 0) drawGrid()
        if (program != 0) scene.forEach { drawObject(it, it.id == selectedId) }
    }

    private fun setupCamera() {
        val yr=Math.toRadians(yaw.toDouble()).toFloat(); val pr=Math.toRadians(pitch.toDouble()).toFloat(); val cp=cos(pr)
        val x=distance*cp*sin(yr)+panX; val y=-distance*cp*cos(yr)+panY; val z=distance*sin(pr)+targetZ
        synchronized(matrixLock){
            Matrix.setLookAtM(view,0,x,y,z,panX,panY,targetZ,0f,0f,1f)
            Matrix.multiplyMM(vp,0,proj,0,view,0)
        }
    }

    private fun drawObject(item: SceneObject, selected: Boolean) {
        val gpu = gpuCache[item.mesh] ?: buildGpuMesh(item.mesh).also { gpuCache[item.mesh]=it }
        buildModelMatrix(item)
        synchronized(matrixLock){ Matrix.multiplyMM(mvp,0,vp,0,modelM,0) }
        GLES30.glUseProgram(program)
        val pos=GLES30.glGetAttribLocation(program,"aPos")
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,gpu.vbo)
        GLES30.glEnableVertexAttribArray(pos)
        GLES30.glVertexAttribPointer(pos,3,GLES30.GL_FLOAT,false,0,0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program,"uMvp"),1,false,mvp,0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program,"uModel"),1,false,modelM,0)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(program,"uSelected"),if(selected) 1f else 0f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES,0,gpu.vertexCount)
        GLES30.glDisableVertexAttribArray(pos)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,0)
    }

    /**
     * Keep the original triangle surface for normal large STL files instead of dropping ~94% of
     * triangles. The data is streamed to a GPU VBO in 1 MiB chunks, so there is no second
     * 110+ MiB direct-buffer copy on the Android heap/native side. Duplicates reuse this VBO.
     */
    private fun buildGpuMesh(mesh: Mesh): GpuMesh {
        val triangleCount=mesh.vertexCount/3
        if(triangleCount<=MAX_FULL_PREVIEW_TRIANGLES){
            tryUpload(mesh.vertices)?.let{return GpuMesh(it,mesh.vertexCount)}
            Log.w("RudrilaSlicer","Full-fidelity GPU preview allocation failed; using safe preview")
        }
        val step=ceil(triangleCount.toDouble()/SAFE_PREVIEW_TRIANGLES.toDouble()).toInt().coerceAtLeast(1)
        val previewTriangles=(triangleCount+step-1)/step
        val floats=FloatArray(previewTriangles*9)
        var out=0;var tri=0
        while(tri<triangleCount){
            val base=tri*9
            System.arraycopy(mesh.vertices,base,floats,out,9)
            out+=9;tri+=step
        }
        val used=if(out==floats.size)floats else floats.copyOf(out)
        val vbo=tryUpload(used) ?: error("OpenGL could not allocate preview mesh")
        return GpuMesh(vbo,used.size/3)
    }

    private fun tryUpload(vertices:FloatArray):Int?{
        drainGlErrors()
        val ids=IntArray(1)
        GLES30.glGenBuffers(1,ids,0)
        if(ids[0]==0)return null
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,ids[0])
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER,vertices.size*4,null,GLES30.GL_STATIC_DRAW)
        if(GLES30.glGetError()!=GLES30.GL_NO_ERROR){
            GLES30.glDeleteBuffers(1,ids,0);GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,0);return null
        }
        val chunk=ByteBuffer.allocateDirect(UPLOAD_CHUNK_FLOATS*4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        var offset=0
        while(offset<vertices.size){
            val n=min(UPLOAD_CHUNK_FLOATS,vertices.size-offset)
            chunk.clear();chunk.put(vertices,offset,n);chunk.flip()
            GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER,offset*4,n*4,chunk)
            if(GLES30.glGetError()!=GLES30.GL_NO_ERROR){
                GLES30.glDeleteBuffers(1,ids,0);GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,0);return null
            }
            offset+=n
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER,0)
        return ids[0]
    }

    private fun drainGlErrors(){while(GLES30.glGetError()!=GLES30.GL_NO_ERROR){}}

    private fun deletePendingVbos(){
        val ids=synchronized(pendingDeleteVbos){if(pendingDeleteVbos.isEmpty())return;val a=pendingDeleteVbos.toIntArray();pendingDeleteVbos.clear();a}
        GLES30.glDeleteBuffers(ids.size,ids,0)
    }

    private fun buildModelMatrix(item: SceneObject) {
        val m=item.mesh; val s=item.transform
        Matrix.setIdentityM(modelM,0)
        Matrix.translateM(modelM,0,s.x,s.y,s.z)
        Matrix.rotateM(modelM,0,s.rotationZ,0f,0f,1f)
        Matrix.rotateM(modelM,0,s.rotationY,0f,1f,0f)
        Matrix.rotateM(modelM,0,s.rotationX,1f,0f,0f)
        Matrix.scaleM(modelM,0,s.scale,s.scale,s.scale)
        Matrix.translateM(modelM,0,-m.centerX,-m.centerY,-m.minZ)
    }

    private fun drawGrid() {
        val gb=gridBuffer?:return
        Matrix.setIdentityM(modelM,0)
        synchronized(matrixLock){ Matrix.multiplyMM(mvp,0,vp,0,modelM,0) }
        GLES30.glUseProgram(gridProgram)
        val pos=GLES30.glGetAttribLocation(gridProgram,"aPos")
        GLES30.glEnableVertexAttribArray(pos); GLES30.glVertexAttribPointer(pos,3,GLES30.GL_FLOAT,false,0,gb)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(gridProgram,"uMvp"),1,false,mvp,0)
        GLES30.glDrawArrays(GLES30.GL_LINES,0,gridVertexCount); GLES30.glDisableVertexAttribArray(pos)
    }

    /** Fast object selection uses conservative transformed AABBs, avoiding million-triangle UI-thread scans. */
    fun pickObject(screenX: Float, screenY: Float): Long? {
        val ray = screenRay(screenX,screenY) ?: return null
        var best=Float.POSITIVE_INFINITY; var bestId:Long?=null
        for(item in scene){
            val b=TransformMath.transformedBoundsFast(item.mesh,item.transform)
            val hit=rayAabbDistance(ray.first,ray.second,b)
            if(hit != null && hit<best){best=hit;bestId=item.id}
        }
        return bestId
    }

    /** Face picking is sampled on very large meshes so a tap cannot block Android's UI watchdog. */
    fun pickSelectedTriangle(screenX: Float, screenY: Float): Int? {
        val id=selectedId?:return null
        val item=scene.firstOrNull{it.id==id}?:return null
        val ray=screenRay(screenX,screenY)?:return null
        return nearestTriangleHit(item,ray.first,ray.second)?.first
    }

    fun screenToPlane(screenX:Float,screenY:Float,planeZ:Float=0f):Pair<Float,Float>?{
        val ray=screenRay(screenX,screenY)?:return null
        val dz=ray.second[2]
        if(abs(dz)<1e-6f)return null
        val t=(planeZ-ray.first[2])/dz
        if(t<0f)return null
        return (ray.first[0]+ray.second[0]*t) to (ray.first[1]+ray.second[1]*t)
    }

    private fun screenRay(sx:Float,sy:Float):Pair<FloatArray,FloatArray>?{
        val inverse=FloatArray(16); val vpCopy=FloatArray(16)
        synchronized(matrixLock){ System.arraycopy(vp,0,vpCopy,0,16) }
        if(!Matrix.invertM(inverse,0,vpCopy,0)) return null
        val nx=2f*sx/viewportW-1f; val ny=1f-2f*sy/viewportH
        val near=unproject(inverse,nx,ny,-1f); val far=unproject(inverse,nx,ny,1f)
        val d=floatArrayOf(far[0]-near[0],far[1]-near[1],far[2]-near[2])
        val len=sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]); if(len<1e-8f)return null
        d[0]/=len;d[1]/=len;d[2]/=len
        return near to d
    }

    private fun unproject(inv:FloatArray,x:Float,y:Float,z:Float):FloatArray{
        val src=floatArrayOf(x,y,z,1f); val out=FloatArray(4); Matrix.multiplyMV(out,0,inv,0,src,0)
        val w=if(abs(out[3])<1e-8f)1f else out[3]
        return floatArrayOf(out[0]/w,out[1]/w,out[2]/w)
    }

    private fun rayAabbDistance(o:FloatArray,d:FloatArray,b:com.rudrila.slicer.model.Bounds3):Float?{
        var tMin=0f;var tMax=Float.POSITIVE_INFINITY
        fun axis(origin:Float,dir:Float,minV:Float,maxV:Float):Boolean{
            if(abs(dir)<1e-8f)return origin in minV..maxV
            var a=(minV-origin)/dir;var c=(maxV-origin)/dir
            if(a>c){val t=a;a=c;c=t}
            tMin=max(tMin,a);tMax=min(tMax,c);return tMax>=tMin
        }
        if(!axis(o[0],d[0],b.minX,b.maxX))return null
        if(!axis(o[1],d[1],b.minY,b.maxY))return null
        if(!axis(o[2],d[2],b.minZ,b.maxZ))return null
        return if(tMax>=max(0f,tMin))max(0f,tMin) else null
    }

    private fun nearestTriangleHit(item:SceneObject,origin:FloatArray,dir:FloatArray):Pair<Int,Float>?{
        val count=item.mesh.vertexCount/3
        if(count<=0)return null
        val step=ceil(count.toDouble()/MAX_FACE_PICK_TRIANGLES.toDouble()).toInt().coerceAtLeast(1)
        val mm=FloatArray(16)
        Matrix.setIdentityM(mm,0)
        val s=item.transform;val m=item.mesh
        Matrix.translateM(mm,0,s.x,s.y,s.z)
        Matrix.rotateM(mm,0,s.rotationZ,0f,0f,1f)
        Matrix.rotateM(mm,0,s.rotationY,0f,1f,0f)
        Matrix.rotateM(mm,0,s.rotationX,1f,0f,0f)
        Matrix.scaleM(mm,0,s.scale,s.scale,s.scale)
        Matrix.translateM(mm,0,-m.centerX,-m.centerY,-m.minZ)
        val a=FloatArray(3);val b=FloatArray(3);val c=FloatArray(3)
        var best=Float.POSITIVE_INFINITY;var bestTri=-1;var t=0
        while(t<count){
            val base=t*9
            transformRaw(m.vertices,base,mm,a);transformRaw(m.vertices,base+3,mm,b);transformRaw(m.vertices,base+6,mm,c)
            val hit=rayTriangle(origin,dir,a,b,c)
            if(hit!=null&&hit<best){best=hit;bestTri=t}
            t+=step
        }
        return if(bestTri>=0)bestTri to best else null
    }

    private fun transformRaw(v:FloatArray,i:Int,m:FloatArray,out:FloatArray){
        val x=v[i];val y=v[i+1];val z=v[i+2]
        out[0]=m[0]*x+m[4]*y+m[8]*z+m[12]
        out[1]=m[1]*x+m[5]*y+m[9]*z+m[13]
        out[2]=m[2]*x+m[6]*y+m[10]*z+m[14]
    }

    private fun rayTriangle(o:FloatArray,d:FloatArray,a:FloatArray,b:FloatArray,c:FloatArray):Float?{
        val e1x=b[0]-a[0];val e1y=b[1]-a[1];val e1z=b[2]-a[2]
        val e2x=c[0]-a[0];val e2y=c[1]-a[1];val e2z=c[2]-a[2]
        val px=d[1]*e2z-d[2]*e2y;val py=d[2]*e2x-d[0]*e2z;val pz=d[0]*e2y-d[1]*e2x
        val det=e1x*px+e1y*py+e1z*pz;if(abs(det)<1e-7f)return null
        val inv=1f/det;val sx=o[0]-a[0];val sy=o[1]-a[1];val sz=o[2]-a[2]
        val u=(sx*px+sy*py+sz*pz)*inv;if(u<0f||u>1f)return null
        val qx=sy*e1z-sz*e1y;val qy=sz*e1x-sx*e1z;val qz=sx*e1y-sy*e1x
        val vv=(d[0]*qx+d[1]*qy+d[2]*qz)*inv;if(vv<0f||u+vv>1f)return null
        val hit=(e2x*qx+e2y*qy+e2z*qz)*inv
        return if(hit>1e-4f)hit else null
    }
    private fun dot(a:FloatArray,b:FloatArray)=a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    private fun cross(a:FloatArray,b:FloatArray)=floatArrayOf(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])

    private fun buildGrid(size:Float,spacing:Float){
        val half=size/2f; val lines=(size/spacing).toInt()+1; val data=FloatArray(lines*12); var i=0; var p=-half
        repeat(lines){data[i++]=p;data[i++]=-half;data[i++]=0f;data[i++]=p;data[i++]=half;data[i++]=0f;data[i++]=-half;data[i++]=p;data[i++]=0f;data[i++]=half;data[i++]=p;data[i++]=0f;p+=spacing}
        gridBuffer=data.toDirectBuffer();gridVertexCount=data.size/3
    }
    private fun FloatArray.toDirectBuffer():FloatBuffer=ByteBuffer.allocateDirect(size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(this@toDirectBuffer);position(0)}

    companion object{
        private const val MAX_FULL_PREVIEW_TRIANGLES = 3_500_000
        private const val SAFE_PREVIEW_TRIANGLES = 300_000
        private const val MAX_FACE_PICK_TRIANGLES = 120_000
        private const val UPLOAD_CHUNK_FLOATS = 262_144
        private const val MESH_VERTEX="""#version 300 es
            uniform mat4 uMvp; uniform mat4 uModel; in vec3 aPos; out vec3 vWorldPos;
            void main(){ vec4 world=uModel*vec4(aPos,1.0); vWorldPos=world.xyz; gl_Position=uMvp*world; }
        """
        private const val MESH_FRAGMENT="""#version 300 es
            precision mediump float; in vec3 vWorldPos; uniform float uSelected; out vec4 fragColor;
            void main(){ vec3 n=normalize(cross(dFdx(vWorldPos),dFdy(vWorldPos))); if(!gl_FrontFacing)n=-n; vec3 light=normalize(vec3(-0.35,-0.45,0.82)); float diff=max(dot(n,light),0.0); float rim=pow(1.0-max(abs(n.z),0.0),2.0)*0.12; vec3 normalBase=vec3(0.30,0.82,0.62); vec3 selectedBase=vec3(0.93,0.67,0.20); vec3 base=mix(normalBase,selectedBase,uSelected); fragColor=vec4(base*(0.32+0.68*diff)+rim,1.0); }
        """
        private const val GRID_VERTEX="""#version 300 es
            uniform mat4 uMvp; in vec3 aPos; void main(){gl_Position=uMvp*vec4(aPos,1.0);}
        """
        private const val GRID_FRAGMENT="""#version 300 es
            precision mediump float; out vec4 fragColor; void main(){fragColor=vec4(0.30,0.34,0.37,0.70);}
        """
    }
}
