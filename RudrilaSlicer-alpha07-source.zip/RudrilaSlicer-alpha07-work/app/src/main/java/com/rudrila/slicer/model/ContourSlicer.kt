package com.rudrila.slicer.model

import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Compact 2D point used by contour/toolpath stages. */
data class Point2(val x: Float, val y: Float)
data class SliceLoop(val points: List<Point2>)
data class SliceLayer(val index: Int, val z: Float, val loops: List<SliceLoop>, val openPaths: List<List<Point2>>)
data class SliceResult(val layers: List<SliceLayer>, val sourceObjectCount: Int) {
    val layerCount get() = layers.size
    val closedLoopCount get() = layers.sumOf { it.loops.size }
    val openPathCount get() = layers.sumOf { it.openPaths.size }
}

data class SliceSummary(val layerCount: Int, val sourceObjectCount: Int, val openPathCount: Int)

/**
 * Exact horizontal contour slicer with bounded working memory.
 *
 * Alpha 0.8 retained a transformed copy of every vertex plus object-heavy Segment/Point objects for every
 * layer at once. A multi-million-triangle STL could therefore exhaust Android's heap. Alpha 0.9 keeps the
 * source mesh once, transforms triangle coordinates into scalar locals, and processes layers in chunks using
 * primitive float buffers. Completed layers are emitted immediately through [sliceEach].
 */
object ContourSlicer {
    private const val EPS = 1e-5f
    private const val JOIN_TOL = 0.02f
    private const val LAYERS_PER_CHUNK = 128

    fun slice(objects: List<SceneObject>, process: ProcessProfile): SliceResult {
        val layers = ArrayList<SliceLayer>()
        val summary = sliceEach(objects, process) { layer, _ -> layers += layer }
        return SliceResult(layers, summary.sourceObjectCount)
    }

    /**
     * Streams exact layers in index order. Only a bounded chunk of primitive intersection segments is live.
     * The callback is invoked on the caller's thread and must not retain the source mesh indirectly.
     */
    fun sliceEach(
        objects: List<SceneObject>,
        process: ProcessProfile,
        onLayer: (SliceLayer, totalLayerCount: Int) -> Unit
    ): SliceSummary {
        require(objects.isNotEmpty()) { "No models on plate" }
        process.validate()

        val prepared = objects.map { PreparedObject(it) }
        var maxZ = Float.NEGATIVE_INFINITY
        for (obj in objects) maxZ = max(maxZ, TransformMath.transformedBounds(obj.mesh, obj.transform).maxZ)
        maxZ = maxZ.coerceAtLeast(0f)
        if (maxZ <= EPS) return SliceSummary(0, objects.size, 0)

        val first = min(process.firstLayerHeightMm, maxZ)
        val step = process.layerHeightMm
        val count = (floor((((maxZ - first) / step) + 1e-4f).toDouble()).toInt() + 1).coerceAtLeast(1)
        var openCount = 0

        var chunkStart = 0
        while (chunkStart < count) {
            val chunkEnd = min(count, chunkStart + LAYERS_PER_CHUNK)
            val buffers = Array(chunkEnd - chunkStart) { SegmentBuffer() }
            for (obj in prepared) {
                fillChunk(obj, first, step, chunkStart, chunkEnd, buffers)
            }

            for (globalLayer in chunkStart until chunkEnd) {
                val z = first + globalLayer * step
                val (loops, open) = stitch(buffers[globalLayer - chunkStart])
                openCount += open.size
                onLayer(SliceLayer(globalLayer, z, loops, open), count)
            }
            chunkStart = chunkEnd
        }
        return SliceSummary(count, objects.size, openCount)
    }

    private class PreparedObject(obj: SceneObject) {
        val mesh = obj.mesh
        val v = mesh.vertices
        val cx = mesh.centerX
        val cy = mesh.centerY
        val baseZ = mesh.minZ
        val scale = obj.transform.scale
        val tx = obj.transform.x
        val ty = obj.transform.y
        val tz = obj.transform.z

        // Rz * Ry * Rx, cached once for the entire slice.
        private val rx = Math.toRadians(obj.transform.rotationX.toDouble()).toFloat()
        private val ry = Math.toRadians(obj.transform.rotationY.toDouble()).toFloat()
        private val rz = Math.toRadians(obj.transform.rotationZ.toDouble()).toFloat()
        private val sx = sin(rx); private val cxr = cos(rx)
        private val sy = sin(ry); private val cyr = cos(ry)
        private val sz = sin(rz); private val czr = cos(rz)
        val m00 = czr*cyr
        val m01 = czr*sy*sx - sz*cxr
        val m02 = czr*sy*cxr + sz*sx
        val m10 = sz*cyr
        val m11 = sz*sy*sx + czr*cxr
        val m12 = sz*sy*cxr - czr*sx
        val m20 = -sy
        val m21 = cyr*sx
        val m22 = cyr*cxr
    }

    /** Primitive [ax, ay, bx, by] buffer: no per-segment heap objects. */
    private class SegmentBuffer(initialSegments: Int = 128) {
        var data = FloatArray(initialSegments * 4)
            private set
        var segmentCount = 0
            private set

        fun add(ax: Float, ay: Float, bx: Float, by: Float) {
            val need = (segmentCount + 1) * 4
            if (need > data.size) data = data.copyOf(max(need, data.size * 2))
            val i = segmentCount * 4
            data[i] = ax; data[i+1] = ay; data[i+2] = bx; data[i+3] = by
            segmentCount++
        }
    }

    private fun fillChunk(
        o: PreparedObject,
        first: Float,
        step: Float,
        chunkStart: Int,
        chunkEnd: Int,
        buffers: Array<SegmentBuffer>
    ) {
        val v = o.v
        val scratch = FloatArray(6) // reused for all triangle-edge intersections in this object/chunk
        var base = 0
        while (base + 8 < v.size) {
            val x0l = (v[base] - o.cx) * o.scale
            val y0l = (v[base+1] - o.cy) * o.scale
            val z0l = (v[base+2] - o.baseZ) * o.scale
            val x1l = (v[base+3] - o.cx) * o.scale
            val y1l = (v[base+4] - o.cy) * o.scale
            val z1l = (v[base+5] - o.baseZ) * o.scale
            val x2l = (v[base+6] - o.cx) * o.scale
            val y2l = (v[base+7] - o.cy) * o.scale
            val z2l = (v[base+8] - o.baseZ) * o.scale

            val x0 = o.m00*x0l + o.m01*y0l + o.m02*z0l + o.tx
            val y0 = o.m10*x0l + o.m11*y0l + o.m12*z0l + o.ty
            val z0 = o.m20*x0l + o.m21*y0l + o.m22*z0l + o.tz
            val x1 = o.m00*x1l + o.m01*y1l + o.m02*z1l + o.tx
            val y1 = o.m10*x1l + o.m11*y1l + o.m12*z1l + o.ty
            val z1 = o.m20*x1l + o.m21*y1l + o.m22*z1l + o.tz
            val x2 = o.m00*x2l + o.m01*y2l + o.m02*z2l + o.tx
            val y2 = o.m10*x2l + o.m11*y2l + o.m12*z2l + o.ty
            val z2 = o.m20*x2l + o.m21*y2l + o.m22*z2l + o.tz

            val lo = min(z0, min(z1, z2))
            val hi = max(z0, max(z1, z2))
            var start = ceil(((lo-first)/step).toDouble() - 1e-4).toInt().coerceAtLeast(chunkStart)
            val end = floor(((hi-first)/step).toDouble() + 1e-4).toInt().coerceAtMost(chunkEnd-1)
            if (end >= start) {
                while (start <= end) {
                    val z = first + start * step
                    val sectionZ = when {
                        z > hi && z-hi <= step*0.01f -> hi
                        z < lo && lo-z <= step*0.01f -> lo
                        else -> z
                    }
                    triangleSection(
                        x0,y0,z0, x1,y1,z1, x2,y2,z2,
                        sectionZ, buffers[start-chunkStart], scratch
                    )
                    start++
                }
            }
            base += 9
        }
    }

    private fun triangleSection(
        x0:Float,y0:Float,z0:Float,
        x1:Float,y1:Float,z1:Float,
        x2:Float,y2:Float,z2:Float,
        z:Float,
        out:SegmentBuffer,
        pts:FloatArray
    ) {
        var count = 0
        for (edge in 0..2) {
            val ax:Float; val ay:Float; val az:Float
            val bx:Float; val by:Float; val bz:Float
            when(edge) {
                0 -> { ax=x0; ay=y0; az=z0; bx=x1; by=y1; bz=z1 }
                1 -> { ax=x1; ay=y1; az=z1; bx=x2; by=y2; bz=z2 }
                else -> { ax=x2; ay=y2; az=z2; bx=x0; by=y0; bz=z0 }
            }
            if (kotlin.math.abs(az-z)<EPS && kotlin.math.abs(bz-z)<EPS) continue
            val crosses = (az < z && bz >= z) || (bz < z && az >= z)
            if (!crosses) continue
            val dz = bz-az
            if (kotlin.math.abs(dz)<EPS) continue
            val t=(z-az)/dz
            val px=ax+(bx-ax)*t
            val py=ay+(by-ay)*t
            var duplicate=false
            var j=0
            while(j<count){ val dx=pts[j*2]-px; val dy=pts[j*2+1]-py; if(dx*dx+dy*dy<EPS*EPS){duplicate=true;break}; j++ }
            if(!duplicate && count<3){pts[count*2]=px;pts[count*2+1]=py;count++}
        }
        if(count==2){
            val dx=pts[0]-pts[2]; val dy=pts[1]-pts[3]
            if(dx*dx+dy*dy>EPS*EPS) out.add(pts[0],pts[1],pts[2],pts[3])
        }
    }

    private class IntList {
        private var a = IntArray(2)
        var size = 0
            private set
        fun add(v:Int){ if(size==a.size)a=a.copyOf(a.size*2);a[size++]=v }
        fun firstUnused(used:BooleanArray):Int?{var i=0;while(i<size){val v=a[i];if(!used[v])return v;i++};return null}
    }

    private fun stitch(segments:SegmentBuffer):Pair<List<SliceLoop>,List<List<Point2>>>{
        val count=segments.segmentCount
        if(count==0)return emptyList<SliceLoop>() to emptyList()
        val d=segments.data
        val used=BooleanArray(count)
        val endpointMap=HashMap<Long,IntList>(count*2)
        fun add(k:Long,i:Int){endpointMap.getOrPut(k){IntList()}.add(i)}
        var i=0
        while(i<count){val b=i*4;add(key(d[b],d[b+1]),i);add(key(d[b+2],d[b+3]),i);i++}

        val loops=ArrayList<SliceLoop>()
        val open=ArrayList<List<Point2>>()
        for(seed in 0 until count){
            if(used[seed])continue
            used[seed]=true
            val sb=seed*4
            val sx=d[sb]; val sy=d[sb+1]; var cx=d[sb+2]; var cy=d[sb+3]
            val path=ArrayList<Point2>()
            path+=Point2(sx,sy);path+=Point2(cx,cy)
            val startKey=key(sx,sy)
            var currentKey=key(cx,cy)
            var guard=0
            while(currentKey!=startKey && guard++<count+4){
                val next=endpointMap[currentKey]?.firstUnused(used)?:break
                used[next]=true
                val nb=next*4
                val aKey=key(d[nb],d[nb+1])
                if(aKey==currentKey){cx=d[nb+2];cy=d[nb+3]}else{cx=d[nb];cy=d[nb+1]}
                path+=Point2(cx,cy);currentKey=key(cx,cy)
            }
            if(currentKey==startKey && path.size>=4){
                val firstP=path.first();val lastP=path.last();val dx=firstP.x-lastP.x;val dy=firstP.y-lastP.y
                if(dx*dx+dy*dy>JOIN_TOL*JOIN_TOL)path+=firstP
                loops+=SliceLoop(path)
            }else open+=path
        }
        return loops to open
    }

    private fun key(x:Float,y:Float):Long{
        val qx=(x/JOIN_TOL).roundToInt()
        val qy=(y/JOIN_TOL).roundToInt()
        return (qx.toLong() shl 32) xor (qy.toLong() and 0xffffffffL)
    }
}
