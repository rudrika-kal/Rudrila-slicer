package com.rudrila.slicer.model

import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** 2D point in centered build-plate coordinates. */
data class Point2(val x: Float, val y: Float)

/**
 * One closed contour. nestingDepth=0 is an outer shell, 1 is a hole, 2 is an island inside a hole, etc.
 * Keeping this classification in the slice result lets walls offset into printable material on both outer
 * boundaries and holes instead of blindly shrinking every ring.
 */
data class SliceLoop(val points: List<Point2>, val nestingDepth: Int = 0) {
    val isHole: Boolean get() = nestingDepth % 2 == 1
}

data class SliceLayer(
    val index: Int,
    val z: Float,
    val loops: List<SliceLoop>,
    val openPaths: List<List<Point2>>,
    val duplicateSegmentsRemoved: Int = 0,
    val degenerateSegmentsRemoved: Int = 0
)

data class SliceDiagnostics(
    val openPathCount: Int = 0,
    val layersWithOpenPaths: Int = 0,
    val duplicateSegmentsRemoved: Int = 0,
    val degenerateSegmentsRemoved: Int = 0
)

data class SliceResult(val layers: List<SliceLayer>, val sourceObjectCount: Int) {
    val layerCount get() = layers.size
    val closedLoopCount get() = layers.sumOf { it.loops.size }
    val openPathCount get() = layers.sumOf { it.openPaths.size }
    val diagnostics: SliceDiagnostics by lazy {
        SliceDiagnostics(
            openPathCount = openPathCount,
            layersWithOpenPaths = layers.count { it.openPaths.isNotEmpty() },
            duplicateSegmentsRemoved = layers.sumOf { it.duplicateSegmentsRemoved },
            degenerateSegmentsRemoved = layers.sumOf { it.degenerateSegmentsRemoved }
        )
    }
}

/**
 * Slice Engine V2 contour stage.
 *
 * Goals for this stage:
 *  - never duplicate the full transformed mesh (important for multi-million-triangle mobile imports)
 *  - deterministic horizontal triangle intersection
 *  - endpoint matching that survives hash-cell boundaries
 *  - duplicate / zero-length segment cleanup before polygon stitching
 *  - explicit outer/hole nesting classification for correct wall offsets
 *  - preserve open contours as a hard downstream safety gate instead of silently closing bad geometry
 */
object ContourSlicer {
    private const val EPS = 1e-5f
    private const val JOIN_TOL = 0.02f
    private const val DEDUP_TOL = 0.002f

    fun slice(objects: List<SceneObject>, process: ProcessProfile): SliceResult {
        require(objects.isNotEmpty()) { "No models on plate" }
        process.validate()
        val maxZ = objects.maxOf { TransformMath.transformedBounds(it.mesh, it.transform).maxZ }.coerceAtLeast(0f)
        if (maxZ <= EPS) return SliceResult(emptyList(), objects.size)

        val first = min(process.firstLayerHeightMm, maxZ)
        val step = process.layerHeightMm
        val count = (floor((((maxZ - first) / step) + 1e-4f).toDouble()).toInt() + 1).coerceAtLeast(1)
        val segmentsByLayer = Array(count) { mutableListOf<Segment>() }

        for (obj in objects) {
            val source = obj.mesh.vertices
            val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
            val worldTri = FloatArray(9)
            var base = 0
            while (base + 8 < source.size) {
                tx.write(base, worldTri, 0)
                tx.write(base + 3, worldTri, 3)
                tx.write(base + 6, worldTri, 6)
                val z0 = worldTri[2]; val z1 = worldTri[5]; val z2 = worldTri[8]
                val lo = min(z0, min(z1, z2)); val hi = max(z0, max(z1, z2))
                val start = ceil(((lo - first) / step).toDouble() - 1e-4).toInt().coerceAtLeast(0)
                val end = floor(((hi - first) / step).toDouble() + 1e-4).toInt().coerceAtMost(count - 1)
                if (end >= start) {
                    for (li in start..end) {
                        val z = first + li * step
                        val sectionZ = when {
                            z > hi && z - hi <= step * 0.01f -> hi
                            z < lo && lo - z <= step * 0.01f -> lo
                            else -> z
                        }
                        triangleSection(worldTri, 0, sectionZ)?.let { segmentsByLayer[li] += it }
                    }
                }
                base += 9
            }
        }

        val layers = ArrayList<SliceLayer>(count)
        for (i in 0 until count) {
            val z = first + i * step
            val stitched = stitch(segmentsByLayer[i])
            layers += SliceLayer(
                index = i,
                z = z,
                loops = classifyNesting(stitched.loops),
                openPaths = stitched.open,
                duplicateSegmentsRemoved = stitched.duplicateSegmentsRemoved,
                degenerateSegmentsRemoved = stitched.degenerateSegmentsRemoved
            )
        }
        return SliceResult(layers, objects.size)
    }

    private data class Segment(val a: Point2, val b: Point2)
    private data class Cell(val x: Long, val y: Long)
    private data class SegmentKey(val ax: Long, val ay: Long, val bx: Long, val by: Long)
    private data class StitchResult(
        val loops: List<SliceLoop>,
        val open: List<List<Point2>>,
        val duplicateSegmentsRemoved: Int,
        val degenerateSegmentsRemoved: Int
    )

    private fun triangleSection(v: FloatArray, base: Int, z: Float): Segment? {
        val pts = ArrayList<Point2>(3)
        fun edge(i0: Int, i1: Int) {
            val z0 = v[i0 + 2]; val z1 = v[i1 + 2]
            // Coplanar triangle edges are intentionally ignored. Adjacent non-coplanar triangles provide the
            // actual contour, avoiding double edges on perfectly horizontal faces.
            if (abs(z0 - z) < EPS && abs(z1 - z) < EPS) return
            val crosses = (z0 < z && z1 >= z) || (z1 < z && z0 >= z)
            if (!crosses) return
            val dz = z1 - z0
            if (abs(dz) < EPS) return
            val t = (z - z0) / dz
            val p = Point2(v[i0] + (v[i1] - v[i0]) * t, v[i0 + 1] + (v[i1 + 1] - v[i0 + 1]) * t)
            if (pts.none { dist2(it, p) < EPS * EPS }) pts += p
        }
        edge(base, base + 3); edge(base + 3, base + 6); edge(base + 6, base)
        return if (pts.size == 2 && dist2(pts[0], pts[1]) > EPS * EPS) Segment(pts[0], pts[1]) else null
    }

    /**
     * Stitch with neighbour-cell lookup instead of a single rounded endpoint key. Two endpoints can be within
     * tolerance while falling on opposite sides of a hash-cell boundary; the old implementation could leave a
     * false open contour in that case.
     */
    private fun stitch(raw: List<Segment>): StitchResult {
        if (raw.isEmpty()) return StitchResult(emptyList(), emptyList(), 0, 0)

        var degenerateRemoved = 0
        var duplicateRemoved = 0
        val dedup = LinkedHashMap<SegmentKey, Segment>()
        for (s in raw) {
            if (dist2(s.a, s.b) <= EPS * EPS) {
                degenerateRemoved++
                continue
            }
            val k = segmentKey(s)
            if (dedup.putIfAbsent(k, s) != null) duplicateRemoved++
        }
        val segments = dedup.values.toList()
        if (segments.isEmpty()) return StitchResult(emptyList(), emptyList(), duplicateRemoved, degenerateRemoved)

        val endpointMap = HashMap<Cell, MutableList<Int>>()
        fun addEndpoint(p: Point2, index: Int) { endpointMap.getOrPut(cell(p, JOIN_TOL)) { mutableListOf() } += index }
        segments.forEachIndexed { i, s -> addEndpoint(s.a, i); addEndpoint(s.b, i) }
        val used = BooleanArray(segments.size)

        fun findNearest(point: Point2): Pair<Int, Point2>? {
            val c = cell(point, JOIN_TOL)
            var bestIndex = -1
            var bestOther: Point2? = null
            var bestD = JOIN_TOL * JOIN_TOL
            for (dy in -1L..1L) for (dx in -1L..1L) {
                val candidates = endpointMap[Cell(c.x + dx, c.y + dy)] ?: continue
                for (idx in candidates) {
                    if (used[idx]) continue
                    val s = segments[idx]
                    val da = dist2(point, s.a)
                    val db = dist2(point, s.b)
                    val d = min(da, db)
                    if (d <= bestD) {
                        bestD = d
                        bestIndex = idx
                        bestOther = if (da <= db) s.b else s.a
                    }
                }
            }
            return if (bestIndex >= 0 && bestOther != null) bestIndex to bestOther!! else null
        }

        val loops = mutableListOf<SliceLoop>()
        val open = mutableListOf<List<Point2>>()
        for (seed in segments.indices) {
            if (used[seed]) continue
            used[seed] = true
            val s = segments[seed]
            val path = ArrayDeque<Point2>()
            path.addLast(s.a); path.addLast(s.b)

            var guard = 0
            while (guard++ < segments.size + 4) {
                val next = findNearest(path.last()) ?: break
                used[next.first] = true
                path.addLast(next.second)
                if (path.size >= 4 && dist2(path.first(), path.last()) <= JOIN_TOL * JOIN_TOL) break
            }
            guard = 0
            while (dist2(path.first(), path.last()) > JOIN_TOL * JOIN_TOL && guard++ < segments.size + 4) {
                val next = findNearest(path.first()) ?: break
                used[next.first] = true
                path.addFirst(next.second)
            }

            val list = path.toMutableList()
            if (list.size >= 4 && dist2(list.first(), list.last()) <= JOIN_TOL * JOIN_TOL) {
                list[list.lastIndex] = list.first()
                val normalized = removeNearDuplicateVertices(list)
                if (normalized.size >= 4 && abs(area(normalized.dropLast(1))) > EPS) loops += SliceLoop(normalized)
                else degenerateRemoved++
            } else {
                open += removeNearDuplicateVertices(list)
            }
        }
        return StitchResult(loops, open, duplicateRemoved, degenerateRemoved)
    }

    private fun removeNearDuplicateVertices(points: List<Point2>): List<Point2> {
        if (points.isEmpty()) return points
        val out = ArrayList<Point2>(points.size)
        for (p in points) if (out.isEmpty() || dist2(out.last(), p) > EPS * EPS) out += p
        return out
    }

    /** Classify nested rings and normalize orientation: printable outers CCW, holes CW. */
    private fun classifyNesting(input: List<SliceLoop>): List<SliceLoop> {
        if (input.isEmpty()) return input
        data class Ring(val poly: List<Point2>, val absArea: Float, val probe: Point2)
        val rings = input.mapNotNull { loop ->
            val poly = if (loop.points.size > 1 && dist2(loop.points.first(), loop.points.last()) <= JOIN_TOL * JOIN_TOL) loop.points.dropLast(1) else loop.points
            if (poly.size < 3) null else {
                val a = area(poly)
                if (abs(a) <= EPS) null else Ring(poly, abs(a), interiorProbe(poly, a))
            }
        }.sortedByDescending { it.absArea }

        val out = ArrayList<SliceLoop>(rings.size)
        for (i in rings.indices) {
            val ring = rings[i]
            var depth = 0
            for (j in 0 until i) if (pointInPolygon(ring.probe, rings[j].poly)) depth++
            val currentArea = area(ring.poly)
            val wantCcw = depth % 2 == 0
            val oriented = if ((currentArea > 0f) == wantCcw) ring.poly else ring.poly.reversed()
            out += SliceLoop(oriented + oriented.first(), depth)
        }
        return out
    }

    private fun interiorProbe(poly: List<Point2>, signedArea: Float): Point2 {
        val a = poly[0]; val b = poly[1]
        val mx = (a.x + b.x) * 0.5f; val my = (a.y + b.y) * 0.5f
        val dx = b.x - a.x; val dy = b.y - a.y
        val len = kotlin.math.hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(EPS)
        // For CCW, polygon interior is left of an edge. For CW, it is right.
        val side = if (signedArea > 0f) 1f else -1f
        val nX = -dy / len * side; val nY = dx / len * side
        val offset = min(JOIN_TOL * 0.25f, len * 0.05f).coerceAtLeast(EPS * 10f)
        return Point2(mx + nX * offset, my + nY * offset)
    }

    private fun pointInPolygon(p: Point2, poly: List<Point2>): Boolean {
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val a = poly[i]; val b = poly[j]
            if (((a.y > p.y) != (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y + 1e-12f) + a.x) inside = !inside
            j = i
        }
        return inside
    }

    private fun segmentKey(s: Segment): SegmentKey {
        fun q(v: Float) = (v / DEDUP_TOL).roundToLong()
        val ax = q(s.a.x); val ay = q(s.a.y); val bx = q(s.b.x); val by = q(s.b.y)
        return if (ax < bx || (ax == bx && ay <= by)) SegmentKey(ax, ay, bx, by) else SegmentKey(bx, by, ax, ay)
    }

    private fun cell(p: Point2, size: Float) = Cell(floor((p.x / size).toDouble()).toLong(), floor((p.y / size).toDouble()).toLong())
    private fun area(poly: List<Point2>): Float {
        if (poly.size < 3) return 0f
        var a = 0.0
        for (i in poly.indices) {
            val p = poly[i]; val q = poly[(i + 1) % poly.size]
            a += p.x * q.y - q.x * p.y
        }
        return (a * 0.5).toFloat()
    }
    private fun dist2(a: Point2, b: Point2): Float { val x = a.x - b.x; val y = a.y - b.y; return x * x + y * y }
}
