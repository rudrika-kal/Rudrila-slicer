package com.rudrila.slicer.model

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** 2D point in the slicer's centered build-plate workspace. */
data class Point2(val x: Float, val y: Float)

/**
 * One closed contour. `nestingDepth` is even for material outlines and odd for holes.
 * Winding is normalized after stitching: material outlines are CCW, holes are CW.
 */
data class SliceLoop(
    val points: List<Point2>,
    val nestingDepth: Int = 0,
    val isHole: Boolean = false
)

data class SliceLayer(val index: Int, val z: Float, val loops: List<SliceLoop>, val openPaths: List<List<Point2>>)

data class SliceResult(val layers: List<SliceLayer>, val sourceObjectCount: Int) {
    val layerCount get() = layers.size
    val closedLoopCount get() = layers.sumOf { it.loops.size }
    val openPathCount get() = layers.sumOf { it.openPaths.size }
    val holeCount get() = layers.sumOf { layer -> layer.loops.count { it.isHole } }
}

/**
 * Geometry-only contour slicer.
 *
 * V2 improvements over the original alpha slicer:
 * - duplicate triangle-plane segments are de-duplicated before stitching;
 * - branch junctions choose the straightest continuation instead of arbitrary hash-map order;
 * - loop points are de-duplicated / collinear points are removed;
 * - loop nesting is classified, holes are tagged, and winding is normalized;
 * - open contours remain explicit and continue to block G-code export.
 *
 * The implementation remains allocation-bounded for very large STL files: no transformed full-mesh copy is made.
 */
object ContourSlicer {
    private const val EPS = 1e-5f
    private const val JOIN_TOL = 0.02f
    private const val MIN_LOOP_AREA = 1e-4f

    fun slice(objects: List<SceneObject>, process: ProcessProfile): SliceResult {
        require(objects.isNotEmpty()) { "No models on plate" }
        process.validate()
        val maxZ = objects.maxOf { TransformMath.transformedBounds(it.mesh, it.transform).maxZ }.coerceAtLeast(0f)
        if (maxZ <= EPS) return SliceResult(emptyList(), objects.size)

        val first = min(process.firstLayerHeightMm, maxZ)
        val step = process.layerHeightMm
        val count = (floor((((maxZ - first) / step) + 1e-4f).toDouble()).toInt() + 1).coerceAtLeast(1)
        val segmentsByLayer = Array(count) { mutableListOf<Segment>() }

        for (obj in objects) {
            // Never materialize a second transformed copy of the entire mesh.
            val source = obj.mesh.vertices
            val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
            val worldTri = FloatArray(9)
            var base = 0
            while (base + 8 < source.size) {
                tx.write(base, worldTri, 0)
                tx.write(base + 3, worldTri, 3)
                tx.write(base + 6, worldTri, 6)
                val z0 = worldTri[2]; val z1 = worldTri[5]; val z2 = worldTri[8]
                val lo = min(z0, min(z1,z2)); val hi = max(z0, max(z1,z2))
                val start = ceil(((lo-first)/step).toDouble() - 1e-4).toInt().coerceAtLeast(0)
                val end = floor(((hi-first)/step).toDouble() + 1e-4).toInt().coerceAtMost(count-1)
                if (end >= start) {
                    for (li in start..end) {
                        val z = first + li*step
                        val sectionZ = when {
                            z > hi && z-hi <= step*0.01f -> hi
                            z < lo && lo-z <= step*0.01f -> lo
                            else -> z
                        }
                        triangleSection(worldTri, 0, sectionZ)?.let { segmentsByLayer[li] += it }
                    }
                }
                base += 9
            }
        }

        val layers = ArrayList<SliceLayer>(count)
        for (i in 0 until count) {
            val z = first + i*step
            val (rawLoops, open) = stitch(segmentsByLayer[i])
            layers += SliceLayer(i, z, classifyLoops(rawLoops), open)
        }
        return SliceResult(layers, objects.size)
    }

    private data class Segment(val a: Point2, val b: Point2)
    private data class Key(val x: Long, val y: Long)
    private data class EdgeKey(val ax: Long, val ay: Long, val bx: Long, val by: Long)

    private fun triangleSection(v:FloatArray, base:Int, z:Float):Segment?{
        val pts = ArrayList<Point2>(3)
        fun edge(i0:Int,i1:Int){
            val z0=v[i0+2]; val z1=v[i1+2]
            // Coplanar edges are deliberately ignored. Adjacent non-coplanar triangles contribute the contour.
            if (abs(z0-z)<EPS && abs(z1-z)<EPS) return
            val crosses = (z0 < z && z1 >= z) || (z1 < z && z0 >= z)
            if(!crosses)return
            val dz=z1-z0
            if(abs(dz)<EPS)return
            val t=(z-z0)/dz
            val x=v[i0]+(v[i1]-v[i0])*t; val y=v[i0+1]+(v[i1+1]-v[i0+1])*t
            val p=Point2(x,y)
            if(pts.none{dist2(it,p)<EPS*EPS})pts+=p
        }
        edge(base,base+3);edge(base+3,base+6);edge(base+6,base)
        return if(pts.size==2 && dist2(pts[0],pts[1])>EPS*EPS) Segment(pts[0],pts[1]) else null
    }

    /**
     * Stitches quantized endpoints into closed contours. Duplicate undirected segments are collapsed to one representative;
     * these are common on duplicate facets or shared triangle edges exactly on a layer plane.
     */
    private fun stitch(input:List<Segment>):Pair<List<List<Point2>>,List<List<Point2>>>{
        if(input.isEmpty())return emptyList<List<Point2>>() to emptyList()

        val unique = LinkedHashMap<EdgeKey, Segment>()
        for (s in input) {
            if (dist2(s.a,s.b) <= EPS*EPS) continue
            val ka=key(s.a); val kb=key(s.b)
            val edge = if (compareKey(ka,kb)<=0) EdgeKey(ka.x,ka.y,kb.x,kb.y) else EdgeKey(kb.x,kb.y,ka.x,ka.y)
            // Exact duplicate segments can come from duplicate facets or a layer plane touching a shared edge.
            // Keep one representative; cancelling both would incorrectly erase valid contour geometry.
            unique.putIfAbsent(edge,s)
        }
        val segments=unique.values.toList()
        if(segments.isEmpty())return emptyList<List<Point2>>() to emptyList()

        val used=BooleanArray(segments.size)
        val endpointMap=HashMap<Key,MutableList<Int>>(segments.size*2)
        fun add(k:Key,i:Int){endpointMap.getOrPut(k){mutableListOf()}+=i}
        segments.forEachIndexed{i,s->add(key(s.a),i);add(key(s.b),i)}
        val loops=mutableListOf<List<Point2>>();val open=mutableListOf<List<Point2>>()

        for(seed in segments.indices){
            if(used[seed])continue
            used[seed]=true
            val s=segments[seed]
            val path=mutableListOf(s.a,s.b)
            val startKey=key(s.a)
            var currentKey=key(s.b)
            var previous=s.a
            var current=s.b
            var guard=0
            while(currentKey!=startKey && guard++<segments.size+4){
                val candidates=endpointMap[currentKey]?.filter{!used[it]}.orEmpty()
                if(candidates.isEmpty())break
                val next=chooseContinuation(segments,candidates,currentKey,previous,current)
                used[next]=true
                val n=segments[next]
                val other=if(key(n.a)==currentKey)n.b else n.a
                path+=other
                previous=current; current=other; currentKey=key(other)
            }
            val clean=sanitizePath(path, currentKey==startKey)
            if(currentKey==startKey && clean.size>=4 && abs(area(clean))>=MIN_LOOP_AREA){
                loops+=clean
            }else if(clean.size>=2) open+=clean
        }
        return loops to open
    }

    /** Prefer continuing in the same direction when several segments meet at one quantized endpoint. */
    private fun chooseContinuation(segments:List<Segment>,candidates:List<Int>,at:Key,previous:Point2,current:Point2):Int{
        val inX=current.x-previous.x; val inY=current.y-previous.y
        val inLen=kotlin.math.hypot(inX.toDouble(),inY.toDouble()).toFloat().coerceAtLeast(EPS)
        var best=candidates.first();var bestScore=-Float.MAX_VALUE
        for(i in candidates){
            val s=segments[i];val other=if(key(s.a)==at)s.b else s.a
            val outX=other.x-current.x;val outY=other.y-current.y
            val outLen=kotlin.math.hypot(outX.toDouble(),outY.toDouble()).toFloat().coerceAtLeast(EPS)
            val dot=(inX*outX+inY*outY)/(inLen*outLen)
            if(dot>bestScore){bestScore=dot;best=i}
        }
        return best
    }

    private fun sanitizePath(raw:List<Point2>,closed:Boolean):List<Point2>{
        if(raw.size<2)return raw
        val pts=ArrayList<Point2>(raw.size)
        for(p in raw){if(pts.isEmpty()||dist2(pts.last(),p)>EPS*EPS)pts+=p}
        if(closed){
            if(pts.size>1 && dist2(pts.first(),pts.last())<=JOIN_TOL*JOIN_TOL) pts[pts.lastIndex]=pts.first()
            else pts+=pts.first()
        }
        if(pts.size<4 || !closed)return pts

        // Remove near-collinear interior points; keep a closed final point.
        val body=pts.dropLast(1).toMutableList()
        var changed=true;var passes=0
        while(changed && body.size>=3 && passes++<3){
            changed=false
            var i=0
            while(i<body.size && body.size>=3){
                val a=body[(i-1+body.size)%body.size];val b=body[i];val c=body[(i+1)%body.size]
                val abx=b.x-a.x;val aby=b.y-a.y;val bcx=c.x-b.x;val bcy=c.y-b.y
                val cross=abs(abx*bcy-aby*bcx)
                val scale=max(1f, kotlin.math.hypot(abx.toDouble(),aby.toDouble()).toFloat()+kotlin.math.hypot(bcx.toDouble(),bcy.toDouble()).toFloat())
                if(cross < 1e-5f*scale){body.removeAt(i);changed=true}else i++
            }
        }
        return if(body.size>=3) body+body.first() else emptyList()
    }

    private fun classifyLoops(raw:List<List<Point2>>):List<SliceLoop>{
        if(raw.isEmpty())return emptyList()
        val bodies=raw.map{if(it.size>1&&dist2(it.first(),it.last())<=JOIN_TOL*JOIN_TOL)it.dropLast(1)else it}
        val areas=bodies.map(::signedArea)
        val out=ArrayList<SliceLoop>(bodies.size)
        for(i in bodies.indices){
            val poly=bodies[i]
            if(poly.size<3 || abs(areas[i])<MIN_LOOP_AREA)continue
            val probe=probeInside(poly,areas[i])
            var depth=0
            for(j in bodies.indices){
                if(i==j)continue
                if(pointInPolygon(probe,bodies[j]))depth++
            }
            val hole=depth%2==1
            val wantCcw=!hole
            val isCcw=areas[i]>0f
            val normalized=if(isCcw==wantCcw)poly else poly.asReversed()
            out+=SliceLoop(normalized+normalized.first(),depth,hole)
        }
        // Stable order: material outlines first by nesting depth, then holes; larger contours first.
        return out.sortedWith(compareBy<SliceLoop>{it.nestingDepth}.thenByDescending{abs(area(it.points))})
    }

    /** A point just inside the first non-degenerate edge, avoiding concave-centroid ambiguity. */
    private fun probeInside(poly:List<Point2>,signedArea:Float):Point2{
        for(i in poly.indices){
            val a=poly[i];val b=poly[(i+1)%poly.size]
            val dx=b.x-a.x;val dy=b.y-a.y
            val len=kotlin.math.hypot(dx.toDouble(),dy.toDouble()).toFloat()
            if(len<=EPS)continue
            val mx=(a.x+b.x)*0.5f;val my=(a.y+b.y)*0.5f
            val leftX=-dy/len;val leftY=dx/len
            val sign=if(signedArea>0f)1f else -1f
            val nudge=max(JOIN_TOL*0.35f,1e-4f)
            return Point2(mx+leftX*sign*nudge,my+leftY*sign*nudge)
        }
        return poly.first()
    }

    private fun pointInPolygon(p:Point2,poly:List<Point2>):Boolean{
        if(poly.size<3)return false
        var inside=false;var j=poly.lastIndex
        for(i in poly.indices){
            val a=poly[i];val b=poly[j]
            if(((a.y>p.y)!=(b.y>p.y)) && p.x < (b.x-a.x)*(p.y-a.y)/(b.y-a.y+1e-20f)+a.x) inside=!inside
            j=i
        }
        return inside
    }

    private fun signedArea(poly:List<Point2>):Float{
        var a=0.0
        for(i in poly.indices){val p=poly[i];val q=poly[(i+1)%poly.size];a+=p.x*q.y-q.x*p.y}
        return (a*0.5).toFloat()
    }
    private fun area(poly:List<Point2>)=signedArea(if(poly.size>1&&dist2(poly.first(),poly.last())<EPS*EPS)poly.dropLast(1)else poly)
    private fun compareKey(a:Key,b:Key)=if(a.x!=b.x)a.x.compareTo(b.x)else a.y.compareTo(b.y)
    private fun key(p:Point2)=Key((p.x/JOIN_TOL).roundToLong(),(p.y/JOIN_TOL).roundToLong())
    private fun dist2(a:Point2,b:Point2):Float{val x=a.x-b.x;val y=a.y-b.y;return x*x+y*y}
}
