package com.rudrila.slicer.model

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/** 2D point in the centered build-plate coordinate system, in millimetres. */
data class Point2(val x: Float, val y: Float)

/**
 * A closed cross-section contour. Outer material boundaries are canonicalized CCW;
 * holes are canonicalized CW. [nestingDepth] is 0 for an outer island, 1 for a hole,
 * 2 for an island inside a hole, and so on.
 */
data class SliceLoop(
    val points: List<Point2>,
    val isHole: Boolean = false,
    val nestingDepth: Int = 0
)

data class SliceLayer(
    val index: Int,
    val z: Float,
    val loops: List<SliceLoop>,
    val openPaths: List<List<Point2>>
)

data class SliceDiagnostics(
    val duplicateSegmentsRemoved: Int = 0,
    val degenerateSegmentsDropped: Int = 0,
    val tinyLoopsDropped: Int = 0
)

data class SliceResult(
    val layers: List<SliceLayer>,
    val sourceObjectCount: Int,
    val diagnostics: SliceDiagnostics = SliceDiagnostics()
) {
    val layerCount get() = layers.size
    val closedLoopCount get() = layers.sumOf { it.loops.size }
    val openPathCount get() = layers.sumOf { it.openPaths.size }
    val isWatertightForExport get() = openPathCount == 0
}

/**
 * Slice Engine V2 contour stage.
 *
 * Design goals for the mobile build:
 * - Never allocate a second transformed copy of a dense source mesh.
 * - Deduplicate coincident triangle/plane segments before graph stitching.
 * - Canonicalize outer/hole loop nesting and winding so walls offset toward material.
 * - Keep open contours visible as a hard export safety gate instead of silently closing them.
 */
object ContourSlicer {
    private const val EPS = 1e-5f
    private const val JOIN_TOL = 0.02f
    private const val MIN_LOOP_AREA_MM2 = 0.0004f

    fun slice(objects: List<SceneObject>, process: ProcessProfile): SliceResult {
        require(objects.isNotEmpty()) { "No models on plate" }
        process.validate()
        val maxZ = objects.maxOf { TransformMath.transformedBounds(it.mesh, it.transform).maxZ }.coerceAtLeast(0f)
        if (maxZ <= EPS) return SliceResult(emptyList(), objects.size)

        val first = min(process.firstLayerHeightMm, maxZ)
        val step = process.layerHeightMm
        val count = (floor((((maxZ - first) / step) + 1e-4f).toDouble()).toInt() + 1).coerceAtLeast(1)
        val segmentsByLayer = Array(count) { mutableListOf<Segment>() }
        var degenerateDropped = 0

        for (obj in objects) {
            val source = obj.mesh.vertices
            val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
            val worldTri = FloatArray(9)
            var base = 0
            while (base + 8 < source.size) {
                tx.write(base, worldTri, 0)
                tx.write(base + 3, worldTri, 3)
                tx.write(base + 6, worldTri, 6)
                val z0 = worldTri[2]; val z1 = worldTri[5]; val z2 = worldTri[8]
                val lo = min(z0, min(z1, z2)); val hi = max(z0, max(z1, z2))
                val start = ceil(((lo - first) / step).toDouble() - 1e-4).toInt().coerceAtLeast(0)
                val end = floor(((hi - first) / step).toDouble() + 1e-4).toInt().coerceAtMost(count - 1)
                if (end >= start) {
                    for (li in start..end) {
                        val z = first + li * step
                        val sectionZ = when {
                            z > hi && z - hi <= step * 0.01f -> hi
                            z < lo && lo - z <= step * 0.01f -> lo
                            else -> z
                        }
                        val section = triangleSection(worldTri, 0, sectionZ)
                        if (section != null) segmentsByLayer[li] += section
                    }
                }
                base += 9
            }
        }

        var duplicateRemoved = 0
        var tinyLoopsDropped = 0
        val layers = ArrayList<SliceLayer>(count)
        for (i in 0 until count) {
            val z = first + i * step
            val dedup = deduplicate(segmentsByLayer[i])
            duplicateRemoved += segmentsByLayer[i].size - dedup.size
            val stitched = stitch(dedup)
            val canonical = canonicalize(stitched.first)
            tinyLoopsDropped += stitched.first.size - canonical.size
            layers += SliceLayer(i, z, canonical, stitched.second)
        }
        return SliceResult(
            layers,
            objects.size,
            SliceDiagnostics(
                duplicateSegmentsRemoved = duplicateRemoved,
                degenerateSegmentsDropped = degenerateDropped,
                tinyLoopsDropped = tinyLoopsDropped
            )
        )
    }

    private data class Segment(val a: Point2, val b: Point2)
    private data class Key(val x: Long, val y: Long) : Comparable<Key> {
        override fun compareTo(other: Key): Int = if (x != other.x) x.compareTo(other.x) else y.compareTo(other.y)
    }
    private data class SegmentKey(val a: Key, val b: Key)

    private fun triangleSection(v: FloatArray, base: Int, z: Float): Segment? {
        val pts = ArrayList<Point2>(3)
        fun edge(i0: Int, i1: Int) {
            val z0 = v[i0 + 2]; val z1 = v[i1 + 2]
            // Coplanar edges are ignored: neighbouring non-coplanar triangles define the contour,
            // while adding coplanar edges creates duplicate/branching graph edges.
            if (abs(z0 - z) < EPS && abs(z1 - z) < EPS) return
            val crosses = (z0 < z && z1 >= z) || (z1 < z && z0 >= z)
            if (!crosses) return
            val dz = z1 - z0
            if (abs(dz) < EPS) return
            val t = (z - z0) / dz
            val p = Point2(v[i0] + (v[i1] - v[i0]) * t, v[i0 + 1] + (v[i1 + 1] - v[i0 + 1]) * t)
            if (pts.none { dist2(it, p) < EPS * EPS }) pts += p
        }
        edge(base, base + 3); edge(base + 3, base + 6); edge(base + 6, base)
        return if (pts.size == 2 && dist2(pts[0], pts[1]) > EPS * EPS) Segment(pts[0], pts[1]) else null
    }

    /** Remove coincident undirected segments generated at shared vertices/edges. */
    private fun deduplicate(segments: List<Segment>): List<Segment> {
        if (segments.size < 2) return segments
        val seen = HashSet<SegmentKey>(segments.size * 2)
        val out = ArrayList<Segment>(segments.size)
        for (s in segments) {
            val ka = key(s.a); val kb = key(s.b)
            if (ka == kb) continue
            val sk = if (ka <= kb) SegmentKey(ka, kb) else SegmentKey(kb, ka)
            if (seen.add(sk)) out += s
        }
        return out
    }

    private fun stitch(segments: List<Segment>): Pair<List<SliceLoop>, List<List<Point2>>> {
        if (segments.isEmpty()) return emptyList<SliceLoop>() to emptyList()
        val used = BooleanArray(segments.size)
        val endpointMap = HashMap<Key, MutableList<Int>>()
        fun add(k: Key, i: Int) { endpointMap.getOrPut(k) { mutableListOf() } += i }
        segments.forEachIndexed { i, s -> add(key(s.a), i); add(key(s.b), i) }

        val loops = mutableListOf<SliceLoop>()
        val open = mutableListOf<List<Point2>>()
        for (seed in segments.indices) {
            if (used[seed]) continue
            used[seed] = true
            val s = segments[seed]
            val path = mutableListOf(s.a, s.b)
            val startKey = key(s.a)
            var currentKey = key(s.b)
            var guard = 0
            while (currentKey != startKey && guard++ < segments.size + 4) {
                val candidates = endpointMap[currentKey]?.filter { !used[it] }.orEmpty()
                if (candidates.isEmpty()) break
                // On a clean manifold graph degree is 2. If numerical noise makes a branch,
                // continue in the straightest direction rather than depending on list order.
                val previous = path.getOrNull(path.lastIndex - 1)
                val current = path.last()
                val next = candidates.minByOrNull { idx ->
                    if (previous == null) 0f else turnPenalty(previous, current, otherEnd(segments[idx], currentKey))
                } ?: break
                used[next] = true
                val other = otherEnd(segments[next], currentKey)
                path += other
                currentKey = key(other)
            }
            if (currentKey == startKey && path.size >= 4) {
                if (dist2(path.first(), path.last()) > JOIN_TOL * JOIN_TOL) path += path.first()
                loops += SliceLoop(cleanClosedPath(path))
            } else if (path.size >= 2) {
                open += cleanOpenPath(path)
            }
        }
        return loops to open
    }

    /** Canonicalize nesting + winding, and remove sub-resolution rings. */
    private fun canonicalize(raw: List<SliceLoop>): List<SliceLoop> {
        val clean = raw.mapNotNull { loop ->
            val pts = normalizeClosed(loop.points)
            if (pts.size < 4) null
            else {
                val open = pts.dropLast(1)
                if (abs(PolygonOps.area(open)) < MIN_LOOP_AREA_MM2) null else open
            }
        }
        if (clean.isEmpty()) return emptyList()

        val out = ArrayList<SliceLoop>(clean.size)
        for (i in clean.indices) {
            var depth = 0
            val sample = clean[i][0]
            for (j in clean.indices) {
                if (i == j) continue
                if (pointInside(sample, clean[j])) depth++
            }
            val hole = depth % 2 == 1
            var poly = clean[i]
            val area = PolygonOps.area(poly)
            val wantsCcw = !hole
            if ((wantsCcw && area < 0f) || (!wantsCcw && area > 0f)) poly = poly.reversed()
            out += SliceLoop(poly + poly.first(), hole, depth)
        }
        // Stable ordering helps deterministic toolpaths/tests: islands before their nested holes, then by area.
        return out.sortedWith(compareBy<SliceLoop> { it.nestingDepth }.thenByDescending { abs(PolygonOps.area(it.points.dropLast(1))) })
    }

    private fun normalizeClosed(points: List<Point2>): List<Point2> {
        if (points.isEmpty()) return emptyList()
        val out = ArrayList<Point2>(points.size)
        for (p in points) if (out.isEmpty() || dist2(out.last(), p) > EPS * EPS) out += p
        if (out.size >= 2 && dist2(out.first(), out.last()) > JOIN_TOL * JOIN_TOL) out += out.first()
        else if (out.size >= 2) out[out.lastIndex] = out.first()
        return out
    }

    private fun cleanClosedPath(points: List<Point2>): List<Point2> = normalizeClosed(points)

    private fun cleanOpenPath(points: List<Point2>): List<Point2> {
        val out = ArrayList<Point2>(points.size)
        for (p in points) if (out.isEmpty() || dist2(out.last(), p) > EPS * EPS) out += p
        return out
    }

    private fun otherEnd(s: Segment, at: Key): Point2 = if (key(s.a) == at) s.b else s.a

    private fun turnPenalty(a: Point2, b: Point2, c: Point2): Float {
        val ux = b.x - a.x; val uy = b.y - a.y
        val vx = c.x - b.x; val vy = c.y - b.y
        val ul = kotlin.math.sqrt(ux * ux + uy * uy).coerceAtLeast(EPS)
        val vl = kotlin.math.sqrt(vx * vx + vy * vy).coerceAtLeast(EPS)
        // 0 = straight, 2 = reverse.
        return 1f - ((ux * vx + uy * vy) / (ul * vl)).coerceIn(-1f, 1f)
    }

    private fun pointInside(p: Point2, poly: List<Point2>): Boolean {
        if (poly.size < 3) return false
        var inside = false
        var j = poly.lastIndex
        for (i in poly.indices) {
            val a = poly[i]; val b = poly[j]
            if (((a.y > p.y) != (b.y > p.y)) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y + 1e-12f) + a.x) inside = !inside
            j = i
        }
        return inside
    }

    private fun key(p: Point2) = Key((p.x / JOIN_TOL).roundToLong(), (p.y / JOIN_TOL).roundToLong())
    private fun dist2(a: Point2, b: Point2): Float { val x = a.x - b.x; val y = a.y - b.y; return x * x + y * y }
}
