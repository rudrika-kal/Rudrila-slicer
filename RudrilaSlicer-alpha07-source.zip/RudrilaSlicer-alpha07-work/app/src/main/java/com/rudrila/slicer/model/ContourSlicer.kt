package com.rudrila.slicer.model

import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

data class Point2(val x: Float, val y: Float)
data class SliceLoop(val points: List<Point2>)
data class SliceLayer(val index: Int, val z: Float, val loops: List<SliceLoop>, val openPaths: List<List<Point2>>)
data class SliceResult(val layers: List<SliceLayer>, val sourceObjectCount: Int) {
    val layerCount get() = layers.size
    val closedLoopCount get() = layers.sumOf { it.loops.size }
    val openPathCount get() = layers.sumOf { it.openPaths.size }
}

/**
 * Geometry-only contour slicer. It creates horizontal cross-section loops that later perimeter/infill/G-code stages consume.
 * This deliberately does not pretend to be a complete production toolpath engine yet.
 */
object ContourSlicer {
    private const val EPS = 1e-5f
    private const val JOIN_TOL = 0.02f

    fun slice(objects: List<SceneObject>, process: ProcessProfile): SliceResult {
        require(objects.isNotEmpty()) { "No models on plate" }
        process.validate()
        val maxZ = objects.maxOf { TransformMath.transformedBounds(it.mesh, it.transform).maxZ }.coerceAtLeast(0f)
        if (maxZ <= EPS) return SliceResult(emptyList(), objects.size)

        val first = min(process.firstLayerHeightMm, maxZ)
        val step = process.layerHeightMm
        val count = (floor((((maxZ - first) / step) + 1e-4f).toDouble()).toInt() + 1).coerceAtLeast(1)
        val segmentsByLayer = Array(count) { mutableListOf<Segment>() }

        for (obj in objects) {
            // Never materialize a second transformed copy of the entire mesh. A 10M-triangle STL
            // already needs ~360 MB for exact XYZ data; duplicating it here would guarantee OOM on
            // many phones. Reuse one 9-float world-space triangle instead.
            val source = obj.mesh.vertices
            val tx = TransformMath.prepareVertexTransform(obj.mesh, obj.transform)
            val worldTri = FloatArray(9)
            var base = 0
            while (base + 8 < source.size) {
                tx.write(base, worldTri, 0)
                tx.write(base + 3, worldTri, 3)
                tx.write(base + 6, worldTri, 6)
                val z0 = worldTri[2]; val z1 = worldTri[5]; val z2 = worldTri[8]
                val lo = min(z0, min(z1,z2)); val hi = max(z0, max(z1,z2))
                val start = ceil(((lo-first)/step).toDouble() - 1e-4).toInt().coerceAtLeast(0)
                val end = floor(((hi-first)/step).toDouble() + 1e-4).toInt().coerceAtMost(count-1)
                if (end >= start) {
                    for (li in start..end) {
                        val z = first + li*step
                        val sectionZ = when {
                            z > hi && z-hi <= step*0.01f -> hi
                            z < lo && lo-z <= step*0.01f -> lo
                            else -> z
                        }
                        triangleSection(worldTri, 0, sectionZ)?.let { segmentsByLayer[li] += it }
                    }
                }
                base += 9
            }
        }

        val layers = ArrayList<SliceLayer>(count)
        for (i in 0 until count) {
            val z = first + i*step
            val (loops, open) = stitch(segmentsByLayer[i])
            layers += SliceLayer(i,z,loops,open)
        }
        return SliceResult(layers, objects.size)
    }

    private data class Segment(val a: Point2, val b: Point2)
    private data class Key(val x: Long, val y: Long)

    private fun triangleSection(v:FloatArray, base:Int, z:Float):Segment?{
        val pts = ArrayList<Point2>(3)
        fun edge(i0:Int,i1:Int){
            val z0=v[i0+2]; val z1=v[i1+2]
            if (kotlin.math.abs(z0-z)<EPS && kotlin.math.abs(z1-z)<EPS) return
            val crosses = (z0 < z && z1 >= z) || (z1 < z && z0 >= z)
            if(!crosses)return
            val dz=z1-z0
            if(kotlin.math.abs(dz)<EPS)return
            val t=(z-z0)/dz
            val x=v[i0]+(v[i1]-v[i0])*t; val y=v[i0+1]+(v[i1+1]-v[i0+1])*t
            val p=Point2(x,y)
            if(pts.none{dist2(it,p)<EPS*EPS})pts+=p
        }
        edge(base,base+3);edge(base+3,base+6);edge(base+6,base)
        return if(pts.size==2 && dist2(pts[0],pts[1])>EPS*EPS) Segment(pts[0],pts[1]) else null
    }

    private fun stitch(segments:List<Segment>):Pair<List<SliceLoop>,List<List<Point2>>>{
        if(segments.isEmpty())return emptyList<SliceLoop>() to emptyList()
        val used=BooleanArray(segments.size)
        val endpointMap=HashMap<Key,MutableList<Int>>()
        fun add(k:Key,i:Int){endpointMap.getOrPut(k){mutableListOf()}+=i}
        segments.forEachIndexed{i,s->add(key(s.a),i);add(key(s.b),i)}
        val loops=mutableListOf<SliceLoop>();val open=mutableListOf<List<Point2>>()
        for(seed in segments.indices){
            if(used[seed])continue
            used[seed]=true
            val s=segments[seed]
            val path=mutableListOf(s.a,s.b)
            val startKey=key(s.a)
            var currentKey=key(s.b)
            var guard=0
            while(currentKey!=startKey && guard++<segments.size+4){
                val next=endpointMap[currentKey]?.firstOrNull{!used[it]}?:break
                used[next]=true
                val n=segments[next]
                val other=if(key(n.a)==currentKey)n.b else n.a
                path+=other;currentKey=key(other)
            }
            if(currentKey==startKey && path.size>=4){
                if(dist2(path.first(),path.last())>JOIN_TOL*JOIN_TOL)path+=path.first()
                loops+=SliceLoop(path)
            }else open+=path
        }
        return loops to open
    }

    private fun key(p:Point2)=Key((p.x/JOIN_TOL).roundToLong(),(p.y/JOIN_TOL).roundToLong())
    private fun dist2(a:Point2,b:Point2):Float{val x=a.x-b.x;val y=a.y-b.y;return x*x+y*y}
}
