package com.rudrila.slicer.model

import android.content.ContentResolver
import android.net.Uri
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object ThreeMfParser {
    private const val MAX_TRIANGLES = 1_500_000
    private const val MAX_MODEL_XML_BYTES = 64 * 1024 * 1024
    data class Part(val name: String, val mesh: Mesh)

    fun parse(resolver: ContentResolver, uri: Uri): Mesh =
        resolver.openInputStream(uri)?.use { parse(it) }
            ?: throw IllegalArgumentException("Unable to open 3MF")

    fun parseParts(resolver: ContentResolver, uri: Uri): List<Part> =
        resolver.openInputStream(uri)?.use { parseParts(it) }
            ?: throw IllegalArgumentException("Unable to open 3MF")

    /** Compatibility API: returns all direct mesh objects merged into one mesh. */
    fun parse(input: InputStream): Mesh = merge(parseParts(input).map { it.mesh })

    /**
     * Imports direct 3MF mesh objects separately. If a build section exists, build items are emitted in build order,
     * including duplicates. 3MF affine build transforms are baked into geometry, so each returned part starts with
     * a clean app transform and can then be moved/rotated independently.
     */
    fun parseParts(input: InputStream): List<Part> {
        val xml = findModelXml(input) ?: throw IllegalArgumentException("3MF model XML not found")
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            try { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Throwable) {}
            try { setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Throwable) {}
            try { setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Throwable) {}
            try { setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false) } catch (_: Throwable) {}
            isXIncludeAware = false
            isExpandEntityReferences = false
        }
        val document = factory.newDocumentBuilder().parse(ByteArrayInputStream(xml))
        val root = document.documentElement
        val unitScale = unitScale(root.getAttribute("unit"))

        val resources = linkedMapOf<String, Pair<String, Mesh>>()
        val objectNodes = document.getElementsByTagNameNS("*", "object")
        for (oi in 0 until objectNodes.length) {
            val obj = objectNodes.item(oi) as? Element ?: continue
            val id = obj.getAttribute("id").takeIf { it.isNotBlank() } ?: continue
            val meshElements = directChildren(obj, "mesh")
            if (meshElements.isEmpty()) continue // component-only objects are a later compatibility pass.
            val mesh = parseMesh(meshElements.first(), unitScale)
            val name = obj.getAttribute("name").takeIf { it.isNotBlank() } ?: "3MF Object $id"
            resources[id] = name to mesh
        }
        require(resources.isNotEmpty()) { "3MF contains no direct mesh objects" }

        val buildItems = document.getElementsByTagNameNS("*", "item")
        if (buildItems.length > 0) {
            val out = mutableListOf<Part>()
            for (i in 0 until buildItems.length) {
                val item = buildItems.item(i) as? Element ?: continue
                val id = item.getAttribute("objectid")
                val pair = resources[id] ?: continue
                val transformed = applyTransform(pair.second, parseTransform(item.getAttribute("transform")))
                out += Part(pair.first, transformed)
            }
            if (out.isNotEmpty()) return out
        }
        return resources.values.map { Part(it.first, it.second) }
    }

    private fun directChildren(parent: Element, localName: String): List<Element> {
        val out = mutableListOf<Element>()
        val children = parent.childNodes
        for (i in 0 until children.length) {
            val e = children.item(i) as? Element ?: continue
            if (e.localName == localName || e.tagName.substringAfter(':') == localName) out += e
        }
        return out
    }

    private fun parseMesh(meshEl: Element, unitScale: Float): Mesh {
        val vertexNodes = meshEl.getElementsByTagNameNS("*", "vertex")
        require(vertexNodes.length in 3..4_500_000) { "3MF has an invalid or excessive vertex count" }
        val local = try { FloatArray(vertexNodes.length * 3) } catch (_: OutOfMemoryError) {
            throw IllegalArgumentException("3MF vertices are too large for available memory")
        }
        for (i in 0 until vertexNodes.length) {
            val e = vertexNodes.item(i) as Element
            local[i * 3] = e.getAttribute("x").toFloat() * unitScale
            local[i * 3 + 1] = e.getAttribute("y").toFloat() * unitScale
            local[i * 3 + 2] = e.getAttribute("z").toFloat() * unitScale
        }
        val triangles = meshEl.getElementsByTagNameNS("*", "triangle")
        require(triangles.length in 1..MAX_TRIANGLES) { "3MF mesh is too complex (${triangles.length} triangles; max $MAX_TRIANGLES)" }
        val vertices = try { FloatArray(triangles.length * 9) } catch (_: OutOfMemoryError) {
            throw IllegalArgumentException("3MF mesh is too large for available memory")
        }
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
        var o = 0
        for (i in 0 until triangles.length) {
            val e = triangles.item(i) as Element
            val ids = intArrayOf(e.getAttribute("v1").toInt(), e.getAttribute("v2").toInt(), e.getAttribute("v3").toInt())
            require(ids.all { it >= 0 && it * 3 + 2 < local.size }) { "3MF contains an invalid triangle index" }
            val p = FloatArray(9)
            for (k in 0..2) {
                p[k*3]=local[ids[k]*3]; p[k*3+1]=local[ids[k]*3+1]; p[k*3+2]=local[ids[k]*3+2]
            }
            for (k in 0..2) {
                val x=p[k*3]; val y=p[k*3+1]; val z=p[k*3+2]
                require(x.isFinite() && y.isFinite() && z.isFinite()) { "3MF contains invalid coordinates" }
                vertices[o]=x; vertices[o+1]=y; vertices[o+2]=z
                minX=min(minX,x); minY=min(minY,y); minZ=min(minZ,z)
                maxX=max(maxX,x); maxY=max(maxY,y); maxZ=max(maxZ,z)
                o += 3
            }
        }
        return Mesh(vertices,FloatArray(0),minX,minY,minZ,maxX,maxY,maxZ)
    }

    /** 3MF transform order: m00 m01 m02 m10 m11 m12 m20 m21 m22 m30 m31 m32. */
    private fun parseTransform(text: String): FloatArray {
        if (text.isBlank()) return floatArrayOf(1f,0f,0f, 0f,1f,0f, 0f,0f,1f, 0f,0f,0f)
        val p = text.trim().split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
        require(p.size == 12) { "Invalid 3MF build transform" }
        return p.toFloatArray()
    }

    private fun applyTransform(mesh: Mesh, m: FloatArray): Mesh {
        val v = mesh.vertices
        val out = FloatArray(v.size)
        var minX=Float.POSITIVE_INFINITY; var minY=Float.POSITIVE_INFINITY; var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY; var maxY=Float.NEGATIVE_INFINITY; var maxZ=Float.NEGATIVE_INFINITY
        var i=0
        while(i<v.size){
            val x=v[i]; val y=v[i+1]; val z=v[i+2]
            // 3MF uses row-vector convention in its serialized 3x4 affine transform.
            val nx=x*m[0]+y*m[3]+z*m[6]+m[9]
            val ny=x*m[1]+y*m[4]+z*m[7]+m[10]
            val nz=x*m[2]+y*m[5]+z*m[8]+m[11]
            out[i]=nx; out[i+1]=ny; out[i+2]=nz
            minX=min(minX,nx); minY=min(minY,ny); minZ=min(minZ,nz)
            maxX=max(maxX,nx); maxY=max(maxY,ny); maxZ=max(maxZ,nz)
            i+=3
        }
        return Mesh(out,FloatArray(0),minX,minY,minZ,maxX,maxY,maxZ)
    }

    private fun merge(meshes: List<Mesh>): Mesh {
        require(meshes.isNotEmpty()) { "3MF contains no mesh triangles" }
        val total = meshes.sumOf { it.vertices.size }
        require(total / 9 <= MAX_TRIANGLES) { "3MF is too complex after merging objects" }
        val vertices = FloatArray(total)
        var offset=0
        var minX=Float.POSITIVE_INFINITY; var minY=Float.POSITIVE_INFINITY; var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY; var maxY=Float.NEGATIVE_INFINITY; var maxZ=Float.NEGATIVE_INFINITY
        for(m in meshes){
            m.vertices.copyInto(vertices,offset)
            offset += m.vertices.size
            minX=min(minX,m.minX); minY=min(minY,m.minY); minZ=min(minZ,m.minZ)
            maxX=max(maxX,m.maxX); maxY=max(maxY,m.maxY); maxZ=max(maxZ,m.maxZ)
        }
        return Mesh(vertices,FloatArray(0),minX,minY,minZ,maxX,maxY,maxZ)
    }

    private fun findModelXml(input: InputStream): ByteArray? {
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && entry.name.endsWith(".model", true) && entry.name.contains("3D/", true)) return readLimited(zip)
                zip.closeEntry()
            }
        }
        return null
    }

    private fun readLimited(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream(minOf(1024 * 1024, MAX_MODEL_XML_BYTES))
        val buffer = ByteArray(64 * 1024)
        var total = 0
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            total += n
            if (total > MAX_MODEL_XML_BYTES) throw IllegalArgumentException("3MF model data is too large for safe mobile import")
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    private fun unitScale(unit: String): Float = when (unit.lowercase()) {
        "micron" -> 0.001f
        "centimeter" -> 10f
        "meter" -> 1000f
        "inch" -> 25.4f
        "foot" -> 304.8f
        else -> 1f
    }

    private fun faceNormal(p: FloatArray): FloatArray {
        val ax=p[3]-p[0]; val ay=p[4]-p[1]; val az=p[5]-p[2]
        val bx=p[6]-p[0]; val by=p[7]-p[1]; val bz=p[8]-p[2]
        var nx=ay*bz-az*by; var ny=az*bx-ax*bz; var nz=ax*by-ay*bx
        val len=sqrt(nx*nx+ny*ny+nz*nz)
        if(len>1e-8f){nx/=len;ny/=len;nz/=len}
        return floatArrayOf(nx,ny,nz)
    }
}
