package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.roundToInt

/** Lightweight vertical layer scrubber; top of the control maps to the highest layer. */
class VerticalLayerSlider(context:Context):View(context){
    private val track=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(70,77,82);strokeWidth=5f;strokeCap=Paint.Cap.ROUND}
    private val active=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(71,214,164);strokeWidth=5f;strokeCap=Paint.Cap.ROUND}
    private val knob=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE;style=Paint.Style.FILL}
    private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(175,183,188);textSize=22f;textAlign=Paint.Align.CENTER}
    var max:Int=0
        set(value){field=value.coerceAtLeast(0);progress=progress.coerceIn(0,field);invalidate()}
    var progress:Int=0
        set(value){val next=value.coerceIn(0,max);if(field!=next){field=next;onProgressChanged?.invoke(next)};invalidate()}
    var onProgressChanged:((Int)->Unit)?=null

    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas)
        val top=34f;val bottom=height-34f;val x=width*0.5f
        canvas.drawLine(x,top,x,bottom,track)
        val fraction=if(max<=0)0f else progress.toFloat()/max
        val y=bottom-(bottom-top)*fraction
        canvas.drawLine(x,bottom,x,y,active)
        canvas.drawCircle(x,y,12f,knob)
        canvas.drawText(if(max>0)"${max+1}" else "1",x,24f,text)
        canvas.drawText("1",x,height-8f,text)
    }

    override fun onTouchEvent(event:MotionEvent):Boolean{
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE->{
                parent?.requestDisallowInterceptTouchEvent(true)
                val top=34f;val bottom=height-34f
                val f=((bottom-event.y)/(bottom-top)).coerceIn(0f,1f)
                progress=(f*max).roundToInt();return true
            }
            MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{parent?.requestDisallowInterceptTouchEvent(false);return true}
        }
        return super.onTouchEvent(event)
    }
}
