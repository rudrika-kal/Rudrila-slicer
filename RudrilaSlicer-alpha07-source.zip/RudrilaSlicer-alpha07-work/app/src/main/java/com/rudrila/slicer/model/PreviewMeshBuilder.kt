package com.rudrila.slicer.model

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Builds a bounded display mesh for very dense STL/3MF geometry.
 *
 * Uniform triangle skipping makes dense models look like a cloud of dots. Instead this builder
 * vertex-clusters the complete surface onto a coarse 3D grid and only removes triangles that
 * collapse inside a grid cell. The result preserves the silhouette and large surface patches while
 * keeping GPU memory bounded. The exact original mesh remains untouched for slicing/export.
 */
object PreviewMeshBuilder {
    const val DEFAULT_MAX_PREVIEW_TRIANGLES = 800_000
    const val DEFAULT_EXACT_TRIANGLE_LIMIT = 500_000

    data class Result(
        val vertices: FloatBuffer,
        val triangleCount: Int,
        val simplified: Boolean,
        val gridResolution: Int
    )

    fun build(
        mesh: Mesh,
        maxPreviewTriangles: Int = DEFAULT_MAX_PREVIEW_TRIANGLES,
        exactTriangleLimit: Int = DEFAULT_EXACT_TRIANGLE_LIMIT
    ): Result {
        require(maxPreviewTriangles > 0)
        val totalTriangles = mesh.vertexCount / 3
        if (totalTriangles <= exactTriangleLimit) {
            val out = allocate(totalTriangles)
            out.put(mesh.vertices)
            out.position(0)
            return Result(out, totalTriangles, simplified = false, gridResolution = 0)
        }

        // Start detailed, then lower the clustering resolution until the complete clustered surface
        // fits the GPU budget. This is deterministic and covers the whole model, unlike stride sampling.
        val candidateResolutions = intArrayOf(320, 256, 224, 192, 160, 128, 96, 72, 56, 40)
        var chosenResolution = candidateResolutions.last()
        var clusteredCount = Int.MAX_VALUE
        for (resolution in candidateResolutions) {
            val count = countClusteredTriangles(mesh, resolution, maxPreviewTriangles + 1)
            chosenResolution = resolution
            clusteredCount = count
            if (count <= maxPreviewTriangles) break
        }

        // If even the coarsest grid still exceeds the budget, get the real survivor count before
        // spacing samples across the entire clustered stream. The capped probe count above is only
        // enough for choosing a grid resolution, not for calculating the final stride.
        if (clusteredCount > maxPreviewTriangles && chosenResolution == candidateResolutions.last()) {
            clusteredCount = countClusteredTriangles(mesh, chosenResolution, Int.MAX_VALUE)
        }
        val boundedCount = min(clusteredCount, maxPreviewTriangles)
        val out = allocate(boundedCount)
        val survivorStride = if (clusteredCount <= maxPreviewTriangles) 1.0
        else clusteredCount.toDouble() / maxPreviewTriangles.toDouble()
        var survivorIndex = 0
        var nextKeep = 0.0
        var written = 0

        val q = Quantizer(mesh, chosenResolution)
        val v = mesh.vertices
        var base = 0
        while (base + 8 < v.size && written < boundedCount) {
            val ax=q.x(v[base]); val ay=q.y(v[base+1]); val az=q.z(v[base+2])
            val bx=q.x(v[base+3]); val by=q.y(v[base+4]); val bz=q.z(v[base+5])
            val cx=q.x(v[base+6]); val cy=q.y(v[base+7]); val cz=q.z(v[base+8])
            if (!collapsed(ax,ay,az,bx,by,bz,cx,cy,cz)) {
                val shouldKeep = clusteredCount <= maxPreviewTriangles || survivorIndex.toDouble() + 1e-9 >= nextKeep
                if (shouldKeep) {
                    out.put(q.px(ax)).put(q.py(ay)).put(q.pz(az))
                    out.put(q.px(bx)).put(q.py(by)).put(q.pz(bz))
                    out.put(q.px(cx)).put(q.py(cy)).put(q.pz(cz))
                    written++
                    nextKeep += survivorStride
                }
                survivorIndex++
            }
            base += 9
        }
        out.position(0)
        out.limit(written * 9)
        return Result(out, written, simplified = true, gridResolution = chosenResolution)
    }

    private fun countClusteredTriangles(mesh: Mesh, resolution: Int, stopAfter: Int): Int {
        val q = Quantizer(mesh, resolution)
        val v = mesh.vertices
        var count = 0
        var base = 0
        while (base + 8 < v.size) {
            val ax=q.x(v[base]); val ay=q.y(v[base+1]); val az=q.z(v[base+2])
            val bx=q.x(v[base+3]); val by=q.y(v[base+4]); val bz=q.z(v[base+5])
            val cx=q.x(v[base+6]); val cy=q.y(v[base+7]); val cz=q.z(v[base+8])
            if (!collapsed(ax,ay,az,bx,by,bz,cx,cy,cz)) {
                count++
                if (count >= stopAfter) return count
            }
            base += 9
        }
        return count
    }

    private fun collapsed(ax:Int,ay:Int,az:Int,bx:Int,by:Int,bz:Int,cx:Int,cy:Int,cz:Int):Boolean {
        val ab = ax==bx && ay==by && az==bz
        val ac = ax==cx && ay==cy && az==cz
        val bc = bx==cx && by==cy && bz==cz
        return ab || ac || bc
    }

    private class Quantizer(mesh: Mesh, private val resolution: Int) {
        private val minX=mesh.minX; private val minY=mesh.minY; private val minZ=mesh.minZ
        private val spanX=max(1e-6f,mesh.maxX-mesh.minX)
        private val spanY=max(1e-6f,mesh.maxY-mesh.minY)
        private val spanZ=max(1e-6f,mesh.maxZ-mesh.minZ)
        private val longest=max(spanX,max(spanY,spanZ))
        private val rx=max(1,(resolution*spanX/longest).toInt())
        private val ry=max(1,(resolution*spanY/longest).toInt())
        private val rz=max(1,(resolution*spanZ/longest).toInt())

        fun x(v:Float)=quant(v,minX,spanX,rx)
        fun y(v:Float)=quant(v,minY,spanY,ry)
        fun z(v:Float)=quant(v,minZ,spanZ,rz)
        fun px(i:Int)=minX + spanX * i.toFloat()/rx.toFloat()
        fun py(i:Int)=minY + spanY * i.toFloat()/ry.toFloat()
        fun pz(i:Int)=minZ + spanZ * i.toFloat()/rz.toFloat()
        private fun quant(v:Float,minV:Float,span:Float,r:Int):Int =
            (((v-minV)/span)*r.toFloat()).toInt().coerceIn(0,r)
    }

    private fun allocate(triangles:Int):FloatBuffer =
        ByteBuffer.allocateDirect(triangles * 9 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
}
