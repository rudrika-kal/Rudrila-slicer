package com.rudrila.slicer.model

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Builds a bounded display mesh for very dense STL/3MF geometry.
 *
 * Uniform triangle skipping makes dense models look like a cloud of dots. Instead this builder
 * vertex-clusters the complete surface onto a coarse 3D grid and only removes triangles that
 * collapse inside a grid cell. The result preserves the silhouette and large surface patches while
 * keeping GPU memory bounded. The exact original mesh remains untouched for slicing/export.
 */
object PreviewMeshBuilder {
    const val DEFAULT_MAX_PREVIEW_TRIANGLES = 500_000
    const val DEFAULT_EXACT_TRIANGLE_LIMIT = 500_000

    data class Result(
        val vertices: FloatBuffer,
        val normals: FloatBuffer,
        val triangleCount: Int,
        val simplified: Boolean,
        val gridResolution: Int
    )

    fun build(
        mesh: Mesh,
        maxPreviewTriangles: Int = DEFAULT_MAX_PREVIEW_TRIANGLES,
        exactTriangleLimit: Int = DEFAULT_EXACT_TRIANGLE_LIMIT,
        buildNormals: Boolean = true
    ): Result {
        require(maxPreviewTriangles > 0)
        val totalTriangles = mesh.vertexCount / 3
        if (totalTriangles <= exactTriangleLimit) {
            val out = allocate(totalTriangles)
            out.put(mesh.vertices)
            out.position(0)
            val normals = if (buildNormals) buildSmoothNormals(out, mesh) else emptyBuffer()
            return Result(out, normals, totalTriangles, simplified = false, gridResolution = 0)
        }

        // Start detailed, then lower the clustering resolution until the complete clustered surface
        // fits the GPU budget. This is deterministic and covers the whole model, unlike stride sampling.
        val candidateResolutions = intArrayOf(320, 256, 224, 192, 160, 128, 96, 72, 56, 40)
        var chosenResolution = candidateResolutions.last()
        var clusteredCount = Int.MAX_VALUE
        for (resolution in candidateResolutions) {
            val count = countClusteredTriangles(mesh, resolution, maxPreviewTriangles + 1)
            chosenResolution = resolution
            clusteredCount = count
            if (count <= maxPreviewTriangles) break
        }

        // If even the coarsest grid still exceeds the budget, get the real survivor count before
        // spacing samples across the entire clustered stream. The capped probe count above is only
        // enough for choosing a grid resolution, not for calculating the final stride.
        if (clusteredCount > maxPreviewTriangles && chosenResolution == candidateResolutions.last()) {
            clusteredCount = countClusteredTriangles(mesh, chosenResolution, Int.MAX_VALUE)
        }
        val boundedCount = min(clusteredCount, maxPreviewTriangles)
        val out = allocate(boundedCount)
        val survivorStride = if (clusteredCount <= maxPreviewTriangles) 1.0
        else clusteredCount.toDouble() / maxPreviewTriangles.toDouble()
        var survivorIndex = 0
        var nextKeep = 0.0
        var written = 0

        val q = Quantizer(mesh, chosenResolution)
        val v = mesh.vertices
        var base = 0
        while (base + 8 < v.size && written < boundedCount) {
            val ax=q.x(v[base]); val ay=q.y(v[base+1]); val az=q.z(v[base+2])
            val bx=q.x(v[base+3]); val by=q.y(v[base+4]); val bz=q.z(v[base+5])
            val cx=q.x(v[base+6]); val cy=q.y(v[base+7]); val cz=q.z(v[base+8])
            if (!collapsed(ax,ay,az,bx,by,bz,cx,cy,cz)) {
                val shouldKeep = clusteredCount <= maxPreviewTriangles || survivorIndex.toDouble() + 1e-9 >= nextKeep
                if (shouldKeep) {
                    out.put(q.px(ax)).put(q.py(ay)).put(q.pz(az))
                    out.put(q.px(bx)).put(q.py(by)).put(q.pz(bz))
                    out.put(q.px(cx)).put(q.py(cy)).put(q.pz(cz))
                    written++
                    nextKeep += survivorStride
                }
                survivorIndex++
            }
            base += 9
        }
        out.position(0)
        out.limit(written * 9)
        val normals = if (buildNormals) buildSmoothNormals(out, mesh) else emptyBuffer()
        return Result(out, normals, written, simplified = true, gridResolution = chosenResolution)
    }

    /**
     * Builds area-weighted, spatially-smoothed vertex normals for the bounded preview only.
     * STL stores independent facet vertices, so flat per-triangle lighting makes a dense curved
     * model look like sand/noise.  A fixed 3D normal field gives visually smooth shading without
     * duplicating or indexing the multi-million-triangle source mesh.
     */
    private fun buildSmoothNormals(vertices: FloatBuffer, mesh: Mesh): FloatBuffer {
        val count = vertices.limit()
        val out = ByteBuffer.allocateDirect(count * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        if (count == 0) return out

        // 96^3 cells = ~10.6 MB for XYZ sums: bounded even for a 10M-triangle source STL.
        val res = 96
        val cellCount = res * res * res
        val sum = FloatArray(cellCount * 3)
        val minX = mesh.minX; val minY = mesh.minY; val minZ = mesh.minZ
        val spanX = max(1e-6f, mesh.maxX - mesh.minX)
        val spanY = max(1e-6f, mesh.maxY - mesh.minY)
        val spanZ = max(1e-6f, mesh.maxZ - mesh.minZ)
        val centerX = mesh.centerX; val centerY = mesh.centerY; val centerZ = mesh.centerZ

        fun cell(x: Float, y: Float, z: Float): Int {
            val ix = (((x - minX) / spanX) * (res - 1)).toInt().coerceIn(0, res - 1)
            val iy = (((y - minY) / spanY) * (res - 1)).toInt().coerceIn(0, res - 1)
            val iz = (((z - minZ) / spanZ) * (res - 1)).toInt().coerceIn(0, res - 1)
            return (iz * res + iy) * res + ix
        }

        val src = vertices.duplicate().apply { position(0) }
        while (src.remaining() >= 9) {
            val ax=src.get(); val ay=src.get(); val az=src.get()
            val bx=src.get(); val by=src.get(); val bz=src.get()
            val cx=src.get(); val cy=src.get(); val cz=src.get()
            val e1x=bx-ax; val e1y=by-ay; val e1z=bz-az
            val e2x=cx-ax; val e2y=cy-ay; val e2z=cz-az
            var nx=e1y*e2z-e1z*e2y
            var ny=e1z*e2x-e1x*e2z
            var nz=e1x*e2y-e1y*e2x
            val len2=nx*nx+ny*ny+nz*nz
            if (len2 > 1e-18f) {
                // STL winding is not always trustworthy. For a closed object, choose the
                // orientation pointing away from the mesh centre before averaging.
                val mx=(ax+bx+cx)/3f-centerX
                val my=(ay+by+cy)/3f-centerY
                val mz=(az+bz+cz)/3f-centerZ
                if (nx*mx + ny*my + nz*mz < 0f) { nx=-nx; ny=-ny; nz=-nz }
                fun add(x:Float,y:Float,z:Float) {
                    val o=cell(x,y,z)*3; sum[o]+=nx; sum[o+1]+=ny; sum[o+2]+=nz
                }
                add(ax,ay,az); add(bx,by,bz); add(cx,cy,cz)
            }
        }

        val src2 = vertices.duplicate().apply { position(0) }
        while (src2.remaining() >= 3) {
            val x=src2.get(); val y=src2.get(); val z=src2.get()
            val o=cell(x,y,z)*3
            var nx=sum[o]; var ny=sum[o+1]; var nz=sum[o+2]
            var len=sqrt(nx*nx+ny*ny+nz*nz)
            if (len < 1e-8f) {
                nx=x-centerX; ny=y-centerY; nz=z-centerZ
                len=sqrt(nx*nx+ny*ny+nz*nz)
            }
            if (len < 1e-8f) { out.put(0f).put(0f).put(1f) }
            else { out.put(nx/len).put(ny/len).put(nz/len) }
        }
        out.position(0)
        return out
    }

    private fun countClusteredTriangles(mesh: Mesh, resolution: Int, stopAfter: Int): Int {
        val q = Quantizer(mesh, resolution)
        val v = mesh.vertices
        var count = 0
        var base = 0
        while (base + 8 < v.size) {
            val ax=q.x(v[base]); val ay=q.y(v[base+1]); val az=q.z(v[base+2])
            val bx=q.x(v[base+3]); val by=q.y(v[base+4]); val bz=q.z(v[base+5])
            val cx=q.x(v[base+6]); val cy=q.y(v[base+7]); val cz=q.z(v[base+8])
            if (!collapsed(ax,ay,az,bx,by,bz,cx,cy,cz)) {
                count++
                if (count >= stopAfter) return count
            }
            base += 9
        }
        return count
    }

    private fun collapsed(ax:Int,ay:Int,az:Int,bx:Int,by:Int,bz:Int,cx:Int,cy:Int,cz:Int):Boolean {
        val ab = ax==bx && ay==by && az==bz
        val ac = ax==cx && ay==cy && az==cz
        val bc = bx==cx && by==cy && bz==cz
        return ab || ac || bc
    }

    private class Quantizer(mesh: Mesh, private val resolution: Int) {
        private val minX=mesh.minX; private val minY=mesh.minY; private val minZ=mesh.minZ
        private val spanX=max(1e-6f,mesh.maxX-mesh.minX)
        private val spanY=max(1e-6f,mesh.maxY-mesh.minY)
        private val spanZ=max(1e-6f,mesh.maxZ-mesh.minZ)
        private val longest=max(spanX,max(spanY,spanZ))
        private val rx=max(1,(resolution*spanX/longest).toInt())
        private val ry=max(1,(resolution*spanY/longest).toInt())
        private val rz=max(1,(resolution*spanZ/longest).toInt())

        fun x(v:Float)=quant(v,minX,spanX,rx)
        fun y(v:Float)=quant(v,minY,spanY,ry)
        fun z(v:Float)=quant(v,minZ,spanZ,rz)
        fun px(i:Int)=minX + spanX * i.toFloat()/rx.toFloat()
        fun py(i:Int)=minY + spanY * i.toFloat()/ry.toFloat()
        fun pz(i:Int)=minZ + spanZ * i.toFloat()/rz.toFloat()
        private fun quant(v:Float,minV:Float,span:Float,r:Int):Int =
            (((v-minV)/span)*r.toFloat()).toInt().coerceIn(0,r)
    }

    private fun emptyBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private fun allocate(triangles:Int):FloatBuffer =
        ByteBuffer.allocateDirect(triangles * 9 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
}
