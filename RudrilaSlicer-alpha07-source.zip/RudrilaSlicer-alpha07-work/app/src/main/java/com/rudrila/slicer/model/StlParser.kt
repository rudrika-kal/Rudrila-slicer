package com.rudrila.slicer.model

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object StlParser {
    // Keep enough headroom for Android UI + GPU buffers. Very large meshes should be simplified before mobile import.
    private const val MAX_TRIANGLES = 1_000_000
    private const val MAX_FLOATS = MAX_TRIANGLES * 9

    private enum class StlFormat { BINARY, ASCII }

    private data class Probe(
        val format: StlFormat,
        val binaryHeaderPresent: Boolean,
        val asciiLike: Boolean
    )

    fun parse(resolver: ContentResolver, uri: Uri): Mesh {
        val probe = probeFormat(resolver, uri)
        return try {
            when (probe.format) {
                StlFormat.BINARY -> {
                    try {
                        parseBinary(resolver, uri)
                    } catch (binaryError: Throwable) {
                        // Only try ASCII when the bytes genuinely look textual. This prevents a valid
                        // dense binary STL from being reported as the misleading "Invalid ASCII STL".
                        if (probe.asciiLike) {
                            try { parseAscii(resolver, uri) } catch (_: Throwable) { throw binaryError }
                        } else {
                            throw binaryError
                        }
                    }
                }
                StlFormat.ASCII -> {
                    try {
                        parseAscii(resolver, uri)
                    } catch (asciiError: Throwable) {
                        // A binary STL is allowed to start with the word "solid". If an 84-byte binary
                        // header is present, preserve the binary parser's diagnostic if ASCII parsing fails.
                        if (probe.binaryHeaderPresent) {
                            try { parseBinary(resolver, uri) } catch (binaryError: Throwable) { throw binaryError }
                        } else {
                            throw asciiError
                        }
                    }
                }
            }
        } catch (_: OutOfMemoryError) {
            throw IllegalArgumentException("Model is too large for mobile memory. Please simplify the STL and try again.")
        }
    }

    /**
     * Robust STL format probing for Android Storage Access Framework providers.
     *
     * Do not rely on AssetFileDescriptor.length: Downloads, Drive and other providers can report -1 or
     * a provider-specific value. Also do not reject a binary header merely because its triangle count is
     * above the mobile import cap; doing that used to route dense binary files into the ASCII parser and
     * display the wrong "Invalid ASCII STL" error.
     */
    private fun probeFormat(resolver: ContentResolver, uri: Uri): Probe {
        val prefix = ByteArray(1024)
        val read = resolver.openInputStream(uri)?.use { raw ->
            val input = BufferedInputStream(raw)
            var off = 0
            while (off < prefix.size) {
                val n = input.read(prefix, off, prefix.size - off)
                if (n < 0) break
                off += n
            }
            off
        } ?: throw IllegalArgumentException("Unable to open STL")

        val asciiLike = looksLikeAsciiStl(prefix, read)
        if (read < 84) return Probe(StlFormat.ASCII, binaryHeaderPresent = false, asciiLike = asciiLike)

        val count = ByteBuffer.wrap(prefix, 80, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
        val binaryHeaderPresent = count > 0L
        val expected = if (count <= (Long.MAX_VALUE - 84L) / 50L) 84L + count * 50L else Long.MAX_VALUE
        val length = try {
            resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        } catch (_: Throwable) {
            -1L
        }

        // Exact binary size is definitive when a provider exposes a trustworthy length.
        if (length > 0L && expected == length) {
            return Probe(StlFormat.BINARY, binaryHeaderPresent = true, asciiLike = asciiLike)
        }

        // Textual STL has a readable "solid ... facet ... vertex ..." prefix. Binary records normally
        // contain many non-printable float bytes, even when their 80-byte header happens to start "solid".
        if (asciiLike) {
            return Probe(StlFormat.ASCII, binaryHeaderPresent = binaryHeaderPresent, asciiLike = true)
        }

        // For non-text data, any positive triangle count is enough to try the binary parser. The parser
        // itself enforces MAX_TRIANGLES and therefore returns a useful "too large" message when required.
        return Probe(
            if (binaryHeaderPresent) StlFormat.BINARY else StlFormat.ASCII,
            binaryHeaderPresent = binaryHeaderPresent,
            asciiLike = false
        )
    }

    private fun looksLikeAsciiStl(bytes: ByteArray, length: Int): Boolean {
        if (length <= 0) return false
        val sampleLength = min(length, 1024)
        var printable = 0
        for (i in 0 until sampleLength) {
            val value = bytes[i].toInt() and 0xff
            if (value == 9 || value == 10 || value == 13 || value in 32..126) printable++
        }
        if (printable * 100 < sampleLength * 92) return false

        val text = bytes.copyOf(sampleLength).toString(Charsets.US_ASCII).lowercase()
        val trimmed = text.trimStart('\u0000', ' ', '\t', '\r', '\n')
        return trimmed.startsWith("solid") && (text.contains("facet") || text.contains("vertex"))
    }

    private fun parseBinary(resolver: ContentResolver, uri: Uri): Mesh {
        resolver.openInputStream(uri)?.use { raw ->
            val input = BufferedInputStream(raw, 1024 * 1024)
            val header = ByteArray(80)
            readFully(input, header)
            val countBytes = ByteArray(4)
            readFully(input, countBytes)
            val triangleCount = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
            require(triangleCount in 1..MAX_TRIANGLES.toLong()) { "STL is too large for mobile import (${triangleCount} triangles)" }
            val triangles = triangleCount.toInt()

            val vertices = FloatArray(triangles * 9)
            val normals = FloatArray(triangles * 9)
            val record = ByteArray(50)
            val b = ByteBuffer.wrap(record).order(ByteOrder.LITTLE_ENDIAN)
            var v = 0
            var minX = Float.POSITIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY
            var minZ = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY
            var maxY = Float.NEGATIVE_INFINITY
            var maxZ = Float.NEGATIVE_INFINITY

            repeat(triangles) {
                readFully(input, record)
                b.clear()
                var nx = b.float
                var ny = b.float
                var nz = b.float

                val ax = b.float; val ay = b.float; val az = b.float
                val bx = b.float; val by = b.float; val bz = b.float
                val cx = b.float; val cy = b.float; val cz = b.float

                if (nx == 0f && ny == 0f && nz == 0f) {
                    val ux = bx - ax; val uy = by - ay; val uz = bz - az
                    val vx = cx - ax; val vy = cy - ay; val vz = cz - az
                    nx = uy * vz - uz * vy
                    ny = uz * vx - ux * vz
                    nz = ux * vy - uy * vx
                    val len = sqrt(nx * nx + ny * ny + nz * nz)
                    if (len > 1e-8f) { nx /= len; ny /= len; nz /= len }
                }

                val coords = floatArrayOf(ax,ay,az,bx,by,bz,cx,cy,cz)
                var i = 0
                while (i < 9) {
                    val x = coords[i]; val y = coords[i + 1]; val z = coords[i + 2]
                    vertices[v] = x; vertices[v + 1] = y; vertices[v + 2] = z
                    normals[v] = nx; normals[v + 1] = ny; normals[v + 2] = nz
                    minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                    maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                    v += 3; i += 3
                }
            }
            return Mesh(vertices, normals, minX, minY, minZ, maxX, maxY, maxZ)
        }
        throw IllegalArgumentException("Unable to open STL")
    }

    private fun parseAscii(resolver: ContentResolver, uri: Uri): Mesh {
        val verts = FloatBuilder(262_144)
        val norms = FloatBuilder(262_144)
        var currentNx = 0f; var currentNy = 0f; var currentNz = 1f
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY

        resolver.openInputStream(uri)?.use { raw ->
            BufferedReader(InputStreamReader(raw), 128 * 1024).useLines { lines ->
                lines.forEach { rawLine ->
                    val line = rawLine.trim()
                    when {
                        line.startsWith("facet normal", ignoreCase = true) -> {
                            val p = line.split(Regex("\\s+"), limit = 6)
                            if (p.size >= 5) {
                                currentNx = p[2].toFloatOrNull() ?: 0f
                                currentNy = p[3].toFloatOrNull() ?: 0f
                                currentNz = p[4].toFloatOrNull() ?: 1f
                            }
                        }
                        line.startsWith("vertex", ignoreCase = true) -> {
                            val p = line.split(Regex("\\s+"), limit = 5)
                            if (p.size >= 4) {
                                require(verts.size + 3 <= MAX_FLOATS) { "STL is too large for mobile import" }
                                val x = p[1].toFloat(); val y = p[2].toFloat(); val z = p[3].toFloat()
                                verts.add3(x,y,z); norms.add3(currentNx,currentNy,currentNz)
                                minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                                maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                            }
                        }
                    }
                }
            }
        }
        require(verts.size >= 9 && verts.size % 9 == 0) { "Invalid ASCII STL" }
        return Mesh(verts.toArray(), norms.toArray(), minX, minY, minZ, maxX, maxY, maxZ)
    }

    private class FloatBuilder(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity.coerceAtLeast(16))
        var size: Int = 0
            private set
        fun add3(a: Float, b: Float, c: Float) {
            ensure(size + 3)
            data[size++] = a; data[size++] = b; data[size++] = c
        }
        private fun ensure(required: Int) {
            if (required <= data.size) return
            var next = data.size
            while (next < required) next = (next * 3 / 2 + 16).coerceAtMost(MAX_FLOATS)
            require(next >= required) { "STL is too large for mobile import" }
            data = data.copyOf(next)
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    private fun readFully(input: BufferedInputStream, bytes: ByteArray) {
        var offset = 0
        while (offset < bytes.size) {
            val n = input.read(bytes, offset, bytes.size - offset)
            if (n < 0) throw IllegalArgumentException("Unexpected end of STL")
            offset += n
        }
    }
}
