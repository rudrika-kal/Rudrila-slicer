package com.rudrila.slicer.model

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

object StlParser {
    private const val MAX_TRIANGLES = 1_500_000

    fun parse(resolver: ContentResolver, uri: Uri): Mesh {
        val length = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        return resolver.openInputStream(uri)?.use { parse(it, length) }
            ?: throw IllegalArgumentException("Unable to open STL")
    }

    /** Pure stream entry point used by tests and by the Android resolver path. */
    fun parse(input: InputStream, length: Long = -1L): Mesh {
        val buffered = if (input is BufferedInputStream) input else BufferedInputStream(input, 1024 * 1024)
        buffered.mark(96)
        val header = ByteArray(84)
        var read = 0
        while (read < header.size) {
            val n = buffered.read(header, read, header.size - read)
            if (n < 0) break
            read += n
        }
        buffered.reset()
        if (read < 15) throw IllegalArgumentException("STL file is empty or truncated")

        val startsSolid = String(header, 0, min(5, read), Charsets.US_ASCII).equals("solid", ignoreCase = true)
        val count = if (read >= 84) (ByteBuffer.wrap(header, 80, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL) else -1L
        val expected = if (count >= 0) 84L + count * 50L else -1L
        val headerCountPlausible = count in 1..5_000_000L
        val exactBinarySize = length > 0L && headerCountPlausible && expected == length
        val paddedBinarySize = length > 0L && headerCountPlausible && expected < length && length - expected <= 1024L * 1024L
        val isBinary = exactBinarySize || paddedBinarySize || (!startsSolid && headerCountPlausible && (length < 0L || expected <= length))

        return if (isBinary) parseBinary(buffered) else parseAscii(buffered, length)
    }

    private fun parseBinary(input: BufferedInputStream): Mesh {
        val header = ByteArray(80); readFully(input, header)
        val countBytes = ByteArray(4); readFully(input, countBytes)
        val triangles = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).int
        require(triangles in 1..MAX_TRIANGLES) { "STL is too complex (${triangles.toLong() and 0xffffffffL} triangles; max $MAX_TRIANGLES)" }

        val vertices = try { FloatArray(triangles * 9) } catch (_: OutOfMemoryError) {
            throw IllegalArgumentException("STL is too large for available memory")
        }
        val record = ByteArray(50)
        var v = 0
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY

        repeat(triangles) {
            readFully(input, record)
            val b = ByteBuffer.wrap(record).order(ByteOrder.LITTLE_ENDIAN)
            b.position(12) // stored normal is not retained; preview computes flat normals in the shader.
            repeat(3) {
                val x = b.float; val y = b.float; val z = b.float
                require(x.isFinite() && y.isFinite() && z.isFinite()) { "STL contains invalid coordinates" }
                vertices[v++] = x; vertices[v++] = y; vertices[v++] = z
                minX=min(minX,x); minY=min(minY,y); minZ=min(minZ,z)
                maxX=max(maxX,x); maxY=max(maxY,y); maxZ=max(maxZ,z)
            }
        }
        return Mesh(vertices, FloatArray(0), minX,minY,minZ,maxX,maxY,maxZ)
    }

    private fun parseAscii(input: BufferedInputStream, length: Long): Mesh {
        val initial = when {
            length in 1..64_000_000L -> (length / 8L).toInt().coerceIn(1024, 1_000_000)
            else -> 64 * 1024
        }
        val verts = FloatBuilder(initial)
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY

        BufferedReader(InputStreamReader(input), 128 * 1024).useLines { lines ->
            lines.forEach { rawLine ->
                val line = rawLine.trim()
                if (line.startsWith("vertex", ignoreCase = true)) {
                    val p = line.split(Regex("\\s+"))
                    if (p.size >= 4) {
                        val x=p[1].toFloatOrNull() ?: throw IllegalArgumentException("Invalid ASCII STL vertex")
                        val y=p[2].toFloatOrNull() ?: throw IllegalArgumentException("Invalid ASCII STL vertex")
                        val z=p[3].toFloatOrNull() ?: throw IllegalArgumentException("Invalid ASCII STL vertex")
                        require(x.isFinite() && y.isFinite() && z.isFinite()) { "STL contains invalid coordinates" }
                        verts.add(x); verts.add(y); verts.add(z)
                        if (verts.size > MAX_TRIANGLES * 9) throw IllegalArgumentException("STL is too complex (max $MAX_TRIANGLES triangles)")
                        minX=min(minX,x); minY=min(minY,y); minZ=min(minZ,z)
                        maxX=max(maxX,x); maxY=max(maxY,y); maxZ=max(maxZ,z)
                    }
                }
            }
        }
        require(verts.size >= 9 && verts.size % 9 == 0) { "Invalid ASCII STL" }
        return Mesh(verts.toArray(), FloatArray(0), minX,minY,minZ,maxX,maxY,maxZ)
    }

    private fun readFully(input: BufferedInputStream, bytes: ByteArray) {
        var offset=0
        while(offset<bytes.size){
            val n=input.read(bytes,offset,bytes.size-offset)
            if(n<0) throw IllegalArgumentException("Unexpected end of STL")
            offset+=n
        }
    }

    private class FloatBuilder(initial: Int) {
        private var data = FloatArray(initial.coerceAtLeast(16))
        var size = 0; private set
        fun add(v: Float) {
            if (size == data.size) {
                val next = (data.size.toLong() * 3L / 2L + 16L).coerceAtMost((MAX_TRIANGLES * 9).toLong()).toInt()
                if (next <= data.size) throw IllegalArgumentException("STL is too complex")
                data = data.copyOf(next)
            }
            data[size++] = v
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }
}
