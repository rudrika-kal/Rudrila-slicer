package com.rudrila.slicer.model

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object StlParser {
    // Binary STL stores only exact XYZ vertices. Preview normals stay renderer-side, so a 10M-triangle
    // binary STL uses about 360 MB for exact geometry instead of roughly double that. The renderer
    // separately samples a bounded preview and does not upload all 10M triangles to the GPU.
    private const val MAX_TRIANGLES = 10_000_000
    private const val MAX_FLOATS = MAX_TRIANGLES * 9

    private enum class StlFormat { BINARY, ASCII }

    private data class Probe(
        val format: StlFormat,
        val binaryHeaderPresent: Boolean,
        val asciiLike: Boolean
    )

    fun parse(resolver: ContentResolver, uri: Uri): Mesh {
        val probe = probeFormat(resolver, uri)
        return try {
            when (probe.format) {
                StlFormat.BINARY -> {
                    try {
                        parseBinary(resolver, uri)
                    } catch (binaryError: Throwable) {
                        // Only try ASCII when the bytes genuinely look textual. This prevents a valid
                        // dense binary STL from being reported as the misleading "Invalid ASCII STL".
                        if (probe.asciiLike) {
                            try { parseAscii(resolver, uri) } catch (_: Throwable) { throw binaryError }
                        } else {
                            throw binaryError
                        }
                    }
                }
                StlFormat.ASCII -> {
                    try {
                        parseAscii(resolver, uri)
                    } catch (asciiError: Throwable) {
                        // A binary STL is allowed to start with the word "solid". If an 84-byte binary
                        // header is present, preserve the binary parser's diagnostic if ASCII parsing fails.
                        if (probe.binaryHeaderPresent) {
                            try { parseBinary(resolver, uri) } catch (binaryError: Throwable) { throw binaryError }
                        } else {
                            throw asciiError
                        }
                    }
                }
            }
        } catch (_: OutOfMemoryError) {
            throw IllegalArgumentException("Model is too large for mobile memory. Please simplify the STL and try again.")
        }
    }

    /**
     * Robust STL format probing for Android Storage Access Framework providers.
     *
     * Do not rely on AssetFileDescriptor.length: Downloads, Drive and other providers can report -1 or
     * a provider-specific value. Also do not reject a binary header merely because its triangle count is
     * above the mobile import cap; doing that used to route dense binary files into the ASCII parser and
     * display the wrong "Invalid ASCII STL" error.
     */
    private fun probeFormat(resolver: ContentResolver, uri: Uri): Probe {
        val prefix = ByteArray(1024)
        val read = resolver.openInputStream(uri)?.use { raw ->
            val input = BufferedInputStream(raw)
            var off = 0
            while (off < prefix.size) {
                val n = input.read(prefix, off, prefix.size - off)
                if (n < 0) break
                off += n
            }
            off
        } ?: throw IllegalArgumentException("Unable to open STL")

        val asciiLike = looksLikeAsciiStl(prefix, read)
        if (read < 84) return Probe(StlFormat.ASCII, binaryHeaderPresent = false, asciiLike = asciiLike)

        val count = ByteBuffer.wrap(prefix, 80, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
        val binaryHeaderPresent = count > 0L
        val expected = if (count <= (Long.MAX_VALUE - 84L) / 50L) 84L + count * 50L else Long.MAX_VALUE
        val length = try {
            resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        } catch (_: Throwable) {
            -1L
        }

        // Exact binary size is definitive when a provider exposes a trustworthy length.
        if (length > 0L && expected == length) {
            return Probe(StlFormat.BINARY, binaryHeaderPresent = true, asciiLike = asciiLike)
        }

        // Textual STL has a readable "solid ... facet ... vertex ..." prefix. Binary records normally
        // contain many non-printable float bytes, even when their 80-byte header happens to start "solid".
        if (asciiLike) {
            return Probe(StlFormat.ASCII, binaryHeaderPresent = binaryHeaderPresent, asciiLike = true)
        }

        // For non-text data, any positive triangle count is enough to try the binary parser. The parser
        // itself enforces MAX_TRIANGLES and therefore returns a useful "too large" message when required.
        return Probe(
            if (binaryHeaderPresent) StlFormat.BINARY else StlFormat.ASCII,
            binaryHeaderPresent = binaryHeaderPresent,
            asciiLike = false
        )
    }

    private fun looksLikeAsciiStl(bytes: ByteArray, length: Int): Boolean {
        if (length <= 0) return false
        val sampleLength = min(length, 1024)
        var printable = 0
        for (i in 0 until sampleLength) {
            val value = bytes[i].toInt() and 0xff
            if (value == 9 || value == 10 || value == 13 || value in 32..126) printable++
        }
        if (printable * 100 < sampleLength * 92) return false

        val text = bytes.copyOf(sampleLength).toString(Charsets.US_ASCII).lowercase()
        val trimmed = text.trimStart('\u0000', ' ', '\t', '\r', '\n')
        return trimmed.startsWith("solid") && (text.contains("facet") || text.contains("vertex"))
    }

    private fun parseBinary(resolver: ContentResolver, uri: Uri): Mesh {
        resolver.openInputStream(uri)?.use { raw ->
            val input = BufferedInputStream(raw, 1024 * 1024)
            val header = ByteArray(80)
            readFully(input, header)
            val countBytes = ByteArray(4)
            readFully(input, countBytes)
            val triangleCount = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
            require(triangleCount in 1..MAX_TRIANGLES.toLong()) { "STL is too large for mobile import (${triangleCount} triangles)" }
            val triangles = triangleCount.toInt()

            val vertices = FloatArray(triangles * 9)
            val record = ByteArray(50)
            val b = ByteBuffer.wrap(record).order(ByteOrder.LITTLE_ENDIAN)
            var v = 0
            var minX = Float.POSITIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY
            var minZ = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY
            var maxY = Float.NEGATIVE_INFINITY
            var maxZ = Float.NEGATIVE_INFINITY

            repeat(triangles) {
                readFully(input, record)
                b.clear()
                // File normal is intentionally skipped. The renderer derives preview normals from
                // triangle vertices, while slicing only needs geometry coordinates.
                b.float; b.float; b.float

                val ax = b.float; val ay = b.float; val az = b.float
                val bx = b.float; val by = b.float; val bz = b.float
                val cx = b.float; val cy = b.float; val cz = b.float

                // Write directly into the final mesh array. Avoid a temporary FloatArray per triangle:
                // at 10M triangles even tiny per-record allocations create extreme GC pressure on Android.
                vertices[v] = ax; vertices[v + 1] = ay; vertices[v + 2] = az
                vertices[v + 3] = bx; vertices[v + 4] = by; vertices[v + 5] = bz
                vertices[v + 6] = cx; vertices[v + 7] = cy; vertices[v + 8] = cz
                v += 9

                minX = min(minX, min(ax, min(bx, cx)))
                minY = min(minY, min(ay, min(by, cy)))
                minZ = min(minZ, min(az, min(bz, cz)))
                maxX = max(maxX, max(ax, max(bx, cx)))
                maxY = max(maxY, max(ay, max(by, cy)))
                maxZ = max(maxZ, max(az, max(bz, cz)))
            }
            return Mesh(vertices, FloatArray(0), minX, minY, minZ, maxX, maxY, maxZ)
        }
        throw IllegalArgumentException("Unable to open STL")
    }

    private fun parseAscii(resolver: ContentResolver, uri: Uri): Mesh {
        val verts = FloatBuilder(262_144)
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY

        resolver.openInputStream(uri)?.use { raw ->
            BufferedReader(InputStreamReader(raw), 128 * 1024).useLines { lines ->
                lines.forEach { rawLine ->
                    val line = rawLine.trim()
                    when {
                        line.startsWith("vertex", ignoreCase = true) -> {
                            val p = line.split(Regex("\\s+"), limit = 5)
                            if (p.size >= 4) {
                                require(verts.size + 3 <= MAX_FLOATS) { "STL is too large for mobile import" }
                                val x = p[1].toFloat(); val y = p[2].toFloat(); val z = p[3].toFloat()
                                verts.add3(x,y,z)
                                minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                                maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                            }
                        }
                    }
                }
            }
        }
        require(verts.size >= 9 && verts.size % 9 == 0) { "Invalid ASCII STL" }
        return Mesh(verts.toArray(), FloatArray(0), minX, minY, minZ, maxX, maxY, maxZ)
    }

    private class FloatBuilder(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity.coerceAtLeast(16))
        var size: Int = 0
            private set
        fun add3(a: Float, b: Float, c: Float) {
            ensure(size + 3)
            data[size++] = a; data[size++] = b; data[size++] = c
        }
        private fun ensure(required: Int) {
            if (required <= data.size) return
            var next = data.size
            while (next < required) next = (next * 3 / 2 + 16).coerceAtMost(MAX_FLOATS)
            require(next >= required) { "STL is too large for mobile import" }
            data = data.copyOf(next)
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    private fun readFully(input: BufferedInputStream, bytes: ByteArray) {
        var offset = 0
        while (offset < bytes.size) {
            val n = input.read(bytes, offset, bytes.size - offset)
            if (n < 0) throw IllegalArgumentException("Unexpected end of STL")
            offset += n
        }
    }
}
