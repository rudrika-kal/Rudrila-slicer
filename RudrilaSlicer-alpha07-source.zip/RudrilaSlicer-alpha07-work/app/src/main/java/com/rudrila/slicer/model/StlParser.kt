package com.rudrila.slicer.model

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

object StlParser {
    private const val MAX_TRIANGLES = 5_000_000

    fun parse(resolver: ContentResolver, uri: Uri): Mesh {
        val isBinary = resolver.openInputStream(uri)?.use { input ->
            val buffered = BufferedInputStream(input)
            val header = ByteArray(84)
            val read = buffered.read(header)
            if (read < 84) false else {
                val count = ByteBuffer.wrap(header, 80, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
                val length = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                length > 0L && 84L + count * 50L == length
            }
        } ?: throw IllegalArgumentException("Unable to open STL")

        return if (isBinary) parseBinary(resolver, uri) else parseAscii(resolver, uri)
    }

    private fun parseBinary(resolver: ContentResolver, uri: Uri): Mesh {
        resolver.openInputStream(uri)?.use { raw ->
            val input = BufferedInputStream(raw, 1024 * 1024)
            val header = ByteArray(80)
            readFully(input, header)
            val countBytes = ByteArray(4)
            readFully(input, countBytes)
            val triangles = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).int
            require(triangles >= 0 && triangles <= MAX_TRIANGLES) { "STL triangle count is invalid or too large" }

            // Keep only geometry needed by slicing. Preview normals are generated in the GPU shader.
            // This halves heap usage for large STL files compared with Alpha 0.7.
            val vertices = FloatArray(triangles * 9)
            val record = ByteArray(50)
            val b = ByteBuffer.wrap(record).order(ByteOrder.LITTLE_ENDIAN)
            var v = 0
            var minX = Float.POSITIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY
            var minZ = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY
            var maxY = Float.NEGATIVE_INFINITY
            var maxZ = Float.NEGATIVE_INFINITY

            repeat(triangles) {
                readFully(input, record)
                b.position(12) // STL face normal is not retained; shader derives preview normals.
                repeat(3) {
                    val x = b.float
                    val y = b.float
                    val z = b.float
                    vertices[v++] = x; vertices[v++] = y; vertices[v++] = z
                    minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                    maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                }
            }
            return Mesh(vertices, FloatArray(0), minX, minY, minZ, maxX, maxY, maxZ)
        }
        throw IllegalArgumentException("Unable to open STL")
    }

    private fun parseAscii(resolver: ContentResolver, uri: Uri): Mesh {
        val verts = FloatBuilder(100_000)
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY

        resolver.openInputStream(uri)?.use { raw ->
            BufferedReader(InputStreamReader(raw), 128 * 1024).useLines { lines ->
                lines.forEach { rawLine ->
                    val line = rawLine.trim()
                    if (line.startsWith("vertex", ignoreCase = true)) {
                        val parts = line.split(Regex("\\s+"))
                        if (parts.size >= 4) {
                            val x = parts[1].toFloat(); val y = parts[2].toFloat(); val z = parts[3].toFloat()
                            verts.add(x); verts.add(y); verts.add(z)
                            require(verts.size <= MAX_TRIANGLES * 9) { "ASCII STL is too large" }
                            minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                            maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                        }
                    }
                }
            }
        }
        require(verts.size >= 9 && verts.size % 9 == 0) { "Invalid ASCII STL" }
        return Mesh(verts.toArray(), FloatArray(0), minX, minY, minZ, maxX, maxY, maxZ)
    }

    private class FloatBuilder(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity.coerceAtLeast(16))
        var size: Int = 0
            private set
        fun add(value: Float) {
            if (size == data.size) data = data.copyOf((data.size * 2).coerceAtMost(MAX_TRIANGLES * 9))
            require(size < data.size) { "STL is too large" }
            data[size++] = value
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    private fun readFully(input: BufferedInputStream, bytes: ByteArray) {
        var offset = 0
        while (offset < bytes.size) {
            val n = input.read(bytes, offset, bytes.size - offset)
            if (n < 0) throw IllegalArgumentException("Unexpected end of STL")
            offset += n
        }
    }
}
