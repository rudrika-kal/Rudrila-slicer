package com.rudrila.slicer.model

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object StlParser {
    fun parse(resolver: ContentResolver, uri: Uri): Mesh {
        val isBinary = resolver.openInputStream(uri)?.use { input ->
            val buffered = BufferedInputStream(input)
            val header = ByteArray(84)
            val read = buffered.read(header)
            if (read < 84) false else {
                val count = ByteBuffer.wrap(header, 80, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
                val length = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                length > 0L && 84L + count * 50L == length
            }
        } ?: throw IllegalArgumentException("Unable to open STL")

        return if (isBinary) parseBinary(resolver, uri) else parseAscii(resolver, uri)
    }

    private fun parseBinary(resolver: ContentResolver, uri: Uri): Mesh {
        resolver.openInputStream(uri)?.use { raw ->
            val input = BufferedInputStream(raw, 1024 * 1024)
            val header = ByteArray(80)
            readFully(input, header)
            val countBytes = ByteArray(4)
            readFully(input, countBytes)
            val triangles = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).int
            require(triangles >= 0 && triangles <= 5_000_000) { "STL triangle count is invalid or too large" }

            val vertices = FloatArray(triangles * 9)
            val normals = FloatArray(triangles * 9)
            val record = ByteArray(50)
            var v = 0
            var minX = Float.POSITIVE_INFINITY
            var minY = Float.POSITIVE_INFINITY
            var minZ = Float.POSITIVE_INFINITY
            var maxX = Float.NEGATIVE_INFINITY
            var maxY = Float.NEGATIVE_INFINITY
            var maxZ = Float.NEGATIVE_INFINITY

            repeat(triangles) {
                readFully(input, record)
                val b = ByteBuffer.wrap(record).order(ByteOrder.LITTLE_ENDIAN)
                var nx = b.float
                var ny = b.float
                var nz = b.float
                val p = FloatArray(9)
                for (i in 0 until 9) p[i] = b.float

                if (nx == 0f && ny == 0f && nz == 0f) {
                    val computed = faceNormal(p)
                    nx = computed[0]; ny = computed[1]; nz = computed[2]
                }

                for (i in 0 until 3) {
                    val x = p[i * 3]
                    val y = p[i * 3 + 1]
                    val z = p[i * 3 + 2]
                    vertices[v] = x; vertices[v + 1] = y; vertices[v + 2] = z
                    normals[v] = nx; normals[v + 1] = ny; normals[v + 2] = nz
                    minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                    maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                    v += 3
                }
            }
            return Mesh(vertices, normals, minX, minY, minZ, maxX, maxY, maxZ)
        }
        throw IllegalArgumentException("Unable to open STL")
    }

    private fun parseAscii(resolver: ContentResolver, uri: Uri): Mesh {
        val verts = ArrayList<Float>(100_000)
        val norms = ArrayList<Float>(100_000)
        var currentNormal = floatArrayOf(0f, 0f, 1f)
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY

        resolver.openInputStream(uri)?.use { raw ->
            BufferedReader(InputStreamReader(raw), 128 * 1024).useLines { lines ->
                lines.forEach { rawLine ->
                    val line = rawLine.trim()
                    when {
                        line.startsWith("facet normal", ignoreCase = true) -> {
                            val p = line.split(Regex("\\s+"))
                            if (p.size >= 5) currentNormal = floatArrayOf(p[2].toFloat(), p[3].toFloat(), p[4].toFloat())
                        }
                        line.startsWith("vertex", ignoreCase = true) -> {
                            val p = line.split(Regex("\\s+"))
                            if (p.size >= 4) {
                                val x = p[1].toFloat(); val y = p[2].toFloat(); val z = p[3].toFloat()
                                verts.add(x); verts.add(y); verts.add(z)
                                norms.add(currentNormal[0]); norms.add(currentNormal[1]); norms.add(currentNormal[2])
                                minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                                maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                            }
                        }
                    }
                }
            }
        }
        require(verts.size >= 9 && verts.size % 9 == 0) { "Invalid ASCII STL" }
        return Mesh(verts.toFloatArray(), norms.toFloatArray(), minX, minY, minZ, maxX, maxY, maxZ)
    }

    private fun readFully(input: BufferedInputStream, bytes: ByteArray) {
        var offset = 0
        while (offset < bytes.size) {
            val n = input.read(bytes, offset, bytes.size - offset)
            if (n < 0) throw IllegalArgumentException("Unexpected end of STL")
            offset += n
        }
    }

    private fun faceNormal(p: FloatArray): FloatArray {
        val ax = p[3] - p[0]; val ay = p[4] - p[1]; val az = p[5] - p[2]
        val bx = p[6] - p[0]; val by = p[7] - p[1]; val bz = p[8] - p[2]
        var nx = ay * bz - az * by
        var ny = az * bx - ax * bz
        var nz = ax * by - ay * bx
        val len = sqrt(nx * nx + ny * ny + nz * nz)
        if (len > 1e-8f) { nx /= len; ny /= len; nz /= len }
        return floatArrayOf(nx, ny, nz)
    }
}
