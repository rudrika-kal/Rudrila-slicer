package com.rudrila.slicer.render

import android.opengl.GLES30

object GlUtil {
    fun createProgram(vertexShader: String, fragmentShader: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertexShader)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragmentShader)
        val program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)
        val link = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) throw RuntimeException(GLES30.glGetProgramInfoLog(program))
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
        return program
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException(GLES30.glGetShaderInfoLog(shader))
        return shader
    }
}
