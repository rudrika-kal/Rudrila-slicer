package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import com.rudrila.slicer.model.*
import kotlin.math.max
import kotlin.math.min

/** Lightweight top-down layer preview. It draws only one layer at a time to keep memory/GPU work bounded on phones. */
class ToolpathPreviewView(context: Context): View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=2f;strokeCap=Paint.Cap.ROUND}
    private var result:ToolpathResult?=null
    var layerIndex:Int=0
        set(value){field=value.coerceIn(0,(result?.layers?.lastIndex?:0).coerceAtLeast(0));invalidate()}

    fun setResult(value:ToolpathResult){result=value;layerIndex=0;invalidate()}

    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas);canvas.drawColor(Color.rgb(16,18,20))
        val r=result?:return;val layer=r.layers.getOrNull(layerIndex)?:return
        val pts=layer.paths.flatMap{it.points};if(pts.isEmpty())return
        val minX=pts.minOf{it.x};val maxX=pts.maxOf{it.x};val minY=pts.minOf{it.y};val maxY=pts.maxOf{it.y}
        val spanX=max(1f,maxX-minX);val spanY=max(1f,maxY-minY);val pad=24f
        val scale=min((width-2*pad)/spanX,(height-2*pad)/spanY).coerceAtLeast(0.01f)
        fun sx(x:Float)=pad+(x-minX)*scale
        fun sy(y:Float)=height-pad-(y-minY)*scale
        for(path in layer.paths){
            paint.color=when(path.role){
                PathRole.WALL->Color.rgb(61,210,155)
                PathRole.SOLID->Color.rgb(255,176,74)
                PathRole.INFILL->Color.rgb(91,158,255)
                PathRole.SUPPORT,PathRole.SUPPORT_INTERFACE->Color.rgb(210,120,255)
                PathRole.BRIM->Color.rgb(230,230,230)
            }
            paint.strokeWidth=if(path.role==PathRole.WALL)2.4f else 1.6f
            for(i in 1 until path.points.size){val a=path.points[i-1];val b=path.points[i];canvas.drawLine(sx(a.x),sy(a.y),sx(b.x),sy(b.y),paint)}
        }
    }
}
