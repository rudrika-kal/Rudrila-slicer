package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.rudrila.slicer.model.*
import kotlin.math.max
import kotlin.math.min

/**
 * Mobile layer preview for Slice Engine V2.
 *
 * - stable plate/global framing between layers
 * - pinch zoom + one-finger pan
 * - role filtering and optional travel visualization
 * - one selected layer is drawn at a time so dense jobs stay bounded on phones
 */
class ToolpathPreviewView(context: Context): View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
    private val travelPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
        style=Paint.Style.STROKE;strokeWidth=1.1f;color=Color.rgb(110,118,124);pathEffect=DashPathEffect(floatArrayOf(8f,7f),0f)
    }
    private val bedPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=1.4f;color=Color.rgb(65,72,77)}
    private val gridPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=0.7f;color=Color.rgb(38,43,47)}

    private var result:ToolpathResult?=null
    private val visibleRoles=PathRole.values().toMutableSet()
    var showTravel:Boolean=false
        set(value){field=value;invalidate()}
    var layerIndex:Int=0
        set(value){field=value.coerceIn(0,(result?.layers?.lastIndex?:0).coerceAtLeast(0));invalidate()}

    private var bedX=256f
    private var bedY=256f
    private var minX=-128f
    private var maxX=128f
    private var minY=-128f
    private var maxY=128f
    private var zoom=1f
    private var panX=0f
    private var panY=0f
    private var lastX=0f
    private var lastY=0f
    private var dragging=false

    private val scaleDetector=ScaleGestureDetector(context,object:ScaleGestureDetector.SimpleOnScaleGestureListener(){
        override fun onScale(detector:ScaleGestureDetector):Boolean{
            zoom=(zoom*detector.scaleFactor).coerceIn(0.6f,12f)
            invalidate();return true
        }
    })

    fun setBedSize(x:Float,y:Float){bedX=x.coerceAtLeast(1f);bedY=y.coerceAtLeast(1f);recomputeBounds();invalidate()}

    fun setResult(value:ToolpathResult){result=value;layerIndex=0;resetCamera();recomputeBounds();invalidate()}

    fun setRoleVisible(role:PathRole,visible:Boolean){if(visible)visibleRoles+=role else visibleRoles-=role;invalidate()}

    fun resetCamera(){zoom=1f;panX=0f;panY=0f;invalidate()}

    private fun recomputeBounds(){
        // Always include the physical bed so switching layers never changes the apparent scale.
        minX=-bedX/2f;maxX=bedX/2f;minY=-bedY/2f;maxY=bedY/2f
        result?.layers?.forEach { layer ->
            layer.paths.forEach { path -> path.points.forEach { p ->
                if(p.x<minX)minX=p.x;if(p.x>maxX)maxX=p.x;if(p.y<minY)minY=p.y;if(p.y>maxY)maxY=p.y
            }}
        }
    }

    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas);canvas.drawColor(Color.rgb(16,18,20))
        val r=result?:return
        val layer=r.layers.getOrNull(layerIndex)?:return
        val spanX=max(1f,maxX-minX);val spanY=max(1f,maxY-minY);val pad=22f
        val baseScale=min((width-2*pad)/spanX,(height-2*pad)/spanY).coerceAtLeast(0.01f)
        val scale=baseScale*zoom
        val cx=(minX+maxX)*0.5f;val cy=(minY+maxY)*0.5f
        fun sx(x:Float)=width*0.5f+(x-cx)*scale+panX
        fun sy(y:Float)=height*0.5f-(y-cy)*scale+panY

        // Bed + 20 mm grid.
        var gx=-bedX/2f
        while(gx<=bedX/2f+0.01f){canvas.drawLine(sx(gx),sy(-bedY/2f),sx(gx),sy(bedY/2f),gridPaint);gx+=20f}
        var gy=-bedY/2f
        while(gy<=bedY/2f+0.01f){canvas.drawLine(sx(-bedX/2f),sy(gy),sx(bedX/2f),sy(gy),gridPaint);gy+=20f}
        canvas.drawRect(sx(-bedX/2f),sy(bedY/2f),sx(bedX/2f),sy(-bedY/2f),bedPaint)

        var previousEnd:Point2?=null
        for(path in layer.paths){
            if(path.points.size<2)continue
            if(showTravel){
                val start=path.points.first();val prev=previousEnd
                if(prev!=null){canvas.drawLine(sx(prev.x),sy(prev.y),sx(start.x),sy(start.y),travelPaint)}
            }
            if(path.role in visibleRoles){
                paint.color=roleColor(path.role)
                paint.strokeWidth=when(path.role){
                    PathRole.WALL->2.6f
                    PathRole.SOLID,PathRole.GAP_FILL->2.0f
                    PathRole.INFILL->1.6f
                    PathRole.SUPPORT,PathRole.SUPPORT_INTERFACE->1.7f
                    PathRole.BRIM->1.8f
                }
                for(i in 1 until path.points.size){val a=path.points[i-1];val b=path.points[i];canvas.drawLine(sx(a.x),sy(a.y),sx(b.x),sy(b.y),paint)}
            }
            previousEnd=path.points.last()
        }
    }

    private fun roleColor(role:PathRole)=when(role){
        PathRole.WALL->Color.rgb(62,220,166)
        PathRole.SOLID->Color.rgb(255,178,73)
        PathRole.GAP_FILL->Color.rgb(255,221,92)
        PathRole.INFILL->Color.rgb(88,155,255)
        PathRole.SUPPORT->Color.rgb(197,112,255)
        PathRole.SUPPORT_INTERFACE->Color.rgb(235,135,255)
        PathRole.BRIM->Color.rgb(226,230,232)
    }

    override fun onTouchEvent(event:MotionEvent):Boolean{
        scaleDetector.onTouchEvent(event)
        when(event.actionMasked){
            MotionEvent.ACTION_DOWN->{lastX=event.x;lastY=event.y;dragging=true;parent?.requestDisallowInterceptTouchEvent(true)}
            MotionEvent.ACTION_MOVE->{
                if(dragging&&!scaleDetector.isInProgress){panX+=event.x-lastX;panY+=event.y-lastY;invalidate()}
                lastX=event.x;lastY=event.y
            }
            MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{dragging=false;parent?.requestDisallowInterceptTouchEvent(false)}
        }
        return true
    }
}
