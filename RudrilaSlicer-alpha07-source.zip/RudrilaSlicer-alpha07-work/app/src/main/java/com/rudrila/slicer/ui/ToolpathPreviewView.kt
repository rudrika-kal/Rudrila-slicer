package com.rudrila.slicer.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.view.View
import com.rudrila.slicer.model.*
import kotlin.math.max
import kotlin.math.min

/**
 * Mobile top-down layer preview. Only one layer is drawn at a time, keeping RAM/GPU use bounded.
 * Slice Engine V2 additionally exposes travel moves and explicit path roles.
 */
class ToolpathPreviewView(context: Context): View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=2f;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND}
    private val travelPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
        style=Paint.Style.STROKE;strokeWidth=1.2f;strokeCap=Paint.Cap.ROUND;color=Color.rgb(100,110,118);pathEffect=DashPathEffect(floatArrayOf(6f,6f),0f)
    }
    private var result:ToolpathResult?=null
    var showTravel:Boolean=true
        set(value){field=value;invalidate()}
    var layerIndex:Int=0
        set(value){field=value.coerceIn(0,(result?.layers?.lastIndex?:0).coerceAtLeast(0));invalidate()}

    fun setResult(value:ToolpathResult){result=value;layerIndex=0;invalidate()}

    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas);canvas.drawColor(Color.rgb(16,18,20))
        val r=result?:return;val layer=r.layers.getOrNull(layerIndex)?:return
        val pts=layer.paths.flatMap{it.points};if(pts.isEmpty())return
        val minX=pts.minOf{it.x};val maxX=pts.maxOf{it.x};val minY=pts.minOf{it.y};val maxY=pts.maxOf{it.y}
        val spanX=max(1f,maxX-minX);val spanY=max(1f,maxY-minY);val pad=24f
        val scale=min((width-2*pad)/spanX,(height-2*pad)/spanY).coerceAtLeast(0.01f)
        fun sx(x:Float)=pad+(x-minX)*scale
        fun sy(y:Float)=height-pad-(y-minY)*scale

        if(showTravel){
            for(move in layer.travelMoves){
                for(i in 1 until move.size){val a=move[i-1];val b=move[i];canvas.drawLine(sx(a.x),sy(a.y),sx(b.x),sy(b.y),travelPaint)}
            }
        }
        for(path in layer.paths){
            paint.color=when(path.role){
                PathRole.OUTER_WALL->Color.rgb(55,225,165)
                PathRole.INNER_WALL->Color.rgb(65,175,235)
                PathRole.TOP_SURFACE->Color.rgb(255,190,76)
                PathRole.BOTTOM_SURFACE->Color.rgb(255,135,78)
                PathRole.GAP_FILL->Color.rgb(248,112,170)
                PathRole.INFILL->Color.rgb(105,145,255)
                PathRole.SUPPORT->Color.rgb(195,115,255)
                PathRole.SUPPORT_INTERFACE->Color.rgb(228,145,255)
                PathRole.BRIM->Color.rgb(230,230,230)
                PathRole.WALL->Color.rgb(61,210,155)
                PathRole.SOLID->Color.rgb(255,176,74)
            }
            paint.strokeWidth=when(path.role){
                PathRole.OUTER_WALL->2.8f
                PathRole.INNER_WALL,PathRole.WALL->2.2f
                else->1.7f
            }
            for(i in 1 until path.points.size){val a=path.points[i-1];val b=path.points[i];canvas.drawLine(sx(a.x),sy(a.y),sx(b.x),sy(b.y),paint)}
        }
    }
}
