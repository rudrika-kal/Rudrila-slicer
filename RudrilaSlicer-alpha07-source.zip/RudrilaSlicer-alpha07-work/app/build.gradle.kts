plugins {
    id("com.android.application")
}

android {
    namespace = "com.rudrila.slicer"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.rudrila.slicer"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.8.2-alpha8-stlfix2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

}
