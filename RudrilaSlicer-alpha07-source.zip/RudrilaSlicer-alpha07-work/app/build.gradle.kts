plugins {
    id("com.android.application")
}

android {
    namespace = "com.rudrila.slicer"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.rudrila.slicer"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "0.8.4-alpha8-10m"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

}
