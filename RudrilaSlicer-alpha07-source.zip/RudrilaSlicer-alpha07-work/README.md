# Rudrila Slicer — Android Alpha 0.8

Native Android mobile-first 3D-print workspace and offline slicer prototype.

## End-to-end flow implemented
1. Import STL or multi-object 3MF.
2. Select, move, rotate, scale, lay face, duplicate/delete, center, place on bed and auto-arrange models.
3. Select printer / filament / process settings; edit infill, supports (Tree/Normal) and brim.
4. Slice manifold mesh geometry into horizontal closed contours.
5. Generate perimeter/wall paths, bottom/top solid skin, infill, support paths and brim.
6. Apply filament volumetric-flow speed caps.
7. Calculate extrusion volume, filament length/grams and a conservative print-time estimate.
8. Preview one layer at a time with a mobile layer slider and color-coded path roles.
9. Export generic G-code through Android's document picker. G-code is streamed directly to storage to avoid holding a large file in RAM.


## Alpha 0.8 import crash hardening
- Import parsing remains off the UI thread, but parsed meshes are now committed to the scene on the UI thread.
- Binary STL detection accepts common trailing-byte variants instead of relying on exact file length.
- ASCII STL uses a primitive float buffer instead of boxed `Float` lists.
- STL/3MF imports have explicit complexity and invalid-coordinate guards so oversized or malformed models fail with a message instead of exhausting memory.
- Mesh normals are no longer duplicated in app memory; the OpenGL ES 3 preview derives flat face normals in the shader.
- Very dense models are decimated only for viewport preview, while full geometry remains available to the slicer.
- Ray-picking work is bounded on huge models to avoid long UI stalls.
- Android `largeHeap` is enabled because slicing and 3D mesh inspection are memory-intensive workloads.

## Mobile-flow protections
- Slicing runs off the UI thread.
- Any geometry/profile edit invalidates the previous slice so stale G-code cannot be exported accidentally.
- Open contour warnings block G-code export.
- Toolpaths are translated from a centered workspace to machine bed coordinates.
- Any G-code point outside the selected printer bed blocks export.
- Support raster uses an adaptive compact boolean grid with bounded resolution instead of object-heavy per-cell sets.
- Travel paths use a lightweight nearest-neighbour ordering.

## Alpha 0.8 geometry/toolpath implementation
- Multi-wall mitered polygon offsets
- Even/odd clipped line fill (preserves holes)
- Bottom/top solid fill
- Grid / alternating diagonal infill foundation
- Normal support columns
- Tree-support foundation with gradual branch merging
- Brim rings
- Volumetric speed cap from filament profile
- Relative-extrusion G-code emission
- Streaming G-code writer
- Top-down mobile layer preview

## Double-check verification
The following JVM suites were run twice after the slicing-core changes:
- Scene/transform/lay-face: PASS ×2
- Contour slicing: PASS ×2
- Profile validation: PASS ×2
- Multi-object 3MF: PASS ×2
- Toolpath + G-code: PASS ×2

The toolpath suite checks walls, solid skin, infill, holes, normal/tree support generation, brim, volumetric flow caps, filament/time estimates, G-code content, centered-to-bed coordinate conversion, out-of-bed export blocking and open-contour export blocking.

## Important release status
Alpha 0.8 is not yet a production-certified replacement for Bambu Studio / OrcaSlicer. The end-to-end offline flow exists, but release quality still requires:
- Android SDK compile + signed APK build.
- Real-device GPU/touch/performance testing.
- Large STL/3MF stress corpus and malformed-mesh repair tests.
- Robust industrial polygon boolean/offset engine for pathological self-intersections and very complex holes.
- Bridge detection, gap fill, adaptive wall ordering, seam control, retraction/pressure advance and printer-flavor-specific start/end G-code.
- Comparison of generated toolpaths/G-code against a trusted desktop slicer before using exports for real printing.

The current G-code header/start/end sequence is generic and should not be treated as a verified Bambu-printer profile until device-specific G-code is validated.

## Toolchain target
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin 2.4.20
- compileSdk / targetSdk 36
- minSdk 26
