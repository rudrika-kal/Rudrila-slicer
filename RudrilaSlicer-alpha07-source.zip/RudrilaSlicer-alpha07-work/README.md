# Rudrila Slicer Alpha 0.11

Mobile-first Android slicer prototype. Alpha 0.11 focuses on the real-device viewport and manipulation issues reported after Alpha 0.10.

## Alpha 0.11 viewport changes
- Full triangle surface is streamed to a GPU VBO for meshes up to 3.5 million triangles, including the reported 3,066,808-triangle STL.
- Upload is chunked so the renderer does not retain another full-size direct copy of the STL.
- Duplicate objects reuse one GPU mesh when they share the same source mesh.
- Double-sided STL rendering avoids holes from inconsistent triangle winding.
- Camera fit uses the complete plate bounds, not only each object's individual size.
- In VIEW mode: drag a model directly to move it; drag empty space to orbit; pinch to zoom; two-finger drag pans.
- Direct movement is constrained to the 256 mm plate.
- Duplicate placement avoids overlap when space is available.

The slicing core, 3MF import, toolpaths, estimates, preview, G-code export, stale-slice invalidation, open-contour gate and out-of-bed gate remain from earlier alphas.

Generic G-code is still a prototype and is not verified as production-safe for Bambu printers.
