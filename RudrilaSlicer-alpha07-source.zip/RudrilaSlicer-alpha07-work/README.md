# Rudrila Slicer Alpha 0.10

Startup-hotfix build after Alpha 0.9. Fixes the OpenGL grid vertex shader that referenced an undefined variable (`world`) and could crash the GL render thread immediately on launch. Shader initialization is now fail-soft, stale profile preferences fall back to defaults, and the large-model memory protections from Alpha 0.9 remain enabled.

Important: generic G-code output is still alpha and is not verified for direct Bambu printer use.
