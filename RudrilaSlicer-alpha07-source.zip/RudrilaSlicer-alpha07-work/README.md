# Rudrila Slicer Alpha 0.9

Mobile-first Android slicer prototype. Alpha 0.9 focuses on large-model stability: bounded-memory exact contour slicing, streaming no-support toolpath planning, faster camera fitting/object selection, and safe failure instead of process death when an unsupported memory-heavy mode is requested.

Important: generic G-code output is still alpha and is not verified for direct Bambu printer use.
