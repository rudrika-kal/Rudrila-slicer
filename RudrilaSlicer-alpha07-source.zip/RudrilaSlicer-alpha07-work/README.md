# Rudrila Slicer — Android Alpha 0.7

Native Android mobile-first 3D-print workspace and offline slicer prototype.

## End-to-end flow implemented
1. Import STL or multi-object 3MF.
2. Select, move, rotate, scale, lay face, duplicate/delete, center, place on bed and auto-arrange models.
3. Select printer / filament / process settings; edit infill, supports (Tree/Normal) and brim.
4. Slice manifold mesh geometry into horizontal closed contours.
5. Generate perimeter/wall paths, bottom/top solid skin, infill, support paths and brim.
6. Apply filament volumetric-flow speed caps.
7. Calculate extrusion volume, filament length/grams and a conservative print-time estimate.
8. Preview one layer at a time with a mobile layer slider and color-coded path roles.
9. Export generic G-code through Android's document picker. G-code is streamed directly to storage to avoid holding a large file in RAM.

## Mobile-flow protections
- Slicing runs off the UI thread.
- Any geometry/profile edit invalidates the previous slice so stale G-code cannot be exported accidentally.
- Open contour warnings block G-code export.
- Toolpaths are translated from a centered workspace to machine bed coordinates.
- Any G-code point outside the selected printer bed blocks export.
- Support raster uses an adaptive compact boolean grid with bounded resolution instead of object-heavy per-cell sets.
- Travel paths use a lightweight nearest-neighbour ordering.

## Alpha 0.7 geometry/toolpath implementation
- Multi-wall mitered polygon offsets
- Even/odd clipped line fill (preserves holes)
- Bottom/top solid fill
- Grid / alternating diagonal infill foundation
- Normal support columns
- Tree-support foundation with gradual branch merging
- Brim rings
- Volumetric speed cap from filament profile
- Relative-extrusion G-code emission
- Streaming G-code writer
- Top-down mobile layer preview

## Double-check verification
The following JVM suites were run twice after the Alpha 0.7 changes:
- Scene/transform/lay-face: PASS ×2
- Contour slicing: PASS ×2
- Profile validation: PASS ×2
- Multi-object 3MF: PASS ×2
- Toolpath + G-code: PASS ×2

The toolpath suite checks walls, solid skin, infill, holes, normal/tree support generation, brim, volumetric flow caps, filament/time estimates, G-code content, centered-to-bed coordinate conversion, out-of-bed export blocking and open-contour export blocking.

## Important release status
Alpha 0.7 is not yet a production-certified replacement for Bambu Studio / OrcaSlicer. The end-to-end offline flow exists, but release quality still requires:
- Android SDK compile + signed APK build.
- Real-device GPU/touch/performance testing.
- Large STL/3MF stress corpus and malformed-mesh repair tests.
- Robust industrial polygon boolean/offset engine for pathological self-intersections and very complex holes.
- Bridge detection, gap fill, adaptive wall ordering, seam control, retraction/pressure advance and printer-flavor-specific start/end G-code.
- Comparison of generated toolpaths/G-code against a trusted desktop slicer before using exports for real printing.

The current G-code header/start/end sequence is generic and should not be treated as a verified Bambu-printer profile until device-specific G-code is validated.

## Toolchain target
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Kotlin 2.4.20
- compileSdk / targetSdk 36
- minSdk 26

## Alpha 0.8 mobile hotfix
- Imported selection is centered on the build plate and the camera re-fits to the actual scene center.
- STL import uses bounded primitive buffers and a mobile triangle guard to reduce force-closes.
- OpenGL preview is capped/sampled for very dense meshes while the full mesh remains available to the slicer core.

## Alpha 0.8.1 import hotfix
- Fixes binary STL detection when Android SAF providers report unknown file length.
- Adds STL/3MF content fallback when a provider hides the extension.
- Parses in background and mutates the scene only on the UI thread.
- Keeps imported selection centered/on-bed and auto-fits camera.
- Shows the real import error instead of silently appearing to do nothing.

## Alpha 0.8.4: 10M-triangle STL import gate
- Binary STL import cap: 10,000,000 triangles.
- Exact binary mesh keeps XYZ only (~360 MB at 10M triangles); file normals are not duplicated.
- Binary parser writes directly into the final vertex array to avoid 10M temporary per-triangle arrays / GC churn.
- OpenGL preview remains sampled/bounded to 250,000 triangles; exact geometry stays available to model operations.
- Import no longer performs a redundant second full-mesh place-on-bed scan after centering.
- `android:largeHeap=true` remains required for multi-million-triangle exact meshes. Actual success still depends on device heap capacity; low-memory devices can reject/close under OS memory pressure.

### Alpha 0.8.5 update
- Solid dense-model preview: full-surface vertex clustering replaces sparse triangle stride preview.
- Two-sided shaded STL rendering for mixed triangle winding.
- Selected object row shows X/Y/Z size in mm.
- SIZE dialog supports proportional resizing by entering any physical X, Y, or Z dimension.


### Alpha 0.8.8 — independent XYZ sizing
The SIZE dialog now has a **Lock proportions** switch. Keep it on for uniform Bambu-style resizing, or turn it off to enter X, Y and Z dimensions independently in millimetres. Rendering, bounds, picking, bed placement and slicing use the same per-axis transform.

## Slice Engine V2 — Step 1 foundation

- robust neighbour-cell contour stitching (avoids false opens at hash-cell boundaries)
- zero-length and duplicate section segment cleanup
- explicit nested contour classification (outer / hole / island)
- normalized outer CCW / hole CW orientation
- hole-aware wall offset direction so perimeters are generated into printable material
- open contours remain a hard G-code export safety gate; they are never silently auto-closed
- geometry cleanup diagnostics are shown after slicing

This is the first production-slicing milestone. It improves contour correctness and wall topology; it is not yet a claim of Bambu Studio parity.
